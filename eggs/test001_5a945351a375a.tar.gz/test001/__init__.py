import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)
while 1:
  ugfx.input_attach(ugfx.JOY_UP, lambda pressed: ugfx.string(100, 100, pressed, "Roboto_Regular18", ugfx.WHITE))
  ugfx.flush()