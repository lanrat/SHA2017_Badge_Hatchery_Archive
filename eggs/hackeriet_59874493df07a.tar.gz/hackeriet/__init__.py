import badge, ugfx, appglue, time

name = badge.nvs_get_str('owner', 'name', 'n00b')
should_exit = False

def button_press():
  global should_exit
  should_exit = True

def program_main():
  try:
    badge.eink_png(0, 0, '/lib/hackeriet/hackeriet.png')
  except:
    ugfx.string(0, 0, 'Failed to load graphixxx', 'Roboto_Regular12', ugfx.BLACK)
  
  ugfx.string(int(ugfx.width()/2), ugfx.height()-12, 'Roboto_Black12', 'Press B to exit', ugfx.BLACK)
  ugfx.string(177, 25, name, 'Roboto_Black16', ugfx.BLACK)
  ugfx.flush()
  
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: button_press(pressed))

  # Try to save some battery
  while True:
    if (should_exit):
      appglue.start_app('')
    else:
      time.sleep(5000)

program_main()