import ugfx, badge, appglue, utime
import deepsleep

def clearGhosting():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    badge.eink_busy_wait()
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()


ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

duckList = ['UPRIGHT', 'FLAT', 'THIRD WAY']
duckSet = set(duckList)

clearGhosting()
ugfx.clear(ugfx.WHITE)
#ugfx.string(25,20,'Found','Roboto_Regular18',ugfx.BLACK)
#ugfx.string(40,40,str(len(ssidSet)),'Roboto_Regular18',ugfx.BLACK)
#ugfx.string(10,60,'Networks','Roboto_Regular18',ugfx.BLACK)
options = ugfx.List(ugfx.width()-int(ugfx.width()/1.5),0,int(ugfx.width()/1.5),ugfx.height())
#options = ugfx.List(ugfx.width(),0,ugfx.width(),ugfx.height())

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
for duck in duckSet:
    options.add_item(duck)

def upright():
    badge.leds_enable()
    badge.leds_send_data(bytes([0, 0, 255, 0,
                            0, 0, 255, 0,
                            0, 0, 255, 0,
                            0, 0, 255, 0,
                            0, 0, 255, 0,
                            0, 0, 255, 0]), 24)
    badge.eink_png(0,0,'/lib/ducktype/Upright.png')
    nick = badge.nvs_get_str("owner", "name", "DEFAULT")
    ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush(ugfx.LUT_FULL)
    badge.eink_busy_wait()
    deepsleep.start_sleeping(60000)

def flat():
    badge.leds_enable()
    badge.leds_send_data(bytes([0, 255, 0, 0,
                            0, 255, 0, 0,
                            0, 255, 0, 0,
                            0, 255, 0, 0,
                            0, 255, 0, 0,
                            0, 255, 0, 0]), 24)
    badge.eink_png(0,0,'/lib/ducktype/Flat.png')
    nick = badge.nvs_get_str("owner", "name", "DEFAULT")
    ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush(ugfx.LUT_FULL)
    badge.eink_busy_wait()
    deepsleep.start_sleeping(60000)

def dominic():
    badge.vibrator_init()
    badge.leds_enable()

    while 1:
        badge.leds_send_data(bytes([0, 0, 0, 0,
                            255, 0, 0, 0,
                            0, 0, 0, 0,
                            255, 0, 0, 0,
                            0, 0, 0, 0,
                            255, 0, 0, 0]), 24)
        badge.eink_png(0,0,'/lib/ducktype/DOMINIC_1.png')
        ugfx.flush()
        badge.vibrator_activate(0x01)
        badge.leds_send_data(bytes([0, 255, 0, 0,
                            0, 0, 0, 0,
                            0, 255, 0, 0,
                            0, 0, 0, 0,
                            0, 255, 0, 0,
                            0, 0, 0, 0]), 24)
        badge.eink_png(0,0,'/lib/ducktype/DOMINIC_2.png')
        badge.vibrator_activate(0x01)
        ugfx.flush()

def select_duck(pushed):
    if(pushed):
        selected = options.selected_index()
        print('selected')
        options.destroy()
        if(selected == 0):
            upright()
        if(selected == 1):
            dominic()
        if(selected == 2):
            flat()

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, select_duck)
ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else 0)
ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else 0)

ugfx.set_lut(ugfx.LUT_FULL)
ugfx.flush()
ugfx.set_lut(ugfx.LUT_FASTER)
#badge.eink_png(0,0,'/lib/ducktype/DOMINIC_1.png')
#badge.eink_png(0,0,'/lib/ducktype/DOMINIC_2.png')
ugfx.flush()