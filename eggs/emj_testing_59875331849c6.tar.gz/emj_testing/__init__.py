### Author: Mattsi Jansky
### Heavily modified from Sam Delaney and Sebastius' Game of Life app.
### Description: A dungeon crawler for SHA 2017's badge
### Category: Games
### License: MIT
### Appname: GoL
### Built-in: no

import badge
import ugfx
import urandom
import deepsleep
from random import randint

MSG_INTERACT = "interact"
STUFF_SOURCE = "source"
STUFF_TARGET = "target"

class Position:
	
	def __init__(self, x, y):
		self.x = x
		self.y = y
		
	def add(self,x,y):
		return Position(self.x + x, self.y + y)

class Message:
	
	def __init__(self, name):
		self.name = name
		self.stuff = []

class Entity:
	
	def __init__(self, render, name, position):
		self.render = render
		self.name = name
		self.position = position
		self.components = []

class Component:
	
	def recieve(msg) : raise NotImplementedError

class CharacterComponent(Component):
	
	def recieve(msg):
		return None

class Tile:
	
	def __init__(self, render):
		self.render = render
		self.entity = None
	
	def __str__(self):
		if(self.entity is not None):
			return self.entity.render
		else:
			return self.render

#### globals
width = 36
height = 7
cell_width = 8
cell_height = 12
grid = [[Tile('.') for x in range(height)] for y in range(width)]
player = Entity('@','player',Position(1,1))
player.components.append(CharacterComponent())
grid[1][1].entity = player
mobs = []
console = []

def interact(source,target):
	msg = Message(MSG_INTERACT)
	msg.stuff[STUFF_SOURCE] = source
	msg.stuff[STUFF_TARGET] = target
	source.recieve(msg)

class Manipulator:
	
	def move(self,entity,position):
		origin = grid[entity.position.x][entity.position.y]
		target = grid[position.x][position.y]
		if(origin.Entity is None):
			origin.entity = None
			target.entity = entity
			entity.position = position
		else:
			interact(entity, target.entity)

manipulator = Manipulator()	

def log(message):
	if(len(message) < 36):
		console.append(message)
	if(len(console) > 3):
		del console[0]

def makemob(position):
	mob = Entity('s', 'skeleton', position)
	mob.components.append(CharacterComponent())
	mobs.append(mob)
	return mob

def randomise():
	for i in range(randint(5,15)):
		pos = Position(randint(0,width-1),randint(0,height-1))
		if(grid[pos.x][pos.y].entity is None):
			grid[pos.x][pos.y].entity = makemob(pos)
			
def moveMob(entity):
	direction = 1
	if(randint(0,1) == 0):
		direction = -direction
	if(randint(0,1) == 0):
		manipulator.move(entity,entity.position.add(direction,0))
	else:
		manipulator.move(entity,entity.position.add(0,direction))

def updateGame():
	for mob in mobs:
		moveMob(mob)

def left(pressed):
	if(pressed): 
		manipulator.move(player,player.position.add(-1,0))
		updateGame()
	
def right(pressed):
	if(pressed): 
		manipulator.move(player,player.position.add(1,0))
		updateGame()
	
def up(pressed):
	if(pressed): 
		manipulator.move(player,player.position.add(0,-1))
		updateGame()
	
def down(pressed):
	if(pressed): 
		manipulator.move(player,player.position.add(0,1))
		updateGame()
	
def emj_test():
	badge.eink_init()
	ugfx.init()
	ugfx.input_init()
	ugfx.input_attach(ugfx.JOY_RIGHT, right)
	ugfx.input_attach(ugfx.JOY_LEFT, left)
	ugfx.input_attach(ugfx.JOY_UP, up)
	ugfx.input_attach(ugfx.JOY_DOWN, down)
	#ugfx.input_attach(ugfx.BTN_A, reboot)
	#ugfx.input_attach(ugfx.BTN_B, reboot)
	ugfx.input_attach(ugfx.BTN_START, reboot)
	#ugfx.input_attach(ugfx.BTN_SELECT, reboot)
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	randomise()
	
	def display():
		#main screen
		ugfx.clear(ugfx.WHITE)
		for x in range(0, width):
			for y in range(0, height):
				ugfx.text(x * cell_width,y * cell_height,str(grid[x][y]),ugfx.BLACK)
		#console
		ugfx.line(0,height * cell_height + 1, width * cell_width, height * cell_height + 1, ugfx.BLACK)
		for index, msg in enumerate(console):
			ugfx.text(0,height * cell_height + 1 + index * cell_height, msg, ugfx.BLACK)
		
		badge.eink_busy_wait()
		ugfx.flush()

	while True:
		display()

def reboot(wut):
	deepsleep.reboot()

emj_test()