import ugfx
import badge
import appglue

ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)

nick = badge.nvs_get_str('owner', 'name')


ugfx.area(10,10,32,32,ugfx.BLACK)

ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)
ugfx.string(16,45,nick,"Roboto_Black22",ugfx.BLACK)

ugfx.flush()

def render(pushed):
    if(pushed):
        ugfx.clear(ugfx.BLACK)
        ugfx.area(10,10,32,32,ugfx.WHITE)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.BLACK)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.WHITE)
        ugfx.string(16,45,nick,"Roboto_Black22",ugfx.WHITE)
    else:
        ugfx.clear(ugfx.WHITE)
        ugfx.area(10,10,32,32,ugfx.BLACK)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)
        ugfx.string(16,45,nick,"Roboto_Black22",ugfx.BLACK)

    ugfx.flush()
    
def buzz(buzz, pushed):
    if(pushed):
		badge.vibrator_activate(buzz)

def home(pressed):
  if pressed:
    appglue.home()


ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, render)
ugfx.input_attach(ugfx.JOY_DOWN, render)
ugfx.input_attach(ugfx.JOY_LEFT, render)
ugfx.input_attach(ugfx.JOY_RIGHT, render)
ugfx.input_attach(ugfx.BTN_A, lambda pressed: buzz(0X44, buzz))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: buzz(0XFF, buzz))
ugfx.input_attach(ugfx.BTN_START, home)
ugfx.input_attach(ugfx.BTN_SELECT, render)
while True:
    pass