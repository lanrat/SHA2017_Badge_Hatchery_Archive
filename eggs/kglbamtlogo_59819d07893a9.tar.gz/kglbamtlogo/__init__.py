import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.string_box(0,10,296,26, "The Königlich Bayerisches Amtsvillage is a Metavillage of not only Bavarian Villages", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,30,296,26, "Come to visit us if you are in the neighbourhood!", "Roboto_BlackItalic22", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,60,296,26, "https://twitter.com/Kgl_Bamt", "Roboto_BlackItalic22", ugfx.BLACK, ugfx.justifyLeft)

badge.eink_png(206,63,'/lib/kglbamtlogo/kglbamt_shabadge.png')
ugfx.flush()