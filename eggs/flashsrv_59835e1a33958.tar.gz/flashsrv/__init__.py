import ugfx, badge, easydraw, time, appglue

easydraw.msg("Press the button on the back of your badge.","Instructions", True)

time.sleep(5)
appglue.home()
