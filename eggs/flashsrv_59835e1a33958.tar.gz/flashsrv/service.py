import ugfx, badge, virtualtimers, machine

def task():
    global pin
    global state
    global oldVal
    
    val = pin.value()
    
    changed = False
    
    if oldVal == 1 and val == 0:
        # Button was pressed
        state = not state
        print("Flashlight: detected button press: "+str(state))
        changed = True
            
    if changed:
        ledVal = 0
        if state:
            ledVal = 255
        output = []
        for i in range(0,24):
            output.append(ledVal)
        badge.leds_send_data(bytes(output),24)
        
    oldVal = val
    return 100

def prevent_sleep_task():
    global state
    if state:
        return 500
    else:
        return 0
    
def prevent_sleep():
    if not virtualtimers.update(500, prevent_sleep_task):
        virtualtimers.new(500, prevent_sleep_task)

def setup():
    global pin
    pin = machine.Pin(0)
    
    global oldVal
    oldVal = pin.value()
    
    global state
    state = False
    
    badge.leds_enable()
    
    virtualtimers.activate(25)
    virtualtimers.new(100, task, True)
