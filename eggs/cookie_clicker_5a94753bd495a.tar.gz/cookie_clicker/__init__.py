import ugfx
import time

score = 0

# X:296    Y: 128
def draw_cookie():
    ugfx.circle(100, 64, 30, ugfx.BLACK)
    ugfx.fill_rounded_box(105, 69, 5, 5, 10, ugfx.BLACK)
    ugfx.fill_rounded_box(100, 52, 5, 5, 10, ugfx.BLACK)
    ugfx.fill_rounded_box(89, 64, 5, 5, 10, ugfx.BLACK)

def draw_score():
	ugfx.string(180, 64, str(score), "PermanentMarker22", ugfx.BLACK)

def cb_btna(pressed):
  global score
  if pressed:
    score += 1
    ugfx.clear()
    draw_cookie()
    draw_score()
    ugfx.flush()

ugfx.init()
ugfx.clear(ugfx.WHITE)

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, cb_btna)

ugfx.clear()
draw_cookie()
draw_score()
ugfx.flush()

while True:
  time.sleep(1)