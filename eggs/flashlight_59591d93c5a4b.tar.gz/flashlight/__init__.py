import badge, ugfx
badge.leds_enable()

ugfx.input_attach(ugfx.BTN_A, lambda pushed: badge.leds_set_state(''.join([('\xff' if pushed else '\0') for i in range(24)])))