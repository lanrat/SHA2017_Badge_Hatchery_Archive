#import esp
import badge
import wifi
import ugfx
import time

badge.init()
badge.eink_init()

ugfx.init()
ugfx.demo("HACKING")

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE)
#ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
i = 0 
while not wifi.sta_if.isconnected():
	i = i+1
	time.sleep(0.1)
	if(i>200):
		ugfx.string(15,20,"Connecting failed...","Roboto_Regular12", 0)
		break
	pass