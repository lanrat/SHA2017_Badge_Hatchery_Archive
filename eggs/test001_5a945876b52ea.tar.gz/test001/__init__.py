import ugfx


ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()

x = 0

def printtest():
  global x
  x = 1
  
ugfx.input_attach(ugfx.BTN_A, printtest)

while 1:
  if x:
    ugfx.string(40, 40, "MIEP", "Roboto_Regular12", ugfx.WHITE)
  ugfx.flush()