import badge
badge.init()
import ugfx
ugfx.init()
ugfx.input_init()

def create_callback(button):
    def callback(pressed):
        print("Button %u" % button, pressed)
    return callback

for i in range(1, 11):
    ugfx.input_attach(i, create_callback(i))