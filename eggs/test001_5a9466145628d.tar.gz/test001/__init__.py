import ugfx
from math import sin, cos
import appglue

ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

x = 50
y = 50
r = 0
v = 0
rv = 0

bulets = []

def up(pressed):
  global v
  v += 1

def down(pressed):
  pass

def left(pressed):
  global rv
  rv-=0.1

def right(pressed):
  global rv
  rv+=0.1
  
def stop(pressed):
  appglue.home()
  
def restart(pressed):
  appglue.start_app("test001")
  
def fire(pressed):
  bulets.append(0,x,y,r)
  

ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.JOY_RIGHT, right)
ugfx.input_attach(ugfx.BTN_A, fire)
ugfx.input_attach(ugfx.BTN_SELECT, stop)
ugfx.input_attach(ugfx.BTN_START, restart)

while 1:
  ugfx.clear(ugfx.WHITE)
  r += rv
  
  x+= cos(r)*v
  y+= sin(r)*v
  
  rv/=1.5
  v /=1.2
  
  ugfx.polygon(int(x), int(y), [(0,0),(10,10),(0,10)], ugfx.BLACK)
  for i in bulets:
    ugfx.circle(int(i[1]),int(i[2]),ugfx.BLACK)
    i[1] +=1
    i[2] +=1
    
  t = []
  for i in range(bulets):
    if bulets[i][3] < 100:
      t.append(bulets[i])
  bulets = t
  ugfx.flush()