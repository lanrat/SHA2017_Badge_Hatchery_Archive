import buienradar

buienradar.Buienradar()