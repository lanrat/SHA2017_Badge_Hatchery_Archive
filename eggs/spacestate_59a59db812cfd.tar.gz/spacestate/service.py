def setup():
    import machine, badge, easydraw
    easydraw.msg("Hacking myself")
    badge.nvs_set_str('boot', 'splash', 'wiki_infotag')
    easydraw.msg("Hacking done!")
    machine.deepsleep(1)