import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.display_image(0,0,"/lib/milliways/milliways.png")

ugfx.flush()