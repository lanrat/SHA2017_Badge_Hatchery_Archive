import badge
import ugfx

badge.init()
ugfx.init()
ugfx.input_init()

for x in range(2):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
  
while 1:
  ugfx.fill_circle(10,10,10, ugfx.BLACK)
  ugfx.flush()
  
ugfx.input_attach(ugfx.BTN_B, go_home)