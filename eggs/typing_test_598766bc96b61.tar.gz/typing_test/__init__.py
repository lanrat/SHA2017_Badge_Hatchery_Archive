import badge 
import ugfx
badge.init()
ugfx.init()
ugfx.ugfx_demo("Hacking")
ugfx.flush()