import ugfx, uos as os, ure as re, appglue

def populate_it():
  global options
  options = ugfx.List(0, 0, int(ugfx.width() / 2), ugfx.height())
  load_path()

def load_path():
  global path
  filematch = '\.led$';
 
  ## not shure what this is doing
  while options.count() > 0:
    options.remove_item(0)
  
  try:
    files = os.listdir(path)
  except OSError:
    files = []

  for file in files:
    #if re.match(filematch, file):
    options.add_item(file)

  ugfx.flush()

ugfx.input_init()
ugfx.set_lut(ugfx.LUT_FASTER)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string_box(148, 0, 148, 26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 23, 148, 23, "A.C.A.B.", "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 48, 148, 26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

# the line under the text
str_len = ugfx.get_string_width("Hacking", "PermanentMarker22")
line_begin = 148 + int((148 - str_len) / 2)
line_end = str_len + line_begin
ugfx.line(line_begin, 46, line_end, 46, ugfx.BLACK)

# the cursor past the text
cursor_pos = line_end + 5
ugfx.line(cursor_pos, 22, cursor_pos, 44, ugfx.BLACK)

# Instructions
ugfx.line(148, 78, 296, 78, ugfx.BLACK)
ugfx.string_box(148, 78, 148, 18, " A: Enter dir", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(148, 78, 148, 18, " B: Exit dir", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyRight)
ugfx.string_box(148, 92, 148, 18, " SELECT: Actions", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.line(148, 110, 296, 110, ugfx.BLACK)
ugfx.string_box(148, 110, 148, 18, " " + "by TransIP", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)

# ugfx.flush()
options = None
## install_path = None
path = '/lib/acab/'

populate_it()

###ugfx.input_attach(ugfx.BTN_A, enter_directory)
##ugfx.input_attach(ugfx.BTN_SELECT, open_selectbox)

ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else 0)
ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else 0)

##ugfx.input_attach(ugfx.BTN_B, exit_directory)
ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.home() if pushed else 0)

ugfx.flush(ugfx.LUT_FULL)