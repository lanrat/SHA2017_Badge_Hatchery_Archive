import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: ugfx.string(100, 100, "test", "Roboto_Regular18", ugfx.WHITE))

ugfx.string(100, 100, "test", "Roboto_Regular18", ugfx.BLACK)

ugfx.flush()