import ugfx, badge

def setup():
    pass

def loop():
    return 0

def draw(y):
    return [9999999999, 0]

def draw_going_to_sleep(y):
    enabled = badge.nvs_get_u8("shownick","enable", 0)
    if enabled:
        nick = badge.nvs_get_str("owner", "name", 'A. Nonymous')
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

        ugfx.string_box(0,10,296,26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,94,296,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

        badge.eink_png(250,0,'/lib/atariinvasion/logo-Atari Invasion.png')

        ugfx.flush(ugfx.LUT_FULL)
        ugfx.flush(ugfx.LUT_FULL)
        badge.eink_busy_wait() 
    return [9999999999, 0]