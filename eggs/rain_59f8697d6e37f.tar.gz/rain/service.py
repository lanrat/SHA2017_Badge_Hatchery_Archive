def setup():
    import machine, badge, easydraw
    easydraw.msg("Setting Rain as boot app")
    badge.nvs_set_str('boot', 'splash', 'Rain')
    machine.deepsleep(1)