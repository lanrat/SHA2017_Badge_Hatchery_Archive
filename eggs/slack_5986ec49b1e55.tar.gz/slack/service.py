import badge

def setup():
    pass
  
def loop():
    return 60000

def draw(y):
    badge.leds_send_data(bytes([32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0]), 24)
    return [60000, 14]