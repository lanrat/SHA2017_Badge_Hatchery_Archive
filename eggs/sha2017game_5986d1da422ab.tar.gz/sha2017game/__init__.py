import sys
BmqaA=range
BmqaK=True
Bmqya=OSError
BmqyH=False
BmqyC=len
Bmqyz=open
BmqaT=sys.path
import gc
Bmqak=gc.collect
import network
BmqaV=network.WLAN
Bmqaf=network.STA_IF
BmqaN=network.AP_IF
import machine
BmqaW=machine.unique_id
import usocket as socket
BmqaQ=socket.getaddrinfo
Bmqau=socket.socket
import badge
Bmqai=badge.nvs_set_str
BmqaI=badge.nvs_get_str
import ugfx
Bmqag=ugfx.BLACK
Bmqad=ugfx.clear
Bmqas=ugfx.input_attach
BmqaM=ugfx.string
BmqaJ=ugfx.WHITE
Bmqan=ugfx.flush
Bmqab=ugfx.BTN_A
BmqaS=ugfx.BTN_B
Bmqap=ugfx.input_init
import appglue
BmqaU=appglue.start_app
BmqaR=appglue.home
import time
BmqaE=time.sleep
import dialogs
BmqaX=dialogs.prompt_boolean
BmqaG=dialogs.prompt_text
import machine
BmqaW=machine.unique_id
BmqaT.append('/lib/SHA2017Game')
import game_common
Bmqaj=game_common.determineLeague
import callsign
BmqaF=callsign.callsign
Bmqay=["red","fuchsia","blue","green","yellow","orange"]
def get_fragments():
 BmqaH=[]
 for i in BmqaA(0,25):
  BmqaC=BmqaI('SHA2017Game',"fragment_%d"%i)
  if BmqaC:
   BmqaH.append(BmqaC)
 return BmqaH
def add_fragment(newfragment):
 for i in BmqaA(0,25):
  BmqaC=BmqaI('SHA2017Game',"fragment_%d"%i)
  if BmqaC:
   if BmqaC==newfragment:
    return
  else:
   Bmqai('SHA2017Game',"fragment_%d"%i,newfragment)
   return
def leaguename():
 Bmqaz=Bmqaj()
 return Bmqay[Bmqaz]
def receiveData(BmqaO,cb,errcb):
 w=BmqaV(BmqaN)
 w.active(BmqaK)
 w.config(essid=BmqaO,channel=11)
 s=Bmqau()
 ai=BmqaQ("0.0.0.0",2017)
 print("Bind address info:",ai)
 Bmqae=ai[0][-1]
 s.bind(Bmqae)
 s.listen(5)
 print('Listening at',BmqaO)
 s.settimeout(30)
 try:
  Bmqaw=s.accept()
  Bmqax=Bmqaw[0]
  Bmqav=Bmqaw[1]
  print("Client address:",Bmqav)
  print("Client socket:",Bmqax)
  BmqaD=Bmqax
  print("Request:")
  Bmqac=BmqaD.readline()
  print(Bmqac)
  BmqaD.send('OK\r\n')
  Bmqao=cb(Bmqac)
  BmqaD.close()
  print("Done.")
 except Bmqya:
  print("Error")
  Bmqao=errcb()
 s.close()
 w.active(BmqyH)
 if Bmqao:
  BmqaU('SHA2017Game')
def gotOracleData(data):
 Bmqai('SHA2017Game','fragment_0',data)
 return BmqaK
def listenForOracle(leaguename):
 Bmqad(BmqaJ)
 BmqaM(0,0,"Find the oracle!","PermanentMarker22",Bmqag)
 BmqaM(0,30,"Welcome, brave traveller of league %s. Your quest"%leaguename,"Roboto_Regular12",Bmqag)
 BmqaM(0,50,"starts once you have found the oracle. When you are","Roboto_Regular12",Bmqag)
 BmqaM(0,70,"near she will call out for you and provide further","Roboto_Regular12",Bmqag)
 BmqaM(0,90,"instructions. You have 30 seconds per attempt.","Roboto_Regular12",Bmqag)
 Bmqan()
 receiveData('OracleSeeker',gotOracleData,BmqaR)
def send_to(recv):
 Bmqad(BmqaJ)
 BmqaM(0,0,"Share your fragments!","PermanentMarker22",Bmqag)
 BmqaM(0,30,"Connecting to other player...","Roboto_Regular12",Bmqag)
 Bmqan()
 n=0
 try:
  w=BmqaV(Bmqaf)
  w.active(BmqaK)
  ap="Gamer %s %s"%(leaguename(),recv)
  print('Connecting to',ap)
  w.connect(ap)
  while not w.isconnected()and n<30:
   BmqaE(1)
   n=n+1
 except msg:
  print("error!",msg)
  BmqaM(0,50,"Error connecting to other player...","Roboto_Regular12",Bmqag)
  Bmqan()
  Bmqap()
  Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
  return
 if n==30:
  print('No connection after sleeping 30 seconds')
  BmqaM(0,50,"Error connecting to other player...","Roboto_Regular12",Bmqag)
  Bmqan()
  Bmqap()
  Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
  return
 BmqaM(0,50,"Sending fragments...","Roboto_Regular12",Bmqag)
 Bmqan()
 s=Bmqau()
 ai=BmqaQ("192.168.4.1",2017)
 Bmqae=ai[0][-1]
 s.connect(Bmqae)
 s.send('#'.join(get_fragments()))
 s.send("\r\n")
 s.readline()
 s.close()
 w.active(BmqyH)
 print('Done sending')
 BmqaM(0,70,"Sent fragments. Press A.","Roboto_Regular12",Bmqag)
 Bmqan()
 Bmqap()
 Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
def gotFragmentData(data):
 print('Got fragment data: ',data)
 for BmqaC in data.decode().split('#'):
  add_fragment(BmqaC.replace('\n','').replace('\r',''))
 BmqaP=get_fragments()
 if BmqyC(BmqaP)>=25:
  BmqaU('SHA2017Game')
 BmqaM(0,70,"You now own %d unique fragments, %d to go!"%(BmqyC(BmqaP),25-BmqyC(BmqaP)),"Roboto_Regular12",Bmqag)
 BmqaM(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",Bmqag)
 Bmqan()
 Bmqap()
 Bmqas(BmqaS,lambda pressed:BmqaR()if pressed else 0)
 Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
 return BmqyH;
def receive_fragments_failed():
 BmqaM(0,70,"Failed to receive fragments. Press A.","Roboto_Regular12",Bmqag)
 Bmqan()
 Bmqap()
 Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
def receive_fragments():
 receiveData("Gamer %s %03d%03d"%(leaguename(),BmqaW()[4],BmqaW()[5]),gotFragmentData,receive_fragments_failed)
def send_or_recv(send):
 if send:
  Bmqad(BmqaJ)
  BmqaG("Receiver address:",cb=send_to)
 else:
  Bmqad(BmqaJ)
  BmqaM(0,0,"Share your fragments!","PermanentMarker22",Bmqag)
  BmqaM(0,30,"Tell the other player of your league your address,","Roboto_Regular12",Bmqag)
  BmqaM(0,50,"which is %03d%03d. Waiting..."%(BmqaW()[4],BmqaW()[5]),"Roboto_Regular12",Bmqag)
  Bmqan()
  receive_fragments()
def initiate_sharing():
 Bmqad(BmqaJ)
 BmqaM(0,0,"Share your fragments!","PermanentMarker22",Bmqag)
 BmqaX("Do you want to send or receive?",true_text="Send",false_text="Receive",height=100,cb=send_or_recv)
def won():
 Bmqad(BmqaJ)
 BmqaM(0,0,"Congratulations!","PermanentMarker22",Bmqag)
 BmqaM(0,30,"Cool! You've unlocked your league's secret. As a reward","Roboto_Regular12",Bmqag)
 BmqaM(0,50,"the signal shown by your badge LEDs will now sparkle.","Roboto_Regular12",Bmqag)
 BmqaM(0,70,"Is this the end? That is up to you! Contact raboof for","Roboto_Regular12",Bmqag)
 BmqaM(0,90,"the game code and design new challenges!","Roboto_Regular12",Bmqag)
 BmqaM(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",Bmqag)
 Bmqan()
 Bmqap()
 Bmqas(BmqaS,lambda pressed:BmqaR()if pressed else 0)
 Bmqas(Bmqab,lambda pressed:initiate_sharing()if pressed else 0)
def main():
 Bmqak()
 Bmqaz=Bmqaj()
 BmqaF(Bmqaz)
 if BmqyH:
  Bmqad(BmqaJ)
  BmqaM(0,0,"Welcome, early bird!","PermanentMarker22",Bmqag)
  BmqaM(0,30,"Welcome to the SHA2017Game! You are in league","Roboto_Regular12",Bmqag)
  BmqaM(0,50,"%s, as your 'callsign' shows if you soldered on your"%leaguename(),"Roboto_Regular12",Bmqag)
  BmqaM(0,70,"LEDs. The game starts when the oracle is on the field,","Roboto_Regular12",Bmqag)
  BmqaM(0,90,"keep an eye on https://twitter.com/SHA2017Game.","Roboto_Regular12",Bmqag)
  BmqaM(5,113,"B: Back to home","Roboto_Regular12",Bmqag)
  Bmqan()
  Bmqap()
  Bmqas(BmqaS,lambda pressed:BmqaR()if pressed else 0)
  return
 BmqaP=get_fragments()
 print('number of fragments so far',BmqyC(BmqaP))
 Bmqat=BmqyH
 if BmqyC(BmqaP)>=25:
  Bmqad(BmqaJ)
  try:
   import os
   os.stat('/lib/SHA2017game/sparkle.py')
   won()
  except:
   import wifi
   import urequests
   import shards
   wifi.init()
   while not wifi.sta_if.isconnected():
    BmqaE(1)
   Bmqar=[]
   for BmqaC in BmqaP:
    Bmqar.append(BmqaC.replace('\n','').replace('\r',''))
   BmqaL=shards.key_from_shards(Bmqar)
   print('Collecting shards.py with key',BmqaL)
   r=urequests.get("http://pi.bzzt.net/%s/sparkle.py"%BmqaL)
   f=Bmqyz('/lib/SHA2017game/sparkle.py','w')
   f.write(r.content)
   f.close()
   won()
 elif BmqyC(BmqaP)>1:
  Bmqad(BmqaJ)
  BmqaM(0,0,"Share your fragments!","PermanentMarker22",Bmqag)
  BmqaM(0,30,"By sharing you have now brought together %d"%BmqyC(BmqaP),"Roboto_Regular12",Bmqag)
  BmqaM(0,50,"fragments of league %s. Sharing will send them all."%leaguename(),"Roboto_Regular12",Bmqag)
  BmqaM(0,70,"Unlock your league %s key with 25 fragments!"%leaguename(),"Roboto_Regular12",Bmqag)
  BmqaM(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",Bmqag)
  Bmqan()
  Bmqap()
  Bmqas(BmqaS,lambda pressed:BmqaR()if pressed else 0)
  Bmqas(Bmqab,lambda pressed:initiate_sharing()if pressed else 0)
 elif BmqyC(BmqaP)==1:
  Bmqad(BmqaJ)
  BmqaM(0,0,"Share your fragments!","PermanentMarker22",Bmqag)
  BmqaM(0,30,"The oracle gave you a fragment of a relic of the "+leaguename(),"Roboto_Regular12",Bmqag)
  BmqaM(0,50,"league. 25 such fragments must be brought together","Roboto_Regular12",Bmqag)
  BmqaM(0,70,"to unlock its potential. Find other league members to","Roboto_Regular12",Bmqag)
  BmqaM(0,90,"share fragments along with a story or Mate.","Roboto_Regular12",Bmqag)
  BmqaM(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",Bmqag)
  Bmqan()
  Bmqap()
  Bmqas(BmqaS,lambda pressed:BmqaR()if pressed else 0)
  Bmqas(Bmqab,lambda pressed:initiate_sharing()if pressed else 0)
 elif Bmqat:
  def oracle_selection_made(value):
   BmqaF(Bmqaz)
   if value:
    listenForOracle(leaguename())
   else:
    BmqaR()
  def dialog_title():
   return "SHA2017Game - you are in league "+leaguename()
  BmqaX('Are you ready to start your quest?',title=dialog_title(),true_text='Search for the oracle',false_text='Back to home screen',height=100,cb=oracle_selection_made)
 else:
  Bmqad(BmqaJ)
  BmqaM(0,0,"Retrieving fragment!","PermanentMarker22",Bmqag)
  BmqaM(0,30,"Welcome player of league "+leaguename(),"Roboto_Regular12",Bmqag)
  BmqaM(0,50,"Fetching your initial fragment!","Roboto_Regular12",Bmqag)
  Bmqan()
  import wifi
  import urequests
  wifi.init()
  n=0
  while not wifi.sta_if.isconnected()and n<30:
   BmqaE(1)
   n=n+1
  if n==30:
   BmqaM(0,70,"Failed! Press A.","Roboto_Regular12",Bmqag)
   Bmqap()
   Bmqas(Bmqab,lambda pressed:BmqaU('SHA2017Game')if pressed else 0)
   return
  Bmqah=(BmqaW()[3]+BmqaW()[4]+BmqaW()[5])%700
  r=urequests.get("http://pi.bzzt.net/oracle/%d/%d"%(Bmqaz,Bmqah))
  gotOracleData(r.content)
  BmqaU('SHA2017Game')
main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)

