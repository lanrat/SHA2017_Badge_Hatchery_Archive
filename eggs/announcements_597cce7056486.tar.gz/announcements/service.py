import ugfx, badge, time, wifi, network
import urequests as requests

wifi.init()
def setup():
    nw = network.WLAN(network.STA_IF)
    if not nw.isconnected():
        nw.active(True)
        nw.connect(wifi.ssid, wifi.password) if wifi.password else nw.connect(wifi.ssid)
        timeout = 4
        while not nw.isconnected():
            time.sleep(0.1)
            timeout = timeout - 1
            if (timeout<1):
                nw.active(True)
                return False
    return True

    url = "https://wiki.sha2017.org/w/Special:Ask/-5B-5B-2DHas-20subobject::Announcements-5D-5D-20-5B-5BEnddate::-3E-3E29-20July-202017-5D-5D/-3FAnnouncement/-3FEnddate/mainlabel%3D-2D/limit%3D300/offset%3D0/format%3Djson/link%3Dall/headers%3Dshow/searchlabel%3Dcurrent-20announcements-20in-20JSON"
    r = requests.get(url)
    schedule = r.json()
    r.close()

def loop(c):
    return False

def draw(x,y):
    
    return 12