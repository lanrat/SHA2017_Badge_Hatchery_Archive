import easywifi
import time
import urequests
import ugfx
import random

X = 10
Y = 10
A = 200
B = 100
COLOUR = ugfx.BLACK
FONT = 'Roboto_Regular'
JUSTIFY = ugfx.justifyLeft
MOPPENNL_URL = 'http://www.moppen.nl/PrintMop.aspx?mopID=%s'




def do_it_all():
    """Returns a table for the downpour over the next 2 hours.

    Return value is a list of pairs of the form ('hh:mm', millimeters)
    """
    ugfx.init()
    ugfx.clear()
    ugfx.string(10, 10, "Getting mop", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()

    easywifi.enable()
    if not easywifi.status(): raise RuntimeError('WiFi is not connected')
    mopnr = random.randint(21100,22301) # of andere nummers. hier doen enkelen het

    resp = urequests.get(MOPPENNL_URL % mopnr)
    cont = resp.text.splitlines()
    mop = cont[21]

    #ugfx.clear()
    print(mop)
    mop = "Er komt een man bij de dokter..." 
    ugfx.string_box(X, Y, A, B, mop, FONT, COLOUR, JUSTIFY)
    ugfx.flush()
    time.sleep(200)


do_it_all()