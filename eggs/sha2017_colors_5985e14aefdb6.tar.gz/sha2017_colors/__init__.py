import badge
import ugfx
import appglue

def home(pushed):
    if(pushed):
        print("go home")
        appglue.home()

def low(pushed):
    if(pushed):
        print("sending low")
        badge.leds_enable()
        badge.leds_send_data(sha2017_low)

def high(pushed):
    if(pushed):
        print("sending high")
        badge.leds_enable()
        badge.leds_send_data(sha2017_high)

def off(pushed):
    if(pushed):
        print("led off")
        badge.leds_disable()

badge.init()
ugfx.init()
badge.leds_init()
ugfx.input_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(170,50,"Coloring","PermanentMarker22",ugfx.BLACK)
len = ugfx.get_string_width("Coloring","PermanentMarker22")
ugfx.line(170, 72, 184 + len, 72, ugfx.BLACK)
ugfx.line(180 + len, 52, 180 + len, 70, ugfx.BLACK)
ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(20, 110, "SELECT: exit, START: off, A: low, B: high","Roboto_Regular12",ugfx.BLACK)
try:
    badge.eink_png(0,40,'/lib/sha2017_colors/shrug.png')
except:
    ugfx.string(100,50,"Error loading shrug.png"),ugfx.BLACK

ugfx.flush()
ugfx.input_attach(ugfx.BTN_SELECT, home)
ugfx.input_attach(ugfx.BTN_START, off)
ugfx.input_attach(ugfx.BTN_A, low)
ugfx.input_attach(ugfx.BTN_B, high)

sha2017_high = bytes(24)
sha2017_high = bytes([87, 192, 214, 0, 106, 8, 154, 0, 77, 91, 219, 0, 126, 44, 82, 0, 154, 211, 73, 0, 185, 6, 57, 0])
sha2017_low = bytes(24)
sha2017_low = bytes([37, 152, 164, 0, 56, 8, 104, 0, 27, 41, 169, 0, 76, 44, 32, 0, 104, 161, 23, 0, 135, 6, 57, 0])

badge.leds_send_data(sha2017_low)

