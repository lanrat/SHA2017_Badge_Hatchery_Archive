import ugfx, gc, wifi, badge, deepsleep, urandom, network, woezel
import urequests as requests 
from time import *

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

f = requests.get("https://badge.sha2017.org/eggs/list/json")
try:
    packages = f.json()
finally:
    f.close()

for package in packages:
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10,10,"Installing...","Roboto_Regular12", 0)
    ugfx.string(10,25,package['name'],"Roboto_Regular12", 0)
    ugfx.flush()    
    woezel.install(package['slug'])

import machine
machine.deepsleep(1)