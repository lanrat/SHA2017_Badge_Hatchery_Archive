import ugfx
import time
import urandom
import badge

badge.init()
ugfx.init()

def logo():
    ugfx.clear(ugfx.WHITE)
    ugfx.display_image(35,0,"GERAFFEL20.png")
    ugfx.flush()



logo()
while True:
    pass
