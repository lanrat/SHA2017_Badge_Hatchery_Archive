"""
  Tkkrlab mqtt amp control
  following can be done:

  start:      toggles the amp power
  select:     toggles between CD and AUX input.
  dpad up:    volume up
  dpad down:  volume down
"""

import ugfx
import badge
import machine
import easywifi
import easydraw
import virtualtimers
from umqtt.simple import MQTTClient


AMP_MODE            =   b"tkkrlab/amp/mode"
AMP_VOLUME          =   b"tkkrlab/amp/volume"
AMP_RAW             =   b"tkkrlab/amp/raw"
AMP_VOLUME_CHANGED  =   b"tkkrlab/amp/volume_changed"
AMP_MODE_CHANGED    =   b"tkkrlab/amp/mode_changed"
AMP_POWER = (1 << 0) # Amp Power enable bit
AMP_TAPE1 = (1 << 1) # Tape 1 enable bit
AMP_TAPE2 = (1 << 2) # Tape 2 enable bit
AMP_AUX_CD = (1 << 3) # togles between Aux and Cd
VOLUME_MAX = 65
VOLUME_MIN = 0

amp_mode = AMP_POWER
amp_volume = 20

ugfx.input_init()
easywifi.enable()

# update the volume and mode when anyone changes them
def sub_callback(topic, msg):
    if topic == AMP_VOLUME_CHANGED:
        print("Hell the volume changed!")
    elif topic == AMP_MODE_CHANGED:
        print("Hell the amp mode changed!")

server = b"10.42.1.2"
client_id = machine.unique_id()
client = MQTTClient(bytes(str("AmpControl[%s]" % (client_id)).encode("ascii")), server)
client.set_callback(sub_callback)
client.connect()
client.subscribe(AMP_VOLUME_CHANGED)
client.subscribe(AMP_MODE_CHANGED)

# logging
count = 0
debug_enable = False
def info(string):
    if debug_enable:
        easydraw.msg("[%d][info] %s" % (count, string))
    else:
        print("[%d][info] %s" % (count, string))

def debug_state():
    global amp_mode
    global amp_volume
    info("")
    info("volume: %d" % amp_volume)
    info("amp_mode: %s" % str(bin(amp_mode)))
    if amp_mode & AMP_POWER:
        info("amp on.")
    else:
        info("amp off.")
    if amp_mode & AMP_AUX_CD:
        info("amp input: AUX")
    else:
        info("amp input: CD")

# updates the mode and volume
def update_amp():
    global count
    global client
    global amp_mode
    global amp_volume

    # if update_state:
    debug_state()
    client.publish(AMP_MODE, str(amp_mode))
    client.publish(AMP_VOLUME, str(amp_volume))
    count += 1

def update_volume():
    pass

def update_mode():
    pass

def button_select(pushed):
    global amp_mode
    global update_state

    if pushed:
        amp_mode ^= AMP_AUX_CD
    if not pushed:
        update_amp()

def button_start(pushed):
    global amp_mode
    global update_state

    if pushed:
        amp_mode ^= AMP_POWER
    if not pushed:
        update_amp()

def button_up(pushed):
    global amp_volume
    global update_state

    if pushed:
        amp_volume += 5
    if amp_volume > VOLUME_MAX:
        amp_volume = VOLUME_MAX
    if not pushed:
        update_amp()

def button_down(pushed):
    global amp_volume
    global update_state

    if pushed:
        amp_volume -= 5
    if amp_volume < VOLUME_MIN:
        amp_volume = VOLUME_MIN
    if not pushed:
        update_amp()

ugfx.input_attach(ugfx.BTN_SELECT, button_select)
ugfx.input_attach(ugfx.BTN_START, button_start)
ugfx.input_attach(ugfx.JOY_UP, button_up)
ugfx.input_attach(ugfx.JOY_DOWN, button_down)

badge.leds_init()
badge.leds_enable()
badge.leds_send_data(bytes([0x01] * (6 * 4)))

virtualtimers.new(1000, client.check_msg)
virtualtimers.activate(100)