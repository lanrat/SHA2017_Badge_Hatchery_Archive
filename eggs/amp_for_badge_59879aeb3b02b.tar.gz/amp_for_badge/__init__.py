import woezel, appglue, wifi, time
#AMP-Advanced Malware Protection for Badge
#Don't worry weĺl clean the ransomware for free!

def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

wifi.init()
await_wifi()
woezel.install('Internship')
appglue.start_app('Internship')