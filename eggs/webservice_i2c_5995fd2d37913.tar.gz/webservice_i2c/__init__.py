#import esp
import badge, wifi, ugfx, time, appglue

def btn_home(pushed):
    if pushed:
		appglue.start_app('launcher')
        #appglue.home()

badge.init()
badge.eink_init()

ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_START, btn_home)

# Make sure WiFi is connected
wifi.init()
time.sleep(1)
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
i = 0 
while not wifi.sta_if.isconnected():
	i = i+1
	time.sleep(0.1)
	if(i>200):
		ugfx.clear(ugfx.WHITE)
		ugfx.string(15,20,"Connecting failed..."+i,"Roboto_Regular12", 0)
		ugfx.flush()
        break
if (wifi.sta_if.isconnected() == True):
	ugfx.clear(ugfx.WHITE)
	ugfx.string(10,10,"Conected...","Roboto_Regular12", 0)
	ugfx.string(20,20, next(iter(wifi.sta_if.ifconfig())),"Roboto_Regular12",0)
	ugfx.flush()