import ugfx, wifi, badge, deepsleep, sys
from time import sleep

ugfx.init()

# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

set_message("Waiting for wifi...")
  
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

set_message("Got wifi. Loading data")

data=None