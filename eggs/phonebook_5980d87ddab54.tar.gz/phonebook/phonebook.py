import ugfx, wifi, badge, deepsleep, sys
from time import sleep

ugfx.init()

# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

set_message("Waiting for wifi...")
  
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

set_message("Got wifi. Loading data")

data=None
try:
  url = "https://188.40.158.211/phonebook.csv?limit=1"
  import urequests_pmenke as requests
  set_message(url)
  r = requests.get(url, headers={"Host": "poc.sha2017.org"}, host_override="poc.sha2017.org")
  data = r.text
  r.close()
except Exception as e:
  set_message("Unexpected error: "+str(e))
  sys.exit()

set_message("Got data. Parsing...")

try:
  for entry in data.split('\n'):
    set_message(entry)
    sleep(5)
    #extension = entry.split(',')[0]
    #name = (entry.split(',')[1]).replace('"', '')
    #ugfx.clear()
    #ugfx.string(10,10,extension+' -> '+name,"Robot_Regular12", 0)
    #ugfx.flush()
    #badge.eink_busy_wait()
    #sleep(0.5)
except Exception as e:
  set_message("Parsing error: "+str(e))
  sleep(10)

ugfx.clear()
ugfx.string(10,10,"End","Robot_Regular12", 0)
ugfx.flush()
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)