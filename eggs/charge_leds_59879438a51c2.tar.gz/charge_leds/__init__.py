import ugfx,badge,machine,time
badge.init()
ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.LUT_FULL)
ns="charge_leds"
svck="enable"

from service import show_leds

status = badge.nvs_get_u8(ns, svck, 0)
redraw = False

def draw():
    global redraw, status
    if redraw:
        ugfx.clear()
        ststring = "enable" if status else "disable"
        ugfx.string(0, 25, "START: main menu",  "Roboto_BlackItalic24", ugfx.BLACK)
        ugfx.string(0, 50, "SELECT: "+ststring+" service", "Roboto_BlackItalic24",  ugfx.BLACK)
        ugfx.flush()
        redraw = False
    show_leds()
    time.sleep(100)

def change_service():
    global redraw, status
    badge.nvs_set_u8(ns, svck, not status)
    status = not status
    redraw = True
    draw()

def btn_change(pushed):
    if pushed:
        change_service()

def btn_home(pushed):
    if(pushed):
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_SELECT, btn_change)
ugfx.input_attach(ugfx.BTN_START, btn_home)

draw()