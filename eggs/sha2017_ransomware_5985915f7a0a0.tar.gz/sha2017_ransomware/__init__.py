import ugfx
import badge
from time import sleep


ugfx.init()
badge.init()


def write(y, message):
    ugfx.string(20, y, message, "Roboto_Regular12", ugfx.BLACK)


def write_lock(victim_id):
    ugfx.clear(ugfx.WHITE)
    ugfx.string(15, 10, "SHA2017 - Ransomware","Roboto_BlackItalic24", ugfx.BLACK)
    write(40, "Oh noes, your badge is being held hostage!")
    write(52, "Deliver a club mate to the Snowden field.")
    write(64, "We're in the first big tent to the left.")
    write(76, "Be sure to show us this ID: " + victim_id)


# Main - Lock the badge and prompt the user to
# get over here and pay the ransom :)
ransom_paid = False
write_lock(victim_id="ABCDEF")

while not ransom_paid:
    sleep(0.1)
    pass