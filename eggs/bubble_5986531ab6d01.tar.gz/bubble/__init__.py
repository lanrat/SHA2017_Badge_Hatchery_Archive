import ugfx
import random

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
    
def bubble():
    x = random.randint(10,286)
    y = random.randint(10,118)
    r = random.randint(2,10)
    ugfx.fill_circle(x,y,r,ugfx.BLACK)
    ugfx.fill_circle(x,y,r-2,ugfx.WHITE)
    ugfx.flush()
    ugfx.input_attach(ugfx.BTN_B, go_home)
    ugfx.input_attach(ugfx.BTN_A, clean)

ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, clean)
while True:
    ugfx.input_attach(ugfx.BTN_B, go_home)
    ugfx.input_attach(ugfx.BTN_A, clean)
    bubble()