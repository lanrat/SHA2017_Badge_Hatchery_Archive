import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.string(100, 100, "test", "Roboto_Regular18", ugfx.BLACK)

ugfx.flush()