import ugfx
import badge
from random import randint

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.input_attach(ugfx.BTN_A, lambda pressed: btn_a(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: btn_b(pressed))

load = 0
quit = 0

def btn_a(pressed):
  global load
  if pressed:
  	load = 1
        

def btn_b(pressed):
  global quit
  if pressed:
   	quit = 1
        
def rroulette():
  global load, quit
  ugfx.clear(ugfx.WHITE)
  
  trial = 0
  bulletcham = randint(1, 6)
  
  while bulletcham != trial and quit == 0 and load == 1:
    if bulletcham == trial:
      ugfx.string(15, 20, str('BAM! Dead...'), "Roboto_BlackItalic30", ugfx.BLACK)
    else:
      ugfx.string(15, 20, str('Survived'), "Roboto_BlackItalic24", ugfx.BLACK)
      load = 0
  
rroulette()