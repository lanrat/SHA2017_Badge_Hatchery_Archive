import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)



def printtest():
  ugfx.string(5, 110, "[UP/DOWN]", "Roboto_Regular12", ugfx.BLACK)
  ugfx.flush()
  
ugfx.input_attach(ugfx.JOY_UP, printtest)