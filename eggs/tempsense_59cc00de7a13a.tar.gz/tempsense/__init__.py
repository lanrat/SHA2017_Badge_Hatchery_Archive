import machine, time, onewire, ds18x20
from machine import Pin
import badge, ugfx, wifi
#, uos, appglue, re #, gc 

def system_init():
  global ds
  global roms
  
  badge.init()
  wifi.init()
  ugfx.init()
  ugfx.input_init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()

  p12=Pin(12,Pin.OUT)
  p12.value(1)
  dat = machine.Pin(33)

  # create the onewire object
  ds = ds18x20.DS18X20(onewire.OneWire(dat))

  # scan for devices on the bus
  roms = ds.scan()


def show_temp():
  ugfx.string(50, 0, "Use A to get temp!" , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(50, 14, "My ip is %s" % (wifi_up()) , "Roboto_BlackItalic12", ugfx.BLACK)
  #cur_ip = wifi_up()
  ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_temp() if pushed else False)
  ugfx.flush()

def get_temp():
  global roms
  global ds

  ds.convert_temp()
  print(ds.read_temp(roms[0]))
  ugfx.area(50,30,100,50,ugfx.WHITE)
  ugfx.string(50, 30, "Temp is %f!" % (ds.read_temp(roms[0])) , "Roboto_BlackItalic12", ugfx.BLACK) 
  ugfx.flush()
  time.sleep_ms(250)

def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
    
try:
  system_init()
 
  get_temp()
  time.sleep_ms(500)
  get_temp()
  
  show_temp()
  print("All systems go!")

except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()