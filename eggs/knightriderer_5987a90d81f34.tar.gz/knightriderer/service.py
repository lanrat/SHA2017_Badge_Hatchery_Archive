import utime, badge, binascii

direction = False
lead = 6
# Prevents hanging LEDs in the beginning
wait = 20
states = [0 for i in range(6)]
serviceEnabled = 0

# This function gets called by the home application at boot
def setup():
    print("[KNIGHTRIDERER] Tag: 20")
    global serviceEnabled
    serviceEnabled = badge.nvs_get_u8('kriderer', 'brightness', 0)
    if serviceEnabled>4:
        serviceEnabled=4
    if (serviceEnabled<1):
        print("[KNIGHTRIDERER] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def encode_leds(states):
    global serviceEnabled
    value = bytearray(24)
    for i, v in enumerate(states):
        value[i*4 + serviceEnabled - 1] = v >> 8
    return value

def loop():
    global serviceEnabled
    global direction
    global states
    global lead
    global wait
        
    if (serviceEnabled>0):
        states = [(v * (26214 if v >= 10485 else 6554) >> 16) for v in states]
        if wait > 0:
            wait -= 1
        elif direction:
            lead += 1
            if lead == 6:
                direction = False
                wait = 40
            else:
                wait = 1
        else:
            lead -= 1 
            if lead == -1:
                direction = True
                wait = 2
            else:
                wait = 1
        if lead >= 0 and lead <= 5:
            states[lead] = 65535
        value = encode_leds(states)
        badge.leds_send_data(bytes(value),24)
        return 50
    return 0
