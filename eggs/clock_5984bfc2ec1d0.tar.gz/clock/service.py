import easyrtc
import ugfx

def setup():
    pass
  
def loop(counter):
    return False

def draw(y):
    t = easyrtc.string()
    ugfx.string(0, y-37, t, "PermanentMarker36", ugfx.BLACK)
    ugfx.flush()
    return [60000, 38]