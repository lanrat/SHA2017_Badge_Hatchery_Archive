import ugfx

def setup():
    pass

def loop():
    return False

def draw(y):
    ugfx.display_image(0, 24, 'fhbw.bmp')
    return [99999999999, 0]