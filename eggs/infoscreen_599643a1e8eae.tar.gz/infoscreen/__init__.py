import time
import urequests
import ugfx
import wifi
import machine #to get the reset cause
import badge #to set splashscreen and wait for eink display
import deepsleep #deepsleep in the main routine
import appglue #to return home
import dialogs #to query the user for the url

#initialization of persistant memory varibles
if(badge.nvs_get_str("infoscreen_url")):
   badge.nvs_set_str("infoscreen_url", "http://voidman.at/cal/cal.php?name=oeh_public")
if(badge.nvs_get_str("infoscreen_font")):
   badge.nvs_set_str("infoscreen_font", "DejaVuSans20")
  
URL = badge.nvs_get_str("infoscreen_url")
SLEEPTIME = 30*1000 #60*60*24*1000 #a day
OWNNAME = "infoscreen"
FONT = badge.nvs_get_str("infoscreen_font")
FONTS = ["Roboto_Regular12", "Roboto_Regular18", "Roboto_Regular22", "Roboto_Black22", "Roboto_BlackItalic24", "PermanentMarker22", "PermanentMarker36", "pixelade13", "DejaVuSans20", "weather42"]

#default code for badge
def clear(color):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.clear(color)

def wait_wifi():
    clear(ugfx.BLACK)
    ugfx.string(50, 25, "STILL", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.string(30, 50, "Connecting to wifi", "PermanentMarker22", ugfx.WHITE)
    le = ugfx.get_string_width("Connecting to wifi", "PermanentMarker22")
    ugfx.line(30, 72, 30 + 14 + le, 72, ugfx.WHITE)
    ugfx.string(140, 75, "Anyway", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.flush()

    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        
def show(newtext):
    lineheight = int(FONT[-2:])
    lines = ugfx.height()/lineheight
    firstN = newtext.split("\n")[:lines]
    clear(ugfx.WHITE)
    i=0 #line counter
    for line in firstN:
        ypos = 1 + i * lineheight; #ypos 0 is invalid somehow?
    	ugfx.string(1,ypos,line, FONT, ugfx.BLACK)
        i+=1
    ugfx.flush()
    
    
def mainroutine():
    try:
        show("Requesting...")
        r = urequests.get(URL)
    except:
        show("Connection problems")
        if not wifi.sta_if.isconnected():
            wifi.init()
            wait_wifi()
    else:
        if r.status_code == 200:
            #gc.collect()
            show(r.text);
            r.close()
        else:
            show("Error at fetching file");
            r.close();
            
        badge.nvs_set_str('boot','splash', OWNNAME) #set badge to reboot into this
        badge.eink_busy_wait() #wait for eink display to draw
        deepsleep.start_sleeping(SLEEPTIME) #let's go to sleep

#allow to set font on call of mainscreen
def mainscreen(font = FONT):
    global FONT
    FONT = font
    badge.nvs_get_str("infoscreen_font",FONT)
    show("[A] Set URL\n[B]Return to home\n[Start] start display routine\n[Select]Select font")
    
def set_url():
    global URL
    URL = dialogs.prompt_text("Please enter fully qualified http[s] url", URL)
    badge.nvs_set_str("infoscreen_url",URL)
    
def set_font():
    global options
    global FONT
    global FONTS
    options = ugfx.List(0,0,int(ugfx.width()),ugfx.height())
    #options already handles up/down on it's own
    for font in FONTS:
        options.add_item(font)
    ugfx.input_attach(ugfx.BTN_A,lambda: mainscreen(FONTS[options.selected_index]))
    ugfx.input_attach(ugfx.BTN_B,mainscreen())
       
ugfx.init()
badge.init()
wifi.init()
wait_wifi()

#if the badge didn't boot from deepsleep, reset it to boot to splash
if( machine.reset_cause() !=  machine.DEEPSLEEP_RESET ):
    badge.nvs_set_str('boot','splash','splash')
    ugfx.input_attach(ugfx.BTN_A,set_url)
    ugfx.input_attach(ugfx.BTN_B,lambda: appglue.start_app("launcher"))
    ugfx.input_attach(ugfx.BTN_START,mainroutine)
    ugfx.input_attach(ugfx.BTN_SELECT,set_font)

    mainscreen()
else:
    mainroutine()