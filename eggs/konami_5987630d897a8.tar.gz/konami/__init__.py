import ugfx
import time
import badge
import time

ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

inputState = []
expected = ['up', 'up', 'down', 'down', 'left', 'right', 'left', 'right', 'b', 'a']

asciiFont = 'fixed_10x20'
notDead = ['  o  ', ' /|\ ', ' / \ ']
notDeadCheer = [' \o/ ', '  |  ', ' / \ ']
dead = ['>->o']

def printAscii(art, font, text):
    ugfx.clear(ugfx.BLACK)
    ugfx.clear(ugfx.WHITE)

    fontW = ugfx.get_string_width(text, font)
    ugfx.string(int(300 / 2) - int(fontW / 2), 80, text, font, ugfx.BLACK)

    i = 0

    for line in art:
       i += 1
       j=0
       for char in line:
           j +=1
           ugfx.string(8*j, 12*i, char, "fixed_10x20", ugfx.BLACK)

def buttonSignal(keyPressed, state):
    if state == True:
        offset = 0
        inputState.append(keyPressed)
        
        for state in inputState:
            # Yous has died
            if expected[offset] != state:
                printAscii(dead, "Roboto_Regular18", 'Oow nooes, you\'s has been died')
                
            offset += 1
                
        # Yous has been awesome
        if len(inputState) == 10:
                while True:
                    printAscii(notDead, "Roboto_Regular12", 'Conglaturations, you are being winnner!')
                    time.sleep_ms(1500)
                    printAscii(notDeadCheer, "Roboto_Regular12", 'Conglaturations, you are being winnner!')
                    time.sleep_ms(1500)

def startApp(pushed):
    if(pushed):
        import launcher

ugfx.input_attach(ugfx.JOY_UP, lambda pressed: buttonSignal('up', pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: buttonSignal('down', pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: buttonSignal('left', pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: buttonSignal('right', pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: buttonSignal('a', pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: buttonSignal('b', pressed))

printAscii([], "Roboto_Regular12", 'You know what to do...')

# Restart
ugfx.input_attach(ugfx.BTN_START, startApp)

# Quit to the launcher
ugfx.input_attach(ugfx.BTN_SELECT, startApp)

while True:
    pass
