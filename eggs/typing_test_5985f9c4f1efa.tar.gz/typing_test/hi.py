import time
print "-hi-"
print "-enter ya msg here boi-"
start = time.time()
v1 = raw_input("enter message : ")
seconds = (time.time() - start)
print "you typed ",v1, "in ","%.1f" %seconds," seconds!" 