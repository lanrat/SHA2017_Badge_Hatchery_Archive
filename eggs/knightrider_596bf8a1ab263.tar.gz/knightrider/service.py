# Knightrider leds service
# Renze Nicolai 2017

import utime, badge, binascii

nyanCnt = 0
nyanLeds = []
nyanEnabled = 0
colorList = []

# This function gets called by the home application at boot
def setup():
    global nyanEnabled
    nyanEnabled = int(badge.nvs_get_str('knightrider', 'state', '0'))
    if (nyanEnabled<1):
        print("Knightrider: Disabled! Please enable in the app!")
    else:
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            badge.leds_enable()
            badge.leds_set_state(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]))
            global nyanLeds
            ledValue = [0,0,0,0]
            for i in range(0,6):
                nyanLeds.append(ledValue)
                
            global colorList
            for i in range(0,len(colorList)):
                colorList[i][0] = round(colorList[i][0] * (nyanEnabled/255))
                colorList[i][1] = round(colorList[i][1] * (nyanEnabled/255))
                colorList[i][2] = round(colorList[i][2] * (nyanEnabled/255))
                colorList[i][3] = round(colorList[i][3] * (nyanEnabled/255))
            print("Knightrider: Leds enabled!")
        else:
            badge.leds_disable()
            print("Knightrider: battery low...")
            return False # Do not prevent sleep

def loop(sleepCnt):
    global nyanEnabled
    if (nyanEnabled>0):
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            global nyanCnt
            global brVal
            global colorList
            nyanCnt = nyanCnt + 1
            if nyanCnt >= 12:
                nyanCnt = 0
                
            pos = nyanCnt
            if pos>5:
                pos = 11-nyanCnt
                                        
            print("Knightrider: position " + str(pos))
            
            output = []            
            for i in range(0,6):
                d = abs(i-pos)/6
                r = round(255-255*d)
                output = output + [0,r,0,0]
            print("Knightrider: Loop ("+str(nyanCnt)+") = ", output)
            badge.leds_set_state(bytes(output))
            return True # Prevent sleep
        else:
            badge.leds_disable()
            print("Knightrider: battery low...")
            return False # Do not prevent sleep
    return False

def draw(x,y):
    # Not drawing anything
    return 0
