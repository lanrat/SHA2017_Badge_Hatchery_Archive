l = open('./boot.py', 'w')
l.write('blah')