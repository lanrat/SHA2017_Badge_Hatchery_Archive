import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)

ugfx.string(100, 35, "STILL", "Roboto_BlackItalic24", ugfx.WHITE)
ugfx.string(100, 55, "KRAKEN-Party", "PermanentMarker22", ugfx.WHITE)
ugfx.string(100, 80, "Anyway", "Roboto_BlackItalic24", ugfx.WHITE)

ugfx.flush()