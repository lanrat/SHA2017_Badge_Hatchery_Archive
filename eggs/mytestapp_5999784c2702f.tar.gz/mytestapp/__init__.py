import time
import ugfx
ugfx.clear(ugfx.WHITE)
ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.flush()
for i in range(128):
  ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
  time.sleep(0.5)
  ugfx.flush()