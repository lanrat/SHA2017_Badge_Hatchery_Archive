import ugfx

ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

x = 50
y = 50
r = 0


v = 0
rv = 0

def up(pressed):
  pass

def down(pressed):
  pass

def left(pressed):
  pass

def right(pressed):
  pass

ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.JOY_RIGHT, right)

while 1:
  ugfx.clear(ugfx.WHITE)
  ugfx.circle(x, y, 5, ugfx.BLACK)
  ugfx.flush()