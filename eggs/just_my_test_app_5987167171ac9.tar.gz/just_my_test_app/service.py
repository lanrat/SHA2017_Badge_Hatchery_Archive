import badge, time

enabled = 1

def setup():
    global enabled
    enabled = badge.nvs_get_u8('justmytestapp', 'enabled', 1)

    if enabled:
        badge.leds_enable()
    else:
        print("[JustMyTestApp] Is disabled");
  
def loop():
    global enabled

    if not enabled:
      return 0

    print("[JustMyTestApp] Got loop event");

    badge.leds_send_data(bytes([0]*22,5,0), 24)

    time.sleep(.2)

    return 60000

def draw(y):
    badge.leds_send_data(bytes([0]*24), 24)
    #return [60000, 0]
    return 0
