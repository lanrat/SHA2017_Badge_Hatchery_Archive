import network, time
import urequests as req

def setup():
    loop()

def loop():
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)
    scanResults = sta_if.scan()
    ssidSet = set([ AP[0] for AP in scanResults ])
    for SSID in ssidSet:
        if SSID == b'lainchan_HQ':
            print("I'm home!")
            sta_if.connect("lainchan_HQ", "lookitsauselesspassword")
            timeout = 4
            while not sta_if.isconnected():
                time.sleep(0.1)
                timeout = timeout - 1
                if (timeout<1):
                    sta_if.active(True)
            r = req.get("http://192.168.4.1/"+name)
            print(r)
    return 5000
