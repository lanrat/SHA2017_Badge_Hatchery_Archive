import badge

def setup():
    pass

def draw(x,y):
    badge.eink_png(130,50,'/lib/fiumerslogo/fiumers.png')
    return 0