import ugfx, machine
from appglue import home

i2c = machine.I2C( sda=machine.Pin(26), scl=machine.Pin(27), freq=100000 )
slaves = i2c.scan()

ugfx.input_init()
ugfx.clear( ugfx.WHITE )
ugfx.string( 0, 0, "Still Scanning Anyway", "PermanentMarker22", ugfx.BLACK )
len = 24
for slave in slaves:
    ugfx.string( 0, 0 + len, hex( slave ), "Roboto_Regular12", ugfx.BLACK )
    len = len + 20

ugfx.string( 0, 115, "Press Start to return to home screen", "Roboto_Regular12", ugfx.BLACK )
ugfx.input_attach( ugfx.BTN_START, lambda pressed: home() if pressed else True )

ugfx.flush()
