import badge
import ugfx
import deepsleep

# width = 296
# height = 128

tile = 20

new_dir = 4
last_dir = 5

def snakeflut():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)

    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_LEFT, left)

    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 10, "Use Up/Down/Left/Right Buttons", "Roboto_Regular12", 0)
    ugfx.flush()

    display()

def display():
    global last_dir
    if new_dir != last_dir:
        # clear
        if last_dir == 0:
            ugfx.area(100 + tile*2, tile*1, tile, tile, ugfx.WHITE)
        if last_dir == 1:
            ugfx.area(100 + tile*3, tile*2, tile, tile, ugfx.WHITE)
        if last_dir == 2:
            ugfx.area(100 + tile*2, tile*3, tile, tile, ugfx.WHITE)
        if last_dir == 3:
            ugfx.area(100 + tile*1, tile*2, tile, tile, ugfx.WHITE)

        # box
        ugfx.box(100 + tile*2, tile*1, tile, tile, ugfx.BLACK)
        ugfx.box(100 + tile*3, tile*2, tile, tile, ugfx.BLACK)
        ugfx.box(100 + tile*2, tile*3, tile, tile, ugfx.BLACK)
        ugfx.box(100 + tile*1, tile*2, tile, tile, ugfx.BLACK)

        # paint
        if new_dir == 0:
            ugfx.area(100 + tile*2, tile*1, tile, tile, ugfx.BLACK)
        if new_dir == 1:
            ugfx.area(100 + tile*3, tile*2, tile, tile, ugfx.BLACK)
        if new_dir == 2:
            ugfx.area(100 + tile*2, tile*3, tile, tile, ugfx.BLACK)
        if new_dir == 3:
            ugfx.area(100 + tile*1, tile*2, tile, tile, ugfx.BLACK)

        last_dir = new_dir

        ugfx.flush()

def up(wut):
    global new_dir
    new_dir = 0
    display()

def right(wut):
    global new_dir
    new_dir = 1
    display()

def down(wut):
    global new_dir
    new_dir = 2
    display()

def left(wut):
    global new_dir
    new_dir = 3
    display()

def reboot(wut):
  deepsleep.reboot()

snakeflut()
