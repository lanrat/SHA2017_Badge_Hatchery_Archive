import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)


ugfx.area(10,10,32,32,ugfx.BLACK)

ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)

ugfx.flush()

def render(text, pushed):
    if(pushed):
        ugfx.clear(ugfx.BLACK)
        ugfx.area(10,10,32,32,ugfx.WHITE)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.BLACK)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.WHITE)
    else:
        ugfx.clear(ugfx.WHITE)
        ugfx.area(10,10,32,32,ugfx.BLACK)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)

    ugfx.flush()
    

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: render('UP', pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: render('DOWN', pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: render('LEFT', pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: render('RIGHT', pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: render('A', pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: render('B', pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: render('Select', pressed))

while True:
    pass