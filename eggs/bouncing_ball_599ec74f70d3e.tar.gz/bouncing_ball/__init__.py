import ugfx

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
  


ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, clean)

ugfx.fill_circle(10,10,10,ugfx.BLACK)
ugfx.fill_circle(10,10,20,ugfx.WHITE)
ugfx.flush()