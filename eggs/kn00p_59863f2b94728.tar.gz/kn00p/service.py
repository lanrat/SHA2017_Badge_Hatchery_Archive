def setup():
    pass

def loop():
    return 60*1000