import badge, ugfx
badge.leds_enable()

#ugfx.input_attach(ugfx.BTN_FLASH, lambda pushed: badge.leds_send_data(''.join([('\xff' if pushed else '\0') for i in range(24)]), 24))
# sorry to edit your app like this, we don't have collaborative edits in place yet
# The line should read:
ugfx.input_attach(ugfx.BTN_FLASH, lambda pushed: badge.leds_send_data(bytes([(0xff if pushed else 0) for i in range(0,24)]),24))