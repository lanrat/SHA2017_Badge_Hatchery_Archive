### Author: Mattsi Jansky
### Description: Testing network functionality
### Category: Unpublished
### License: MIT
### Appname: nettest
### Built-in: no

import badge
import ugfx
import deepsleep
import wifi
import time
import sys

sys.path.append('/lib/Network_test')
import network_lib

testDict = {"foo":"bar", "pos": {"x": 1, "y": 2}, "name":"barry", "items":["fish", "barry"]}

def network_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    wifi_up()
    cleanScreen()
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.text(10, 10, "Testing network", ugfx.BLACK)
    ugfx.flush()

    #Test GET
    result = network_lib.sendGET("https://jsonplaceholder.typicode.com/posts/1", debug = True )
    #Test POST
    result = network_lib.sendPOST("http://ptsv2.com/t/emjay/post", testDict, debug = True)

def cleanScreen():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def reboot(wut):
    deepsleep.reboot()

def wifi_up():
  wifi.init()
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  return wifi.sta_if.ifconfig()[0]

network_test()