import ugfx
import machine

def go_home(pushed):
    if(pushed):
        machine.deepsleep(1)

ugfx.init()
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.clear(ugfx.WHITE)
ugfx.fill_circle(100, 10, 4, ugfx.BLACK)
ugfx.fill_circle(100, 10, 6, ugfx.WHITE)
ugfx.fill_circle(150, 20, 8, ugfx.BLACK)
ugfx.fill_circle(150, 20, 6, ugfx.WHITE)