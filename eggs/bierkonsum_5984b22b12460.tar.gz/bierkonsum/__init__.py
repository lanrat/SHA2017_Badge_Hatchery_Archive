import ugfx, wifi, appglue
import time, json
import urequests as requests

apiurl = "http://hotglue.tech:5000/api/get/current"

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass


ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Connecting to MQTT...","Roboto_Regular12", 0)
ugfx.flush()


beer = "-"


def main():
    global beer
    response = requests.get(apiurl).json()
    beer = response['total']
    ugfx.string(0, 20,  "Koeniglich Bayrisches Amtsvillage", "PermanentMarker16", ugfx.BLACK)
    ugfx.string(0, 70, "Bier gezapft: {}l".format(beer), "Roboto_Black22", ugfx.BLACK)
    ugfx.flush()
    time.sleep(5)


def go_home(pushed):
    if pushed:
        appglue.home()


ugfx.input_attach(ugfx.BTN_B, go_home)
main()
