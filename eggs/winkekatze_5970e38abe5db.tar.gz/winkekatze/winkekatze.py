
import ugfx
import time
import badge
import wifi

import urandom 
from umqtt.simple import MQTTClient

class WinkeKatze:
    #   |\_/|
    #   (. .)
    #    =w=  (\
    #  /  ^  \//
    #  (|| ||)
    #  ,""_""_ .

    #   |\_/|
    #   (. .)
    #    =w=  
    #  /  ^  \\
    #  (|| ||)\\
    #  ,""_""_(/.

    def draw_cat(self,cat='up',footer="https://devlol.org"):
        i=0
        if (cat == 'up'):
            drawcat = self.cat
        elif (cat == 'down'):
            drawcat = self.catdown

        ugfx.clear(ugfx.WHITE)
        for line in drawcat:
           i += 1
           j=0
           for char in line:
               j +=1
               ugfx.string(8*j, 12*i,char, self.font, ugfx.BLACK)
           print (line)
        if footer:
            i +=1
            ugfx.string(8,12*i,footer,self.font,ugfx.BLACK)
        ugfx.flush()

    def sub_cb(self,topic,msg):
        print ("received mqtt message topic: %s, payload: %s" % (topic,msg))
        for count in [1,2,3,4]:
            self.draw_cat(cat="down")
            time.sleep(0.5)
            self.draw_cat()
            time.sleep(0.5)

    def __init__(self, font="fixed_10x20",server='mqtt.devlol.org',topic='devlol/h19/mainroom/winkekatze'):
        self.cat =    ['   |\_/|   ', '   (. .)   ', '    =w=  (\ ', '  /  ^  \// ', '  (|| ||)  ', '  ,""_""_ .']
        self.catdown =['   |\_/|   ', '   (. .)   ', '    =w=    ', '  /  ^  \\\\  ', '  (|| ||)\\', '  ,""_""_(/.']
        self.font = font 
        self.clientname = 'SHA2017Badge' + str(urandom.getrandbits(30))
        self.server = server
        self.topic = topic

        badge.init()
        ugfx.init()
        wifi.init()
        while not wifi.sta_if.isconnected():
            time.sleep(1)
            print ("waiting for wifi")
            pass

        print ("connecting to mqtt server:%s  clientname:%s" %(self.server,self.clientname))
        c = MQTTClient(self.clientname,self.server)
        c.set_callback(self.sub_cb)
        c.connect()
        c.subscribe(self.topic)

        ugfx.clear(ugfx.BLACK)
        ugfx.flush
        ugfx.clear(ugfx.WHITE)
        ugfx.flush

        self.draw_cat()
        while True:
            time.sleep(0.5)
            c.check_msg()

wk = WinkeKatze()
