import badge
import ugfx
import network
import wifi
import time
import math
import dialogs
import usocket as socket
import _thread as thread


def clearGhosting():
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()

def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  return wifi.sta_if.ifconfig()[0]

lines = []
def render_term():
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  cy = 0
  h = ugfx.height()
  count = math.floor(h / 13)
  for line in lines[-count:]:
    ugfx.string(0, cy, line, "pixelade13", ugfx.BLACK)
    cy = cy + 13
    if cy > h:
      break
  ugfx.flush()


def send_message(pressed):
	print("send_message") 
	s.send(bytes(name+": "+dialogs.prompt_text("Your message:") + "\n", 'utf-8'))

ugfx.init()
badge.init()
ugfx.input_init()


clearGhosting()
ugfx.clear(ugfx.WHITE)
ugfx.string(100,50,'Connecting to server...','Roboto_Regular18',ugfx.BLACK)
ugfx.flush()
wifi_up()
name = badge.nvs_get_str("owner", "name", "Hacker1337")
s = socket.socket()
ai = socket.getaddrinfo("151.216.199.76", 3000)
addr = ai[0][-1]
s.connect(addr)
s.send(bytes(name+": "+"hello! \n", 'utf-8'))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: thread.start_new_thread(send_message, (pressed,)))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: thread.start_new_thread(send_message, (pressed,)))

while True:
	text = s.readline()
	lines.append(text)
  	render_term()



