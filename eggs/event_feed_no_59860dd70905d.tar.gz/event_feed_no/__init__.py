import urequests
import time
import badge
import ugfx
import wifi

wifi.init()
while not wifi.sta_if.isconnected():
    time.sleep(0.1)


png = '/lib/event_feed_no/stream_no.png'
url = 'https://dedi.vdwaa.nl/~jelle/feed_s5.png'


while True:
  r = urequests.get(url, stream=True)
  with open(png, 'wb') as out_file:
    out_file.write(r.content)
  badge.eink_png(0,0, png)  
  ugfx.flush()
  time.sleep(2)