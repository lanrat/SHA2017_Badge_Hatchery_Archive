import badge
badge.leds_enable()
badge.leds_set_state(str([255 for i in range(24)]))