# NYANCAT APPLICATION
# SHOWN ONCE AFTER SETUP

import ugfx, badge, appglue, deepsleep

def program_main():
    print("--- NYANCAT APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    badge.leds_init()
    h = 4
    badge.leds_send_data(bytes([51/h, 102/h, 255/h, 0,
                                153/h, 0/h, 255/h, 0,
                                255/h, 51/h, 0/h, 0,
                                255/h, 255/h, 0/h, 0,
                                153, 255/h, 0/h, 0,
                                0/h, 255/h, 0/h, 0]), 24)
    try:
        badge.eink_png(0,0,'/lib/nyancat/nyancat.png')
    except:
        ugfx.string(0, 0, "NYANCAT LOAD ERROR nyancat.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(5000)
    appglue.start_app("") # Return home

# Start main application
program_main()