import ugfx, appglue
import ujson as json
import wifi, badge
import gc
import urequests as requests
import time, utime

ugfx.init()
wifi.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for Badge...","Roboto_Regular12", 0)
ugfx.flush()
time.sleep(3)

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()


messages = []
index_counter=0
def get_messages():
    gc.collect()
    try:
        data = requests.get("https://slack.com/api/channels.history?token=xoxp-222140683761-223564779030-223566349494-4f253c3185f11a91479c7d33ba7dd712&channel=C6JMKFHRS&unreads=1&count=8")
    except:
        print("Could not download JSON!")
        time.sleep(1)
        return
    try:
        global messages
        messages = json.loads(str(data.text))
    except:
        data.close()
        print("Could not decode JSON!")
        time.sleep(1)
        return
    data.close()
    message_array = []
    for message in messages['messages']:
        text=str(message['text'])
        ts=str(message['ts']).encode("utf-8")
        ts=ts[:10]
        year, month, mday, hour, minute, second, weekday, yearday = utime.localtime(int(ts))
        message_array.append("{}/{} {}:{} {}".format(month, mday, hour, minute, text))
    return list(reversed(message_array))

def display_next(messages,pressed):
    global index_counter
    if (pressed):
        index_counter = index_counter+8
    if index_counter>len(messages)-1:
    	index_counter=0
    ugfx.clear(ugfx.WHITE)
    for x in range(0,8):
    	if index_counter+x<len(messages):
    		ugfx.string(5,(x*15),(messages[index_counter+x]),"Roboto_Regular12",ugfx.BLACK)
    ugfx.flush()

def display_prev(messages,pressed):
    global index_counter
    if (pressed):
        index_counter=index_counter-8
    if index_counter<0:
    	index_counter=0
    ugfx.clear(ugfx.WHITE)
    message_text= (messages[index_counter])
    ugfx.string(5,50,message_text,"Robot_Regular12",ugfx.BLACK)
    ugfx.flush()

def passout():
    appglue.start_app("")

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, lambda pressed: display_next(messages,pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: display_prev(messages,pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: passout())

def main():
    while True:
        messages = get_messages()
        display_next(messages,0)
        time.sleep(5)

main()

speed = 0.1

def speed_inc(pressed):
    global speed;
    if(pressed):
        speed -= 0.01
        if speed < 0.05:
            speed = 0.05

def speed_dec(pressed):
    global speed;
    if(pressed):
        speed += 0.01
    
def loop_leds(color):
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color[:4])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color[:8])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color )
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0] + color + [0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0] + color + [0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color[4:] + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color[8:] + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: speed_inc(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: speed_dec(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))
badge.leds_init()
badge.leds_enable()

leds_array = bytes(24)

while True:
    # green
    color = [255, 0, 0, 0, 25, 0, 0, 0, 5, 0, 0, 0]
    loop_leds(color)
    loop_leds(color)
    # red
    color = [0, 255, 0, 0, 0, 25, 0, 0, 0, 5, 0, 0]
    loop_leds(color)
    loop_leds(color)
    # blue
    color = [0, 0, 255, 0, 0, 0, 25, 0, 0, 0, 5, 0]
    loop_leds(color)
    loop_leds(color)