from game_of_life import game_of_life
