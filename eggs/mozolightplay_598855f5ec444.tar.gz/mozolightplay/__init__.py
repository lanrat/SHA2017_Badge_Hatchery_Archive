import badge
import ugfx
import time
from random import randint
import appglue

badge.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()
ugfx.LUT_FULL
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.input_init()
ugfx.init()

def home(pressed):
    if (pressed):
        appglue.start_app("")
    
def buzz(pressed):
  if pressed:
	badge.vibrator_activate(0xFF)

def rood(pressed):
  if pressed:
    local_leds_array = bytes(24)
    r = 80
    g = 0
    b = 80
    w = 80
    local_leds_array = local_leds_array[4:] + bytes([r, g, b, w, 24])
    badge.leds_send_data(local_leds_array)
    time.sleep(10)
    
ugfx.input_attach(ugfx.JOY_RIGHT, buzz)
ugfx.input_attach(ugfx.JOY_LEFT, buzz)
ugfx.input_attach(ugfx.JOY_UP, buzz)
ugfx.input_attach(ugfx.JOY_DOWN, buzz)
ugfx.input_attach(ugfx.JOY_RIGHT, buzz)
ugfx.input_attach(ugfx.BTN_A, rood)
ugfx.input_attach(ugfx.BTN_B, home)
ugfx.input_attach(ugfx.BTN_START, buzz)
ugfx.input_attach(ugfx.BTN_SELECT, buzz)

ugfx.string_box(0,10,296,26, "Mozolightplay", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,30,296,26, "Druk op [B] om deze app te verlaten", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,40,296,26, "Press [B] to exit this app", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,50,296,26, "bekijk onze website", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,60,296,26, "Check out our website", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,70,296,26, "http://www.imozocom.jouwweb.nl/", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.flush()
badge.eink_png(245,73,'/lib/mozolightplay/mozo.png')

leds_array = bytes(24)

while True:
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[4:] + bytes([randint(128, 255), randint(0, 255), randint(0, 128), 0])
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[4:] + bytes([randint(0, 128), randint(0, 255), randint(128, 255), 0])