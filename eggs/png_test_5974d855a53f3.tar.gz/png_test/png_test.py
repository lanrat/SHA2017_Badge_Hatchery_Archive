import ugfx, badge, utime

def show_wink():
    for x in range(1, 7):
        try:
            badge.eink_png(0,0,'/lib/png_test/wink%s.png' % x)
        except:
            ugfx.string(0, 0, "LOAD ERROR #"+str(x), "Roboto_Regular12", ugfx.BLACK)
		
        ugfx.flush(ugfx.LUT_FULL)
        badge.eink_busy_wait()
        utime.sleep(0.2)

def program_main():
    print("--- Animated Winkekatze ---")
    ugfx.init()
    
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.set_lut(ugfx.LUT_FULL)
    show_wink()

# Start main application
program_main()