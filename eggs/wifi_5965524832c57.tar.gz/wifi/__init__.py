import dialogs, ugfx, badge, deepsleep

ssid = badge.nvs_get_str("badge", "wifi.ssid", "SHA2017-insecure")
ssid = dialogs.prompt_text("WiFi SSID", ssid)
if ssid:
  badge.nvs_set_str("badge", "wifi.ssid", ssid)
  
password = badge.nvs_get_str("badge", "wifi.password", "")
password = dialogs.prompt_text("WiFi password", password)
if password:
  badge.nvs_set_str("badge", "wifi.password", password)
  
ugfx.clear(ugfx.WHITE)

ugfx.string(80,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(60,50,"ReBooting","PermanentMarker36",ugfx.BLACK)
str_len = ugfx.get_string_width("ReBooting","PermanentMarker36")
ugfx.line(60, 86, 74 + str_len, 86, ugfx.BLACK)
ugfx.line(70 + str_len, 52, 70 + str_len, 84, ugfx.BLACK)
ugfx.string(70,90,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)

ugfx.flush(ugfx.LUT_FULL)

badge.eink_busy_wait()
deepsleep.start_sleeping(1)