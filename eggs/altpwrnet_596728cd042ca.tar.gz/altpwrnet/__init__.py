import ugfx, gc, wifi, badge, deepsleep, urandom
from time import *
psuvoltage='00.00'
psucurrent='00.00'

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
  
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Connecting to MQTT...","Roboto_Regular12", 0)
ugfx.flush()

from umqtt.simple import MQTTClient


# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    global psuvoltage
    global psucurrent
    print((topic, msg))
    print(msg.decode('utf-8'))

    if(topic.decode('utf-8')=='AltPwr/PSU/Voltage'):
    	psuvoltage = msg.decode('utf-8')
    if(topic.decode('utf-8')=='AltPwr/PSU/Current'):
    	psucurrent = msg.decode('utf-8')

    ugfx.clear(ugfx.WHITE) 
    ugfx.string(10,5,"ALTPWR.NET","Roboto_Black22", 0)
    ugfx.string(155,6,"BUILDING A VERSATILE","Roboto_Regular12", 0)
    ugfx.string(155,16,"DC POWER GRID","Roboto_Regular12", 0)
    ugfx.line(5,28,291,28,ugfx.BLACK)
    
    ugfx.string(5, 33,"PSU:", "Roboto_Black22", ugfx.BLACK)
    
    ugfx.string(50,31,psuvoltage,"PermanentMarker22",ugfx.BLACK)
    ugfx.string(150,31,psucurrent,"PermanentMarker22",ugfx.BLACK)
    ugfx.flush()

def main(server="mqtt.sha2017.org"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"AltPwr/PSU/#")
    print('mqtt set')
    c.check_msg()
    while True:
        c.check_msg()
        sleep(1)
    c.disconnect()
    
def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
        
ugfx.input_attach(ugfx.BTN_B, go_home)
main()