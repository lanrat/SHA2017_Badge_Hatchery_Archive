### Author: Mattsi Jansky
### Description: Testing network functionality
### Category: Unpublished
### License: MIT
### Appname: nettest
### Built-in: no

try:
    import usocket as socket
except:
    import socket
import badge
import ugfx
import sys
import deepsleep
import network
import wifi
import time
import urequests as requests
import gc

def network_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    wifi_up()
    cleanScreen()
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.text(10, 10, "Testing network", ugfx.BLACK)
    ugfx.flush()
    result = sendGET("https://jsonplaceholder.typicode.com/posts/1")
    ugfx.text(10, 50, result, ugfx.BLACK)
    ugfx.flush()
    result = sendPOST("https://jsonplaceholder.typicode.com/posts/1", type('',(object,),{'bar':'foo','x':1,'y':2})())
    ugfx.text(10, 50, result, ugfx.BLACK)
    ugfx.flush()


def cleanScreen():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def reboot(wut):
    deepsleep.reboot()

def wifi_up():
  wifi.init()
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  return wifi.sta_if.ifconfig()[0]

def sendGET(url):
    r = requests.get(url)
    gc.collect()
    data = r.json()
    r.close()

    print(data)
    return data

def sendPOST(url, data):
    r = requests.post(url, json = data)
    gc.collect()
    data = r.json()
    r.close()

    print(data)
    return data

network_test()