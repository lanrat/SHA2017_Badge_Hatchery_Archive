import ugfx, wifi, network
from time import sleep
ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"wifi is connected. Start scanning...","Roboto_Regular12", 0)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = network.scan('bssid')
ugfx.clear(ugfx.WHITE);
n = 5
for AP in scanResults:
  ugfx.string_box(0,n,296,20, AP[0],"Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
  n = n+15
ugfx.flush()
ugfx.input_attach(ugfx.BTN_B, go_home)