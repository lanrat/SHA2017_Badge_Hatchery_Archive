### Author: Mattsi Jansky
### Heavily modified from Sam Delaney and Sebastius' Game of Life app.
### Description: ???
### Category: Games
### License: MIT
### Appname: GoL
### Built-in: no

import badge
import ugfx
import urandom
import deepsleep

class Position:
	
	def __init__(self, x, y):
		self.x = x
		self.y = y

class Entity:
	
	def __init__(self, render, name, position):
		self.render = render
		self.name = name
		self.position = position

class Tile:
	
	def __init__(self, render):
		self.render = render
		self.entity = None
	
	def __str__(self):
		if(self.entity is not Null):
			return self.entity.render
		else:
			return render

def emj_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_RIGHT, reboot)
    ugfx.input_attach(ugfx.JOY_LEFT, reboot)
    ugfx.input_attach(ugfx.JOY_UP, reboot)
    ugfx.input_attach(ugfx.JOY_DOWN, reboot)
    ugfx.input_attach(ugfx.JOY_RIGHT, reboot)
    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    width = 36
    height = 11
    cell_width = 8
    cell_height = 12
    grid = [[Tile('.') for x in range(height)] for y in range(width)]

    def display():
        for x in range(0, width):
            for y in range(0, height):
                ugfx.text(x * cell_width,y * cell_height,str(grid[x][y]),ugfx.BLACK)
        badge.eink_busy_wait()
        ugfx.flush()

    def step():
        for x in range(width):
            for y in range(height):
                grid[x][y] = grid[x][y]

    while True:
        step()
        display()

def reboot(wut):
    deepsleep.reboot()

emj_test()