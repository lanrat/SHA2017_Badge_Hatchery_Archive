import ugfx, badge, sys

ugfx.init()
badge.init()

def start():
    del sys.modules['splash']
    sys.modules['splash'] = __import__('tmpmod')
    import splash
    splash.draw(0)

start()