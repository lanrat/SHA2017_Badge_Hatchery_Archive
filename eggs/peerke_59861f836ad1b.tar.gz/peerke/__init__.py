import ugfx, badge

def program_main():
    print("--- PEERKE APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    badge.leds_init()
#    badge.leds_send_data(bytes([51, 102, 255, 0,
#                            153, 0, 255, 0,
#                            255, 51, 0, 0,
#                            255, 255, 0, 0,
#                            153, 255, 0, 0,
#                            0, 255, 0, 0]), 24)
    try:
    	badge.eink_png(0,0,'/lib/peerke/rene2.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()

# Start main application
program_main()