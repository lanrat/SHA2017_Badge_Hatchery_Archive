import network, time, appglue, ugfx
import urequests as req

ugfx.input_init()
ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()

def home(pressed):
  if pressed:
    appglue.home()

def setup():
    print("starting service")
    loop()

def loop():
    #name = "f0x"
    while True:
        sta_if = network.WLAN(network.STA_IF)
        sta_if.active(True)
        scanResults = sta_if.scan()
        ssidSet = set([ AP[0] for AP in scanResults ])
        for SSID in ssidSet:
            if SSID == b'lainchan_HQ':
                print("I'm home!")
                sta_if.connect("lainchan_HQ", "lookitsauselesspassword")
                timeout = 4
                while not sta_if.isconnected():
                    time.sleep(0.1)
                    timeout = timeout - 1
                    if (timeout<1):
                        sta_if.active(True)
                r = req.get("http://192.168.4.1/presence")
                print(r)

        return 100
def draw(x, y):
    return 0
ugfx.input_attach(ugfx.BTN_B, home)
loop()