import ugfx, badge #dialogs
#import utime

def show_redlight():
    badge.eink_png(0,0,'/lib/redlight/redlight_bw.png')

def program_main():
    show_redlight()
    #msg = dialogs.prompt_text("Message: ", str)
    #topic = dialogs.prompt_text("To: ", str)
    #ugfx.string(0, 20, "to: "+str(topic), "Roboto_Regular12", ugfx.BLACK)
    #ugfx.string(2, 20, "send: "+str(msg), "Roboto_Regular12", ugfx.BLACK)


# Start main application
program_main()
