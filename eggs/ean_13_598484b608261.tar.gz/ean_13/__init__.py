import ugfx
import badge
from time import sleep

badge.init()
ugfx.init()
badge.eink_init()
​
# two groups og 6 digits with one leading digit
# 7 bits/bars per digit
# first digit decides pattern
# 296×128 px display

bar_width = 2
bar_len = 40
sep_len = bar_len + 10
x = int((296-53*bar_width)/2)
y = 10
​
first_dig_to_parity = {
  0: "LLLLLLRRRRRR",
  1: "LLGLGGRRRRRR",
  2: "LLGGLGRRRRRR",
  3: "LLGGGLRRRRRR",
  4: "LGLLGGRRRRRR",
  5: "LGGLLGRRRRRR",
  6: "LGGGLLRRRRRR",
  7: "LGLGLGRRRRRR",
  8: "LGLGGLRRRRRR",
  9: "LGGLGLRRRRRR"
}
​
dig_encoding = {
  0: {'L': "0001101", 'G': "0100111", 'R': "1110010"},
  1: {'L': "0011001", 'G': "0110011", 'R': "1100110"},
  2: {'L': "0010011", 'G': "0011011", 'R': "1101100"},
  3: {'L': "0111101", 'G': "0100001", 'R': "1000010"},
  4: {'L': "0100011", 'G': "0011101", 'R': "1011100"},
  5: {'L': "0110001", 'G': "0111001", 'R': "1001110"},
  6: {'L': "0101111", 'G': "0000101", 'R': "1010000"},
  7: {'L': "0111011", 'G': "0010001", 'R': "1000100"},
  8: {'L': "0110111", 'G': "0001001", 'R': "1001000"},
  9: {'L': "0001011", 'G': "0010111", 'R': "1110100"}
}

digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2]
​
def clear_paper():
    for i in range(2):
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

def digits_to_code(digits):
    parity = first_dig_to_parity[digits[0]]
    code = []
    for i in range(1, len(digits)):
        code += dig_encoding[digits[i]][parity[i-1]]
    return code

def draw_seperator(x, y, bar_width, sep_len):
    for pos_x in [x, x+2*bar_width]:
        ugfx.fill_rounded_box(pos_x, y, bar_width, sep_len, 0, ugfx.BLACK)

def draw_code(code, x, y, bar_width, bar_len, sep_len):
    pos_x = x
    draw_seperator(pos_x, y, bar_width, sep_len)
    pos_x += 3*bar_width

    for i in range(int(len(code)/2)):
        if code[i] == '1':
            ugfx.fill_rounded_box(pos_x, y, bar_width, bar_len, 0, ugfx.BLACK)
        pos_x += bar_width

    pos_x += bar_width
    draw_seperator(pos_x, y, bar_width, sep_len)
    pos_x += 3*bar_width
    pos_x += bar_width

    for i in range(int(len(code)/2), len(code)):
        if code[i] == '1':
            ugfx.fill_rounded_box(pos_x, y, bar_width, bar_len, 0, ugfx.BLACK)
        pos_x += bar_width

    draw_seperator(pos_x, y, bar_width, sep_len)

    ugfx.flush()

clear_paper()
draw_code(code, x, y, bar_width, bar_len, sep_len)
​
sleep(1)
