import usocket as socket
import wifi
import time
import badge
import ugfx
import ure
import dialogs
import appglue

badge.init()
ugfx.init()
wifi.init()

messages = ['','','','','','','','','','']

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"IRC pager","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.flush()

time.sleep(2)

HOST = "chat.freenode.net"
PORT = 6667

NICK = badge.nvs_get_str('owner', 'name', 'Hacker1337')+"_badge"
REALNAME = "SHA2017 attendant"

CHANNEL = badge.nvs_get_str("irc", "channel", "ACKspaceBots")

def changechan():
    global CHANNEL
    chan = dialogs.prompt_text("Enter channel", CHANNEL)
    if chan != CHANNEL:
        badge.nvs_set_str("irc", "channel", chan)
        CHANNEL = chan  

def exit_app():
    global s
    s.send(bytes("QUIT :%s\r\n" % "Pressed Start", "UTF-8"))
    s.close()
    appglue.home()

def press_a():
    global s
    s.send(bytes("PRIVMSG %s :%s\r\n" % (CHANNEL, "button A: affirmative"), "UTF-8"))

def press_b():
    global s
    s.send(bytes("PRIVMSG %s :%s\r\n" % (CHANNEL, "button B: negative"), "UTF-8"))

def alert():
    badge.leds_send_data(''.join(['\0\0\0\50' for i in range(6)]))
    badge.vibrator_activate(0b11)
    badge.leds_send_data(''.join(['\0\0\0\0' for i in range(6)]))
    time.sleep(0.5)


if CHANNEL != "":
    changechan()

ugfx.input_init()
#TODO: make sure app doesn't hang up when displaying prompt mode
#ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: changechan())
ugfx.input_attach(ugfx.BTN_START, lambda pressed: exit_app())
ugfx.input_attach(ugfx.BTN_A, lambda pressed: press_a())
ugfx.input_attach(ugfx.BTN_B, lambda pressed: press_b())

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"IRC pager","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(0,24,"Connecting to %s:%s #%s" % (HOST,PORT,CHANNEL),"Roboto_Regular12",ugfx.BLACK)
ugfx.flush()

s = socket.socket()
s.connect((HOST, PORT))

s.send(bytes("NICK %s\r\n" % NICK, "UTF-8"))
s.send(bytes("USER %s 0 * :%s\r\n" % (NICK, REALNAME), "UTF-8"))
s.send(bytes("JOIN #%s\r\n" % CHANNEL, "UTF-8"));
s.setblocking(False)

while 1:
    line = s.readline()
    if line is not None:
        parts = line.rstrip().split()
        
        if parts:
            if(parts[0] == b"PING"):
                s.send(bytes("PONG %s\r\n" % line[1], "UTF-8"))
            if(parts[1] == b"PRIVMSG"):
                msg = b' '.join(parts[3:])
                rnick = line.split(b'!')[0]
                messages = messages[1:] + [rnick+msg]
                ugfx.clear(ugfx.WHITE)
                for i, m in enumerate(messages):
                    ugfx.string(0,i*12,m,"Roboto_Regular12",ugfx.BLACK)
                ugfx.flush()
                if ure.match(".*"+NICK+".*", msg):
                    alert()
                    alert()
            if(parts[1] == b"JOIN"):
                msg = b' '.join(parts[3:])
                rnick = line.split(b'!')[0]
                messages = messages[1:] + [rnick+msg]
                if ure.match(".*"+NICK+".*", rnick):
                    ugfx.string(0,36,"Joined!","Roboto_Regular12",ugfx.BLACK)
                    ugfx.flush()
            print(line)