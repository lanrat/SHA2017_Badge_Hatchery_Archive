import machine
from umqtt.simple import MQTTClient

AMP_MODE = "tkkrlab/amp/mode"
AMP_VOLUME = "tkkrlab/amp/volume"
AMP_RAW = "tkkrlab/amp/raw"
AMP_POWER = (1 << 0) # Amp Power enable bit
AMP_TAPE1 = (1 << 1) # Tape 1 enable bit
AMP_TAPE2 = (1 << 2) # Tape 2 enable bit
AMP_AUX_CD = (1 << 3) # togles between Aux and Cd


client_id = machine.unique_id()

server = b"mrmeeseeks.tkkrlab"
client = MQTTClient((b"AmpControl[%s]" % (client_id)), server)
client.connect()
client.publish(AMP_MODE, 0)
client.disconnect()