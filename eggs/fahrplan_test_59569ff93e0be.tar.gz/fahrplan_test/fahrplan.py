import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.thickline(96, 0, 95, 128, ugfx.BLACK)
ugfx.thickline(192, 0, 192, 128, ugfx.BLACK)

