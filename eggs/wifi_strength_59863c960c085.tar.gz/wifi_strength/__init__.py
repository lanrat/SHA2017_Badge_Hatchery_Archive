import ugfx
import badge
import network
strength = 0
ugfx.init()
badge.init()
ugfx.clear(ugfx.BLACK)

network_if = network.WLAN(network.STA_IF)
network_if.active(True)
for network in network_if.scan():
	if(network[0].decode("ascii")== badge.nvs_get_str("badge","wifi.ssid","")):
		strength = network[3]
        ugfx.string(130, 50, str(strength), "PermanentMarker22", ugfx.WHITE)