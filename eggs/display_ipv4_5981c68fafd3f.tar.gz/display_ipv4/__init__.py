import badge
import ugfx
import network
import time
badge.init()
ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)

wifi_ssid = badge.nvs_get_str("badge", "wifi.ssid", "SHA2017-insecure")
wifi_psk = badge.nvs_get_str("badge", "wifi.password", "")


ugfx.string(0, 0, "Attempting to connect to " + wifi_ssid + "...", "pixelade13", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
if wifi_psk == "":
  netif.connect(wifi_ssid)
else:
  netif.connect(wifi_ssid, wifi_psk)
netif.isconnected()

cur_ip = netif.ifconfig()[0]
dots = ""
while True:
  if cur_ip == "0.0.0.0":
    ugfx.string(0, 13, "waiting to receive an IPv4 address..." + dots, "pixelade13", ugfx.BLACK)
    ugfx.flush()
    time.sleepms(500)
    cur_ip = netif.ifconfig()[0]
    dots = dots + "."
    pass
  else:
    break

ugfx.string(0, 26, "got ip: "  + cur_ip, "pixelade13", ugfx.BLACK)
ugfx.string(0, 39, "Press a to return to menu....", "pixelade13", ugfx.BLACK)
ugfx.flush()