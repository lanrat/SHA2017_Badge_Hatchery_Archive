import network
import usocket as socket
import badge
import ugfx

badge.vibrator_init()

ugfx.init()
ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)

ugfx.string(140, 75, "CampCast Receiver","Roboto_BlackItalic24", ugfx.BLACK)

# Network config
netif = network.WLAN(network.STA_IF)
netif.active(True)
netif.connect("Crazy Belgians")

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(('', 2115))

# Main loop
while True:
    m = sock.recvfrom(4096)
    print("Received message {}".format(m))
    badge.vibrator_activate(1)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(140, 75, m,"Roboto_BlackItalic24", ugfx.BLACK)
