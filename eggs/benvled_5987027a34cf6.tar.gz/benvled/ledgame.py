import ugfx, badge, time, random
# import appglue

#def action_home(pressed):
#    if (pressed):
#        appglue.home()

def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Homescreen text", "PermanentMarker22", ugfx.BLACK)
    global serviceText
    global serviceFont
    if (len(serviceText)>0):
        ugfx.string(0, 25, "Service is " + ("enabled!" if serviceEnabled else "disabled."), "Roboto_Regular12", ugfx.BLACK)
        ugfx.string(0, 38, "Press start to " + ("" if serviceEnabled else "not ") + "see it in action.", "Roboto_Regular12", ugfx.BLACK)
    else:
        ugfx.string(0, 25,  "No text! Setup with SELECT", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*1, "UP: Enable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*2, "DOWN: Disable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*3, "START: Go to homescreen", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*4, "SELECT: Enter text", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*5, "A: Font: " + serviceFont, "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()

def action_up(pressed):
    if pressed:
        print("[LEDGAME] UP")

def action_down(pressed):
    if pressed:
        print("[LEDGAME] DOWN")

def action_left(pressed):
    if pressed:
        print("[LEDGAME] LEFT")

def action_right(pressed):
    if pressed:
        print("[LEDGAME] RIGHT")

def action_select(pressed):
    if pressed:
        print("[LEDGAME] SELECT")

def action_start(pressed):
    if pressed:
        print("[LEDGAME] START")

def action_b(pressed):
    if pressed:
        print("[LEDGAME] B")

def action_a(pressed):
    if pressed:
        print("[LEDGAME] A")

def action_instructions(pressed):
    if pressed:
        print("[LEDGAME] Instructions request")
        instructions()

def instructions():
    print("[LEDGAME] instructions.")
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"Instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"A random LED will light up","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"The objective is to press the corresponding button before it dies out","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"Have fun! Press A/B to start, SELECT to quit.","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()

def program_init():
    print("[LEDGAME] init.")
    ugfx.init()
    ugfx.input_init()
    badge.init()
    badge.leds_init()
    badge.vibrator_init()
    global leddata
    leddata = bytearray([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

def action_quit(pressed):
    if pressed:
        print("[LEDGAME] Quit.")
        import launcher

def action_start(pressed):
    if pressed:
        print("[LEDGAME] Start!")
        game_start()

def leds_off():
    badge.leds_send_data(bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), 24)

def leds_on(brightness = 255):
    badge.leds_send_data(bytes([brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness]), 24)

def light_led(led, r, g, b, w):
    if led > 6:
        print("[LEDGAME] BUG - NO SUCH LED " + str(led))
        return
    global leddata
    if len(leddata) != 24:
        leddata = bytearray([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    print("[LEDGAME] Led " + str(led) + " to RGBW %d/%d/%d/%d" % (r, g, b, w))
    # GRBW
    leddata[(led-1) * 4 + 0] = g
    leddata[(led-1) * 4 + 1] = r
    leddata[(led-1) * 4 + 2] = b
    leddata[(led-1) * 4 + 3] = w
    badge.leds_send_data(bytes(leddata), len(leddata))

def game_start():
    print("[LEDGAME] Game start.")
    # rehook buttons for game
    ugfx.input_attach(ugfx.BTN_B, action_b)
    ugfx.input_attach(ugfx.BTN_A, action_a)
    # Draw button connections
    ugfx.clear(ugfx.BLACK)
    # We'll assume 296 for now. 296 / 6 =~ 49
    ugfx.line(23, 0, 23, ugfx.height(), ugfx.WHITE)
    ugfx.line(72, 0, 72, ugfx.height(), ugfx.WHITE)
    ugfx.line(121, 0, 121, ugfx.height(), ugfx.WHITE)
    ugfx.line(170, 0, 170, ugfx.height(), ugfx.WHITE)
    ugfx.line(219, 0, 219, ugfx.height(), ugfx.WHITE)
    ugfx.line(280, 0, 280, ugfx.height(), ugfx.WHITE)
    ugfx.flush()
    lives = 3
    while lives > 0:
        # Light a random LED
        led = random.randint(1,6)
        light_led(led, 255, 255, 255, 255)
        time.sleep(0.1)
        light_led(led, 128, 128, 128, 128)
        time.sleep(0.1)
        light_led(led, 128, 64, 64, 0)
        time.sleep(0.1)
        light_led(led, 256, 0, 0, 0)
        time.sleep(0.1)
        light_led(led, 0, 0, 0, 0)
        badge.vibrator_activate(1)
        lives = lives - 1
    game_over()

def game_over():
    print("[LEDGAME] main menu.")
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"GAME OVER","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"Start: instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"Select: Quit game ","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"B or A: Start game","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()
    leds_off()
    leds_on()
    badge.vibrator_activate(7)
    time.sleep(0.1)
    leds_off()
    badge.vibrator_activate(3)
    time.sleep(0.1)
    leds_on()
    badge.vibrator_activate(7)
    time.sleep(0.1)
    leds_off()
    badge.vibrator_activate(0)
    ugfx.input_attach(ugfx.BTN_B, action_start)
    ugfx.input_attach(ugfx.BTN_A, action_start)

def program_main_menu():
    print("[LEDGAME] main menu.")
    ugfx.input_attach(ugfx.JOY_UP, action_up)
    ugfx.input_attach(ugfx.JOY_DOWN, action_down)
    ugfx.input_attach(ugfx.JOY_LEFT, action_left)
    ugfx.input_attach(ugfx.JOY_RIGHT, action_right)
    ugfx.input_attach(ugfx.BTN_SELECT, action_quit)
    ugfx.input_attach(ugfx.BTN_START, action_instructions)
    ugfx.input_attach(ugfx.BTN_B, action_start)
    ugfx.input_attach(ugfx.BTN_A, action_start)
    # ugfx.input_attach(ugfx.BTN_B, action_b)
    # ugfx.input_attach(ugfx.BTN_A, action_a)
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"Menu","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"Start: instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"Select: Quit game ","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"B or A: Start game","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()
    while True:
        pass

# Start game
program_init()
program_main_menu()
