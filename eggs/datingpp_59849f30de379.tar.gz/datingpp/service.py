import ugfx, badge, os

interval = 300000

def setup():
    pass

def loop():
    global interval
    enabled = badge.nvs_get_u8("datingpp","enable", 0)
    if enabled:
        return 9999999999
    else:
        return 0

def draw(y):
    enabled = badge.nvs_get_u8("datingpp","enable", 0)
    if enabled:
        datingchoice = badge.nvs_get_str("datingpp", "datingchoice", "something awesome!")

    	ugfx.clear(ugfx.BLACK)
    	ugfx.flush()
    	ugfx.clear(ugfx.WHITE)
    	ugfx.flush()

    	ugfx.string_box(0,10,296,26, "I'm still looking for", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,45,296,38, datingchoice, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,94,296,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.flush()
    
    return 0