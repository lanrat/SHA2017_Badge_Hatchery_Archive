from devlol_antivirus import devlol_antivirus

def setup():
    print('devlol_antivirus started by setup')

    devlol_antivirus.full_system_check_while_boot()
