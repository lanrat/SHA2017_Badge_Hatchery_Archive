if __name__ == 'main':
    print('devlol_antivirus started as application')

    from devlol_antivirus import devlol_antivirus

    import appglue

    devlol_antivirus.full_system_check()

    appglue.home()
else:
    print('devlol_antivirus was started with __name__: {}'.format(__name__))
