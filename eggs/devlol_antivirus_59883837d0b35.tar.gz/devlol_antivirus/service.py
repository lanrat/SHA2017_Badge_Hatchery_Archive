from devlol_antivirus import full_system_check

def setup():
    full_system_check()
