import ugfx, badge, time
import urequests as requests

import easywifi, easydraw

announcements = []

def setup():
    if not easywifi.status():
        if not easywifi.enable():
            return
    easydraw.msg("Checking Gas Anyway...", True)
    try:
        url = "http://roling.nu/SHA2017/test.json"
        r = requests.get(url)
        data = r.json()
        r.close()
        global announcements
        for result in data['results']:
            announcements.append(data['results'][result]['printouts']['Announcement'][0])
        easydraw.msg("Success!")
        easydraw.msg("Fetched "+str(len(announcements))+" announcements.")
    except:
        easydraw.msg("Whoops.")
    

def loop(c):
    return False

def draw(x,y):
    ypos = y
    pixels_used = 0
    global announcements
    c = len(announcements)
    if c>0:
        for i in range(0,c):
            text = announcements[i]
            try:
                badge.eink_png(x,ypos,'/lib/announcements_test/sha.png')
            except:
                ugfx.string(x, ypos, "[SHA]",'Roboto_Regular12',ugfx.BLACK)
            ugfx.string(x+41, ypos+1, text, "Roboto_Regular12",ugfx.BLACK)
            ypos += 14
    return ypos-y