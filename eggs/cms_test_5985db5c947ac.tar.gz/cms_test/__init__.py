import appglue
appglue.home()