import ugfx, wifi, badge, deepsleep
from . import urequests_pmenke as requests
from time import sleep

ugfx.init()
ugfx.input_init()
# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

limit = 5
offset=  0

def load_entries():
  set_message("Waiting for wifi...")
  
  # Wait for WiFi connection
  while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
  
  set_message("Got wifi. Loading data")
  
  data=None
  try:
    url = "http://188.40.158.211/phonebook.csv?limit="+str(limit)+"&offset="+str(offset)
    r = requests.get(url, headers={"Host": "poc.sha2017.org"}, host_override="poc.sha2017.org")
    data = r.text
    r.close()
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()
  try:
    entries = []
    for entry in data.split('\n'):
      if entry == "":
        continue
      extension = entry.split(',')[0]
      name = (entry.split(',')[1]).replace('"', '')
      entries.append((extension,name))
    set_message("Loaded "+str(len(entries))+" entries")
    return entries
  except Exception as e:
    set_message("Parsing error: "+str(e))
    sleep(10)

def draw(entries):
  set_message("Will now draw")
  y = 10
  ugfx.clear(ugfx.WHITE)
  for entry in entries:
    extension = entry[0]
    name = entry[1]
    ugfx.string(10, y, extension + " -> " + name, "Roboto_Regular12", 0)
    y += 20
  ugfx.flush()
  badge.eink_busy_wait()

up_state   = False
down_state = False
def up_pressed(pressed):
  if up_state and not pressed:
    offset += 1
    draw(load_entries())
  up_state = pressed

def down_pressed(pressed):
  if down_state and not pressed and offset > 0:
    offset -= 1
    draw(load_entries())
  down_state = pressed

try:
  draw(load_entries())
except Exception as e:
  set_message("Error: "+str(e))
  sleep(10)
  deepsleep.reboot()

ugfx.input_attach(ugfx.JOY_UP, up_pressed)
ugfx.input_attach(ugfx.JOY_DOWN, down_pressed)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: deepsleep.reboot())
  
while True:
  sleep(0.1)