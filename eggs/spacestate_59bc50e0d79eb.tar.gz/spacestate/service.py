import badge, easywifi, gc
import tasks.powermanagement as pm
import services 

timeout = 10*60*1000

def setup():
    pass
      
def loop():
    global timeout
    global png_data

    pm.kill()

    if not easywifi.enable(False):
        easydraw.msg("Wifi connetion failed")
        badge.eink_busy_wait()

        import appglue
        appglue.home()

    #get status from internet
    import urequests as requests
    data = requests.get(badge.nvs_get_str("spacestate", "url"))
    content=data.json()['state']['open']
    data.close()
    gc.collect()

    #get image
    if content == True: #space is open 
        imagenaam = 'badge_open.png'
    else:
        imagenaam = 'badge_closed.png'

    gc.collect()
    data=requests.get(badge.nvs_get_str("spacestate","image_url")+imagenaam)
    gc.collect()
    png_data = data.content
    data.close()
    gc.collect()

    services.force_draw()

    return 10*60*1000 #in mili sec, 10 

def draw(y):
    global png_data
    global timeout
    gc.collect()
    width,height,bitdepth,colortype=badge.eink_png_info(png_data)
    badge.eink_png(0, int((128-height)/2), png_data)
    badge.eink_busy_wait()
    return [10*60*1000,0]

    

    