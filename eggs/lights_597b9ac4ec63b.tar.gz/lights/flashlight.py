###Lights Egg
### Author: f0x
### License: GPLv3

## A flashlight app which does red and white light, and allows you to change the brightness

import badge, ugfx
import binascii
badge.leds_enable()
ugfx.input_init()
ugfx.init()

red = binascii.unhexlify("00ff00")
white = binascii.unhexlify("ffffff")

on = False
night_mode = False
brightness = 120

# ""borrowed"" from Cheerlights
def gamma(x, gamma, max_in, max_out):
    print("I:",x)
    r = int(pow(float(x)/float(max_in), gamma) * max_out + 0.5)
    if r < 0:
        r = 0
    if r > 255:
        r = 255
    return r

def hex_to_grbw_list(hex_str):
    global cheerlightsEnabled
    r,g,b = binascii.unhexlify(hex_str)
    w = 0
    g = gamma(g*1.1, 2.8, 255, 255)
    r = gamma(r,     2.8, 255, 255)
    b = gamma(b,     2.8, 255, 255)
    if r == g and g == b and b == 255:
        r,g,b = 0, 0, 0
        w = 255
    return [g, r, b, w]

def brightness_up(pressed):
	global brightness
	global on
	if pressed:
		brightness = brightness + 20
		if brightness > 255:
			brightness = 255
		if on:
			on = False
		else:
			on = True
		print(brightness)
        toggle(True)

def brightness_down(pressed):
	global brightness
	global on
	if pressed:
		brightness = brightness - 20
 		if brightness < 0:
			brightness = 0
		if on:
			on = False
		else:
			on = True
		print(brightness)
        toggle(True)

            
def toggle(pressed):
	global on
	if pressed:
		if on:
			on = False
			badge.leds_send_data(''.join(['\0' for i in range(24)]), 24)
			print("off")
		else :
			on = True
			if night_mode:
				#colors = [red, red, red, red, red, red]
				#red = hex(brightness)[2:]+"0000"
				#badge.leds_send_data(bytes(red+red+red+red+red+red), 24)
				color = "#ff0000"
				colors = hex_to_grbw_list(color)
				badge.leds_send_data(bytes(6*colors), 24)
			else :
				#colors = [white, white, white, white, white, white]
				hex_chars = hex(brightness)[:2]
				badge.leds_send_data(''.join(['\\'+hex_chars for i in range(24)]), 24)
				#white = hex(brightness)[2:]+hex(brightness)[2:]+hex(brightness)[2:]
				#badge.leds_send_data(bytes(white+white+white+white+white+white), 24)
			#all_leds = ''.join([''.join(["{0:02x}".format(int(x)) for x in [r, g, b, 0]]) for (r, g, b) in colors])
			#badge.leds_send_data(binascii.unhexlify(all_leds), 24)
			print("on")

def mode(pressed):
	global night_mode
	if pressed:
		if night_mode:
			night_mode = False
		else :
			night_mode = True
		ugfx.string(20, 20, "Night Mode: " + str(night_mode), "Roboto_Regular18", ugfx.BLACK)
        ugfx.flush()

ugfx.input_attach(ugfx.BTN_A, toggle)
ugfx.input_attach(ugfx.BTN_FLASH, toggle)
ugfx.input_attach(ugfx.JOY_LEFT, mode)
ugfx.input_attach(ugfx.JOY_RIGHT, mode)
ugfx.input_attach(ugfx.JOY_UP, brightness_up)
ugfx.input_attach(ugfx.JOY_DOWN, brightness_down)