# Based on the weather egg by Henk de Vries.
# https://badge.sha2017.org/projects/weather
import appglue, ugfx, wifi, deepsleep
import urequests as requests

#, gc, badge, deepsleep
#from time import *

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

# loading screen
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Loading the webpage...","Roboto_Regular12", 0)
ugfx.string(110,100,"https://badge.sha2017.org/","Roboto_Regular12", 0)
ugfx.flush()

sleep(10)

ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Whelp, that's as far as this egg will go for now. Bye!","Roboto_Regular12", 0)
ugfx.flush()

sleep(10)

appglue.home()
