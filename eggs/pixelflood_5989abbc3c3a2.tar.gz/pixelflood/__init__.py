import ugfx
import wifi
import usocket
#import _thread
from time import sleep

'''
There's still werk ta do. *werk-werk*
Just usin' the Hatchery 'cause it's soo easy to deploy.
Not working yet; hang in there :3
'''

def clear_screen():
    for color in [ugfx.WHITE, ugfx.BLACK, ugfx.WHITE]:
        ugfx.clear(color)
        ugfx.flush()


def socket_create(port):
    sock = usocket.socket()
    addr_info = usocket.getaddrinfo("0.0.0.0", port)
    addr = addr_info[0][-1]
    sock.bind(addr)
    
    ugfx.demo("a")
    sleep(0.3)
    
    sock.listen()
    
    ugfx.demo("b")
    sleep(0.3)
    
    return sock


def pixelflood_server(sock):
    while True:
        client_sock = sock.accept()[0]
        
    	ugfx.demo("c")
    	sleep(0.3)
        
        # fucks up ;_;
        #_thread.start_new_thread(pixelflood_handler, (client_sock,))
        pixelflood_handler(client_sock)


def pixelflood_handler(client_sock):
    while True:
        line = client_sock.readline().decode('ascii')
        if line == '' or line == '\r\n':
            break
        
        line_parts = line.split(' ')
        if len(line_parts) != 4  or line_parts[0] != 'PX':
            break
        
        try:
            int(line_parts[1])
            int(line_parts[2])
            int(line_parts[3], 16)
        except ValueError:
            break
        
        x, y = int(line_parts[1]), int(line_parts[2])
        col  = ugfx.BLACK if int(line_parts[3], 16) < 0x800000 else ugfx.WHITE
        
        if x in range (0, 296) and y in range(0, 128):
            ugfx.pixel(x, y, col)
            ugfx.flush()

    client_sock.close()


ugfx.init()
wifi.init()

# connect to wifi
clear_screen()
ugfx.demo('connecting :3')
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
clear_screen()
current_ip = wifi.sta_if.ifconfig()[0]
ugfx.demo(current_ip)

# start server
try:
    sock = socket_create(2323)
    pixelflood_server(sock)
except OSError:
    clear_screen()
    ugfx.string(0, 0, 'An OSError occured. Duno.', 'Roboto_Regular12', ugfx.BLACK)
except:
    clear_screen()
    ugfx.string(0, 0, 'Something failed \_(;_;)_/', 'Roboto_Regular12', ugfx.BLACK)
ugfx.flush()

while True:
    pass