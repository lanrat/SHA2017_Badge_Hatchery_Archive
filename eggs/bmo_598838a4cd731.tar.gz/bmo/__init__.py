import badge
import ugfx
import time
import random
import appglue

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def home(pressed):
    if pressed:
        appglue.home()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_B, home)

while True:
    ugfx.clear()
    badge.eink_png(0,0,"/lib/bmo/default.png")
    ugfx.flush()
    time.sleep(random.uniform(0.5,5))
    ugfx.clear()
    badge.eink_png(0,0,"/lib/bmo/happy.png")
    ugfx.flush()
    time.sleep(random.uniform(0.1,1))