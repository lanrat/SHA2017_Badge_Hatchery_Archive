# Dicts for Encoding
first_dig_to_parity = {
  0: "LLLLLLRRRRRR",
  1: "LLGLGGRRRRRR",
  2: "LLGGLGRRRRRR",
  3: "LLGGGLRRRRRR",
  4: "LGLLGGRRRRRR",
  5: "LGGLLGRRRRRR",
  6: "LGGGLLRRRRRR",
  7: "LGLGLGRRRRRR",
  8: "LGLGGLRRRRRR",
  9: "LGGLGLRRRRRR"
}

dig_encoding = {
  0: {'L': "0001101", 'G': "0100111", 'R': "1110010"},
  1: {'L': "0011001", 'G': "0110011", 'R': "1100110"},
  2: {'L': "0010011", 'G': "0011011", 'R': "1101100"},
  3: {'L': "0111101", 'G': "0100001", 'R': "1000010"},
  4: {'L': "0100011", 'G': "0011101", 'R': "1011100"},
  5: {'L': "0110001", 'G': "0111001", 'R': "1001110"},
  6: {'L': "0101111", 'G': "0000101", 'R': "1010000"},
  7: {'L': "0111011", 'G': "0010001", 'R': "1000100"},
  8: {'L': "0110111", 'G': "0001001", 'R': "1001000"},
  9: {'L': "0001011", 'G': "0010111", 'R': "1110100"}
}

def add_check_digit(digits):
    sum = 0
    for i in range(0, 12, 2):
        sum += digits[i] + 3*digits[i+1]
    return digits+[(-sum)%10]

def digits_to_code(digits):
  parity = first_dig_to_parity[digits[0]]
  code = []
  for i in range(1, len(digits)):
    code += dig_encoding[digits[i]][parity[i-1]]
  return code
