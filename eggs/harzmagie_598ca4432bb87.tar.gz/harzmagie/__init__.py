import ugfx, time, appglue, badge

sleeptime = 0.200

ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_A, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.home() if pushed else 0)

badge.eink_png(0,0,'/lib/harzmagie/harzmagie.png')
ugfx.flush()

badge.leds_enable()
while True:
  badge.leds_send_data(bytes([0,84,56, 0,98,65, 0,112,75, 0,116,84, 0,140,93, 0,153,102, 23,162,73, 46,171,129]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([0,98,65, 0,112,75, 0,116,84, 0,140,93, 0,153,102, 23,162,73, 46,171,129, 0,84,56]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([0,112,75, 0,116,84, 0,140,93, 0,153,102, 23,162,73, 46,171,129, 0,84,56, 0,98,65]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([0,116,84, 0,140,93, 0,153,102, 23,162,73, 46,171,129, 0,84,56, 0,98,65, 0,112,75]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([0,140,93, 0,153,102, 23,162,73, 46,171,129, 0,84,56, 0,98,65, 0,112,75, 0,116,84]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([0,153,102, 23,162,73, 46,171,129, 0,84,56, 0,98,65, 0,112,75, 0,116,84, 0,140,93]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([23,162,73, 46,171,129, 0,84,56, 0,98,65, 0,112,75, 0,116,84, 0,140,93, 0,153,102]), 24)
  time.sleep(sleeptime)
  badge.leds_send_data(bytes([46,171,129, 0,84,56, 0,98,65, 0,112,75, 0,116,84, 0,140,93, 0,153,102, 23,162,73]), 24)
  time.sleep(sleeptime)