import ugfx,badge,appglue,time,gc,wifi
import urequests as requests

def home(pushed):
    if(pushed):
        appglue.home()
        
def reset(pushed):
    global doreset
    if(pushed):
        badge.nvs_set_u16("porn","ts",0)
        doreset = True
        
def show_frame(frame):
    ugfx.clear()
    badge.eink_png(62,0,frame)
    ugfx.flush()

def get_frame(ts):
    r = requests.get("http://151.216.14.147/fabod.php?ts=%s"%(ts))
    return r.content

def init():
    global ts
    badge.init()
    wifi.init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, home)
    ugfx.input_attach(ugfx.BTN_SELECT, reset)
    ugfx.set_lut(ugfx.GREYSCALE)

    ugfx.clear(ugfx.WHITE);
    ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
    ugfx.flush()

    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

def run():
    global doreset
    doreset = False
    init()
    n = time.ticks_add(time.ticks_ms(),-(badge.nvs_get_u16("porn","ts",0)*1000))
    f = get_frame(n/1000)
    while True:
        show_frame(f)
        st = time.ticks_ms()
        tf = time.ticks_diff(st,n)/1000
        badge.nvs_set_u16("porn","ts",int(tf))
        if doreset:
            doreset = False
            n = time.ticks_ms()
        f = get_frame(time.ticks_diff(time.ticks_ms(),n)/1000)
        gc.collect()
        badge.eink_busy_wait()
        time.sleep(max(time.ticks_diff(time.ticks_add(st,500),time.ticks_ms())/1000,0))

if __name__ == 'porn':
    run()
