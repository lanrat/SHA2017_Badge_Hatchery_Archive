import ugfx, badge, time

def start():
    ugfx.clear(ugfx.BLACK)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(3)
    ugfx.string(20, 40, 'Hi there :p', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()

ugfx.init()
badge.init()
badge.leds_enable()
start()