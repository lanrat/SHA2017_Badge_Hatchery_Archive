import ugfx
#import esp
import wifi
import time
import usocket as socket
import appglue

HOST = 'bananapi'
PORT = 6600
#PASSWORD = 'password'

def show (str1="",str2="",str3=""):
  ugfx.clear(ugfx.BLACK)
  ugfx.string(15, 5, str1, "Roboto_Regular12", ugfx.WHITE)
  ugfx.string(15, 20, str2, "Roboto_Regular12", ugfx.WHITE)
  ugfx.string(15, 35, str3, "Roboto_Regular12", ugfx.WHITE)
  ugfx.flush()

def connect():
  try:
    show("Connecting to socket","on",HOST)
    s = socket.socket()
    s.connect(socket.getaddrinfo(HOST, PORT)[0][-1])
    try:
      reply = s.recv(4096).decode('utf-8')
      show("MPD version",reply.replace("OK ",""),"")
      return s
    except:
      return None
  except:
    return None

def mpdCommand ( command ):
  s.send(command + " \n")
  reply = s.recv(4096).decode('utf-8')
  return reply

def showNowPlaying ():
  reply = mpdCommand("currentsong")
  replylines = reply.split('\n')[:-2]
  mydict = dict( (line.split(": ", 1)) for line in replylines)
  if not 'Artist' in mydict:
    myArtist = ""
  else:
    myArtist = mydict['Artist']
  if not 'Title' in mydict:
    myTitle = ""
  else:
    myTitle = mydict['Title']
  if not 'File' in mydict:
    myFile = ""
  else:
    myTitle = mydict['File']
  show( myArtist , myTitle , myFile )

def vol_up (pushed):
  if pushed:
    mpdCommand("volume 5")
    showNowPlaying()
    print("vol_up")
def vol_down(pushed):
  if pushed:
    mpdCommand("volume -5")
    showNowPlaying()
    print("vol_down")
def prev(pushed):
  if pushed:
    mpdCommand("previous")
    showNowPlaying()
    print("previous song")
def nxt(pushed):
  if pushed:
    mpdCommand("next")
    showNowPlaying()
    print("next song")
#def select():
def return_home(pushed):
  if pushed:
    print("returning home")
    appglue.home()
#def A():
#def B():

ugfx.init()
wifi.init()

ugfx.input_attach(ugfx.JOY_UP, vol_up)
ugfx.input_attach(ugfx.JOY_DOWN, vol_down)
ugfx.input_attach(ugfx.JOY_LEFT, prev)
ugfx.input_attach(ugfx.JOY_RIGHT, nxt)
#ugfx.input_attach(ugfx.BTN_SELECT, select)
ugfx.input_attach(ugfx.BTN_START, return_home)
#ugfx.input_attach(ugfx.BTN_A, A)
#ugfx.input_attach(ugfx.BTN_B, B)

show("Connecting","teh","wifis")
while not wifi.sta_if.isconnected():
  time.sleep(0.1)
s = connect()
reply = mpdCommand("currentsong")
if "permission" in reply:
  try:
    if PASSWORD and len(PASSWORD) > 0:
      reply = mpdCommand("password " + PASSWORD )
      if reply.strip() == "OK":
        show("Password accepted")
      else:
        show("Password not accepted","","Exiting...")
        time.sleep(3)
        appglue.home()
  except:
    pass

while 1:
  showNowPlaying()
  time.sleep(10)

s.close()
