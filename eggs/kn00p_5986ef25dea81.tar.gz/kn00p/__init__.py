import badge, ugfx, time

def kn00p():
	badge.init()
	ugfx.init()

	ugfx.clear(ugfx.WHITE)
	ugfx.flush()


	badge.leds_init()
	badge.leds_enable()
	while 1==1:
		leds_array=[0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)

kn00p()