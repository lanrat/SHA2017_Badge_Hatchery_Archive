import ugfx, badge 

ugfx.init()

while True:
    for x in range(0, 9)
        badge.eink_png(0,0 '/lib/parrot/parrot%s.png' % x)
        ugfx.flush()
