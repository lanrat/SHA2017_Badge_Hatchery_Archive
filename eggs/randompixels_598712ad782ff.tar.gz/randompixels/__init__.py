import ugfx
from urandom import randint
from utime import sleep

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
listofobjs = []

while True:
    x = randint(0, 296)
    y = randint(0, 128)
    xy_list = [x, y]
    if xy_list not in listofobjs and len(listofobjs) < 37888:
        listofobjs.append(xy_list)
        ugfx.pixel(x, y, ugfx.BLACK)
        ugfx.flush()
#        sleep(0.01)
#    else:
#        listofobjs.remove(xy_list)
#        ugfx.pixel(x, y, ugfx.WHITE)
#        ugfx.flush()
#        sleep(0.01)