import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(206,63,'logobadge.png')
    return 0