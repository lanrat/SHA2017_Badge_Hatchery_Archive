import ugfx, gc, wifi, badge, time
import urequests as requests

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Getting info from uRadMonitor ...","Roboto_Regular12", 0)
ugfx.string(110,100,"https://uradmonitor.com/","Roboto_Regular12", 0)
ugfx.flush()

def show_screen(output):
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    badge.eink_png(0,0,output)
#    ugfx.string_box(88,0,208,25, "Push A to Refresh Data", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(88,25,208,25, "Push B to Put Badge to Sleep", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()

def refresh_data(pushed):
    if(pushed):
        show_screen(output)

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

#Json request info
headers = {'X-User-id': 'sha2017', 'X-User-hash': 'badge'}
url = 'https://data.uradmonitor.com/api/v1'
#unit = {0: '64000024', 1: '64000025', 2: '82000065'}
#duration = '36000'
#counter_unit = 0
#counter_meas = 8

#ugfx.clear(ugfx.WHITE)
#badge.eink_png(0,0,'/lib/SHAirQuality/urad3.png')
#ugfx.flush()
# fetching data
r = requests.get('http://data.uradmonitor.com/api/v1/chart/64000024/temperature/36000', headers=headers)
gc.collect()
output = r.json()
r.close()
show_screen(output)



#def startscreen():
#    ugfx.string_box(0,50,296,26, "Push Up or Down to Select Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(0,76,296,26, "Push Left or Right for Measurements on Current Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(0,102,296,26, "Push A to go Home and Refresh, B to Power Down", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.flush()
#    gc.collect()
#        
#def a_select():
#    ugfx.string_box(0,50,296,26, "A selected", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.flush()
#    gc.collect()
    
    
#startscreen()
#url+'/devices/'+unit_val+'/all/last'

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)
#ugfx.input_attach(ugfx.BTN_START, go_home)
#ugfx.input_attach(ugfx.BTN_SELECT, go_home)
#ugfx.input_attach(ugfx.JOY_UP, up_pushed)
#ugfx.input_attach(ugfx.JOY_DOWN, down_pushed)
#ugfx.input_attach(ugfx.JOY_LEFT, left_pushed)
#ugfx.input_attach(ugfx.JOY_RIGHT, right_pushed)