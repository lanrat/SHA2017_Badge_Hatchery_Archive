import badge
import ugfx

ugfx.string(50,50,"Snake Game","PermanentMarker22",ugfx.BLACK)