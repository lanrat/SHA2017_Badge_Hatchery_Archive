import time
import ugfx
for x in range(2):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
i = 0
while 1:
  while i < 102:
      ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
      time.sleep(0.05)
      ugfx.flush()
      ugfx.clear(ugfx.WHITE)
      i += 1

  while i > 0:
      ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
      time.sleep(0.05)
      ugfx.flush()
      ugfx.clear(ugfx.WHITE)
      i -= 1
      
  while i < 102:
      ugfx.string(i, 50, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
      time.sleep(0.05)
      ugfx.flush()
      ugfx.clear(ugfx.WHITE)
      i += 1

  while i > 0:
      ugfx.string(i, 50, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
      time.sleep(0.05)
      ugfx.flush()
      ugfx.clear(ugfx.WHITE)
      i -= 1