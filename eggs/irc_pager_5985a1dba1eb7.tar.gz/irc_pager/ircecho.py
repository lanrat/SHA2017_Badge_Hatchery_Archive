import usocket as socket
import wifi
import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"IRC pager","Roboto_BlackItalic24",ugfx.BLACK)

HOST = "chat.freenode.net"
PORT = 6667

NICK = badge.nvs_get_str('owner', 'name', 'Hacker1337')+"_badge"
REALNAME = "SHA2017 attendant"

s = socket.socket()
s.connect((HOST, PORT))

s.send(bytes("NICK %s\r\n" % NICK, "UTF-8"))
s.send(bytes("USER %s 0 * :%s\r\n" % (NICK, REALNAME), "UTF-8"))
s.send(bytes("JOIN #sha2017\r\n", "UTF-8"));

while 1:
    line = s.readline()
    parts = line.split()

    if parts:
        if(parts[0] == "PING"):
            s.send(bytes("PONG %s\r\n" % line[1], "UTF-8"))
        if(parts[1] == "PRIVMSG"):
            print("###")
        print(line)