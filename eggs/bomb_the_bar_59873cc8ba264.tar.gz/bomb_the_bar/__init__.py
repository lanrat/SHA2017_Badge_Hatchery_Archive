import badge
import ugfx
import network
import wifi
import time
import math
import dialogs
import usocket as socket
import _thread as thread

ugfx.init()
ugfx.string(50, 50, "popcorn","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

def quit(pressed):
    if(pressed):
        appglue.start_app("")
    ugfx.flush()
    
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))