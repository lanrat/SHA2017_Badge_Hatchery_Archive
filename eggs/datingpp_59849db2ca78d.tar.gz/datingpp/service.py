import ugfx, badge, os

interval = 300000

def setup():
    pass

def loop():
    global interval, seeded, message, swearing
    enabled = badge.nvs_get_u8("datingpp","enable", 0)
    if enabled:
	   return interval

    return 9999999999

def draw(y):
    enabled = badge.nvs_get_u8("datingpp","enable", 0)
    if enabled and seeded:
        datingchoice = badge.nvs_get_str("datingpp", "datingchoice", "something awesome!")

	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()

	ugfx.string_box(0,10,296,26, "I'm still looking for", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,45,296,38, datingchoice, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,94,296,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

	return [interval, 0]

