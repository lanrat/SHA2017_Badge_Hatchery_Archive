import dialogs, badge, easydraw, time, appglue

easydraw.msg("","Dating++", True)

savedchoice = badge.nvs_get_str("datingpp", "datingchoice", "")
datingchoice = dialogs.prompt_text("What are you looking for?", savedchoice)
if datingchoice:
	badge.nvs_set_str("datingpp", "datingchoice", datingchoice)

enabled = badge.nvs_get_u8("datingpp","enable", 0)
if enabled:
    enabled = 0
    easydraw.msg("Disabled Dating++!")
else:
    enabled = 1
    easydraw.msg("Enabled Dating++!")
    easydraw.msg("Go back to the splash and wait...")
enabled = badge.nvs_set_u8("datingpp","enable", enabled)

time.sleep(3)
appglue.home()

