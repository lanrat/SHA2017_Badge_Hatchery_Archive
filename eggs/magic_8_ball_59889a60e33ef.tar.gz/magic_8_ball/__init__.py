import ugfx, appglue

ugfx.init()
ugfx.input_init()

def home(pressed):
  if pressed:
    appglue.home()

ugfx.input_attach(ugfx.BTN_START, home)
ugfx.clear(ugfx.WHITE)
ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)