import usocket, appglue, badge, wifi, utime, uos

badge.init()
badge.leds_init()
badge.leds_enable()

wifi.init()
        
ssid = badge.nvs_get_str('badge', 'wifi.ssid', 'SHA2017-insecure')
print("Loading...", "WiFi: connecting to '"+ssid+"'...")
timeout = 100
while not wifi.sta_if.isconnected():
    utime.sleep(0.1)
    timeout = timeout - 1
    if (timeout<1):
        print("Error", "Timeout while connecting!")
        utime.sleep(5)
        appglue.home()
        break
    else:
        pass

sock = usocket.socket()
addr = usocket.getaddrinfo("151.216.93.210", 2342)
sock.connect(addr[0][-1])

def randomint():
  ranbytes = uos.urandom(2)
  return ranbytes[0] >> 8 | ranbytes[1]

#while True:
prev_pos = 10
for i in range(0, 10):
  ledinfo = [0] * 24;
  pos = randomint % 5
  if pos >= prev_pos:
  	pos = pos + 1
  prev_pos = pos
  pos = pos * 4
  ledinfo[pos+1] = 0xFF
  ledinfo[pos] = 0xAA
  ledinfo[pos+2] = 0x5E
  badge.leds_send_data(bytes(ledinfo), 24)
  for j in range(0, 1000):
    x = randomint() % 480
    y = randomint() % 264
    try:
        sock.send("PX {:d} {:d} FFAA5E\n".format(x,y).encode('utf-8'))
    except:
        print("send error")
        utime.sleep(1)
        break
sock.close()

badge.leds_disable()
appglue.home()