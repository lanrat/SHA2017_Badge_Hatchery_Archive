import os, appglue 

ransomware_list = ['ascii_porn', 'the_legend_of_zelda', 'internship', '1p0rn', 'another_hack_simulator']


def remove_dir(program):
    path = '/lib/' + program
    for files in os.listdir(path):
        os.remove(path + '/' + files)
    os.rmdir(path)


def remove_ransomware():
    installed_software = os.listdir('/lib')

    for program in installed_software:
        if program in ransomware_list:
            print("remove ransomware: {}".format(program))
            remove_dir(program)


remove_ransomware()

appglue.home()