import ugfx


def drawGraph(xpos,ypos,xsize,ysize,data,unit = ''):
    maxdata = xsize
    #Draw Frame
    ugfx.line(xpos      ,ypos      ,xpos+xsize,ypos      ,ugfx.BLACK)
    ugfx.line(xpos      ,ypos      ,xpos      ,ypos+ysize,ugfx.BLACK)
    ugfx.line(xpos      ,ypos+ysize,xpos+xsize,ypos+ysize,ugfx.BLACK)
    ugfx.line(xpos+xsize,ypos      ,xpos+xsize,ypos+ysize,ugfx.BLACK)
    #Find Max and min values
    minyval =data[0]
    maxyval =data[0]
    for d in data:
        if d>maxyval:
            maxyval=d
        if d<minyval:
            minyval=d
    print("[GRAPH] Min X:" + str(minyval) +  " MaxX:" + str(maxyval))
    dataCount = 0
    xstart = xpos+xsize
    ystart = ypos+ysize
    maxy = int(ysize*0.9)
    lastx= xstart
    lasty= ystart
    count = 0
    #Draw
    ugfx.string(xpos+1,ypos+1,str(data[-1])+unit, "Roboto_Regular12", ugfx.BLACK)
    for d in reversed(data):
        dataCount = dataCount +1
        if dataCount>maxdata:
            break
        x = xstart-count
        y = ystart-int(d/maxyval*maxy)
        ugfx.line(lastx,lasty,x,y,ugfx.BLACK)
        lastx = x
        lasty = y
        count = count+1
    ugfx.flush()
