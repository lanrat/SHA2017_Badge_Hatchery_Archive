import badge
import ugfx
import network
import usocket as socket
badge.init()
ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(0, 0, "Attempting to connect to SHA2017-insecure...", "pixelade13", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.connect("SHA2017-insecure")
netif.active(True)
netif.isconnected()
cur_ip = netif.ifconfig()[0]

ugfx.string(0, 13, "got ip: "  + cur_ip, "pixelade13", ugfx.BLACK)
ugfx.flush()