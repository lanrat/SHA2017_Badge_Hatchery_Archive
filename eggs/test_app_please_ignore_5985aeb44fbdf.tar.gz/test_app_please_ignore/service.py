import machine, utime, ugfx, appglue, badge, easyrtc, time, machine

def setup():
    pass

def loop():
    pass

def draw(y):
    lenny.render_creation(
            lambda w, h: (lenny.BADGE_EINK_WIDTH - w, y),
            lenny.creation)
