import ugfx,badge,appglue,time,gc,wifi
import urequests as requests

def home(pushed):
    if(pushed):
        appglue.home()

def saveoffset():
    global offset
    offset = min(max(offset,0),65535)
    badge.nvs_set_u16("porn","ts",int(offset))

def reset(pushed):
    global offset
    if(pushed):
        offset = 0.
        saveoffset()

def left(pushed):
    global offset
    if(pushed):
        offset -= 1.

def right(pushed):
    global offset
    if(pushed):
        offset += 1.
        saveoffset()

def up(pushed):
    global offset
    if(pushed):
        offset += 5.
        saveoffset()

def down(pushed):
    global offset
    if(pushed):
        offset -= 5.
        saveoffset()

def a(pushed):
    global offset
    if(pushed):
        offset += 60.
        saveoffset()

def b(pushed):
    global offset
    if(pushed):
        offset -= 60.
        saveoffset()

def show_frame(frame):
    ugfx.clear()
    badge.eink_png(62,0,frame)
    ugfx.flush()

def get_frame(ts):
    r = requests.get("http://fabod.xiscosoft.net/fabod.php?ts=%s"%(ts))
    c = r.content
    r.close()
    r = None
    return c

def init():
    global offset
    badge.init()
    wifi.init()
    ugfx.init()
    ugfx.input_init()
    offset = float(badge.nvs_get_u16("porn","ts",0))
    ugfx.input_attach(ugfx.BTN_START, home)
    ugfx.input_attach(ugfx.BTN_SELECT, reset)
    ugfx.input_attach(ugfx.BTN_A, a)
    ugfx.input_attach(ugfx.BTN_B, b)
    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_LEFT, left)
    
    ugfx.clear(ugfx.WHITE);
    ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
    ugfx.flush()
    ugfx.set_lut(ugfx.GREYSCALE)
    
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)

def run():
    global offset
    init()
    n = time.ticks_ms()
    f = get_frame(offset)
    while True:
        show_frame(f)
        f=None
        gc.collect()
        st = time.ticks_ms()
        offset += time.ticks_diff(st,n)/1000
        n = st
        saveoffset()
        f = get_frame(offset)
        gc.collect()
        badge.eink_busy_wait()
        time.sleep(max(time.ticks_diff(time.ticks_add(st,500),time.ticks_ms())/1000,0))

if __name__ == 'porn':
    run()
