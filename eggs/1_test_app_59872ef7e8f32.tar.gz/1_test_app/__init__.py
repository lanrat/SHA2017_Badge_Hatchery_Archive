import ugfx, badge, sys, appglue

ugfx.init()
badge.init()

def start():
    del sys.modules["splash"]
    sys.modules["splash"] = __import__("tmpmod")
    appglue.start_app("")

start()