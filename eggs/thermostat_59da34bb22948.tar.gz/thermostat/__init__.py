import time, badge, _thread, ugfx, wifi
import usocket as socket
from machine import Pin

#try to maintain targettemp
ctemp=20.0
ttemp=20.0
mtemp=0.5
burn=0
schedule= [[[9,30,21.0],[23,59,18.0]],[[9,30,21.0],[23,59,18.0]]
  [[7,10,21.0],[7,45,18.0],[18.0,0,21.0],[23,59,18.0]],
[[7,10,21.0],[7,45,18.0],[18.0,0,21.0],[23,59,18.0]],  
[[7,10,21.0],[7,45,18.0],[18.0,0,21.0],[23,59,18.0]],
[[7,10,21.0],[7,45,18.0],[18.0,0,21.0],[23,59,18.0]],
[[7,10,21.0],[7,45,18.0],[18.0,0,21.0],[23,59,18.0]] ]

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

def init_hw():
  global p12
  badge.init()
  ugfx.init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  
  badge.power_sdcard_enable()
  p12=Pin(12,Pin.OUT)
  p12.value(0)
  
def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def init_web():
  global s
  #init webserver stuff
  wifi.init()
  ai = socket.getaddrinfo(wifi_up(),80)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.bind(addr)
  s.listen(5)

def main_target_temp():
  global ctemp,ttemp,mtemp,burn,p12
  
  print("Target temp thread started!")
  while True:
    if ctemp<(ttemp-mtemp):
      burn=1
    else:
      burn=0
    p12.value(burn)
    update_screen()
    time.sleep(15)

def update_screen():
  global burn,ctemp,ttemp
  tstatus=('burning','idleing')
  ugfx.clear(ugfx.WHITE)
  ugfx.string(10, 0, "Current Temperature is %s" % (ctemp) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(10, 14, "Target Temperature is %s" % (ttemp) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(10, 28, "Date %d/%d/%d Day %d" % (time.locatime[2],time.locatime[1],time.locatime[0],time.locatime[6]) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(10, 42, "Time %d:%d" % (time.locatime[3],time.locatime[4]) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(20, 56, "Status is %s!" %(tstatus[burn]), "DejaVuSans20", ugfx.BLACK)
  ugfx.flush()
  
  
def main_scheduler():
  global schedule
  print("Scheduler thread started!")
  while True:
    now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
    print("Day of the week is %d" % (now[6]))
    print("Target temperature is %f" %(schedule[now[6]][2]))
    time.sleep(60)
  
  
def main_handle_web():
  print("Handle web thread started!")
  global s
  global burn, ttemp,ctemp
  while True:
    res = s.accept()
    client_s = res[0]
    client_ip = str(res[1][0])
    print("Connection from ",client_ip)
    request = client_s.recv(1024)
    request = str(request)
    print("Request was : %s" % request)
    if request.find('/favicon.ico')>0:  
      client_s.close()
    else:
      if request.find('/?ctemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ctemp=float(arg[1])
        print("change current temp to %s" % ctemp)
      if request.find('/?ttemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ttemp=float(arg[1])
        print("change target temp to %s" % ttemp)

      client_s.send(default_reply)
      client_s.send("<html><head><title>Thermostat by Tommy Faasen</title></head><body>")
      client_s.send("<center>Status:")
      if(burn==0):
        client_s.send(" Not")
      client_s.send(" Burning!</center><br>")
      client_s.send("<center> Target Temperature %f - Current temperature %f</center><br>" % (ttemp,ctemp))
      client_s.send("</body></html>")
      client_s.close()

  
try:
  print("Initializing")
  init_hw()
  init_web()
  print("Done, starting up!")
  time.sleep(1)
  _thread.start_new_thread(main_target_temp,())
  _thread.start_new_thread(main_scheduler,())
  _thread.start_new_thread(main_handle_web,())
  print("All systems go!")
  
except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()