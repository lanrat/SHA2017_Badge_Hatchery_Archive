import os, appglue

known_signatures = ['ascii_porn', 'the_legend_of_zelda', 'internship', '1p0rn', 'another_hack_simulator']

known_src_signatures = ['install(\'Internship\')', '92.222.19.24', 'paradoxis.nl', 'ransom_', 'held hostage!', 'virus']

def uninstall_ransomware(program):
    path = '/lib/' + program
    for files in os.listdir(path):
        os.remove(path + "/" + files)
    os.rmdir(path)


def remove_by_known_signatures():
    installed_software = os.listdir('/lib')

    for program in installed_software:
        if program in known_signatures:
            print("remove ransomware by signature: {}".format(program))
            uninstall_ransomware(program)


def is_known_src(path):
    with open(path) as src_file:
        src = src_file.read()
        for sig in known_src_signatures:
            if sig in src:
                return True
    return False


def remove_by_known_src():
    installed_software = os.listdir('/lib')

    for program in installed_software:
        if program == 'ransomware_decrypter': # we don't want to delete ourself
            continue

        path = '/lib/' + program
        for files in os.listdir(path):
            file_path = path + "/" + files
            if is_known_src(file_path):
                print("remove ransomware by source: {}".format(program))
                uninstall_ransomware(program)


remove_by_known_signatures() # signature (name) based
remove_by_known_src() # signature (code) based

# TODO: reinstall all software, if a virus was found

appglue.home()