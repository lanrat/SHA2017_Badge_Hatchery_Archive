import machine, ujson, utime, ugfx, badge

#Globals
alarms = []

# Management

def alarms_add(timestamp,guid,title):
    global alarms
    alarm = {"timestamp":timestamp, "guid":guid, "title":title}
    alarms.append(alarm)
    
def alarm_exists(guid):
    global alarms
    for alarm in alarms:
        if (alarm['guid']==guid):
            return True
    return False
    
def alarms_remove(id):
    global alarms
    if (id<0):
        print("Whoops, this shouldn't happen...")
    else:
        alarms.pop(id)
    
def alarms_read():
    global alarms
    try:
        f = open('alarms.json', 'r')
        data = f.read()
        f.close()
    except:
        data = ""
    try:
        alarms = ujson.loads(data)
    except:
        alarms = []
    
def alarms_write():
    global alarms
    data = ujson.dumps(alarms)
    f = open('alarms.json', 'w')
    f.write(data)
    f.close()
    
# Alarm clock
def alarm_msg(title):
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Event starts soon!", "PermanentMarker22", ugfx.BLACK)
    ugfx.string(0, 25, title, "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()
    badge.vibrator_activate(0xFF)
    utime.sleep(1)

def alarm_notify():
    alarms_read() #Get alarms from flash
    current_datetime = utime.time()
    
    global alarms
    acount = len(alarms)
    
    # Showing
    for ap in range(0,acount):
        alarm = alarms[ap]
        c = int(alarm['timestamp']) + 2*60*60 + 10*60 #10 minutes before start
        if (c < current_datetime):
            print("ALARM!")
            alarm_msg(alarm['title'])
        else:
            print("NO ALARM YET")
    
    # Cleaning
    for ac in range(0,acount):
        ap = len(acount)-1-ac
        c = int(alarm['timestamp']) + 2*60*60 + 9*60 #9 minutes before start
        if (c<current_datetime):
          print("Removing alarm ("+str(ap)+")!")
          alarms.pop(ap)
  
