# Service file for SHA2017 event program app
# Renze Nicolai 2017

import machine

def event_program_timer_callback(tmr):
    print("Event program service timer!")


# This function gets called by the home application at boot
def service(tmr, cstate, percent, srvTmrId):
    global event_program_timer
    event_program_timer = machine.Timer(srvTmrId)    
    event_alarm = __import__('lib/sha2017_event_program/event_alarm')
    print("Event program service entered!")
    event_program_timer.init(period=500, mode=machine.Timer.PERIODIC, callback=event_program_timer_callback)
    print("Event program service finished!")
    #event_alarm.alarm_notify()
