import ugfx, badge, machine, ntp, network, wifi, utime

def draw_msg(title, desc):
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, title, "PermanentMarker22", ugfx.BLACK)
    ugfx.string(0, 25, desc, "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()
    

def program_main():  
    ugfx.init()
    draw_msg("Welcome!","Starting app...")
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, start_launcher)
    global ledTimer
    ledTimer.init(period=1000, mode=Timer.PERIODIC, callback=ledTimer_callback)
    badge.leds_enable()
    
    draw_msg("Loading...", "WiFi: starting radio...")
    wifi.init()
        
    ssid = badge.nvs_get_str('badge', 'wifi.ssid', 'SHA2017-insecure')
    draw_msg("Loading...", "WiFi: connecting to '"+ssid+"'...")
    timeout = 100
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        timeout = timeout - 1
        if (timeout<1):
            draw_msg("Error", "Timeout while connecting!")
            time.sleep(5)
            start_launcher(True)
            break
        else:
            pass
        
    draw_msg("Loading...","Setting clock...")
    timestamp = ntp.get_NTP_time()
    machine.RTC().datetime(utime.localtime(timestamp))
    
    draw_msg("Done!","")
    utime.sleep(1)
    esp.rtcmem_write_string("")
    esp.start_sleeping(1)
    
program_main()
