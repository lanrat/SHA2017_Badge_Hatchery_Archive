import time, badge, _thread, ugfx, wifi
import usocket as socket
from machine import Pin

#try to maintain targettemp
ctemp=20.0
ttemp=20.0
mtemp=0.5
burn=0
schedule=(((7,10,21),(7,45,18),(18,0,21),(23,59,18)),
((7,10,21),(7,45,18),(18,0,21),(23,59,18)),  
((7,10,21),(7,45,18),(18,0,21),(23,59,18)),
((7,10,21),(7,45,18),(18,0,21),(23,59,18)),
((7,10,21),(7,45,18),(18,0,21),(23,59,18)),
((9,30,21),(23,59,18)),((9,30,21),(23,59,18)) )

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

def init_hw():
  global p12
  badge.init()
  ugfx.init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  badge.power_sdcard_enable()
  p12=Pin(12,Pin.OUT)
  p12.value(0)
  
def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def init_web():
  global s
  #init webserver stuff
  wifi.init()
  ai = socket.getaddrinfo(wifi_up(),80)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.bind(addr)
  s.listen(5)

def main_target_temp():
  global ctemp,ttemp,mtemp,burn,p12
  
  print("Target temp thread started!")
  while True:
    if ctemp<(ttemp-mtemp):
      burn=1
    else:
      burn=0
    p12.value(burn)
    time.sleep(15)

def main_scheduler():
  global schedule
  print("Scheduler thread started!")
  while True:
    time.sleep(60)
  
  
def main_handle_web():
  print("Handle web thread started!")
  global s
  global burn
  while True:
    res = s.accept()
    client_s = res[0]
    client_ip = str(res[1][0])
    print("Connection from ",client_ip)

    client_s.send(default_reply)
    client_s.send("<html><head><title>Thermostat by Tommy Faasen</title></head><body>")
    client_s.send("<center>Status:")
    if(burn==0):
      client_s.send(" Not")
    client_s.send(" Burning!</center><br>")
    client_s.send("</body></html>")
    client_s.close()

  
try:
  print("Initializing")
  init_hw()
  init_web()
  print("Done, starting up!")
  time.sleep(1)
  _thread.start_new_thread(main_target_temp,())
  _thread.start_new_thread(main_scheduler,())
  _thread.start_new_thread(main_handle_web,())
  print("All systems go!")
  
except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()