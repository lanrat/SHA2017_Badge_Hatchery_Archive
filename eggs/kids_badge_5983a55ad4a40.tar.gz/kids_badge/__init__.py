import ugfx
import time
import dialogs

ugfx.init()

ugfx.clear(ugfx.BLACK)
#nick="Jon de Boer Jr"
#contactphone="0034666000666"


name = badge.nvs_get_str("owner", "name", "")
nick = dialogs.prompt_text("Please enter nasme", name)
if nick:
      badge.nvs_set_str("owner", "name", nick)

phone = badge.nvs_get_str("owner", "phone", "")
contactphone = dialogs.prompt_text("Please enter parents contact phone", phone)
if contactphone:
      badge.nvs_set_str("owner", "phone", nick)




ugfx.box(20,20,50,50,ugfx.WHITE)

ugfx.string(120,25,nick,"PermanentMarker36",ugfx.WHITE)
ugfx.string(25,80,"In Case of emergency please contact:","Roboto_Regular12",ugfx.WHITE)
ugfx.string(100,95,contactphone,"Roboto_BlackItalic24",ugfx.WHITE)

ugfx.flush()

def render(text, pushed):
    if(pushed):
        ugfx.string(100,10,text,"PermanentMarker22",ugfx.WHITE)
    else:
        ugfx.string(100,10,text,"PermanentMarker22",ugfx.BLACK)
    ugfx.flush()

def start_app(pushed):
    if(pushed):
        import launcher

while True:
    pass