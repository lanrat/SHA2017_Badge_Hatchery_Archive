#import dialogs, ugfx, badge
#import ugfx
#ugfx.clear(ugfx.BLACK)
#ugfx.flush()
#ugfx.clear(ugfx.WHITE)
#ugfx.flush()

#ugfx.string_box(0,10,296,26, "username", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
#ugfx.string_box(0,45,296,38, "IPv6, security (fail), ...", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
#ugfx.string_box(0,94,296,26, "@nickname", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

#the line under the text
#str_len = ugfx.get_string_width("IPv6, security (fail), ...", "Roboto_BlackItalic24")
#line_begin = int((296-str_len)/2)
#line_end = str_len+line_begin
#ugfx.line(line_begin, 83, line_end, 83, ugfx.BLACK)

#the cursor past the text
#cursor_pos = line_end+5
#ugfx.line(cursor_pos, 46, cursor_pos, 81, ugfx.BLACK)

#ugfx.flush(ugfx.LUT_FULL)

#import ugfx, badge, easydraw, time, appglue
import badge, easydraw, time, appglue

easydraw.msg("","Show nickname", True)

enabled = badge.nvs_get_u8("shownicktags","enable", 0)
if enabled:
    enabled = 0
    easydraw.msg("Show nickname disabled!")
else:
    enabled = 1
    easydraw.msg("Show nickname enabled!")
    easydraw.msg("Go back to the splash and wait...")
enabled = badge.nvs_set_u8("shownicktags","enable", enabled)

time.sleep(5)
appglue.home()