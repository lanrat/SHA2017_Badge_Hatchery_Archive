### Author: Leiden Tech 
### Description: Leiden Tech
### Category: Games
### License: MIT
### Appname: Geek 8-Ball
### Built-in: no

import badge
import ugfx
import machine
import random
import time
import appglue

def g8ball():
    badge.init()
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP,lambda pressed: btn_up(pressed))
    ugfx.input_attach(ugfx.JOY_DOWN,lambda pressed: btn_down(pressed))
    ugfx.input_attach(ugfx.JOY_LEFT,lambda pressed: btn_left(pressed))
    ugfx.input_attach(ugfx.JOY_RIGHT,lambda pressed: btn_right(pressed))
    ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: btn_select(pressed))
    ugfx.input_attach(ugfx.BTN_START,lambda pressed: btn_start(pressed))
    ugfx.input_attach(ugfx.BTN_A,lambda pressed: btn_a(pressed))
    ugfx.input_attach(ugfx.BTN_B,lambda pressed: btn_b(pressed))

    [year, month, mday, wday, hour, minute, second, microseconds] = machine.RTC().datetime()
    random.seed(int(microseconds))
    display()

def display():
    global font, fgcolor, messages
    messNum=len(messages) - 1
    value = random.randint(0,messNum)
    msg=messages[value]
    ugfx.string_box(0,0,296,128, msg, font, fgcolor, ugfx.justifyCenter)
    ugfx.flush()

def quit():
    global fgcolor,font
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.string(50, 50, "Quitting", font,fgcolor)
    ugfx.flush()
    appglue.start_app("launcher",False)

def btn_a(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_b(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_up(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_down(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_left(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_right(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_start(pressed):
    if pressed:
        quit()

def btn_select(pressed):
    if pressed:
        g8ball()

########
# MAIN #
########
fgcolor=ugfx.BLACK
font="PermanentMarker22"
messages = [
    "Computer says no",
    "42",
    "Have you tried turning it off and on again?",
    "It's not a bug, it's a feature",
    "I have a bad feeling about this",
    "I'm sorry, I'm afraid I can't do that",
    "Hasta la vista, baby",
    "Make it so",
    "Reverse the polarity of the neutron flow",
    "When I say run, run ... RUN",
    "EX-TER-MIN-ATE!",
    "The truth is out there",
    "Resistance is futile",
    "I believe that's my stapler"
]
g8ball()
