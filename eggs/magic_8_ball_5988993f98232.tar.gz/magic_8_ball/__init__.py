import badge, ugfx
import appglue

def action_home(pressed):
    if (pressed):
        appglue.start_app("")

def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)

def program_main():
    badge.init()
    ugfx.init()
    ugfx.input_init()   
    ugfx.input_attach(ugfx.BTN_START, action_home)
    draw()
          
# Start main application
program_main()