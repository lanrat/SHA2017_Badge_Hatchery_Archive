import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

# loading screen
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Getting pixeldata ...","Roboto_Regular12", 0)
ugfx.flush()

# fetching data
url = "https://tomemig.de/pixeldata.json"
r = requests.get(url)

print(r)

gc.collect()
data = r.json()
r.close()

print(data)

# print data
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"0: (" + str(data["0"]["r"]) + ", " + str(data["0"]["g"]) + ", " + str(data["0"]["b"]) + ")","Roboto_Regular12", 0)
ugfx.flush()

sleep(100)

# end stuff
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)