import ugfx

ugfx.init()

while True:
  for x in range(1, 5):
    ugfx.display_image(0,0,'/lib/badger/badger%s.png' % x)
    ugfx.flush()