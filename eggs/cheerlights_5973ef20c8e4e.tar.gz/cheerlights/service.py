import urequests
import json
import badge
import wifi
import binascii
import time

def hex_to_grbw_list(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    w = 0
    while (r>0) and (g>0) and (b>0):
        r = r - 1
        g = g - 1
        b = b - 1
        w = w + 0.5
    return [g,r,b,int(w)]

def update():
    global cheerlightsEnabled
    r = urequests.get("http://api.thingspeak.com/channels/1417/field/2/last.json")
    data = json.loads(r.text)
    vals = hex_to_grbw_list(data['field2'][1:])
    map(lambda x: int(cheerlightsEnabled*x/255.0), vals)
    print(data)
    print(vals)
    badge.leds_set_state(bytes(6*vals))

def setup():
    wifi.init()
    badge.leds_enable()
    badge.leds_set_state(bytes(6*([0]*4)))

    global cheerlightsEnabled
    cheerlightsEnabled = int(badge.nvs_get_str('cheerlights', 'state', '0'))
    if (cheerlightsEnabled<1):
        print("Cheerlights: Disabled! Please enable in the app!")

def loop(sleepCount):
    global cheerlightsEnabled
    if cheerlightsEnabled:
        update()
        time.sleep(30)
    return False