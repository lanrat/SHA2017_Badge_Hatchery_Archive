import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass


# loading screen
ugfx.clear(ugfx.WHITE);
ugfx.string(10, 10, "Getting latest updates from the Travel Village ...", "Roboto_Regular12", 0)
ugfx.flush()

# fetching data
url = "http://badge.jonasleitner.de/update.json"
r = requests.get(url)
gc.collect()
data = r.json()
r.close()
text = data["text"]

# displaying data
ugfx.clear()
ugfx.string(5, 5, text, "pixelade13", 0)

ugfx.flush(ugfx.LUT_FULL)

badge.eink_busy_wait()
deepsleep.start_sleeping(5000)