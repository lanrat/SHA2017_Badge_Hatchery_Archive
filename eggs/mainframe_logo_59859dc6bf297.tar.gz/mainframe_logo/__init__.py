import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.string_box(0,5,296,20, "Mainfrage the beasty Hackspace in the north", " Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,20,296,20, "if it happens to you to be in Oldenburg/GERMANY", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,35,296,20, "please come to visit us. We are open daily", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,50,296,20, "from 9:00pm to midnight!", "Roboto_Regular12",  ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,75,296,36, "mainframe.io", "PermanentMarker36", ugfx.BLACK, ugfx.justifyLeft)
badge.eink_png(230,55,'/lib/Mainframe_Logo/mainframe_shabadge.png')

ugfx.flush()