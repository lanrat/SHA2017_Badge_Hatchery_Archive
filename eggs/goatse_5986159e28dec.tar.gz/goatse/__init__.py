# GOATSE APPLICATION
# SHOWN ONCE AFTER SETUP for 500s
# Shamless ripoff of the NYAN CAT APP (graphics)

import ugfx, badge, appglue, deepsleep

def program_main():
    print("--- GOATSE APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    badge.leds_init()
    #badge.leds_send_data(bytes([51, 102, 255, 0,
    #                        153, 0, 255, 0,
    #                        255, 51, 0, 0,
    #                        255, 255, 0, 0,
    #                        153, 255, 0, 0,
    #                        0, 255, 0, 0]), 24)
    try:
        badge.eink_png(0,0,'/lib/goatse/goatse.png')
    except:
        ugfx.string(0, 0, "GOATSE LOAD ERROR goatse.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(500000)
    appglue.start_app("") # Return home

# Start main application
program_main()