### SHAirQuality Egg
### Author: Barbabee & Ron
### License: GPLv3

# Improvements are very welcome

# Outside temperature deviates from internal Urad temperature
# TODO calculate the deviation
# TODO Add graphics to measurements

import ugfx, gc, wifi, badge
import urequests as requests
from time import *
import datetime

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()

# Make sure WiFi is connected
wifi.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
badge.eink_png(0,0,'/lib/uradmonitor/urad3.png')
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE)
badge.eink_png(0,0,'/lib/uradmonitor/urad3.png')
ugfx.flush()

def get_uradData(pushed):
    if(pushed):
        ugfx.string_box(0,50,296,26, "Push Left for Mobile Monitor #1", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,76,296,26, "Push Down for Fixed Monitor", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,102,296,26, "Push Right for Mobile Monitor #2", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.flush()
        gc.collect()
        try:
            if ugfx.JOY_DOWN:
                raw_data = requests.get("https://data.uradmonitor.com/api/v1/devices/82000065/all/last")
                data = raw_data.max(axis=0)
            elif ugfx.JOY_LEFT:
                raw_data_mobile_one = requests.get("https://data.uradmonitor.com/api/v1/devices/64000024/all/last")
                data = raw_data_mobile_one.max(axis=0)
            elif ugfx.JOY_RIGHT:
                raw_data_mobile_two = requests.get("https://data.uradmonitor.com/api/v1/devices/64000025/all/last")
                data = raw_data_mobile_two.max(axis=0)
        except:
            ugfx.string(10,10,"Could not download JSON","Roboto_Regular12", 0)
            ugfx.flush()
            sleep(1)
            go_home(1)
            return
        try:
            global output
            output = data.json()
            timestamp = output['time']
            value = datetime.datetime.fromtimestamp(timestamp)
            hrtime = value.strftime('%Y-%m-%d %H:%M:%S')
            
        except:
            data.close()
            ugfx.string(10,10,"Data cannot be processed!","Roboto_Regular12", 0)
            ugfx.flush()
            sleep(1)
            go_home(1)
            return
        data.close()    
    print("Rendering list...")

    show_alarmleds(output['cpm'])
    show_screen(output, hrtime)

def show_screen(output, hrtime):
    # https://fukushimahounds.freeforums.net/thread/373/radiation-conversion-dose-sieverts-year
    radi = (output['cpm'] * 3 / 1000000)
    ugfx.clear(ugfx.WHITE)
    badge.eink_png(0,0,'/lib/uradmonitor/urad3.png')
    ugfx.flush()
    ugfx.string_box(88,0,208,13, "Refreshed at", "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(88,14,208,24, str(hrtime), " Roboto_Black22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(88,37,208,13, "Press A to refresh data, B to power down", "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,50,37,26, "pressure", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,76,37,26, str(output['pressure']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,102,37,26, "Pa", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(37,50,37,26, "humidity", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(37,76,37,26, str(output['humidity']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(37,102,37,26, "% RH", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(74,50,37,26, "pm25", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(74,76,37,26, str(output['pm25']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(74,102,37,26, "μg m3", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(111,50,37,26, "voc", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(111,76,37,26, str(output['voc']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(111,102,37,26, "air", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(148,50,37,26, "radiation", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(148,76,37,26, str(radi), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(148,102,37,26, "μSv/h", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    # Outside temperature deviates from internal Urad temperature
    # TODO calculate the deviation
    ugfx.string_box(259,50,37,26, "temperature", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(259,76,37,26, "TODO", " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(259,102,37,26, "°C", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)   
    if not output['formaldehyde'] in output:
        output['formaldehyde'], output['carbondioxide'] = "###"
    ugfx.string_box(185,50,37,26, "formaldehyde", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(185,76,37,26, str(output['formaldehyde']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(185,102,37,26, "CH2O", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(222,50,37,26, "carbondioxide", "DejaVuSans20", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(222,76,37,26, str(output['carbondioxide']), " Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(222,102,37,26, "CO2", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()
        
def main():
    get_uradData(1)

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

def show_alarmleds():
    if output['cpm'] >= 200:
        show_alarmleds()
        led_val = 5
        badge.leds_enable()
        badge.leds_send_data(bytes([0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0]), 24)
    else:
        badge.leds_disable()

ugfx.input_attach(ugfx.BTN_A, get_uradData)
ugfx.input_attach(ugfx.BTN_B, go_home)

main()