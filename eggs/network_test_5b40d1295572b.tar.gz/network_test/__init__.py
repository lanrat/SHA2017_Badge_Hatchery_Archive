### Author: Mattsi Jansky
### Description: Testing network functionality
### Category: Unpublished
### License: MIT
### Appname: nettest
### Built-in: no

try:
    import usocket as socket
except:
    import socket
import badge
import ugfx
import sys
import deepsleep
import network
import wifi
import time

def network_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    wifi_up()
    cleanScreen()
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.text(10, 10, "Testing network", ugfx.BLACK)
    result = sendHttpRequest("google.com")
    ugfx.text(10, 50, result, ugfx.BLACK)


def cleanScreen():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def reboot():
    deepsleep.reboot()

def wifi_up():
  wifi.init()
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  return wifi.sta_if.ifconfig()[0]

def sendHttpRequest(url):
    s = socket.socket()
    ai = socket.getaddrinfo(url, 80)
    print("Address infos:", ai)
    addr = ai[0][-1]

    print("Connect address:", addr)
    s.connect(addr)


    s.send(b"GET / HTTP/1.0\r\n\r\n")
    result = s.recv(4096)
    print(result)
    return result

network_test()