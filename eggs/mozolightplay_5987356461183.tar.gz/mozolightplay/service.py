import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(245,73,'/lib/mozolightplay/mozo.png')
    return 0