import ugfx

ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.string(180,25,"Fahrplan","Roboto_Black24",ugfx.BLACK)
