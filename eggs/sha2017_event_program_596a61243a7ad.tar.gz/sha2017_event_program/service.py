# Service file for SHA2017 event program app
# Renze Nicolai 2017

import machine, utime, ugfx, appglue

# Prepare libs
event_alarm = __import__('lib/sha2017_event_program/event_alarm')

# Prepare variables
counter = 0

# This function gets called by the home application at boot
def setup():
    print("Event program service setup!")

def loop(sleepCnt):
    global counter
    print("Event program service loop: "+str(counter))
    counter = counter + 1
    alarm_notify()
    return False # Do not prevent sleep

def alarm_notify():
    global event_alarm
    event_alarm.alarms_read()
    current_datetime = utime.time()
    
    amount_of_alarms = len(event_alarm.alarms)
    
    for i in range(0, amount_of_alarms):
        alarm = event_alarm.alarms[i]
        c = int(alarm['timestamp']) + 2*60*60 + 10*60 #10 minutes before start
        if (c < current_datetime):
            print("Alarm! ("+alarm['title']+")")
            appglue.start_app("sha2017_event_program")
        else:
            print("Not yet... ("+alarm['title']+", "+str(c - current_datetime)+")")
