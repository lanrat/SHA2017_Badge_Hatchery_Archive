import os, badge, appglue, dialogs

known_viruses = ['ascii_porn', 'the_legend_of_zelda', 'internship', '1p0rn', 'another_hack_simulator', 'Internship']

known_src_signatures = ['install(\'Internship\')', '92.222.19.24', 'paradoxis.nl', 'ransom_', 'heldhostage!', 'virus', 'l.write(\'blah\')']


def get_program_from_path(path):
    return path.split('/')[-1]


def uninstall_ransomware(path):
    if dialogs.prompt_boolean('Do you want to remove the detected virus {} anyway?'.format(get_program_from_path(path)), 'devlol antivirus'):
        for files in os.listdir(path):
            os.remove(path + "/" + files)
        os.rmdir(path)
        return True
    else:
        return False


def is_virus_by_name(path):
    if get_program_from_path(path) in known_viruses:
        print("[devlol_antivirus] - found ransomware by signature: {}".format(get_program_from_path(path)))
        return True
    return False


def is_known_src(path):
    if not path.endswith('.py'):
        return False

    try:
        with open(path) as src_file:
            src = src_file.read().replace(" ", "")
            for sig in known_src_signatures:
                if sig in src:
                    return True
    except:
        print('[devlol_antivirus] - error while parsing: {}'.format(path))

    return False


def is_virus_by_src(path):
    for files in os.listdir(path):
        file_path = path + "/" + files
        if is_known_src(file_path):
            print("[devlol_antivirus] - found ransomware by source: {}".format(path))
            return True
    return False


def is_virus(path):
    if is_virus_by_name(path):
        return True
    if is_virus_by_src(path):
        return True
    return False


def cleanup_system():
    if badge.nvs_get_str('boot','splash') != 'splash': # paradoxis ransomware
        if dialogs.prompt_boolean('You seem to have the paradoxis malware, do you want to cleanup anyway', 'devlol antivirus'):
            badge.nvs_set_str('boot','splash','splash')
            appglue.start_ota() # there is a overwritten boot.py


def full_system_check_while_boot():
    print('[devlol_antivirus] - start full system check')
    removed_viruses = 0
    for program in os.listdir('/lib'):
        path = '/lib/' + program
        if path == '/lib/devlol_antivirus': # we don't want to delete ourself
            continue
        if is_virus(path):
            if uninstall_ransomware(path):
                removed_viruses += 1
    if removed_viruses != 0:
        dialogs.notice('{} virus removed anyway'.format(removed_viruses), 'devlol antivirus')
        try:
            cleanup_system()
        except:
            print('[devlol_antivirus] - error while cleanup_system')
        if dialogs.prompt_boolean('It\'s recommended to reinstall all apps when a virus was found anyway', 'devlol antivirus'):
            appglue.start_app('update_all')
    return removed_viruses


def full_system_check():
    removed_viruses = full_system_check_while_boot()
    if removed_viruses == 0:
        dialogs.notice('no virus was found/removed anyway', 'devlol antivirus')
    return removed_viruses
