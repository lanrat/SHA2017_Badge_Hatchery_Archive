from devlol_antivirus import service

print('[devlol_antivirus] - is setup: {}'.format(service.is_setup))

try:
    from devlol_antivirus import devlol_antivirus

    devlol_antivirus.full_system_check_while_boot()
except:
    print('[devlol_antivirus] - error while __init__()')

import appglue

#appglue.home()
