import ugfx
from . import buienradar

buienradar.rain_graph(0, 0, 296, 128, 1.0)
ugfx.flush()