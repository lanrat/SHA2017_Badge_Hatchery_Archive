import urequests as requests
import deepsleep
import wifi
import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()
badge.leds_init()
badge.vibrator_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()



def set_message(text):
  ugfx.clear(ugfx.BLACK)
  ugfx.clear(ugfx.WHITE)
  ugfx.string(45,60,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()
    
def home(pressed):
  if pressed:
    deepsleep.reboot()

def vendmate(pressed):
  try:
    set_message("U WOT MATE?!?!")
    url = "https://automate.nwlab.nl/api/vend"
    h = {"Authorization":"Basic YmFkZ2U6NjViY2Q0YWRhZjhiMzBjNjU3Y2QwYjUyZmFlMzE1NzY="}
    data = requests.get(url, headers=h)
    data.close()
    time.sleep(5)
    set_message("Get your free Club Mate from the vending machine")
    badge.leds_send_data(bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100]))
    badge.vibrator_activate(0xFF)
    time.sleep(3)
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    deepsleep.reboot()

def main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(45,60,"Free Mate @ Torvalds","Roboto_Regular12",ugfx.BLACK)
    ugfx.string(45,120,"When u get there, press A!",ugfx.BLACK)
    ugfx.flush()


set_message("Waiting for wifi")
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, vendmate)
ugfx.input_attach(ugfx.BTN_SELECT, home)
main()