import network
import ugfx
#192x60
wlan = network.WLAN(network.STA_IF)
wlan.active(True)

ugfx.init()
ugfx.clear(ugfx.BLACK)  # cycle all pixels to try and cut ghosting
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

dimensions = (296, 128)

while(True):
  # (b'TUvisitor', b'\x00\xa3\x8elea', 13, -58, 0, False)
  # 0: ssid
  # 1: bssid (mac)
  # 2: channel
  # 3: RSSI dBm
  # 4: Auth mode
  # 	0: open
  #		1: WEP
  # 	2: WPA-PSK
  # 	3: WPA2-PSK
  #		4: WPA/WPA2-PSK
  #		5: WPA2-Enterprise ?
  # 5: hidden(False)
  aps = wlan.scan()
  # arc(x1, y1, r, angle1, angle2, colour)
  ugfx.clear(ugfx.BLACK)  # cycle all pixels to try and cut ghosting
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  for ap in aps:
    x = 15 * int(ap[2])
    y = 50 - int(ap[3])
    ugfx.arc(x, y, 10, 0, 180, ugfx.BLACK)
    ugfx.text(x, y - 21, ap[0], ugfx.BLACK)
  ugfx.flush()