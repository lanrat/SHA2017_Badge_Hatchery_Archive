import requests
import ugfx

def setup():
    pass

def loop():
    return 60000

def draw(y):
    try:
        data = requests.get("https://br-gpsgadget-new.azurewebsites.net/data/raintext/?lat=52.28&lon=5.53")
    except:
        ugfx.string(10,10,"Could not download weather data","Roboto_Regular12", 0)
        ugfx.flush()
        return

    tv = []
    for v in data:
        tv = v.split("\\|")

    data.close()

    ugfx.string(0, y-12, tv[1][1], "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    return [60000, 14]