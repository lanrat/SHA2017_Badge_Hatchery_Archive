'''
Screen dimensions:
296x
128y

https://www.thonky.com/qr-code-tutorial

first get numeric mode figured out, then expand to different modes
start with version 1 (21x21 px), then go up in density

define binary value with specific length:
    '{0:0<length>b}.format(value)'
'''

import ugfx
ugfx.init()

def clearScreen(amount = 4):
    for x in range(0, amount):
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

qrValue = '01189998819991197253'
qrMode = 1
clearScreen()