import ugfx, badge

ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.display_image(0,0,'/lib/Nidorina/nidorina130.png')
ugfx.string(150, 50, "Nidorina", "PermanentMarker22", ugfx.BLACK)
ugfx.line(155, 75, 245, 75, ugfx.BLACK)


ugfx.flush()
