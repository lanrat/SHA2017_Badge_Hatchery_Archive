import ugfx

BADGE_EINK_WIDTH  = 296
BADGE_EINK_HEIGHT = 128

font = {}

def resolve_file(rel_path):
    return __file__.rsplit('/', 1)[0] + '/' + rel_path

class Char(object):
    def __init__(self, filename, fd):
        offset = fd.tell()
        metadata = f.read(3)
        self.__width = metadata[0] << 8 | metadata[1]
        self.__height = metadata[2]
        self.__filename = filename
        self.__offset = offset
        fd.seek(offset + 3 + self.width() * self.height() // 8)

    def width(self):
        return self.__width

    def height(self):
        return self.__height

    def __raster(self):
        with open(self.__filename, "rb") as f:
            f.seek(self.__offset + 3)
            return f.read(self.width() * self.height() // 8)

    def render(self, at_x, at_y):
        width = self.width()
        height = self.height()
        raster = self.__raster()
        for x in range(0, width):
            for y in range(0, height):
                i = y * width + x
                if raster[i // 8] & (1 << (i & 7)):
                    ugfx.pixel(at_x + x, at_y + y, ugfx.BLACK)

ugfx.init()
ugfx.input_init()

print_line = 0

def print(st):
    global print_line
    if print_line == 12:
        print_line = 0
        ugfx.clear(ugfx.WHITE)
    ugfx.string(0, print_line * 10, st, "", ugfx.BLACK)
    ugfx.flush()
    print_line += 1

print("loading glyphs...")

# Load our custom font.
for comp_name in ["ears", "eyes", "mouth"]:
    print("loading set %s" % comp_name)
    comp_list = []
    filename = resolve_file("lenny_%s.png" % comp_name)
    print("open %s" % filename)
    with open(filename, "rb") as f:
        print("open %s OK" % filename)
        comp = []
        i = 0
        while True:
            char_header = f.read(3)
            print("i: %d" % i)
            print("len(header)=%d" % len(char_header))
            print("header=%s" % repr(char_header))
            if not char_header:
                print("break")
                break # EOF
            print("calculating char_size")
            # Decode the number of bytes in the character.
            char_size = char_header[1] << 8 | char_header[2]
            print("char_size=%d" % char_size)
            char_offset = f.tell()
            print("char_offset=%d" % char_offset)

            # This bit indicates whether the character should be considered
            # part of a a collection.
            if not char_header[0] and len(comp) > 0:
                print("reset comp")
                comp_list.append(comp)
                comp = []

            print("append char to comp")
            comp.append(Char(filename, f))
            print("append OK %d" % len(comp))

            i += 1 # XXX

    font[comp_name] = comp_list

print("done loading glyphs")


#creation = {
#    "mouth": 1,
#    "eyes": 24,
#    "ears": 1,
#}
#cursor_position = 2
#
#def render():
#    ugfx.clear(ugfx.WHITE)
#
#    start_y = BADGE_EINK_HEIGHT // 2 - font["mouth"][0][0].height() // 2
#    total_width = 0
#    characters = []
#    for (comp_name, comp_n) in [("ears", 0), ("eyes", 0), ("mouth", 0), ("eyes", 1), ("ears", 1)]:
#        comp = font[comp_name][creation[comp_name]]
#        char = comp[comp_n % len(comp)]
#        total_width += char.width()
#        characters.append(char)
#    start_x = BADGE_EINK_WIDTH // 2 - total_width // 2
#
#    advance_x = start_x
#    for i, char in enumerate(characters):
#        char.render(advance_x, start_y)
#        if i == cursor_position:
#            ugfx.fill_circle(advance_x + char.width() // 2, start_y + char.height() + 0, 5, ugfx.BLACK);
#        advance_x += char.width()
#
#    ugfx.string(0, BADGE_EINK_HEIGHT - 24, "http://textsmili.es/", "PermanentMarker22", ugfx.BLACK)
#    ugfx.flush()
#
#def cursor_move(delta):
#    cursor_position = (cursor_position + delta + 5) % 5
#    render()
#
#def rotate_selection(delta):
#    comp_name = ["ears", "eyes", "mouth", "eyes", "ears"][cursor_position]
#    n = len(font[comp_name])
#    creation[creation[comp_name]] = (creation[creation[comp_name]] + delta + n) % n
#    render()
#
#ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: cursor_move(-1) if pressed else ())
#ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: cursor_move(1) if pressed else ())
#ugfx.input_attach(ugfx.JOY_UP, lambda pressed: rotate_selection(-1) if pressed else ())
#ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: rotate_selection(1) if pressed else ())
#
#render()
