import badge,wifi,time,ntp,woezel,appglue,uos,ugfx

def initstuff():
  badge.init()
  wifi.init()
  ugfx.init()
  ugfx.input_init() #clear buttons
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.string(10, 30, "Initializing!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(10, 50, "Press [SELECT]!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(10, 70, "to clear settings!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: clear_settings() if pushed else False)
  ugfx.flush()
  
def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def clear_settings():
  badge.nvs_set_str('boot','splash','splash')
  badge.nvs_set_str('boot','manager','')
  ugfx.clear(ugfx.BLACK)
  ugfx.string(40, 30, "Clearing Settings!" , "DejaVuSans20", ugfx.WHITE)
  ugfx.flush()
  time.sleep(3)
  appglue.start_app('launcher')
  
def set_boot(file):
  print("Settings boot->splash->%s" %(file))
  try:
  	badge.nvs_set_str('boot','splash','Bootmanager')
  	badge.nvs_set_str('boot','manager',file)
  except:
    print("Could not set nvram settings!")
  ugfx.clear(ugfx.WHITE)
  ugfx.string(10, 30, "Boot SET!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(10, 50, "[%s]" %(file) , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(10, 70, "Starting in 3 sec!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.flush()
  time.sleep(3)
  appglue.start_app(file)
    
def test_file(file):
  ugfx.area(148,0,148,40,ugfx.WHITE)
  now=time.localtime()
  ugfx.string(int(ugfx.width()/2)+4, 0, "Time: %d:%d:%d" % (now[3],now[4],now[5]), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(int(ugfx.width()/2)+4, 14, "%s" % (file), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  
def main_loop():
  #start of main loop
  
  initstuff()
  wifi_up()
  ugfx.input_init() #clear buttons
  ugfx.clear(ugfx.WHITE)
  ugfx.set_lut(ugfx.LUT_FASTER)
  ugfx.flush()
  
  try:
    ntp.set_NTP_time()
    for n in range(3):
      if not ntp.set_NTP_time():
        time.sleep(2)
      else:
        break
  except:
    print("NTP has a bug!")
  app=badge.nvs_get_str('boot','manager','')
  if len(app)>0:
    print("Updating :%s!"%(app))
    badge.nvs_set_str('boot','splash','Bootmanager')
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 50, "Updating [%s]" %(app) , "DejaVuSans20", ugfx.BLACK)
    ugfx.flush()
    try:
      woezel.install(app)
    except:
      print("Whatever, continuing anyway!")
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 50, "Starting [%s]" %(app) , "DejaVuSans20", ugfx.BLACK)
    ugfx.flush()
    appglue.start_app(app)
  now=time.localtime()
  ugfx.clear(ugfx.WHITE)
  options = ugfx.List(0,0,int(ugfx.width()/2),ugfx.height())
  print("Time is : %d:%d" % (now[3],now[4]))

  files=uos.listdir('/lib')
  for file in files:
    if file is not 'Bootmanager':
      options.add_item("%s" % file)
  ugfx.input_attach(ugfx.JOY_UP, lambda pushed: test_file(files[options.selected_index()]) if pushed else False)
  ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: test_file(files[options.selected_index()]) if pushed else False)  
  ugfx.string(int(ugfx.width()/2)+4, 0, "Time: %d:%d" % (now[3],now[4]), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(int(ugfx.width()/2)+4, 14, "%s" % (files[options.selected_index()]), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(int(ugfx.width()/2)+4, 28, "Press A to select", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.input_attach(ugfx.BTN_A, lambda pushed: set_boot(files[options.selected_index()]) if pushed else False)
  ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.start_app("launcher", False) if pushed else False)
  ugfx.flush()
  while True:
    pass
 
main_loop()