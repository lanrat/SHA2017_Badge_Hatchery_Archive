import ugfx
import time
import badge
import wifi
import appglue
from hashlib import sha1

import uos
import ubinascii

from umqtt.simple import MQTTClient

class DevPlant:
  
    def draw_test(self):
        ugfx.clear(ugfx.WHITE)
        ugfx.string(0,12, "test", self.font, ugfx.BLACK)
        ugfx.flush()

    def __init__(self, font="fixed_10x20",server='mqtt.devlol.org',topic='devlol/h19/mainroom/winkekatze'):
        self.draw_test()
        self.font = font
        self.server = server
        self.topic = topic
        
    
        


dp = DevPlant()