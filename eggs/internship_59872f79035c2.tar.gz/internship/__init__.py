import ugfx, badge, appglue

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.string(20, 40, "Redirecting to home...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

badge.init()
appglue.start_app("")