import badge
import ugfx

############
## Config ##
############

name        = "Demo"
age         = "14y"
allergies   = "grain"

# Onsite contact
onsite_name     = "L33t Papa"
onsite_dect     = "1337"
onsite_mob      = "+31.612345678"

# Offsite contact
offsite_name    = "Mama"
offsite_mob     = "+31.612345678"

############
############

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)


ugfx.string(10, 5, "Name:","Roboto_pixelade13", ugfx.WHITE)
ugfx.string(0, 15, name, "PermanentMarker36", ugfx.WHITE)
ugfx.line(5, 55, 180, 55, ugfx.WHITE)
ugfx.string(10, 65, "Age:          " + age, "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(10, 80, "Allergies:  " + allergies, "Roboto_pixelade13", ugfx.WHITE)


ugfx.line(180, 0, 180, 150, ugfx.WHITE)

ugfx.area(180, 0, 120, 30, ugfx.WHITE)
ugfx.string(210, 5, "ICE", "Roboto_BlackItalic24", ugfx.BLACK)
ugfx.line(180, 30, 300, 30, ugfx.WHITE)

ugfx.string(190, 35, "Onsite contact:", "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(190, 45, "Name: " + onsite_name, "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(190, 55, "DECT: " + onsite_dect, "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(190, 65, "Mob: " + onsite_mob, "Roboto_pixelade13", ugfx.WHITE)

ugfx.string(190, 90, "Offsite contact:", "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(190, 100, "Name: " + offsite_name, "Roboto_pixelade13", ugfx.WHITE)
ugfx.string(190, 110, "Mob: " + offsite_mob, "Roboto_pixelade13", ugfx.WHITE)

ugfx.flush(ugfx.LUT_FULL)
badge.eink_busy_wait()

