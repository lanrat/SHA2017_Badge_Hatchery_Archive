### Description: Leiden Tech
### Category: Games
### License: MIT
### Appname: Dice
### Built-in: no

import badge
import ugfx
import machine
import math
import random
import appglue
import time
import deepsleep

def dice():
    badge.init()
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP,lambda pressed: btn_up(pressed))
    ugfx.input_attach(ugfx.JOY_DOWN,lambda pressed: btn_down(pressed))
    ugfx.input_attach(ugfx.JOY_LEFT,lambda pressed: btn_left(pressed))
    ugfx.input_attach(ugfx.JOY_RIGHT,lambda pressed: btn_right(pressed))
    ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: btn_select(pressed))
    ugfx.input_attach(ugfx.BTN_START,lambda pressed: btn_start(pressed))
    ugfx.input_attach(ugfx.BTN_A,lambda pressed: btn_a(pressed))
    ugfx.input_attach(ugfx.BTN_B,lambda pressed: btn_b(pressed))

    [year, month, mday, wday, hour, minute, second, microseconds] = machine.RTC().datetime()
    random.seed(int(microseconds))
    display()

def drawPip(pipNum,dieNum):
# 1 2 3
# 4 5 6
# 7 8 9
    global fgcolor, gxoffset, gyoffset,  pipRad, pipDim, xoffset
    row = math.floor( (pipNum - 1) / 3 ) + 1
    col = ((pipNum - 1) % 3) + 1
    x = col * 2 
    y = row * 2
    dieWidth=pipDim*7
    ugfx.fill_circle(x * pipDim + xoffset - pipRad , y * pipDim + gyoffset - pipRad, pipRad, fgcolor)

def display():
    global fgcolor, gxoffset, gyoffset, pipRad, pipDim, numOfDie, cheatOn, xoffset
    clearbg()
    for i in range(numOfDie):
        dieNum=i+1
        dieWidth=pipDim*7
        xoffset = gxoffset + (dieWidth * (dieNum - 1)) + (i * 2)

        if i is 0 or cheatOn is False:
            value = random.randint(1,6)
        if (value == 6):#6
            drawPip(2,dieNum)
            drawPip(8,dieNum)
        if (value > 1): #2 3 4 5 6
            drawPip(3,dieNum)
            drawPip(7,dieNum)
        if (value > 3): #4 5 6
            drawPip(1,dieNum)
            drawPip(9,dieNum)
        if (value % 2 != 0 ): #1 3 5
            drawPip(5,dieNum)

        ugfx.line(xoffset,gyoffset,xoffset,dieWidth+gyoffset,fgcolor)
        ugfx.line(xoffset,dieWidth+gyoffset,dieWidth+xoffset,dieWidth+gyoffset,fgcolor)
        ugfx.line(dieWidth+xoffset,dieWidth+gyoffset,dieWidth+xoffset,gyoffset,fgcolor)
        ugfx.line(dieWidth+xoffset,gyoffset,xoffset,gyoffset,fgcolor)

    badge.eink_busy_wait()
    ugfx.flush()

def resize(numOfDie):
    global font,pipRad, pipDim, gyoffset, gxoffset
    pipRad=9 - numOfDie
    pipDim=pipRad*2
    gyoffset=5 * numOfDie
    gxoffset=math.floor(296 / 2 - ( ( pipDim * 7 * numOfDie ) / 2 )) - pipRad

def quit():
    global font,bgcolor,fgcolor
    clearbg()
    ugfx.string(50, 50, "Quitting", font,fgcolor)
    ugfx.flush()
    appglue.start_app("launcher",False)

def clearfg():
    global font,bgcolor,fgcolor
    ugfx.clear(fgcolor)
    ugfx.flush()
    
def clearbg():
    global font,bgcolor,fgcolor
    ugfx.clear(bgcolor)
    ugfx.flush()

def clearScreen():
    clearfg()
    clearbg()

def btn_a(pressed):
    if pressed:
        display()

def btn_b(pressed):
    if pressed:
        display()

def btn_up(pressed):
    global cheatOn
    if pressed:
        cheatOn=True

def btn_down(pressed):
    global cheatOn
    if pressed:
        cheatOn=False

def btn_left(pressed):
    global numOfDie, pipRad, pipDim, gyoffset, gxoffset
    if pressed:
        if (numOfDie > 1):
            numOfDie=numOfDie-1
            resize(numOfDie)
        clearfg()
        display()

def btn_right(pressed):
    global numOfDie, pipRad, pipDim, gyoffset, gxoffset
    if pressed:
        if (numOfDie < 5):
            numOfDie=numOfDie+1
            resize(numOfDie)
        clearfg()
        display()

def btn_start(pressed):
    if pressed:
        quit()

def btn_select(pressed):
    if pressed:
        global font,bgcolor,fgcolor
        clearbg()
        ugfx.string(50, 50, "Restarting", font,fgcolor)
        ugfx.flush()
        appglue.start_app("dice",False)

########
# MAIN #
########
bgcolor=ugfx.WHITE
fgcolor=ugfx.BLACK
font="PermanentMarker22"
numOfDie=1
cheatOn=False
resize(numOfDie)
dice()
