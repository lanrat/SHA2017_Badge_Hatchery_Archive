import ugfx
#import random

x = 56
y = 83

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
  


ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.BTN_START, go_home)
ugfx.input_attach(ugfx.BTN_A, clean)
ugfx.flush()

#x = random.randint(20,276)
#y = random.randint(20,108)

while True:
  if x > 287:
    x -= 1
    
  if x < 1:
    x += 2
    
  if y > 119:
    y -= 2
  else:
    y += 1
  y += 1
  ugfx.fill_circle(x, y, 8, ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)