import badge
import ugfx
import network
import usocket as socket
import time
badge.init()
ugfx.init()
ugfx.string(0, 0, "acquiring network connection...", "pixelade13", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
netif.connect("SHA2017-insecure")
netif.isconnected()

cur_ip = netif.ifconfig()[0]
while True:
	cur_ip = netif.ifconfig()[0]
	if cur_ip == "0.0.0.0":
		time.sleep(1)
		pass
	else:
		break

ai = socket.getaddrinfo(cur_ip,8080)
addr = ai[0][4]
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(addr)
s.listen(5)

ugfx.string(0, 13, "Listening on: "  + cur_ip + ":8080", "pixelade13", ugfx.BLACK)
ugfx.flush()