import wifi
import ugfx
import urequests
import time

ugfx.init()
ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)

ugfx.string(30, 50, "Connecting to Wifi...", "PermanentMarker22", ugfx.BLACK)
ugfx.flush()

wifi.init()
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# Display 'Still Trolling Anyway'
ugfx.clear(ugfx.BLACK)
ugfx.string(150,25,"STILL","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.string(130,50,"Trolling","PermanentMarker22",ugfx.WHITE)
len = ugfx.get_string_width("Hacking","PermanentMarker22")
ugfx.line(130, 72, 144 + len, 72, ugfx.WHITE)
ugfx.line(140 + len, 52, 140 + len, 70, ugfx.WHITE)
ugfx.string(140,75,"Anyway","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.flush()

def troll(code):
    def troll_callback(pressed):
        return urequests.post('http://sha2017.hsbxl.be/cgi-bin/sounds.sh', data=code)
    return troll_callback

# Setting up callbacks
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, troll('f74c333609ffc8298501919537d2fef9'))
ugfx.input_attach(ugfx.JOY_DOWN, troll('32331bfbf6694d163a6bdd39a4882c1f'))
ugfx.input_attach(ugfx.JOY_LEFT, troll('ef24b840c4c1243b286cb96c2bad111c'))
ugfx.input_attach(ugfx.JOY_RIGHT, troll('52ea65b92688de13fcaa776b23c54dd9'))
ugfx.input_attach(ugfx.BTN_A, troll('71d297ca53bda6f1967c85242ddd1668'))
ugfx.input_attach(ugfx.BTN_B, troll('3aa0e8daa508fd335ac98c7caa4e8ece'))
ugfx.input_attach(ugfx.BTN_START, troll('583956b46bd344d29b5684416cf2b349'))
ugfx.input_attach(ugfx.BTN_SELECT, troll('e2a174d850be7f3b7fa85511afdfbc50'))

while True:
    pass
