import ugfx
import badge

ugfx.init()
ugfx.input_init()
badge.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()


def printtest():
  ugfx.string(40, 40, "MIEP", "Roboto_Regular12", ugfx.WHITE)
  ugfx.flush()
  
ugfx.input_attach(ugfx.JOY_UP, printtest)

while 1:
  pass