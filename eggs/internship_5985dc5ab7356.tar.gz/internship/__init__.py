import ugfx, badge

def start():
    ugfx.string(20, 40, 'Hi there :p', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()

ugfx.init()
badge.init()
start()