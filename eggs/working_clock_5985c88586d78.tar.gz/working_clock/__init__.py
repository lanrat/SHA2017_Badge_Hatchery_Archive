import easyrtc
import ugfx
import badge
import ugfx
import time

badge.init()
ugfx.init()

while True:
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0,0,"A working clock","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(0, 20, easyrtc.string(), "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    time.sleep(23)
