from buienradar import Buienradar

Buienradar.start()
