import badge
import ugfx
import appglue

def home(pushed):
    if(pushed):
        appglue.home()

badge.init()
ugfx.init()
badge.leds_init()
ugfx.input_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(170,50,"Coloring","PermanentMarker22",ugfx.BLACK)
len = ugfx.get_string_width("Coloring","PermanentMarker22")
ugfx.line(170, 72, 184 + len, 72, ugfx.BLACK)
ugfx.line(180 + len, 52, 180 + len, 70, ugfx.BLACK)
ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
try:
    badge.eink_png(0,50,'/lib/sha2017_colors/shrug.png')
except:
    ugfx.string(100,50,"Error loading shrug.png"),ugfx.BLACK

ugfx.flush()
ugfx.input_attach(ugfx.BTN_SELECT, home)

sha2017 = bytes(24)

while True:
    sha2017 = bytes([87, 192, 214, 1, 106, 8, 154, 1, 77, 91, 219, 1, 126, 44, 82, 1, 154, 211, 73, 1, 185, 6, 57, 1, 255, 255, 255])
    badge.leds_send_data(sha2017)