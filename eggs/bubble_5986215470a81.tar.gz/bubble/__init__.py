import ugfx
import machine

def go_home(pushed):
    if(pushed):
        machine.deepsleep(1)

ugfx.init()
ugfx.clear(ugfx.BLACK)
        
ugfx.input_attach(ugfx.BTN_B, go_home)

ugfx.fill_circle(10, 10, 4, ugfx.BLACK)
ugfx.fill_circle(10, 10, 4, ugfx.BLACK)
ugfx.fill_circle(10, 10, 4, ugfx.BLACK)
  
while True:
	pass