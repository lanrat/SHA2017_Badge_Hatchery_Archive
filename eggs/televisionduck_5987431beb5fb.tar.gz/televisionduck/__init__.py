import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.line(10,20,40,10,ugfx.BLACK)
ugfx.box(100,110,150,130,ugfx.BLACK)