import ugfx, wifi, network, ubinascii, gc
from time import sleep
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"wifi is connected. Start scanning...","Roboto_Regular12", 0)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = sta_if.scan()
sorted(scanResults, key=lambda net: net[3], reverse=True)
ugfx.clear(ugfx.WHITE);
bssids = ""
for AP in scanResults:
  bssid = ubinascii.hexlify(AP[1]).upper()
  bssids = bssids + ',{:12}'.format(bssid[0:12])
bssids = bssids[1:]
# do request the POS
url = "http://openwifi.su/api/v1/bssids/"+bssids
r = requests.get(url)
gc.collect()
data = r.json()
r.close()

ugfx.string(10,10, str(data), "Roboto_Regular12", 0)
ugfx.flush()
ugfx.input_attach(ugfx.BTN_B, go_home)