import buienradar

def setup():
    pass

def loop():
    return 60000

def draw(y):
    buienradar.Buienradar()
    return [60000, 20]