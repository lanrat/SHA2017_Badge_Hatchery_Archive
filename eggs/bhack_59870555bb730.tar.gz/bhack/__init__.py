import badge, time, appglue, ugfx

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.area(10,10,32,32,ugfx.WHITE)
ugfx.string(16,15,"B","Roboto_Black22",ugfx.BLACK)
ugfx.string(42,15,"hack","Roboto_Black22",ugfx.WHITE)

enabled = badge.nvs_get_u8("bhack","enable", 0)
if enabled:
    enabled = 0
    ugfx.string(16,45 , "bhack enabled")
else:
    enabled = 1
    ugfx.string(16, 45, "bhack enabled, go to splash", "Roboto_Black22", ugfx.BLACK)
enabled = badge.nvs_set_u8("sweary","enable", enabled)

time.sleep(5)
appglue.home()