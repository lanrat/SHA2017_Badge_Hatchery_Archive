from umqtt.simple import MQTTClient

try:
    import pixelSnake
except Exception as e:
    def log_start(self):
        c = MQTTClient()
        c.connect("pixelSnakeDebug", "mqtt.sha2017.org", clean_session=False)
        c.publish(str(e))
        c.disconnect()
