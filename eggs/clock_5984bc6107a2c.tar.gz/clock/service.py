import easyrtc
import ugfx

def setup():
    pass
  
def loop(counter):
    return False

def draw(y):
    t = easyrtc.string()
    ugfx.string(0, 50, t, "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    return [60000, 0]