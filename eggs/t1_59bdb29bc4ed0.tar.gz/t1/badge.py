def leds_send_data(value, size):
    pass