# fork of sha_color

import badge
import ugfx
import appglue

def set_brightness(value):
    values = bytes([0, 0, 0, value, 0, 0, 0, value, 0, 0, 0, value, 0, 0, 0, value, 0, 0, 0, value, 0, 0, 0, value])
    badge.leds_send_data(values)

def home(pushed):
    if(pushed):
        print("go home")
        appglue.home()

def low(pushed):
    global brightness
    if(pushed):
        print("sending low")
        badge.leds_enable()
        brightness -= 10
        brightness %= 255
        set_brightness(brightness)
        

def high(pushed):
    global brightness
    if(pushed):
        print("sending high")
        badge.leds_enable()
        brightness += 10
        brightness %= 255
        set_brightness(brightness)

def off(pushed):
    if(pushed):
        print("led off")
        badge.leds_disable()

brightness = 100

badge.init() 
ugfx.init()
badge.leds_init()
ugfx.input_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(170,50,"Torching","PermanentMarker22",ugfx.BLACK)
len = ugfx.get_string_width("Torching","PermanentMarker22")
ugfx.line(170, 72, 184 + len, 72, ugfx.BLACK)
ugfx.line(180 + len, 52, 180 + len, 70, ugfx.BLACK)
ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(20, 110, "SELECT: exit, START: off, A: low, B: high","Roboto_Regular12",ugfx.BLACK)
ugfx.string(255, 115, "rev. 18","Roboto_Regular12",ugfx.BLACK)
try:
    badge.eink_png(0,40,'/lib/sha2017_colors/shrug.png')
except:
    ugfx.string(100,50,"Error loading shrug.png"),ugfx.BLACK

ugfx.flush()
ugfx.input_attach(ugfx.BTN_SELECT, home)
ugfx.input_attach(ugfx.BTN_START, off)
ugfx.input_attach(ugfx.BTN_A, low)
ugfx.input_attach(ugfx.BTN_B, high)


badge.leds_enable()
set_brightness(brightness)