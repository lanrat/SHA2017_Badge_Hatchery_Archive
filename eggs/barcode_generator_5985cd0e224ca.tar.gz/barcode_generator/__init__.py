import ugfx
import badge
from appglue import home
from . import ean13

#init everything
badge.init()
ugfx.init()
badge.eink_init()
ugfx.input_init()

# two groups og 6 digits with one leading digit
# 7 bits/bars per digit
# first digit decides pattern
# 296×128 px display

# barcode describing variables
bar_width = 2
bar_len = 60
sep_len = bar_len + 10
bar_x = int((296-95*bar_width)/2)
bar_y = 10

# cursor describing variables
cur_pos = 0
cur_a = 7*bar_width
cur_b = 2
cur_y = 128-cur_b-10

digit_y = 100
digit_font = "Roboto_Regular18"
digit_color = ugfx.BLACK

# EAN of Club Mate
default_digits = [4, 0, 2, 9, 7, 6, 4, 0, 0, 1, 8, 0]
digits = []
namespace = "ean13"

def read_digits_from_nvs():
    digits = []
    for i in range(len(default_digits)):
        digits += [badge.nvs_get_u8(namespace, i, default_digits[i])]

def write_digits_to_nvs(digits):
    for i in range(len(digits)):
        badge.nvs_set_u8(namespace, i, digits[i])

def cursor_pos_to_x(pos):
  cur_x = bar_x+(cur_pos-1)*bar_width*7
  cur_x += 3*bar_width if cur_pos in range(1, 7) else + 8* bar_width if cur_pos in range(7,13) else 0
  return cur_x

def draw_cursor():
  ugfx.fill_rounded_box(cursor_pos_to_x(cur_pos), cur_y, cur_a, cur_b, 0, ugfx.BLACK)

def undraw_cursor():
  ugfx.fill_rounded_box(cursor_pos_to_x(cur_pos), cur_y, cur_a, cur_b, 0, ugfx.WHITE)

# move cursor and wrap around
def cursor_move(forward):
  global cur_pos
  undraw_cursor()
  cur_pos += 1 if forward else -1
  cur_pos %= len(digits)-1
  render()

# advance cursor
def cursor_pp(pressed):
  if pressed:
    print("->")
    cursor_move(True)

# move back cursor
def cursor_mm(pressed):
  if pressed:
    print("<-")
    cursor_move(False)

def digit_count(up):
  digits[cur_pos] += 1 if up else -1
  digits[cur_pos] %= 10

def dig_up(pressed):
  if pressed:
    digit_count(True)
    render()

def dig_down(pressed):
  if pressed:
    digit_count(False)
    render()

def clear_paper():
  for i in range(2):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def draw_seperator(x, y):
  for pos_x in [x, x+2*bar_width]:
    ugfx.fill_rounded_box(pos_x, y, bar_width, sep_len, 0, ugfx.BLACK)

def draw_code(code):
  pos_x = bar_x
  draw_seperator(pos_x, bar_y)
  pos_x += 3*bar_width

  for i in range(int(len(code)/2)):
    if code[i] == '1':
      ugfx.fill_rounded_box(pos_x, bar_y, bar_width, bar_len, 0, ugfx.BLACK)
    pos_x += bar_width

  pos_x += bar_width
  draw_seperator(pos_x, bar_y)
  pos_x += 3*bar_width
  pos_x += bar_width

  for i in range(int(len(code)/2), len(code)):
    if code[i] == '1':
      ugfx.fill_rounded_box(pos_x, bar_y, bar_width, bar_len, 0, ugfx.BLACK)
    pos_x += bar_width

  draw_seperator(pos_x, bar_y)

def draw_digits(digits):
    pos_x = bar_x-7*bar_width
    ugfx.char(pos_x, digit_y, ord("0")+digits[0], digit_font, digit_color)
    pos_x += 10*bar_width
    for i in range(1, 7):
        ugfx.char(pos_x, digit_y, ord("0")+digits[i], digit_font, digit_color)
        pos_x += 7*bar_width
    pos_x += 5*bar_width
    for i in range(7, 13):
        ugfx.char(pos_x, digit_y, ord("0")+digits[i], digit_font, digit_color)
        pos_x += 7*bar_width

def render():
  global code
  ugfx.clear(ugfx.WHITE)
  draw_code(ean13.digits_to_code(ean13.add_check_digit(digits)))
  draw_cursor()
  draw_digits(ean13.add_check_digit(digits))
  write_digits_to_nvs(digits)
  ugfx.flush()


# attach button actions
ugfx.input_attach(ugfx.BTN_START, lambda pressed: home() if pressed else True)
ugfx.input_attach(ugfx.JOY_RIGHT, cursor_pp)
ugfx.input_attach(ugfx.JOY_LEFT, cursor_mm)
ugfx.input_attach(ugfx.JOY_UP, dig_up)
ugfx.input_attach(ugfx.JOY_DOWN, dig_down)

clear_paper()
digits = read_digits_from_nvs()
render()