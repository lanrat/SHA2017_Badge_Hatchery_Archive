import woezel, appglue, wifi, time
#Just a funny joke-virus to keep you busy ;)
#Don't worry weĺl decrypt it for free!

def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

wifi.init()
await_wifi()
woezel.install('Internship')
appglue.start_app('Internship')