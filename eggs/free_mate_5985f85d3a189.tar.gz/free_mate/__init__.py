import usocket as socket
import wifi
import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

HOST = "https://badge:65bcd4adaf8b30c657cd0b52fae31576@automate.nwlab.nl/api/vend"
PORT = 443

def passout():
    exit()

def vendmate():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(45,85,"A pressed, Come get it!","Roboto_Black22",ugfx.BLACK)
    ugfx.flush()
    s = socket.socket()
    s.connect((HOST, PORT))

def main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(45,85,"Free Mate @ Torvalds press A","Roboto_Black22",ugfx.BLACK)
    ugfx.flush()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, vendmate)
ugfx.input_attach(ugfx.BTN_SELECT, passout)
main()