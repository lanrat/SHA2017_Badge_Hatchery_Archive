import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.string_box(0,10,296,26, "Mijn badge.", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)

badge.eink_png(206,63,'/lib/personal_logo/logobadge.png')
ugfx.flush()