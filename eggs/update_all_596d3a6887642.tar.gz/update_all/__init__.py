import ugfx, gc, wifi, badge, deepsleep, network, woezel, os
from time import *

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

try:
    apps = os.listdir('lib')
except OSError:
    apps = []

for app in apps:
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10,10,"Installing...","Roboto_Regular12", 0)
    ugfx.string(10,25,app,"Roboto_Regular12", 0)
    ugfx.flush()    
    woezel.install(app)

import machine
machine.deepsleep(1)