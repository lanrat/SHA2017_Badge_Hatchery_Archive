import ugfx, badge, time, random, os

interval = 900000

items = [
        "beer",
        "food",
        "xxxx"
]
names = [
        "name 1",
        "name 2",
        "name 3"
]

seeded = False
name = ""
item = ""

def setup():
    pass

def loop():
    global interval, seeded, name, item, items, names
    enabled = badge.nvs_get_u8("item_roulette","enable", 0)
    if enabled:
        if not seeded:
            seed = sum(c << (i*8) for i, c in enumerate(os.urandom(4)))
            random.seed(seed)
            seeded = True
        # Do this here so that we don't choose a new message as soon as we redraw for sleep
        name = random.choice(names)
        item = random.choice(items)
        return interval

    return 9999999999

def draw(y, sleep=2):
    global item, name
    enabled = badge.nvs_get_u8("item_roulette","enable", 0)
    if enabled and seeded and sleep:
        intro = "The lucky one to get "+ item +" is..."

        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

        led_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100])
        badge.leds_enable()
        badge.leds_send_data(led_array,24)

        ugfx.string_box(0,10,296,28, intro, "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
        ugfx.string_box(0,30,296,70, name, "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0, 100, 296, 30, "-item_roulette based on Sweary", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyRight)
	    time.sleep(1)
	    badge.leds_disable()
        return [interval, 0]

    return [9999999999, 0]