import ugfx, appglue

ugfx.init()
ugfx.input_init()

def home(pressed):
  if pressed:
    appglue.home()

ugfx.input_attach(ugfx.BTN_B, home)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.display_image(0,0,'/lib/Bulwark/bulwark.png')
ugfx.string(120, 50, "Bulwark", "Roboto_Black22", ugfx.BLACK)
ugfx.line(155, 75, 245, 75, ugfx.BLACK)


ugfx.flush()