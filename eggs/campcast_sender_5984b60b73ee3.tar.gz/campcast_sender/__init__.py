import network
import usocket as socket
import time

ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)

ugfx.string(140, 75, "CampCast Sender","Roboto_BlackItalic24", ugfx.BLACK)

netif = network.WLAN(network.STA_IF)
netif.enable(True)
time.sleep(0.5)
netif.connect("Crazy Belgians")
time.sleep(0.5)

print(netif.ifconfig())

def send_msg(text):
      sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
      sock.sendto(text, ('255.255.255.255', 2115))


def send_hello(pressed):
    send_msg("Sent from my CampCast!")


def send_yo(pressed):
    send_msg("Yo this is cool!")


ugfx.input_attach(ugfx.BTN_A, send_hello)
ugfx.input_attach(ugfx.BTN_B, send_yo)

while True:
    pass
