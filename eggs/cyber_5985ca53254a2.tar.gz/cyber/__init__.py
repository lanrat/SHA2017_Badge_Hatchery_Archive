import ugfx, badge, appglue, utime

def cyber():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    try:
        # Proudly stolen from https://cyber.equipment/cyber_plain.png
        badge.eink_png(0, 0, '/lib/cyber/cyber_plain.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    utime.sleep(4)

def program_main():
    print("--- Cyber Cyber v4 ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    cyber()
    appglue.start_app("") # Return home

# Start main application
program_main()