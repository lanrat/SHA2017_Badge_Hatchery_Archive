import umqtt.simple

clnt = ""

def sub_cb(topic, msg):
	print((topic, msg))

def main():
  print("Init")
  clnt = umqtt.simple.UMQTTClient("umqtt_client","mosquitto.revspace.nl")
  clnt.set_callback(sub_cb)
  print("Connect")
  clnt.connect()
  clnt.subscribe(b"revspace")