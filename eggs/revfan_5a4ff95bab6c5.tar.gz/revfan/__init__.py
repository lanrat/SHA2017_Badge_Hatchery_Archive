import easywifi, easydraw, urandom, gc, ugfx, badge
from time import *

easydraw.msg("Connecting to WiFi", title = 'Still Connecting Anyway...', reset = True)
easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(5000)

easydraw.msg("Connecting to MQTT")

from umqtt.simple import MQTTClient

co2 = 0;
humi = 100;
fan = 0;
space_open = False;

def update_display():
  ugfx.clear(ugfx.WHITE)
  ugfx.string(0,  0, "Humidity: " + str(humi), "Roboto_Black22", ugfx.BLACK)
  ugfx.string(0, 25, "CO2: "      + str(co2),  "Roboto_Black22", ugfx.BLACK)
  ugfx.string(0, 50, "Space: "    + ("open" if space_open else "closed"), "Roboto_Black22", ugfx.BLACK)
  ugfx.string(0, 75, "Fan: "      + str(fan),  "Roboto_Black22", ugfx.BLACK)

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    global co2
    global humi
    
    print((topic, msg))
    
    if topic == b"revspace/sensors/humidity":
        humi = float(msg.decode('utf-8').split(' ')[0])
    if topic == b"revspace/sensors/co2":
        co2 = float(msg.decode('utf-8').split(' ')[0])
    if topic == b"revspace/state":
        space_open = (msg == b"open")
    update_display()

def main(server="mosquitto.space.revspace.nl"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"revspace/sensors/humidity")
    c.subscribe(b"revspace/sensors/co2")
    
    easydraw.msg("MQTT Connected", title = 'Still MQTT Anyway...', reset = True)
    c.check_msg()
    
    lastupdate = ticks_ms()
    while True:
        gc.collect()
        c.check_msg()
        now = ticks_ms()
        if ticks_diff(now, lastupdate) > 1000:
          newfan = 0
          if co2 > 1500: newfan += 1
          if co2 > 1200: newfan += 1
          if co2 >  900: newfan += 1
          if co2 >  600: newfan += 1
          if humi < 38:  newfan -= 1
          if humi < 34:  newfan -= 1
          if space_open: newfan -= 1
          print(newfan)
          if newfan != fan:
            newfan = fan;
            # fan = 1 if newfan else 0;
            # pulse on/off
        sleep_ms(10)
    c.disconnect()

main()