import urequests
import json
import badge
import wifi
import binascii
import machine

def gamma(x, gamma, max_in, max_out):
    return int(pow(float(x)/float(max_in), gamma) * max_out + 0.5)

def hex_to_grbw_list(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    w = 0
    # gamma
    g = gamma(g, 2.8, 255, 116)
    r = gamma(r, 2.8, 255, 255)
    b = gamma(b, 2.8, 255, 255)
    # white balance
    while (r>0) and (g>0) and (b>0):
        r = r - 1
        g = g - 1
        b = b - 1
        #w = w + 1
    return [g, r, b, w]

next_update = None

def update():
    global cheerlightsEnabled
    global next_update

    t = machine.RTC().datetime()
    next_update = (t[0], t[1], t[2], t[3], t[4], t[5], t[6]+30, t[7])

    r = urequests.get("http://api.thingspeak.com/channels/1417/field/2/last.json")
    data = json.loads(r.text)
    print("Cheerlights data: %s" % data)
    vals = hex_to_grbw_list(data['field2'][1:])
    print(vals)
    return vals

def setup():
    global next_update
    global cheerlightsEnabled

    cheerlightsEnabled = int(badge.nvs_get_str('cheerlights', 'state', '0'))
    if (cheerlightsEnabled<1):
        print("Cheerlights: Disabled! Please enable in the app!")
    else:
        wifi.init()
        badge.leds_enable()
        test()
        badge.leds_set_state(bytes(6*([0]*4)))
        next_update = machine.RTC().datetime()

def flatten(l):
    return [item for sublist in l for item in sublist]

def test():
    white = hex_to_grbw_list("ffffff")
    yellow = hex_to_grbw_list("fffc0b")
    green = hex_to_grbw_list("5bff0b")
    orange = hex_to_grbw_list("ffb70b")
    red = hex_to_grbw_list("ff0b50")
    blue = hex_to_grbw_list("330bff")
    badge.leds_set_state(bytes(white+yellow+green+orange+red+blue))
    import time
    time.sleep(1)

# Thanks to https://stackoverflow.com/questions/28015400/how-to-fade-color for the tip
def lerp(a, b, t):
    return a*(1 - t) + b*t

last_color = [0,0,0,0]
next_color = [0,0,0,0]
i = 0

def loop(sleepCount):
    global cheerlightsEnabled
    global next_update
    global last_color
    global next_color
    global i
    if cheerlightsEnabled:
        if machine.RTC().datetime() >= next_update:
            next_color = update()
        last_color = list(int(lerp(c, w, 0.01)) for c, w in zip(last_color, next_color))
        badge.leds_set_state(bytes(6*last_color))
    return False