import ugfx
import time
import badge
import wifi
import appglue
from hashlib import sha1

import uos
import ubinascii

from umqtt.simple import MQTTClient

class DevPlant:
  
    def draw_test(self):
        ugfx.clear(ugfx.WHITE)
        ugfx.string(0,12, "test")
        ugfx.flush()

    def __init__(self):
        self.draw_test()
        


dp = DevPlant()