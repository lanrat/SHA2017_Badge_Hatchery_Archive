import badge
import ugfx
import time
import appglue

def quit(pressed):
    if(pressed):
        appglue.start_app("")
    ugfx.flush()

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
#ugfx.input_attach(ugfx.BTN_START, lambda pressed: quit(pressed))
#ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(50, 50, "popcorn","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))

leds_array = bytes(24)
ps = 1

while True:
    if ps > 5:
      ps = 1
    arr = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ps = ps + 1
    arr[ps * 4] = 255
    leds_array = bytes(arr)
    badge.leds_send_data(leds_array)
    time.sleep(1)