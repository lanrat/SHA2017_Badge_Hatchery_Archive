import badge                                                                                                                                                                    
badge.init()
badge.eink_init()
badge.eink_busy()

import time
import ugfx
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)

OPTIONS = 5 # maximum five people can play this game
scrollPos = 0 

def choose_mod_scroll_up(pressed):
    if pressed:
        global scrollPos
        if scrollPos>0:
            scrollPos -= 1
            display_amount_of_people_menu(scrollPos)

def choose_mod_scroll_down(pressed):
    if pressed:
        global scrollPos
        if scrollPos<OPTIONS-1:
            scrollPos += 1
            display_amount_of_people_menu(scrollPos)


def display_selected_box(display_text,x,y):
    ugfx.fill_rounded_box(0,y,300,12,0,ugfx.BLACK)
    ugfx.string(x,y,display_text,"Roboto_Regular12",ugfx.WHITE)

def display_non_selected_box(display_text,x,y):
    ugfx.string(x,y,display_text,"Roboto_Regular12",ugfx.BLACK)

def display_amount_of_people_menu(selection=0):

    string_array = [ 
        "You want to play this game alone",
        "You want to play this together",
        "You want to play this with three people",
        "You want to play this with four people",
        "You want to play this with five people"
    ]

    for ix,elt in enumerate(string_array):
        if selection==ix:
            display_selected_box(elt,1,12*ix)
        else:
            display_non_selected_box(elt,1,12*ix)

    ugfx.input_attach(ugfx.JOY_UP, choose_mod_scroll_up)
    ugfx.input_attach(ugfx.JOY_DOWN, choose_mod_scroll_down)

def select_option():
    ugfx.clear(ugfx.BLACK)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(x,y,"\o/ That was fun!","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(x,y,"You chose index: %s" % scrollPos,"Roboto_BlackItalic24",ugfx.BLACK)

def attach_keys_to_menu():
   ugfx.input_attach(ugfx.JOY_UP, choose_mod_scroll_up)
   ugfx.input_attach(ugfx.JOY_DOWN, choose_mod_scroll_down)
   ugfx.input_attach(ugfx.BTN_A, select_option)

display_amount_of_people_menu()
attach_keys_to_menu()