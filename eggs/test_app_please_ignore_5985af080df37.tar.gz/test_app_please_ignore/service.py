import lenny_face_generator as lenny

def setup():
    pass

def loop():
    pass

def draw(y):
    lenny.render_creation(
            lambda w, h: (lenny.BADGE_EINK_WIDTH - w, y),
            lenny.creation)
