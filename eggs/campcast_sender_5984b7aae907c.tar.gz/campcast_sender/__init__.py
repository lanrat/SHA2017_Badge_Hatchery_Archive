import network
import usocket as socket
import time
import ugfx

ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)

ugfx.string(40, 75, "CampCast Sender","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
time.sleep(0.5)
netif.connect("Crazy Belgians")
while netif.ifconfig()[0] == '0.0.0.0':
    time.sleep(0.1)
    print('Waiting for network...')

print(netif.ifconfig())

def send_msg(text):
      sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
      sock.sendto(text, ('255.255.255.255', 2115))


def send_hello(pressed):
    send_msg("Sent from my CampCast!")


def send_yo(pressed):
    send_msg("Yo this is cool!")


ugfx.input_attach(ugfx.BTN_A, send_hello)
ugfx.input_attach(ugfx.BTN_B, send_yo)

while True:
    pass
