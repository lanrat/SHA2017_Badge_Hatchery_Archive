"""
build rainbow
attach hardware to controller
launch the rainbow attack
"""
import math
import time
import badge
import ugfx
import deepsleep

#import time
#from random import randint, random
#import sys


def go_home():
    deepsleep.reboot()


def hardware_init():
    badge.init()
    ugfx.init()
    ugfx.input_init()
    badge.leds_init()
    badge.leds_enable()

#decoupler
def badge_leds_send_data(b):
    badge.leds_send_data(b)


class LedsController:
    def __init__(self, set_color_bytes, err_handler):
        self.leds_init()
        self.set_color_bytes = set_color_bytes # avoid self binding
        self.err_handler = err_handler

    def leds_init(self):
        self.leds = []
        for _ in range(6):
            self.leds.append([0, 0, 0, 0])


    def show_leds(self):
        try:
            # sum() doesnt work
            leds_data = bytes(self.leds[0] + 
                self.leds[1] + 
                self.leds[2] + 
                self.leds[3] + 
                self.leds[4] + 
                self.leds[5]) 
            
            self.set_color_bytes(leds_data)

        except Exception as e:
            self.err_handler(e)




def press_handler(e):
    if e:
        go_home()

def attach_press_handlers():
    ugfx.input_attach(ugfx.JOY_RIGHT, press_handler)
    ugfx.input_attach(ugfx.JOY_LEFT, press_handler)
    ugfx.input_attach(ugfx.JOY_UP, press_handler)
    ugfx.input_attach(ugfx.JOY_DOWN, press_handler)
    ugfx.input_attach(ugfx.JOY_RIGHT, press_handler)
    ugfx.input_attach(ugfx.BTN_A, press_handler)
    ugfx.input_attach(ugfx.BTN_B, press_handler)
    ugfx.input_attach(ugfx.BTN_START, press_handler)
    ugfx.input_attach(ugfx.BTN_SELECT, press_handler)



def show_error(err):
    ugfx.set_lut(ugfx.LUT_NORMAL)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 10, str(err), "Roboto_Regular12", 0)
    ugfx.flush()


def buildRainbow(size):
    result = []
    k = math.pi * 2 / size
    for i in range(size):

        r = math.sin(i * k)
        r = r * r * 255.99999
        r = math.floor(r)
        g = math.sin(i * k + math.pi * 2/3)
        g = g * g * 255.99999
        g = math.floor(g)
        b = math.sin(i * k + math.pi * 4/3)
        b = b * b * 255.99999
        b = math.floor(b)
        val = [int(r), int(g), int(b), int(0)]
        result.append(val)
    return result

def main():

    attach_press_handlers()
    lc = LedsController(badge_leds_send_data, show_error)
    hardware_init()

    rainbow_len = 300
    leds_gap = 10
    rainbow = buildRainbow(rainbow_len)
    rainbow_state = 0


    while True:

        for i in range(6):
            led_state = (rainbow_state + i*leds_gap) % rainbow_len
            lc.leds[i] = rainbow[led_state]
        
        lc.show_leds()
        rainbow_state += 1

        time.sleep_ms(10)


try:
    main()
except Exception as e:
    show_error(e)