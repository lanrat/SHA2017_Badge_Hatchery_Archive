import badge
import ugfx
import math
from angel import pyqrnative

def make_qr(name):
	# up to level 27 (125x125px) can be displayed
	qr = pyqrnative.QRCode(2, pyqrnative.QRErrorCorrectLevel.Q)
	qr.addData(name)
	qr.make()
	

def draw_qr(qr, y_offset):
	max_x = max_y = qr.getModuleCount()
	matrix = qr.modules
	disp_x, disp_y = (296, 128 - y_offset)
	block_size = math.floor(disp_y/max_y)
	offset_x = 0
	# offset_x = int(disp_x/2) - int(block_size*max_y/2)
	offset_y = int(disp_y/2) - int(block_size*max_x/2) + y_offset

	ugfx.init()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()

	for y, row in enumerate(matrix):
	    for x, col in enumerate(row):
	        if qr.isDark(x, y):
	            ugfx.area(offset_x+x*block_size, offset_y+y*block_size, block_size, block_size, ugfx.BLACK)
	ugfx.string(150,10,"ANGEL","PermanentMarker22",ugfx.BLACK)
	ugfx.string(150,50,name,"PermanentMarker22",ugfx.BLACK)
	ugfx.flush()
	return disp_y

name="angel-{}".format(badge.nvs_get_str("owner", "name", ""))
draw_qr(make_qr(name))