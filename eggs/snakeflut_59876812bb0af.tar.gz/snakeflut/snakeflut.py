import badge
import ugfx
import deepsleep

# width = 296
# height = 128

tile = 20;
dir = 0
last_dir = 0


def snakeflut():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)

    # input
    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_LEFT, left)

    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def display():
    if dir != last_dir:
        ugfx.clear(ugfx.WHITE)
        if dir == 0:
            ugfx.area(tile*2, tile*1, tile*1, tile*1, ugfx.BLACK)
        if dir == 1:
            ugfx.area(tile*3, tile*2, tile*1, tile*1, ugfx.BLACK)
        if dir == 2:
            ugfx.area(tile*2, tile*3, tile*1, tile*1, ugfx.BLACK)
        if dir == 3:
            ugfx.area(tile*1, tile*2, tile*1, tile*1, ugfx.BLACK)

        last_dir = dir
        ugfx.flush()

def up(wut):
    dir = 0
    display()

def right(wut):
    dir = 1
    display()

def down(wut):
    dir = 2
    display()

def left(wut):
    dir = 3
    display()

def reboot(wut):
  deepsleep.reboot()

snakeflut()
