import ugfx

def setup():
    pass

def loop():
    return 60000

def draw(y):
    start(y)
    printRain(y)
    return [60000, 36]

def printRain(y):
    ugfx.string(0, y-50, "Still raining anyway %i" %y, "Roboto_Regular12", ugfx.BLACK)

def start(y):
    data = get_data()
#    printRain(12)
    draw_chart(data,y-36,20,4)
#    printRain(60)
    ugfx.string(x,y-12,"Buienradar","Roboto_Regular12", 0)

def get_data():
    try:
        #reponse = requests.get("http://br-gpsgadget-new.azurewebsites.net/data/raintext/?lat=52.28&lon=5.53")
        response = """020|22:10
000|22:15
000|22:20
000|22:25
000|22:30
000|22:35
030|22:40
040|22:45
050|22:50
090|22:55
200|23:00
150|23:05
050|23:10
000|23:15
000|23:20
000|23:25
000|23:30
000|23:35
000|23:40
000|23:45
000|23:50
000|23:55
000|00:00
000|00:05"""
    except:
        ugfx.string(80,10,"Could not download weather data","Roboto_Regular12", 0)
        return

    try:
        data = []
        for v in response.split("\n"):
            kv = v.split('|')
            data.append(v.split('|'))
    except:
        ugfx.string(80,10,"Could not convert data","Roboto_Regular12", 0)
    #reponse.close()
    return data


def draw_chart(data,dy,height,barsize): #[],10,20,4
    n = 0
    for v in data:
        spacer = 1
        mm = int(v[0])
        time = v[1]
        barsize=4
        x=n*(barsize+spacer)+spacer
        barheight=int(height/255*mm)
        y=dy-height-barheight
        cx=barsize
        cy=barheight+1
        ugfx.area(x,y,cx,cy, ugfx.BLACK)
#        printRain(36)
        n+=1
#        print(mm,time,n,x,y,cx,cy)
