#  import urequests as requests
 #  import deepsleep
import wifi
 #  import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()
badge.leds_init()
badge.vibrator_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(5,50,"Test1","PermanentMarker36",ugfx.BLACK)
    ugfx.flush()

if __name__ == "__main__":
    main()