import utime, badge, binascii

counter = 0
direction = True
serviceMode = 0

# This function gets called by the home application at boot
def setup():
    global serviceMode
    serviceMode = badge.nvs_get_u8('stijlrijder', 'serviceMode', 0)
    if serviceMode>5:
        serviceMode=5
    if (serviceMode<1):
        print("[STIJLRIJDER] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def leds(counter, direction):
    global serviceMode
    led = 0
    value = counter
    while value>10:
        led += 1
        value -= 10
               
    if direction:
        prevLed = led-1
        nextLed = led+1
    else:
        prevLed = led+1
        nextLed = led-1
        value = 10-value
    
    # pre-clearing output array
    output = []
    for i in range(0,24):
        output.append(0)
        

    # TODO: write funtion Drawpixel (pos, color)
    # TODO: convert chosen color to RGBW array

    ledLoc = led*4 + serviceMode-1
    output[ledLoc] = 255
    if prevLed>=0 and prevLed<=5:
        prevLedLoc = prevLed*4 + serviceMode-1
        output[prevLedLoc] = 255-round(value*25.5)
    if nextLed>=0 and nextLed<=5:
        nextLedLoc = nextLed*4 + serviceMode-1
        output[nextLedLoc] = round(value*25.5)
    return output

def loop():
    global serviceMode
    global direction
    global counter
        
    if (serviceMode>0): 
        if direction:
            counter += 1
        else:
            counter -= 1
        if counter>50:
            counter = 50
        if counter<10:
            counter = 10
        if counter==50 or counter==10:
            direction = not direction
        values = leds(counter, direction)
        badge.leds_send_data(bytes(values),24)
        return 5
    return 0
