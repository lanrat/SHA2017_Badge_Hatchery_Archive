import badge, ugfx
badge.leds_enable()
ugfx.input_init()


on = False

def button_a(pressed):
    global on
    if on:
      on = False
    else:
      on = True
    badge.leds_send_data(''.join([('\xff' if on else '\0') for i in range(24)]), 24)
    
ugfx.input_attach(ugfx.BTN_A, button_a)