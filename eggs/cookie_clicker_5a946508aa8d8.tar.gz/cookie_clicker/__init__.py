import ugfx
import time

# DISPLAY LOW LEVEL

# X:296    Y: 128
def draw_cookie():
    ugfx.circle(200, 64, 30, ugfx.BLACK)


def flush():
    ugfx.flush()


draw_cookie()
flush()

while True:
  time.sleep(10)