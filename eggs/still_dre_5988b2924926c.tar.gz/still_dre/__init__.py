# rasmis' idea, sshow's wisdom
import ugfx, badge, dialogs, appglue, time

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

txt = ["representin' for gangstas\n all across the world", "hittin' them corners\n in them lo-lo's, girl", "takin' time to\n perfect the beat", "got love for the streets", "D.R.E." ]

def exit_app():
  appglue.home()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit_app())

i = 0
while i < 5:
  ugfx.string_box(0,10,296,26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
  if i == 4:
    ugfx.string_box(0,40,296,48, txt[i], "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
  else:  
    ugfx.string_box(0,25,300,68, txt[i], "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)

  ugfx.string_box(0,94,296,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)


  ugfx.flush()
  time.sleep(3)
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()



  i += 1
  if i == 5:
    i=0