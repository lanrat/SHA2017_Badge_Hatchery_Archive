import uos

def enable():
    with open("/splash.py", "r") as f:
        orig = f.read()
    with open("/rsplash.py", "w") as f:
        f.write(orig)
    with open("/splash.py", "w") as f:
        f.write("""\
import ugfx, time
try:
    badge.eink_png(0,0,'/lib/ascii_porn/dickbutt.png')
    time.sleep(5)
except:
    pass
__import__('ascii_porn')
        """)
            
def disable():
    with open("/rsplash.py", "r") as f:
        orig = f.read()
    with open("/splash.py", "w") as r:
        r.write(orig)
