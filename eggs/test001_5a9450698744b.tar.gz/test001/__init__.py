import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.string(50, 30, "test", "Roboto_Regular18", ugfx.BLACK)

ugfx.flush()