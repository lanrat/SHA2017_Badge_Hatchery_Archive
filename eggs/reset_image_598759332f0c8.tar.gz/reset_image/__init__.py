import ugfx,badge,machine
ugfx.set_lut(ugfx.GREYSCALE)
ugfx.clear()
badge.eink_png(0,0,'/media/hacking.png')
ugfx.flush()

def home(pushed):
    if(pushed):
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_START, home)