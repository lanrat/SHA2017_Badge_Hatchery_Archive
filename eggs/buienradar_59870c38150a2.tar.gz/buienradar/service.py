import buienradar

def setup():
    pass

def loop():
    return 60000

def draw(y):
    ugfx.string(0, y-12, "Still raining anyway", "Roboto_Regular12", ugfx.BLACK)
    buienradar.start(y)
    return [60000, 20]
