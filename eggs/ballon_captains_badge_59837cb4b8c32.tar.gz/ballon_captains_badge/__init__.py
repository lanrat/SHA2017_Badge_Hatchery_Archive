import ballon_captains

ballon_captains.main()