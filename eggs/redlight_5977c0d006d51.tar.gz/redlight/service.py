import ugfx, badge

def setup():
    pass

def loop(c):
    pass

def draw(x,y):
    ugfx.clear(ugfx.BLACK)
    badge.eink_png(0,0,'/lib/redlight/redlight_bw.png')
    ugfx.flush()
