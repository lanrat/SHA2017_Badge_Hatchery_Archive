from memory import memory
