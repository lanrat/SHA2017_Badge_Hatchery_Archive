import ugfx, badge

compugroen = bytes([181,160,5,0,181,160,5,0,181,160,5,0,181,160,5,0,181,160,5,0,181,160,5,0])

badge.leds_enable()
badge.leds_send_data(compugroen, 24)

ugfx.init()
ugfx.set_lut(ugfx.LUT_FULL)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

badge.eink_png(0,0,'/lib/Dex/Dex.png')
ugfx.flush()