# Requires latest git pull submodule sync magic to actually work!
# Based on https://badge.sha2017.org/files/15130

import badge, ugfx, gc, wifi, time

SLEEPTIME = 24*60*60*1000 # uur * minuten * seconden * mili
old_status = False

def wait_wifi():
    print("Connecting to wifi")
    while not wifi.sta_if.isconnected():
        print("Retry...")
        time.sleep(10)

def update_status():
    #LED_colors = ("FF000000", "FF000000", "FF000000", "0000FF00", "0000FF00", "0000FF00")
    #badge.leds_send_data(bytes(leds_as_grbw), 24)

    import urequests as requests
    gc.collect()
    data = requests.get(badge.nvs_get_str("spacestate", "url"))
    new_status = data.json()['state']['open']
    data.close()
    gc.collect()

    print("Status is "+new_status)

    if new_status != old_status:
        #update screen
        if new_status:
            imagenaam = 'badge_open.png'
            led_colors = ("FF000000", "FF000000", "FF000000", "0000FF00", "0000FF00", "0000FF00")
        else:
            imagenaam = 'badge_closed.png'
            led_colors = ("FF000000", "FF000000", "FF000000", "0000FF00", "0000FF00", "0000FF00")

        data=requests.get(badge.nvs_get_str("spacestate","image_url")+imagenaam)
        gc.collect()
        png_data = data.content
        data.close()
        gc.collect()

        #badge.leds_send_data(bytes(led_colors), 24)

        ugfx.set_lut(ugfx.GREYSCALE)
        ugfx.clear(ugfx.WHITE)
        gc.collect()
        width,height,bitdepth,colortype=badge.eink_png_info(png_data)
        badge.eink_png(0, int((128-height)/2), png_data)
        ugfx.flush()
        badge.eink_busy_wait()

        old_status = new_status


def SpaceState():
    wifi.init()
    badge.nvs_set_str('boot','splash', OWNNAME) #set badge to reboot into this
    while True:
        wait_wifi()
        update_status()
        deepsleep.start_sleeping(SLEEPTIME) #let's go to sleep

if __name__ == '__main__':
    SpaceState()

ugfx.init()
badge.init()

displayloop = badge.nvs_get_str('boot','splash', "splash") == OWNNAME
#if the badge didn't boot from deepsleep, reset it to boot to splash
if( machine.reset_cause() == machine.DEEPSLEEP_RESET and displayloop ):
    mainroutine()
else:
    badge.nvs_set_str('boot','splash','splash')
    mainscreen()