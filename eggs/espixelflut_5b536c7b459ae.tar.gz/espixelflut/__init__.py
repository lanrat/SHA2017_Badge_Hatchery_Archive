import badge
import ugfx
import wifi
import os

badge.init()
ugfx.init()
wifi.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

pos = 0

i = 0
for file in os.listdir(os.getcwd()):
  if i == pos:
    color = ugfx.BLACK
  else:
    color = ugfx.WHITE
  ugfx.thickline(0, 26+i*12, 100, 26+i*12, color, 12, 0)
  i += 1
i = 0
for file in os.listdir():
  if i == pos:
    color = ugfx.WHITE
  else:
    color = ugfx.BLACK
  ugfx.string(0,20+i*12,file,"Roboto_Regular12",color)
  i += 1
ugfx.flush()