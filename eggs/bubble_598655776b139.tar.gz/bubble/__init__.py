import ugfx
import random

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
    
def bubble():
    x = random.randint(10,276)
    y = random.randint(10,108)
    r = random.randint(4,20)
    ugfx.fill_circle(x,y,r,ugfx.BLACK)
    ugfx.fill_circle(x,y,r-4,ugfx.WHITE)
    ugfx.flush()
    ugfx.fill_circle(x,y,r-3,ugfx.WHITE)
    ugfx.flush()
    ugfx.fill_circle(x,y,r-2,ugfx.WHITE)
    ugfx.flush()
    ugfx.input_attach(ugfx.BTN_B, go_home)
    ugfx.input_attach(ugfx.BTN_A, clean)

ugfx.init()
ugfx.clear(ugfx.WHITE)
while True:
    bubble()
    ugfx.input_attach(ugfx.BTN_B, go_home)
    ugfx.input_attach(ugfx.BTN_A, clean)