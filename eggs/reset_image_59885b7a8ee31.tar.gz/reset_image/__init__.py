import ugfx,badge,appglue
badge.init()
ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.GREYSCALE)
ugfx.clear()
badge.eink_png(0,0,'/media/hacking.png')
ugfx.flush()

def home(pushed):
    if(pushed):
        appglue.home()

ugfx.input_attach(ugfx.BTN_START, home)