import ugfx, wifi, network
from time import sleep
ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"wifi is connected. Start scanning...","Roboto_Regular12", 0)
ugfx.flush()

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = sta_if.scan()
ugfx.clear(ugfx.WHITE);
n = 0
for AP in scanResults:
  ugfx.string(10,n, AP[1],"Roboto_Regular12", 0)
  n = n+1
ugfx.flush()