import badge
import binascii
import time

# Lots borrowed from nyan.py
def hex_to_rgb_tuple(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    return (r,g,b)

white = hex_to_rgb_tuple("ffffff")
off = hex_to_rgb_tuple("000000")

pastel_pink = hex_to_rgb_tuple("ffd1dc")
pastel_blue = hex_to_rgb_tuple("aec6cf")

red = hex_to_rgb_tuple("e40303")
orange = hex_to_rgb_tuple("ff8c00")
yellow = hex_to_rgb_tuple("ffed00")
green = hex_to_rgb_tuple("008026")
blue = hex_to_rgb_tuple("004dff")
purple = hex_to_rgb_tuple("750787")

trans_pride_colours = [off, pastel_pink, pastel_blue, white, pastel_blue, pastel_pink]
lgbt_pride_colours = [red, orange, yellow, green, blue, purple]

def show_colours(colours, times = 500):
    for i in range(0, times):
        allcolours = ''.join([''.join(["{0:02x}".format(int(x)) for x in [r,g,b,0]]) for (r,g,b) in colours])
        badge.leds_send_data(binascii.unhexlify(allcolours), 24)
        time.sleep(0.02)

while True:
    show_colours(trans_pride_colours)
    show_colours(lgbt_pride_colours)