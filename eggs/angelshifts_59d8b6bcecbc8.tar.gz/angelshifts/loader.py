exec("l = []\nwhile True:\n\ti = input()\n\tif i.strip() == '***':\n\t\tbreak\n\telse:\n\t\tl.append(i)\nwith open('/lib/angelshifts/__init__.py', 'w') as f:\n\tf.write('\\n'.join(l))")

exec("l = []\nwhile True:\n\ti = input()\n\tif i.strip() == '***':\n\t\tbreak\n\telse:\n\t\tl.append(i)\nwith open('/lib/angelshifts/service.py', 'w') as f:\n\tf.write('\\n'.join(l))")

exec("l = []\nwhile True:\n\ti = input()\n\tif i.strip() == '***':\n\t\tbreak\n\telse:\n\t\tl.append(i)\nwith open('/lib/angelshifts/service.json', 'w') as f:\n\tf.write('\\n'.join(l))")
