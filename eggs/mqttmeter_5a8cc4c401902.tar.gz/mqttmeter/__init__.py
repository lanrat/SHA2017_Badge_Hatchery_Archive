import umqtt.simple

clnt = ""

def sub_cb(topic, msg):
    print((topic, msg))
    try:
        ms = msg.decode("utf-8")
        s = ms.split(" ")[0]
        a = float(s)
        print(topic,"=",a)
    except:
    	print("boohbooh")
  
  
def main():
  print("Init")
  clnt = umqtt.simple.MQTTClient("umqtt_client","revspace.nl")
  clnt.set_callback(sub_cb)
  print("Connect")
  clnt.connect()
  clnt.subscribe(b"revspace/#")
  while True:
    clnt.wait_msg()