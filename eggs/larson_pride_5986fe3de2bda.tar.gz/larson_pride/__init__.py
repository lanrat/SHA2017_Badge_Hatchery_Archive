import badge
import binascii
import time

n = 0
i = 1
larson_seq = [ 0, 0, 0, 0, 0, 0 ]

badge.init()

def larson_color(idx,val):
    return (val * x for (x) in binascii.unhexlify("ff000000"))

def larson_pride(idx,val):
    return [
        (val * x for (x) in binascii.unhexlify("75078710")),
        (val * x for (x) in binascii.unhexlify("004dff10")),
        (val * x for (x) in binascii.unhexlify("00802610")),
        (val * x for (x) in binascii.unhexlify("ffed0010")),
        (val * x for (x) in binascii.unhexlify("ff8c0010")),
        (val * x for (x) in binascii.unhexlify("e4030310")),
    ][idx]

while True:
    for x in range(0,6):
        larson_seq[x] = larson_seq[x] - 0.2 if larson_seq[x] > 0.2 else 0
    larson_seq[n] = 1
    n = n + i
    i = -i if n == 0 or n == 5 else i
    allcolors = ''.join([''.join(["{0:02x}".format(int(led)) for led in larson_pride(idx,val)]) for idx,val in enumerate(larson_seq)])
    badge.leds_set_state(binascii.unhexlify(allcolors))
    time.sleep(0.1)