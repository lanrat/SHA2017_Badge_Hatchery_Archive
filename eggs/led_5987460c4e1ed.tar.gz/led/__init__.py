import badge
import ugfx
import time
from random import randint
import deepsleep

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

def close(pressed):
  if pressed:
    deepsleep.reboot()


ugfx.input_attach(ugfx.BTN_B, close)

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

r = 0
g = 0
b = 0

while True:
	if r == 255 or g == 255 or b == 255:
		r = 0
		g = 0
		b = 0
	else: 
		badge.leds_send_data(leds_array)
		time.sleep(0.5)
		leds_array = leds_array[2:] + bytes([r, g, b, 0])
		badge.leds_send_data(leds_array)
		time.sleep(0.5)
		leds_array = leds_array[2:] + bytes([r + 1 , g + 1, b +1, 0])