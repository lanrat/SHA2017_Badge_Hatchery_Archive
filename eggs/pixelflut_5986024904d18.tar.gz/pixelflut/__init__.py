import network, badge, ugfx, usocket as socket
import uselect as select

class PixelFlutServer:
    def on_px(self, x, y, color):
        global pixelcount
        pixelcount += 1
        x, y = int(x), int(y)
        if color == "0":
            ugfx.pixel(x, y, ugfx.BLACK)
        else:
            ugfx.pixel(x, y, ugfx.WHITE)

    def serve_client(self, socket):
        readline = socket.makefile().readline
        try:
            for line in readline(1024):
                if not line:
                    break
                arguments = line.strip().split()
                if len(arguments) == 4 and arguments[0] == "PX":
                    self.on_px(arguments[1], arguments[2], arguments[3])
        finally:
            self.disconnect(socket)

    def disconnect(self, sock):
        self.sockets.remove(sock)
        sock.close()

    def serve(self, host, port):
        self.host = host
        self.port = port
        self.sockets = []

        self.socket = socket()
        #self.socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        self.socket.setblocking(0)
        self.socket.bind((host, port))
        self.socket.listen(100)
        self.sockets.append(socket)
        while self.sockets:
            readable, writable, exceptional = select.select(self.sockets, [], self.sockets)
            for sock in readable:
                if sock is self.socket:
                    client_sock, addr = self.socket.accept()
                    client_sock.setblocking(0)
                    self.sockets.append(client_sock)
                else:
                    self.serve_client(sock)
            for sock in exceptional:
                self.disconnect(sock)
                if sock == self.socket:
                    return

badge.init()
ugfx.init()

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
sta_if.connect("sha2017-insecure")
sta_if.isconnected()

curIP = sta_if.ifconfig()[0]

ugfx.clear();
ugfx.string(10,10,curIP + '1234/text',"PermanentMarker22",0)
ugfx.flush()

server = PixelFlutServer()
server.serve("0.0.0.0", 1234)