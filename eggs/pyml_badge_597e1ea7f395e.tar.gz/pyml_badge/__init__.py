import pyml_badge
pyml_badge.main()