import urequests as requests
import deepsleep
import wifi
import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def set_message(text):
  ugfx.clear(ugfx.BLACK)
  ugfx.clear(ugfx.WHITE)
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()
  
def passout(pressed):
    exit()

def vendmate(pressed):
  set_message("Mate button pressed.")
  data = None
  try:
    set_message("U WOT MATE?!?!")
    url = "http://automate.nwlab.nl/api/vend";
    h = {"Authentication":"Basic YmFkZ2U6NjViY2Q0YWRhZjhiMzBjNjU3Y2QwYjUyZmFlMzE1NzY="}
    data = requests.get(url, headers=h)
    set_message("Request sent.")
    data.close()
    set_message("Get your free Club Mate from the vending machine")
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    deepsleep.reboot()

def main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(45,85,"Free Mate @ Torvalds press A","Roboto_Black22",ugfx.BLACK)
    ugfx.flush()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, vendmate)
ugfx.input_attach(ugfx.BTN_SELECT, passout)
main()