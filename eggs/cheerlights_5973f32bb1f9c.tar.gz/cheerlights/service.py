import urequests
import json
import badge
import wifi
import binascii
import machine

def hex_to_grbw_list(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    w = 0
    while (r>0) and (g>0) and (b>0):
        r = r - 1
        g = g - 1
        b = b - 1
        w = w + 0.5
    return [g,r,b,int(w)]

next_update = None

def update():
    global cheerlightsEnabled
    global next_update

    t = machine.RTC().datetime()
    next_update = (t[0], t[1], t[2], t[3], t[4], t[5], t[6]+30, t[7])

    r = urequests.get("http://api.thingspeak.com/channels/1417/field/2/last.json")
    data = json.loads(r.text)
    print("Cheerlights data: %s" % data)
    vals = hex_to_grbw_list(data['field2'][1:])
    map(lambda x: int(cheerlightsEnabled*x/255.0), vals)
    badge.leds_set_state(bytes(6*vals))

def setup():
    global next_update
    global cheerlightsEnabled

    cheerlightsEnabled = int(badge.nvs_get_str('cheerlights', 'state', '0'))
    if (cheerlightsEnabled<1):
        print("Cheerlights: Disabled! Please enable in the app!")
    else:
        wifi.init()
        badge.leds_enable()
        badge.leds_set_state(bytes(6*([0]*4)))
        next_update = machine.RTC().datetime()

def loop(sleepCount):
    global cheerlightsEnabled
    global next_update
    if cheerlightsEnabled:
        if machine.RTC().datetime() >= next_update:
            update()
    return False