import ugfx, wifi, badge, deepsleep
import urequests as requests
from time import sleep

def set_message(text):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

def runfirst():
  ugfx.init()
  ugfx.input_init()
  ugfx.input_attach(ugfx.JOY_UP, forward)
  ugfx.input_attach(ugfx.JOY_DOWN, backward)
  ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: deepsleep.reboot())

  # Make sure WiFi is connected
  wifi.ssid = "NW-challenge"
  wifi.password = "Northwave Treintjes"
  wifi.init()
  while not wifi.sta_if.isconnected():
      sleep(1.0)
      set_message("Waiting for NW Wifi connection")
      pass
  set_message("Connected to NW Wifi")
  set_message("Up: forward, Down: backward")

def forward(pressed):
  data=None
  try:
    url = "http://192.168.1.7/controller/process.php";
    parameters = {'uid': '1', 'id': '0', 'richting': 'forward', 'snelheid':'4'}
    data = requests.post(url, data=parameters)
    set_message(data)
    data.close()
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()

def backward(pressed):
  data=None
  try:
    url = "http://192.168.1.7/controller/process.php";
    parameters = {'uid': '1', 'id': '0', 'richting': 'reverse', 'snelheid':'4'}
    data = requests.post(url, data=parameters)
    set_message(data)
    data.close()
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()

runfirst()
while True:
  sleep(0.2)