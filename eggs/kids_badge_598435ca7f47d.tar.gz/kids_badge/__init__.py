import badge
import ugfx
import time
import dialogs

badge.init()
ugfx.init()
badge.leds_disable()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
#nick="Jon de Boer Jr"
#contactphone="0034666000666"


name = badge.nvs_get_str("owner", "name", "")
nick = dialogs.prompt_text("Please enter nasme", name)
if nick:
      badge.nvs_set_str("owner", "name", nick)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

phone = badge.nvs_get_str("owner", "phone", "")
contactphone = dialogs.prompt_text("Please enter parents contact phone", phone)
if contactphone:
      badge.nvs_set_str("owner", "phone", contactphone)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()



ugfx.box(20,20,50,50,ugfx.WHITE)

ugfx.string(120,25,nick,"PermanentMarker36",ugfx.BLACK)
ugfx.string(25,80,"In Case of emergency please contact:","Roboto_Regular12",ugfx.BLACK)
ugfx.string(100,95,contactphone,"Roboto_BlackItalic24",ugfx.BLACK)

ugfx.flush()

#def render(text, pushed):
#    if(pushed):
#       ugfx.string(100,10,text,"PermanentMarker22",ugfx.WHITE)
#    else:
#        ugfx.string(100,10,text,"PermanentMarker22",ugfx.BLACK)
#    ugfx.flush()

#def start_app(pushed):
#    if(pushed):
#        import launcher

ugfx.flush(ugfx.LUT_FULL)
import deepsleep
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)