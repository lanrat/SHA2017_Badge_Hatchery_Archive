import badge
import ugfx
import network
import urandom
import time

ugfx.init()
ugfx.LUT_FULL

# SHA2017 ticket counter on Badge!
# Install dependencies first

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
badge.wifi_init()

ugfx.clear(ugfx.WHITE)
ugfx.string(20,25,"Connecting to:","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(140,75, "WiFi","PermanentMarker22",ugfx.BLACK)
ugfx.flush()

while not sta_if.isconnected():
    time.sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

from umqtt.simple import MQTTClient

# Publish test messages e.g. with:
# mosquitto_pub -t foo_topic -m hello

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    print((topic, msg))

    links, rechts = msg.decode('utf-8').split(';')
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.string(50,10,links,"Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(10,40,rechts,"PermanentMarker36",ugfx.BLACK)
    ugfx.string(40,90,"tickets.sha2017.org","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.flush()

def main(server="test.mosquitto.org"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"tickets.sha2017.org")
    print('mqtt set')
    while True:
        if True:
            c.wait_msg()
        else:
            c.check_msg()
        # Then need to sleep to avoid 100% CPU usage (in a real
        # app other useful actions would be performed instead)
            print('sleeping')
            time.sleep(10)
            print('sleep done')
    c.disconnect()

if __name__ == "__main__":
    main()