import badge, ugfx, appglue, wifi, time
# TODO:
# autoupdate on start with woezel

name = badge.nvs_get_str('owner', 'name', 'n00b')
log_window_x = ugfx.width() / 7 * 3
log_window_y = 0
log = ['', '', '', '', '']

def font(size):
  return 'Roboto_Black' + str(size)

def log(text):
  log.insert(0, text)
  log.pop()
  status_height = 12
  for i, line in enumerate(log):
  	ugfx.string(log_window_x, log_window_y + status_height * i, line, font(status_height), ugfx.BLACK)

def clear_ghosting():
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()

def attempt_update_self():
  attempts = 0
  attempts_max = 5
  while not wifi.sta_if.isconnected():
    log('Waiting for wifi... (%d/%d)' % (attempts, attempts_max))
    time.sleep(1)
    pass

def exit_app(pressed):
  appglue.start_app('')
  
def redraw():
  global position

def program_main():
  ugfx.init()
  wifi.init()
  clear_ghosting()
  
  try:
    badge.eink_png(0, 0, '/lib/hackeriet/hackeriet.png')
  except:
    log('Failed to load graphics')
  
  bx = int(ugfx.width() / 2)
    
  ugfx.string(bx, ugfx.height() - 16, '[Press B to exit]', font(16), ugfx.BLACK)
  ugfx.string(177, 25, name, font(16), ugfx.BLACK)
  ugfx.flush()
  
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit_app(pressed))
  
  iterations = 0
  while True:
    ugfx.string(bx, ugfx.height() - 32, str(iterations), font(16), ugfx.BLACK)
    iterations = iterations + 1

program_main()