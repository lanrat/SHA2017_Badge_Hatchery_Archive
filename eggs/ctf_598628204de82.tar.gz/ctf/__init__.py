import ugfx, badge, appglue, deepsleep
import urequests as requests
import wifi
import ujson as json
import time


def flash_led():
    leds_array = bytes([
                235, 84, 122, 0,
                217, 177, 7, 0,
                193, 17, 108, 0,
                169, 38, 15, 0,
                32, 58, 77, 0,
                4, 18, 188, 0,
    ])
    for x in range(12):
        badge.leds_send_data(leds_array, 24)
        leds_array = leds_array[4:] + leds_array[:4]

        badge.vibrator_activate(1)
        time.sleep(0.1)
    badge.leds_send_data(bytes([
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
        0, 0, 0, 0,
    ]), 24)



def program_main():
    ugfx.init()
    wifi.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    badge.leds_init()
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
    ugfx.flush()
    flash_led()

    # Wait for WiFi connection
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    prev_scores = []
    last_submit = {}
    last_solve = ''
    first = True
    while True:
        scores = []
        redraw = False
        # Get scoreboard
        data = requests.get('https://52.213.133.141/json?view=graph').content
        data = json.loads(data)
        for x in range(5):
            f = "%-20s - %-5s" % (str(data[x].get('name')), str(data[x].get('score')))
            scores.append(["%s. %s" % (x+1,str(data[x].get('name'))), str(data[x].get('score'))])

        if scores != prev_scores:
            redraw = True
            prev_scores = scores
        data = requests.get('https://52.213.133.141/json?view=last_submission').content
        data = json.loads(data)
        if data[0] != last_submit:
           redraw = True
           last_submit = data[0]

        if redraw:
            ugfx.clear(ugfx.WHITE)
            last_solve = "Last solve: %s by %s" % (data[0].get('title'), data[0].get('team'))
            if not first:
                flash_led()
            first = False
            ugfx.string(0, 0, "-= CTF Scoreboard =-", "Roboto_Regular12", ugfx.BLACK)
            for (x,f) in enumerate(scores):
                ugfx.string(0, 20 + x*20, f[0], "Roboto_Regular12", ugfx.BLACK)
                ugfx.string(200, 20 + x*20, f[1], "Roboto_Regular12", ugfx.BLACK)
            ugfx.string(0, 115, last_solve, "Roboto_Regular12", ugfx.BLACK)
            ugfx.flush()
        time.sleep(2)

# Start main application
program_main()
