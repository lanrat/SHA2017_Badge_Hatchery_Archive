print('[devlol_antivirus] - load __init__.py')

import appglue

try:
    from devlol_antivirus import devlol_antivirus

    devlol_antivirus.full_system_check_while_boot()
except:
    print('[devlol_antivirus] - error while __init__()')

#appglue.home()
