import utime, badge, binascii

counter = 0
direction = True
serviceEnabled = 0

# This function gets called by the home application at boot
def setup():
    global serviceEnabled
    serviceEnabled = badge.nvs_get_u8('krider', 'brightness', 0)
    if (serviceEnabled<1):
        print("[KNIGHTRIDER] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def leds(counter, direction):
    led = round(counter/10)
    value = counter
    while value>10:
        value -= 10
               
    if direction:
        prevLed = led-1
        nextLed = led+1
    else:
        prevLed = led+1
        nextLed = led-1
        
    output = []
    for i in range(0,24):
        output.append(0)
        
    ledLoc = led*4 + 1
    output[ledLoc] = 255
    if prevLed>=0 and prevLed<=5:
        prevLedLoc = prevLed*4 + 1
        output[prevLedLoc] = 255-round(value*25.5)
    if nextLed>=0 and nextLed<=5:
        nextLedLoc = nextLed*4 + 1
        output[nextLedLoc] = round(value*25.5)
        
    print("KN: "+str(counter)+" | "+str(direction)+" | "+str(led)+" | "+str(value)+" | "+str(prevLedLoc)+"/"+str(ledLoc)+"/"+str(nextLedLoc))
    return output

def loop():
    global serviceEnabled
    global direction
    global counter
    
    if (serviceEnabled>0): 
        if direction:
            counter += 1
        else:
            counter -= 1
        if counter>50:
            counter = 40
        if counter<0:
            counter = 0
        if counter==50 or counter==0:
            direction = not direction
        values = leds(counter, direction)
        badge.leds_send_data(bytes(values),24)
        return 10
    return 0
