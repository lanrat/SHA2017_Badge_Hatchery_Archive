"""
here comes some docs
"""

import badge
import ugfx
import time
from random import randint, random
import sys


badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()



leds = []
for led_id in range(6):
    leds.append([0, 0, 0, 0])


def show_leds():
    global leds
    try:
        leds_data = bytes(leds[0] + leds[1] + leds[2] + leds[3] + leds[4] + leds[5]) # sum doesnt work
        badge.leds_send_data(leds_data)
    except Exception as e:
        show_error(e)
        exit()

def show_error(err):
    ugfx.set_lut(ugfx.LUT_NORMAL)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 10, str(err), "Roboto_Regular12", 0)
    ugfx.flush()


leds[0] = [0, 0, 0, 255]
leds[1] = [0, 0, 255, 0]
leds[2] = [0, 255, 0, 0]
leds[3] = [255, 0, 0, 0]
leds[4] = [0, 0, 255, 255]
leds[5] = [0, 255, 0, 255]

show_leds()

#while True:
#    time.sleep(0.1)