import badge, ugfx, time

def setup ():

def loop():
    return 60000