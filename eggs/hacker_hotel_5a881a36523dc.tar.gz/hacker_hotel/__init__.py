import ugfx, badge, deepsleep

def main():
    ugfx.init()
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.set_lut(ugfx.LUT_FULL)


    nick = badge.nvs_get_str("owner","name", "Hacker1337")
    badge.eink_png(0, 0, '/lib/hacker_hotel/hackerhotel.png')
    ugfx.string_box(0, 96, 292, 32, nick, 'Roboto_Black22', ugfx.BLACK, ugfx.justifyRight)
    ugfx.flush(0xff)

    badge.eink_busy_wait()
    deepsleep.start_sleeping(60000)

main()