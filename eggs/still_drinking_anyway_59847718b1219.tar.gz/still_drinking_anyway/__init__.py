import badge
import ugfx
import random
import deepsleep


 
badge.init()
ugfx.init()
 
ugfx.clear(ugfx.BLACK)
 
 
ugfx.string(20,5,"still drinking anyway","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.string(100,50,"¯\_(''/)_/¯","DejaVuSans20",ugfx.WHITE)
ugfx.string(90,80,"gtpp, 2017","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.string(90,110,"A or B=Begin, Start=Rules","",ugfx.WHITE)
 
 
ugfx.flush()
 
lines = []
with open("/lib/still_drinking_anyway/q.txt") as file:
    for line in file:
        line = line.strip() #or some other preprocessing
        lines.append(line) #storing everything in memory!
 
def question(lines,pr):
    if (pr):
        ugfx.clear(ugfx.BLACK)
        render(random.choice(lines), pr)
 
def render(text, pushed):
    if(pushed):
        hit = random.uniform(1, 10)
        if int(hit) == 4:
            ugfx.string_box(0,5,300,20,"~ DEATHMATCH ~","Roboto_Regular18",ugfx.WHITE,ugfx.justifyCenter)
            # maybe add vibration here?
        ugfx.string_box(0,20,280,50,text,"Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    else:
        ugfx.string(100,10,text,"PermanentMarker22",ugfx.BLACK)
    ugfx.flush()
 
def rules():
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"Rules","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"1.The badge holder asks the person on their right","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"2.If they answer correctly, pass the badge. If not, they have to drink. Then pass the badge ;)","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"3. DEATHMATCH Questions. Answer correctly and everyone drinks. Answer wrong and you drink TWICE!","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
 
def passout():
	deepsleep.reboot() # or something that actually works...
 
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, lambda pressed: question(lines,pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: question(lines,pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: rules())
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: passout())
 
while True:
    pass