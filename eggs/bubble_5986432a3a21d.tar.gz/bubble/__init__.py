import badge
import ugfx
import random

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def bubble():
    x = random.randint(10,100)
    y = random.randinit(10,20)
    r = random.randinit(2,10)
    ugfx.fill_circle(x,y,r,ugfx.BLACK)
    ugfx.fill_circle(x,y,r-2,ugfx.WHITE)
    ugfx.flush()

badge.init()
ugfx.init()
ugfx.clear(ugfx.WHITE)

while True:
     bubble()