import ugfx,badge,machine,time,appglue

ns="charge_leds"
svck="enable"


def get_svc_status():
    return badge.nvs_get_u8(ns, svck, 0)

def draw():
    ugfx.clear()
    ststring = "disable" if get_svc_status() else "enable"
    ugfx.string(0, 25, "START: main menu",  "Roboto_BlackItalic24", ugfx.BLACK)
    ugfx.string(0, 50, "SELECT: "+ststring+" service", "Roboto_BlackItalic24",  ugfx.BLACK)
    ugfx.flush()
    redraw = False

def change_service():
    badge.nvs_set_u8(ns, svck, get_svc_status())

def btn_change(pushed):
    if pushed:
        change_service()
        draw()

def btn_home(pushed):
    if(pushed):
        appglue.home()

def main():
    badge.init()
    ugfx.init()
    ugfx.input_init()
    ugfx.set_lut(ugfx.LUT_FULL)
    ugfx.input_attach(ugfx.BTN_SELECT, btn_change)
    ugfx.input_attach(ugfx.BTN_START, btn_home)
    draw()

print("Hi my name is ",__name__)
if __name__ == '__main__':
    main()
