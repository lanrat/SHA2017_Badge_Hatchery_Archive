<div style="max-width: 600px; margin: 0 auto; color: #333; font-family: sans-serif;">
	<h1>Hello World!</h1>
	<p>
		This is a badge web server.
	</p>
</div>
