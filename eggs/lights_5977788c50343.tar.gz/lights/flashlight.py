### Lights Egg
### Author: f0x
### License: GPLv3

## A flashlight app which does red and white light, and allows you to change the brightness

import badge, ugfx
badge.leds_enable()
ugfx.input_init()


on = False
night_mode = False

def toggle(pressed):
	global on
	if pressed:
		if on:
			on = False
		else:
			on = True
        if night_mode:
			badge.leds_send_data(''.join([('\0\xff\0\0' if on else '\0') for i in range(24)]), 6)
        else:
            badge.leds_send_data(''.join([('\xff' if on else '\0') for i in range(24)]), 24)

def mode(pressed):
      global night_mode
      if pressed:
          if night_mode:
			 night_mode = False
      else:
          night_mode = True
      
ugfx.input_attach(ugfx.BTN_A, toggle)
ugfx.input_attach(ugfx.JOY_LEFT, mode)
ugfx.input_attach(ugfx.JOY_RIGHT, mode)