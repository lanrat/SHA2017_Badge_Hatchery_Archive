import easyrtc

def draw(x, y):
    t = easyrtc.string()
    ugfx.string(100, 0, t, "Roboto_BlackItalic12", ugfx.BLACK)
    return 0
