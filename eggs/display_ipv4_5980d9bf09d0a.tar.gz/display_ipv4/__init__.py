import badge
import ugfx
import network
badge.init()
ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.string(0, 0, "Attempting to connect to SHA2017-insecure...", "pixelade13", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
netif.connect("SHA2017-insecure")
netif.isconnected()
cur_ip = netif.ifconfig()[0]

ugfx.string(0, 13, "got ip: "  + cur_ip, "pixelade13", ugfx.BLACK)
ugfx.flush()