import badge

badge.leds_init()
badge.leds_enable()

badge.leds_send_data(bytes([
    255, 0, 0, 0,
    0, 255, 0, 0,
    0, 0, 255, 0,
    0, 0, 0, 255,
    255, 255, 255, 0,
    255, 255, 0, 0,
]))
