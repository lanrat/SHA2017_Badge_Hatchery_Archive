import easywifi, easydraw, machine, gc, ugfx, badge, woezel
from time import ticks_ms, sleep_ms, ticks_diff
from umqtt.simple import MQTTClient

co2 = 0
humi = 100
fan = None
fan_changed = None
space_open = False
delay = 30

on  = machine.Pin(16, machine.Pin.OUT)
off = machine.Pin(4,  machine.Pin.OUT)

easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network","FAILURE")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    machine.deepsleep(5000)

easydraw.msg("Checking for updates")
try:
    woezel.install('Revfan')
    easydraw.msg("Updated! Rebooting now!")
    badge.eink_busy_wait()
    machine.deepsleep(1)
except:
    easydraw.msg("No update available. Starting app!")
    easydraw.msg("Connecting to MQTT")

def update_display():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0,  0, "Humidity: " + str(humi), "Roboto_Black22", ugfx.BLACK)
    ugfx.string(0, 25, "CO2: "      + str(co2),  "Roboto_Black22", ugfx.BLACK)
    ugfx.string(0, 50, "Space: "    + ("open" if space_open else "closed"), "Roboto_Black22", ugfx.BLACK)
    ugfx.string(0, 75, "Fan: "      + str(fan),  "Roboto_Black22", ugfx.BLACK)
    if fan_changed != None:
      ugfx.string(0, 100, "Change: "   + str(int(ticks_diff(ticks_ms(), fan_changed) / 1000)), "Roboto_Black22", ugfx.BLACK)
 
    ugfx.flush()
    sleep_ms(50)

def clear_display():
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    sleep_ms(50)
    update_display()
                
# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    global co2
    global humi
    global space_open
    
    print((topic, msg))
    
    if topic == b"revspace/sensors/humidity":
        humi = float(msg.decode('utf-8').split(' ')[0])
    if topic == b"revspace/sensors/co2":
        co2 = float(msg.decode('utf-8').split(' ')[0])
    if topic == b"revspace/state":
        space_open = (msg == b"open")

def main(server="mosquitto.space.revspace.nl"):
    global fan
    global fan_changed
    
    clientname = 'badge' + str(machine.unique_id())
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"revspace/sensors/humidity")
    c.subscribe(b"revspace/sensors/co2")
    c.subscribe(b"revspace/state")
    
    easydraw.msg("MQTT Connected", title = 'Still MQTT Anyway...', reset = True)
    c.check_msg()
    
    badge.leds_init();
    badge.leds_enable();
    
    lastupdate = ticks_ms()
    while True:
        gc.collect()
        c.check_msg()
        now = ticks_ms()
        if ticks_diff(now, lastupdate) > 1000:
          newfan = 0
          lastupdate = now
          if co2 > 1500: newfan += 1
          if co2 > 1200: newfan += 1
          if co2 >  900: newfan += 1
          if co2 >  500: newfan += 1
          if humi < 38:  newfan -= 1
          if humi < 34:  newfan -= 1
          if space_open: newfan -= 1
          if newfan < 0: newfan = 0
          
          update_display()
          
          if bool(newfan) != bool(fan):
            fan_changed = now;
          
          fan = newfan
 
        if fan == None or (fan_changed and ticks_diff(now, fan_changed) > delay * 1000):
          pin = on if fan else off;
          pin.value(1)
          sleep_ms(60)
          pin.value(0)
          fan_changed = None
          clear_display()
            
        sleep_ms(100)
    c.disconnect()

main()