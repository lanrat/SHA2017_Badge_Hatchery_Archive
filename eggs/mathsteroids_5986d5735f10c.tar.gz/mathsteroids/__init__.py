import ugfx
import time
import badge
from math import sin,cos,floor,pi
ugfx.init()

SCREEN_Y = 126
SCREEN_X = 295
SPEED = 10
ROTATION = pi/8
FRAMERATE = 0.2

x,y,r = 30,30,0

def draw_line(x,y,x1,y1,x2,y2,r):
    x1_ = int(floor(x+(x1-x)*cos(r) - (y1-y)*sin(r)))
    y1_ = int(floor(y+(y1-y)*cos(r) + (x1-x)*sin(r)))
    x2_ = int(floor(x+(x2-x)*cos(r) - (y2-y)*sin(r)))
    y2_ = int(floor(y+(y2-y)*cos(r) + (x2-x)*sin(r)))
    ugfx.line(x1_,y1_,x2_,y2_,ugfx.BLACK)

def draw(x, y, r):
    ugfx.clear(ugfx.WHITE)
    x,y = int(x),int(y)

    draw_line(x,y,x,y,x-10,y-5,r)
    draw_line(x,y,x,y,x-10,y+5,r)
    draw_line(x,y,x-7,y,x-10,y-5,r)
    draw_line(x,y,x-7,y,x-10,y+5,r)


#    ugfx.line(x,y,x-10,y-5,ugfx.BLACK)
#    ugfx.line(x,y,x-10,y+5,ugfx.BLACK)
#    ugfx.line(x-7,y,x-10,y-5,ugfx.BLACK)
#    ugfx.line(x-7,y,x-10,y+5,ugfx.BLACK)

draw(x,y,r)

def add(press):
    global r
    global ROTATION
    r += ROTATION

def take(press):
    global r
    global ROTATION
    r -= ROTATION

ugfx.input_init()
#ugfx.input_attach(ugfx.JOY_UP, life1)
#ugfx.input_attach(ugfx.JOY_DOWN, life1)
ugfx.input_attach(ugfx.JOY_LEFT, take)
ugfx.input_attach(ugfx.JOY_RIGHT, add)

while True:
    x += SPEED*cos(r)
    y += SPEED*sin(r)

    if y<-5:
        y += SCREEN_Y
    if y>SCREEN_Y+5:
        y -= SCREEN_Y
    if x<-5:
        x += SCREEN_X
    if x>SCREEN_X+5:
        x -= SCREEN_X

    draw(x,y,r)
    time.sleep(FRAMERATE)