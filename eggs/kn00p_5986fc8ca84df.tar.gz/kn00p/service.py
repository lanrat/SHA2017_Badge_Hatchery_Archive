import badge, ugfx, time

def kn00p():
	badge.init()
	ugfx.init()

	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	time.sleep(2)
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	time.sleep(2)
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()

	badge.leds_init()
	badge.vibrator_init()
	leds_array=[185,6,57,0,154,211,73,0,126,44,82,0,77,91,219,0,106,8,154,0,87,192,214,0]
	badge.leds_send_data(bytes(leds_array),24)
	badge.vibrator_activate(0xABCD)
	time.sleep(4.1)
	badge.leds_disable()
	ugfx.string(1,1,"test","arial",ugfx.BLACK)
	ugfx.flush()
	time.sleep(30)
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	time.sleep(0.5)
	leds_array=[0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10]
	for x in range(1,5):
		light=255/x
		leds_array=[0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light)]
		badge.leds_send_data(bytes(leds_array),24)
        time.sleep(0.2)
        badge.leds_disable()
        time.sleep(0.2)
        
	ugfx.string(50,10,"kn00p says:","PermanentMarker22",ugfx.BLACK)
	ugfx.flush()
	time.sleep(3)
	ugfx.string(100,75,"HAAI!","PermanentMarker36",ugfx.BLACK)
	ugfx.flush()
    
	for x in range(1,3):
		leds_array=[185,6,57,0,154,211,73,0,126,44,82,0,77,91,219,0,106,8,154,0,87,192,214,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(10)
		badge.leds_disable()

    
def setup():
    kn00p()

def loop():
    return 60*1000