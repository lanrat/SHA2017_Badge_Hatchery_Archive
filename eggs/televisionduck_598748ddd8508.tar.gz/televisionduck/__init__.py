import ugfx

black = ugfx.BLACK
white = ugfx.WHITE

ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.area( 100, 26, 24, 15 , black)
ugfx.area( 124, 26, 6, 7, black)
ugfx.area( 130, 26, 24, 15, black)

ugfx.flush()