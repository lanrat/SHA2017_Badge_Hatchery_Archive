import badge, ugfx, uos, appglue

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)

path='lib/bookread'

def test_file():
  global files
  global options
  global path
  index = options.selected_index()
  if files[index]> 0:	
    fpath=path+'/'+files[index]
    ugfx.string(150, 20, "f%d:%s" % (index,fpath), "Roboto_BlackItalic12", ugfx.BLACK)
  else:
  	ugfx.string(150, 20, "Directory back ", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  
def update_filelist():
  global path
  global options
  global files

  while options.count() > 0:
    options.remove_item(0)
  uos.chdir(path)
  files=uos.listdir()
  options.add_item("<- Go Dir Up")
  for file in files:
    options.add_item("%s" % file)   
  
def select_file():
  global files
  global options
  global path
  
  index = options.selected_index()
  if files[index]> 0:
    ugfx.string(150, 20, "Open %s?" % files[index], "Roboto_BlackItalic12", ugfx.BLACK)
  else:
    ugfx.string(150, 20, "Going up", "Roboto_BlackItalic12", ugfx.BLACK)
    path='/'
    update_filelist()
  ugfx.flush()
  
def filepick():
  global options
  global files
  global path
  #ugfx.flush()
  options = ugfx.List(0,0,int(ugfx.width()/2),ugfx.height())

  ugfx.string(150, 0, "Use A to select file %d" % (options.selected_index()), "Roboto_BlackItalic12", ugfx.BLACK)
  update_filelist()
  #options.selected_index(0)

  ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.BTN_A,  lambda pushed: select_file if pushed else False)
  ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.start_app("launcher", False) if pushed else False)

  ugfx.flush()
  ugfx.set_lut(ugfx.LUT_NORMAL)

try:
  ugfx.clear(ugfx.WHITE)
  ugfx.set_lut(ugfx.LUT_FASTER)
  filepick()

except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  #dont re-raise it in the hope the user can continue
  #raise e