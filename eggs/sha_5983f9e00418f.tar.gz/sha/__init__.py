f = open("boot.py", "r")
orig = f.read()
f.close()
f = open("boot.py", "w")
f.write("""\
import ugfx
import urandom
import math
ugfx.clear(ugfx.WHITE)
ugfx.flush()
w = ugfx.width()
h = ugfx.height()
strs = ["SHA", "2017", "Still", "Hacking", "Anyways"]
while True:
 x = math.floor(urandom.random() * w)
 y = math.floor(urandom.random() * h)
 i = math.floor(urandom.random() * len(strs))
 j = math.floor(urandom.random() * 100)
 ugfx.string(x,y,strs[i], "pixelade13", ugfx.BLACK)
 ugfx.flush()
 if j == 0:
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
""")