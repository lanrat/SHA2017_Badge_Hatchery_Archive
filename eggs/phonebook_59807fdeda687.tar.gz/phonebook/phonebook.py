import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear();
ugfx.string(10,10,"SHA2017 ¯\_(ツ)_/¯","pixelade13", 0)
ugfx.flush()