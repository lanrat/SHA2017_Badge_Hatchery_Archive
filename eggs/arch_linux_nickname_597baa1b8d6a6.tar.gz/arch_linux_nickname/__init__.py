import ugfx, badge, deepsleep

def main():
    ugfx.init()
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.set_lut(ugfx.LUT_FULL)

    badge.eink_png(0, 0, '/lib/arch_name/arch.png')

    nick = badge.nvs_get_str("owner","name", "Hacker1337")
    ugfx.string(150, 45, nick, "PermanentMarker36", ugfx.BLACK)

    ugfx.flush(ugfx.LUT_FULL)

    badge.eink_busy_wait()
    deepsleep.start_sleeping(60000)

main()