import badge, ugfx#, appglue, time, network
#import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1     
        
def test():
    badge.vibrator_activate(0xFF)
    
def setup(): 
    ugfx.init()
    badge.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: test())
    
def loop():
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: test())
    #sta_if = network.WLAN(network.STA_IF)
    #sta_if.active(True)
    #sta_if.connect("SHA2017-insecure")
    #time.sleep(4)
    #t = requests.get("http://project1.online/sha2017-plsdonthackme/test.json").json()
    #_id = t["id"]
    _id = "2"
    if _id == "1":
        global _continue
        _continue = 0
        
    if (_continue):
        leds_array = bytes([0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        
        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh no :'(", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device has been locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 55, 'Your ID is: xxxx', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'Visit us a XXXXXX so we ', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'unlock ur badge 4 free ;)', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
        
    else:     
        leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
        badge.leds_send_data(leds_array)
        
        ugfx.clear(ugfx.BLACK)
        ugfx.line(0, 30, 300, 33, ugfx.WHITE)
        ugfx.string(80, 10, "Ooohh yes :)", "DejaVuSans20", ugfx.WHITE)
        ugfx.string(3, 30, 'Ur device is UN-locked', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 55, 'dont fall for this again', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 80, 'uninstall the app to ', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.string(3, 105, 'remove this message', 'Roboto_BlackItalic24', ugfx.WHITE)
        ugfx.flush()
    return 100