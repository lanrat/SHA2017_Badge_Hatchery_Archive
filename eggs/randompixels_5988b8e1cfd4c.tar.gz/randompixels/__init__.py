import ugfx, gc, wifi, badge, time
import urequests as requests

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Getting info from uRadMonitor ...","Roboto_Regular12", 0)
ugfx.string(110,100,"https://uradmonitor.com/","Roboto_Regular12", 0)
ugfx.flush()

def show_screen():
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    url = "http://data.uradmonitor.com/api/v1/chart/64000025/temperature/36000"
    response = requests.get(url, headers=headers)
    gc.collect()
    badge.eink_png(0,0,response.content)
    ugfx.flush()

def refresh_data(pushed):
    if(pushed):
        show_screen()

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

#Json request info
headers = {'X-User-id': 'sha2017', 'X-User-hash': 'badge'}
url = 'https://data.uradmonitor.com/api/v1'


show_screen()

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)