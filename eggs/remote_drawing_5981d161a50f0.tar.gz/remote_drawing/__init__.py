import badge
import ugfx
import network
import time
import usocket as socket
badge.init()
ugfx.init()
ugfx.string(0, 0, "acquiring network connection...", "pixelade13", ugfx.BLACK)
ugfx.flush()

wifi_ssid = badge.nvs_get_str("badge", "wifi.ssid", "SHA2017-insecure")
wifi_psk = badge.nvs_get_str("badge", "wifi.password", "")

print("wifi ssid:" + wifi_ssid)
print("wifi psk:" + wifi_psk)

ugfx.string(0, 13, "Attempting to connect to " + wifi_ssid + "...", "pixelade13", ugfx.BLACK)
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
if wifi_psk == "":
  netif.connect(wifi_ssid)
else:
  netif.connect(wifi_ssid, wifi_psk)
netif.isconnected()

cur_ip = netif.ifconfig()[0]
dots = ""
while True:
  if cur_ip == "0.0.0.0":
    ugfx.string(0, 26, "waiting to receive an IPv4 address..." + dots, "pixelade13", ugfx.BLACK)
    ugfx.flush()
    time.sleep(1)
    cur_ip = netif.ifconfig()[0]
    dots = dots + "."
    pass
  else:
    break

ugfx.string(0, 39, "got ip: "  + cur_ip, "pixelade13", ugfx.BLACK)
ugfx.flush()



s = socket.socket()
ai = socket.getaddrinfo(cur_ip, 8080)
addr = ai[0][-1]
#s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(addr)
s.listen(5)

ugfx.string(0, 52, "listening on port 8080...", "pixelade13", ugfx.BLACK)
ugfx.flush()


while True:
  res = s.accept()
  client_s = res[0]
  client_addr = res[1]
  print("Client address:", client_addr)
  #client_s.recv(4096)
  #client_s.send(bytes(CONTENT.format(counter), "ascii"))
  #client_s.close()
  #parts = req.decode('ascii').split(' ')
  req = str(client_s.readline().decode("ascii"))
  print("req:" + req)
  headers = []
  while True:
    cline = str(client_s.readline().decode("ascii"))
    if cline == "" or cline == "\r\n":
       break
    print("header:" + cline)
    headers.append(cline)
  print("test test")
  #body = str(client_s.recv(4096).decode("ascii"))
  #print("body:" + body)
  client_s.send(b"HTTP/1.0 200 OK\r\n\r\nHello World!")
  client_s.close()