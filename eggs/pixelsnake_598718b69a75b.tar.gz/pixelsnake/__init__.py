from umqtt.simple import MQTTClient

#try:
import pixelSnake
#except Exception as e:
    #from umqtt.simple import MQTTClient
#    c = MQTTClient("pixelSnake/Debug", "mqtt.sha2017.org")
#    c.connect()
#    c.publish(str(e))
#    c.disconnect()
