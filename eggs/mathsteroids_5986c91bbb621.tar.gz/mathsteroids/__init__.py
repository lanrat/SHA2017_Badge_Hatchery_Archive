### Author: Matthew Scroggs
### Description: Mathsteroids
### Category: Games
### License: None
### Appname: Mathsteroids
### Built-in: no

import ugfx
import time
from math import sin,cos,floor,pi
ugfx.init()

ugfx.clear(ugfx.WHITE)

x,y = 30,30


ugfx.line(x,y,x-10,y-5,ugfx.BLACK)
ugfx.line(x,y,x-10,y+5,ugfx.BLACK)
ugfx.line(x-7,y,x-10,y-5,ugfx.BLACK)
ugfx.line(x-7,y,x-10,y+5,ugfx.BLACK)

def dot(input):
    ugfx.area(60,60,10,10,ugfx.BLACK)

def undot(input):
    ugfx.area(60,60,10,10,ugfx.WHITE)

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_RIGHT, dot)
ugfx.input_attach(ugfx.JOY_LEFT, undot)