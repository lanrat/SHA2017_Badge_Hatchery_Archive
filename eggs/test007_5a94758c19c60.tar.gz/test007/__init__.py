import ugfx
import badge
import random

badge.init()
ugfx.init()
ugfx.input_init()
random.init()

ugfx.input_attach(ugfx.BTN_A, lambda pressed: btn_a(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: btn_b(pressed))
values = [1, 2, 3, 4, 5, 6]
trig = 0
quit = 0
trial = 0
bulletcham = random.choice(values)

def btn_a(pressed):
	global trig
	if pressed:
		trig = 1
		ugfx.clear(ugfx.WHITE)
		ugfx.flush()
        rroulette()

def btn_b(pressed):
  global quit
  if pressed:
   	quit = 1
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
        
def rroulette():
	global trig, quit, trial, bulletcham
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
  
 	if trig == 0:
 		ugfx.string(15, 20, str('Press A to pull the trigger'), "Roboto_BlackItalic24", ugfx.BLACK)
		ugfx.string(30, 50, str(bulletcham), "Roboto_BlackItalic24", ugfx.BLACK)
 		ugfx.flush()
  	else:
 		while bulletcham != trial and quit == 0 and trig == 1:
			ugfx.clear(ugfx.WHITE)
			ugfx.flush()
			trial += 1
			if bulletcham == trial:
				ugfx.string(30, 50, str('BAM! Dead...'), "Roboto_BlackItalic24", ugfx.BLACK)
				ugfx.flush()
				trig = 0
			else:
				ugfx.string(50, 40, str('Survived'), "Roboto_BlackItalic24", ugfx.BLACK)
				ugfx.flush()
				trig = 0
  
rroulette()