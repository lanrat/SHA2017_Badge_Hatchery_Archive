import ugfx, badge, appglue, deepsleep

def program_main():
    print("--- GERAFFEL APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    try:
        badge.eink_png(0,0,'/lib/geraffel/geraffel.png')
    except:
        ugfx.string(0, 0, "GERAFFEL LOAD ERROR geraffel.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(24*3600*1000)
    appglue.start_app("") # Return home

# Start main application
program_main()