import badge

def setup():
    pass

def draw(x,y):
    badge.eink_png(100,50,'/lib/berlin-building/buildingsmall.png')
    return 0