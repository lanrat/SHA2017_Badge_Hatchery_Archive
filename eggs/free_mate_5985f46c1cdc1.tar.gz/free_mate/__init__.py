import usocket as socket
import wifi
import time
import badge
import ugfx

badge.init()
ugfx.init()
wifi.init()

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

HOST = "https://badge:65bcd4adaf8b30c657cd0b52fae31576@automate.nwlab.nl/api/vend"
PORT = 443

def passout():
    exit()

def vendmate():
    s = socket.socket()
    s.connect((HOST, PORT))

def main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(45,85,"Free Mate at Torvalds when u press A","Roboto_Black22",ugfx.BLACK)
    ugfx.flush()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, lambda pressed: vendmate)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: passout)
main()