html = """<!DOCTYPE html>
<html>
    <head> <title>ESP8266 Pins</title> </head>
    <body> <h1>Poep hier je tekst naartoe!</h1>
    <form method='post'>
    <input type='text' name='peop'/>
    <input type='submit' value='submit'/>
    </form>
    </body>
</html>
"""

search = "peop"
import badge
import ugfx

badge.init()
ugfx.init()

import network
ap_if = network.WLAN(network.AP_IF)


import socket
addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]



s = socket.socket()
s.bind(addr)
s.listen(1)

print('listening on', addr)

while True:
    cl, addr = s.accept()
    stringvar = cl.recv(10240)
    for line in stringvar.splitlines():
        if line.find(search, 0, len(search)) == 0:
            printvalue = line - (search + "=")
            ugfx.string(130, 50, printvalue, "PermanentMarker22", ugfx.WHITE)
    print('client connected from', addr)
    cl.send(html)
    cl.close()