import ugfx, badge, virtualtimers, machine, import tasks.powermanagement as pm

def task():
    global pin
    global state
    global oldVal
    
    val = pin.value()
    
    changed = False
    
    if oldVal == 1 and val == 0:
        # Button was pressed
        state = not state
        print("Flashlight: detected button press: "+str(state))
        changed = True
            
    if changed:
        ledVal = 0
        if state:
            ledVal = 255
            prevent_sleep()
        output = []
        for i in range(0,24):
            output.append(ledVal)
        badge.leds_send_data(bytes(output),24)
        
    oldVal = val
    return 100

def prevent_sleep_task():
    global state
    if state:
        print("FLASHLIGHT PREVENTS SLEEP NOW")
        return 500
    else:
        print("FLASHLIGHT NO LONGER PREVENTS SLEEP")
        return 0
    
def prevent_sleep():
    pm.feed()
    if not virtualtimers.update(500, prevent_sleep_task):
        print("Prevent sleep not yet running, starting...")
        virtualtimers.new(500, prevent_sleep_task)
    else:
        print("Prevent sleep already running...")

def setup():
    global pin
    pin = machine.Pin(0)
    
    global oldVal
    oldVal = pin.value()
    
    global state
    state = False
    
    badge.leds_enable()
    
    virtualtimers.activate(25)
    virtualtimers.new(100, task, True)
