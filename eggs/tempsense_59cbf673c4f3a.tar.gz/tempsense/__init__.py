import machine
import onewire, ds18x20
from machine import Pin
import badge, ugfx
#, uos, appglue, re #, gc 

def system_init():
  global ds
  global roms
  
  badge.init()
  ugfx.init()
  ugfx.input_init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)


  p12=Pin(12,Pin.OUT)
  p12.value(1)
  dat = machine.Pin(33)

  # create the onewire object
  ds = ds18x20.DS18X20(onewire.OneWire(dat))

  # scan for devices on the bus
  roms = ds.scan()


def show_temp():
  ugfx.string(150, 0, "Use A to get temp!" , "Roboto_BlackItalic12", ugfx.BLACK) 
  ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_temp() if pushed else False)

def get_temp():
  global roms
  global ds

  ds.convert_temp()
  print(ds.read_temp(roms[0]))
  ugfx.string(150, 30, "Temp is %f!" % (ds.read_temp(roms[0])) , "Roboto_BlackItalic12", ugfx.BLACK) 
    
try:
  system_init()
  get_temp()
  show_temp()
  print("All systems go!")

except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()