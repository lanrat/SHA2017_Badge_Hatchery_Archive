import easydraw, badge, appglue, time

# Determine our service state
shouldRun = badge.nvs_get_u8("spaceapimon", "enabled", 0)

easydraw.msg(
    "Toggling state to %s" % ('ON' if shouldRun ^ 1 else 'OFF'),
    "Toggling SpaceAPIMon"
)

# Toggle state
print("[SpaceAPIMon] New service state: %s" % ('ON' if shouldRun ^ 1 else 'OFF'))
badge.nvs_set_u8("spaceapimon", "enabled", shouldRun ^ 1)
time.sleep(3)

# We're done here. --Cave Johnson
appglue.home()

