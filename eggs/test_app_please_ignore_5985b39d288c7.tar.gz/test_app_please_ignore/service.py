import lenny_face_generator as lenny

def setup():
    pass

def loop():
    pass

def draw(at_y):
    (x, y, w, h) = lenny.render_creation(
            lambda w, h: (lenny.BADGE_EINK_WIDTH - w, at_y),
#            lambda w, h: (0, 0),
            lenny.creation)
    return [1000, h]
