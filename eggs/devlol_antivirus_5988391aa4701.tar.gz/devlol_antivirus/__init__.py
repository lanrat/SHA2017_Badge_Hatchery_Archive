from devlol_antivirus.devlol_antivirus import full_system_check

import appglue


full_system_check()

appglue.home()
