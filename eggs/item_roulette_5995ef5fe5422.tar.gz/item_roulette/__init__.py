import badge, time, ugfx, deepsleep


def home():
    deepsleep.reboot()

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.string(10,10,"item_roulette","PermanentMarker22",ugfx.WHITE)
ugfx.flush()
time.sleep(1)
ugfx.clear(ugfx.BLACK)
ugfx.flush()

enabled = badge.nvs_get_u8("item_roulette","enable", 0)
if enabled:
    enabled = 0
    ugfx.string(10,10,"item_roulette disabled","PermanentMarker22",ugfx.WHITE)
else:
    enabled = 1
    ugfx.string(10,10,"item_roulette enabled","PermanentMarker22",ugfx.WHITE)
enabled = badge.nvs_set_u8("item_roulette","enable", enabled)
ugfx.flush()
time.sleep(2)
home()