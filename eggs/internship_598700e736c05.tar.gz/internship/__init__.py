import ugfx, badge, appglue, os

def start():
    test = os.system("ls")
    ugfx.clear(ugfx.BLACK)
    ugfx.string(20, 40, test, 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()

ugfx.init()
badge.init()
ugfx.input_init()   
start()

def home(pressed):
    if (pressed):
        appglue.start_app("")
        
ugfx.input_attach(ugfx.BTN_START, home)