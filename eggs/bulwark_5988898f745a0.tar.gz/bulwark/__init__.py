import ugfx, appglue

ugfx.init()
ugfx.input_init()

def home(pressed):
  if pressed:
    appglue.home()

ugfx.input_attach(ugfx.BTN_B, home)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.display_image(0,0,'/lib/Bulwark/bulwark.png')
ugfx.string(120, 50, "Bulwark", "PermanentMarker36", ugfx.BLACK)
ugfx.line(130, 90, 270, 90, ugfx.BLACK)


ugfx.flush()