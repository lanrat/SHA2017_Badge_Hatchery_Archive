import ugfx, wifi, badge, deepsleep
from time import sleep

ugfx.init()
ugfx.input_init()
# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

set_message("Waiting for wifi...")
  
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

set_message("Got wifi. Loading data")

data=None
try:
  url = "http://188.40.158.211/phonebook.csv?limit=10"
  from . import urequests_pmenke as requests
  set_message(url)
  r = requests.get(url, headers={"Host": "poc.sha2017.org"}, host_override="poc.sha2017.org")
  data = r.text
  r.close()
except Exception as e:
  set_message("Unexpected error: "+str(e))
  sleep(10)
  deepsleep.reboot()

set_message("Got data. Parsing...")

try:
  for entry in data.split('\n'):
    if entry == "":
      continue
    extension = entry.split(',')[0]
    name = (entry.split(',')[1]).replace('"', '')
    ugfx.clear()
    ugfx.string(10,10,extension+' -> '+name,"Roboto_Regular12", 0)
    ugfx.flush()
    badge.eink_busy_wait()
    sleep(0.5)
except Exception as e:
  set_message("Parsing error: "+str(e))
  sleep(10)

ugfx.input_attach(ugfx.JOY_UP, lambda pressed: set_message(str(pressed)))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: deepsleep.reboot())
  
while True:
  sleep(0.1)