import ugfx, badge, random, os

seeded = False
hipd = 70
reye = 50
rpupil = 20
xp = 0
yp = 0

maxdev = reye-rpupil

def setup():
    pass

def loop():
    global seeded, xp, yp, maxdev
    enabled = badge.nvs_get_u8("eyes","enable", 0)
    if enabled:
	if not seeded:
	    seed = sum(c << (i*8) for i, c in enumerate(os.urandom(4)))
	    random.seed(seed)
	    seeded = True
	# Do this here so that we don't choose a new position as soon as we redraw for sleep
	while True:
	    xp = random.randrange(-maxdev, maxdev)
	    yp = random.randrange(-maxdev, maxdev)
	    if (xp*xp + yp*yp <= maxdev*maxdev):
		break

    return 9999999999

def draw(y, sleep=2):
    global xp, yp, hipd, reye, rpupil
    enabled = badge.nvs_get_u8("eyes","enable", 0)
    if enabled and seeded and sleep:
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()

	cx = int(ugfx.width()/2)
	cy = int(ugfx.height()/2)
	ugfx.fill_circle(cx-hipd, cy, reye, ugfx.WHITE);
	ugfx.fill_circle(cx+hipd, cy, reye, ugfx.WHITE);

	ugfx.fill_circle(cx-hipd+xp, cy+yp, rpupil, ugfx.BLACK);
	ugfx.fill_circle(cx+hipd+xp, cy+yp, rpupil, ugfx.BLACK);

    return [9999999999, 0]
