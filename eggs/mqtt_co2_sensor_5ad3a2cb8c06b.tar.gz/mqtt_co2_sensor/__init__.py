import easywifi, easydraw, machine, badge, woezel
#from time import ticks_ms, sleep_ms, ticks_diff
from umqtt.simple import MQTTClient

server = "mqtt.bitlair.nl"

mqtt = MQTTClient('badge' + str(machine.unique_id()), server)

easywifi.enable(True)
if easywifi.state == False:
  easydraw.msg("Meh unable to connect to network","FAILURE")
  easydraw.msg("Waiting 5 seconds to try again!")
  badge.eink_busy_wait()
  machine.deepsleep(5000)

def reboot(message = "Rebooting"):
  easydraw.msg(message)
  badge.eink_busy_wait()
  machine.deepsleep(1)
  
easydraw.msg("Checking for updates")
try:
  woezel.install('MQTT Co2 sensor')
  reboot("Updated! Rebooting now!")
except:
  easydraw.msg("No update available. Starting app!")
  easydraw.msg("Connecting to MQTT")