import time, badge

# This function starts
def setup():
  vbatt = badge.battery_volt_sense()
  if (vbatt>4000):
    badge.leds_enable()
    badge.leds_send_data(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]), 24)
    time.sleep(2)
    badge.leds_send_data(bytes([32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0]), 24)
    time.sleep(2)
    badge.leds_send_data(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]), 24)
  else:
    badge.leds_disable()
    print("Badge battery low ("+str(vbatt)+" < 4000)...")