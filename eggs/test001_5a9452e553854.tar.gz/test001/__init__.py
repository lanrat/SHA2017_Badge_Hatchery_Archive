import ugfx

ugfx.init()

ugfx.clear(ugfx.WHITE)
while 1:
  ugfx.string(100, 100, "test", "Roboto_Regular18", ugfx.BLACK)
  ugfx.input_attach(ugfx.JOY_UP, lambda pressed: ugfx.string(100, 100, "test", "Roboto_Regular18", ugfx.WHITE))



ugfx.flush()