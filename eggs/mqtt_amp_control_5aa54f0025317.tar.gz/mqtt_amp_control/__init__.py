"""
  Tkkrlab mqtt amp control
  following can be done:

  start:      toggles the amp power
  select:     toggles between CD and AUX input.
  dpad up:    volume up
  dpad down:  volume down
"""

import ugfx
import badge
import machine
import easywifi
import easydraw
import virtualtimers
from umqtt.simple import MQTTClient

AMP_MODE = "tkkrlab/amp/mode"
AMP_VOLUME = "tkkrlab/amp/volume"
AMP_RAW = "tkkrlab/amp/raw"
AMP_POWER = (1 << 0) # Amp Power enable bit
AMP_TAPE1 = (1 << 1) # Tape 1 enable bit
AMP_TAPE2 = (1 << 2) # Tape 2 enable bit
AMP_AUX_CD = (1 << 3) # togles between Aux and Cd
VOLUME_MAX = 50
VOLUME_MIN = 0

amp_mode = AMP_POWER | AMP_AUX_CD
easydraw.msg("[%d] amp_mode: %s" % (count, str(bin(amp_mode)))) 
amp_volume = 20
update_state = True

ugfx.input_init()
easywifi.enable()

server = "10.42.1.2"
client_id = machine.unique_id()
client = MQTTClient(("AmpControl[%s]" % (client_id)), server)

def button_select(pushed):
    global amp_mode
    global update_state

    if pushed:
        update_state = True
        amp_mode ^= AMP_AUX_CD

def button_start(pushed):
    global amp_mode
    global update_state

    if pushed:
        update_state = True
        amp_mode ^= AMP_POWER

def button_up(pushed):
    global amp_volume
    global update_state

    if pushed:
        update_state = True
        amp_volume += 5
    if amp_volume > VOLUME_MAX:
        amp_volume = VOLUME_MAX

def button_down(pushed):
    global amp_volume
    global update_state

    if pushed:
        update_state = True
        amp_volume -= 5
    if amp_volume < VOLUME_MIN:
        amp_volume = VOLUME_MIN

ugfx.input_attach(ugfx.BTN_SELECT, button_select)
ugfx.input_attach(ugfx.BTN_START, button_start)
ugfx.input_attach(ugfx.JOY_UP, button_up)
ugfx.input_attach(ugfx.JOY_DOWN, button_down)

badge.leds_init()
badge.leds_enable()
badge.leds_send_data(bytes([0x01] * (6 * 4)))

count = 0
# task that updates the mode and volume
def update_amp_state():
  global count
  global client
  global amp_mode
  global amp_volume
  global update_state

  if update_state:
    easydraw.msg("")
    easydraw.msg("[%d] volume: %d" % (count, amp_volume))
    easydraw.msg("[%d] ampmode: %s" % (count, bin(amp_mode)))
    if amp_mode & AMP_POWER:
        easydraw.msg("[%d] amp turned on." % count);
    else:
        easydraw.msg("[%d] amp turned off." % count);
    if amp_mode & AMP_AUX_CD:
        easydraw.msg("[%d] amp in AUX mode." % count);
    else:
        easydraw.msg("[%d] amp in CD mode." % count);
    update_state = False
    client.connect()
    client.publish(AMP_MODE, str(amp_mode))
    client.publish(AMP_VOLUME, str(amp_volume))
    client.disconnect()
  count += 1
  
  return 1000

virtualtimers.new(1000, update_amp_state)
virtualtimers.activate(100)