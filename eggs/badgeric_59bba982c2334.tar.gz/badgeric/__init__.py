import ugfx
import badge
import wifi
import gc
import urequests as requests
import time
import dialogs

jobs = [
    {
        'content': [
            {'text': "Eric Darchis", 'y': 1, 'font': "PermanentMarker36"},
            {'text': "Freelance Dev-Ops-Sec", 'y': 36, 'font': "DejaVuSans20"},
            {'text': "Java, Groovy/Grails, Angular", 'y': 61, 'font': "DejaVuSans20"}],
        'delay': 10
    },
    {
        'content': [
            {'text': "@edarchis", 'y': 1, 'font': "PermanentMarker36"}
        ],
        'delay': 10
    }
]

refreshing = False
dataVersion = 0
badgeUrl = ""


def go_home(pushed):
    if pushed:
        import machine
        machine.deepsleep(1)


def refresh():
    global refreshing
    global dataVersion
    global jobs
    global badgeUrl
    refreshing = True
    ugfx.string(10, 10, "Downloading JSON", "Roboto_Regular12", 0)
    ugfx.flush()
    gc.collect()
    try:
        data = requests.get(badgeUrl)
    except:
        ugfx.string(10, 10, "Could not download JSON", "Roboto_Regular12", 0)
        ugfx.flush()
        time.sleep(5)
        go_home(1)
        return
    try:
        global output
        jobs = data.json()
        refreshing = False
        dataVersion += 1
    except:
        data.close()
        ugfx.string(10, 10, "Cannot understand shit", "Roboto_Regular12", 0)
        ugfx.flush()
        time.sleep(5)
        go_home(1)
        return
    data.close()


def main():
    global refreshing
    global dataVersion
    global jobs
    while True:
        if refreshing or dataVersion == 0:
            time.sleep(1)
        else:
            current_version = dataVersion
            for job in jobs:
                ugfx.clear()
                for row in job['content']:
                    ugfx.string_box(0, row['y'], 296, row['y'] + 42, row['text'], row['font'], ugfx.BLACK, ugfx.justifyCenter)
                ugfx.flush(ugfx.LUT_FULL)

                badge.eink_busy_wait()
                if refreshing or dataVersion != current_version:
                    break
                time.sleep(job['delay'])
                if refreshing or dataVersion != current_version:
                    break


ugfx.init()

badgeUrl = badge.nvs_get_str("badgeric", "url", "http://darchis.be/eric/badge.json")
badgeUrl = dialogs.prompt_text("Please enter JSON URL", badgeUrl)
if badgeUrl:
  badge.nvs_set_str("badgeric", "url", badgeUrl)

ugfx.input_attach(ugfx.BTN_A, refresh)
ugfx.input_attach(ugfx.BTN_B, go_home)
wifi.init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
ugfx.flush()
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
refresh()
main()