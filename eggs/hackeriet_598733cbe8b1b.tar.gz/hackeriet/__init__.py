import badge, ugfx, appglue, deepsleep

def button_press():
  appglue.start_app('')

def program_main():
  try:
    badge.eink_png(0,0, '/lib/hackeriet/hackeriet.png')
  except:
    ugfx.string(0, 0, 'Failed to load graphixxx', 'Roboto_Regular12', ugfx.BLACK)
  ugfx.flush()
  badge.eink_busy_wait()

  name = badge.nvs_get_str('owner', 'name', 'n00b')
  ugfx.string(int(ugfx.width()/2), ugfx.height()-12, 'Roboto_Black12', 'Press B to exit', ugfx.WHITE)
  ugfx.string(177, 25, name, 'Roboto_Black16', ugfx.WHITE)
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: button_press(pressed))

  # Try and save some battery
  while True:
    deepsleep.start_sleeping(5000)

program_main()