import easywifi

import urequests
import ugfx

# settings
x=10
y=10
a=200
b=100
colour = 'black'
justify = 'ugfx.justifyLeft'
font = "Hacking" # these should all be uppercase
MOPPENNL_URL = 'http://www.moppen.nl/PrintMop.aspx?mopID=%s'

mopnr = 22237  # for now

def get_flauwe_mop():
    """Returns a table for the downpour over the next 2 hours.

    Return value is a list of pairs of the form ('hh:mm', millimeters)
    """
    if not easywifi.status(): raise RuntimeError('WiFi is not connected')

    resp = urequests.get(MOPPENNL_URL % mopnr)
    cont = resp.text.splitlines()
    mop = cont[21] # ultralelijk maar het moet even snel
    return mop

if __name__ == "__main__":
    mop = get_flauwe_mop()
    import ufgx
    ufgx.init()
    ugfx.clear()
    #ugfx.flush()
    ugfx.string_box(x,y, a, b, mop, font, colour, justify)
    ugfx.flush()