def setup():
    return

def loop():
    return 60000