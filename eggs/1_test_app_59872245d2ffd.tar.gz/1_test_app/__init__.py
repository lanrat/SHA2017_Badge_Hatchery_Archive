import ugfx, badge

ugfx.init()
badge.init()

def start():
    x = open("/boot.py", "w")
    x.seek(18)
    x.write("        test = 1 #AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")    
    x.close()
    
start()