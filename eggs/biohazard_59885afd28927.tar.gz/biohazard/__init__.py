# Testing if changing code works
# App doesn't load
#
################################

import ugfx, badge, appglue

ugfx.init()
ugfx.input_init()

def home(pressed):
  if pressed:
    appglue.home()

ugfx.input_attach(ugfx.BTN_B, home)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.display_image(0,0,'/lib/biohazard/biohazard.png')
ugfx.string(150, 50, "Knickz0r", "PermanentMarker22", ugfx.BLACK)
ugfx.line(155, 75, 245, 75, ugfx.BLACK)


ugfx.flush()