#Author: Ruben Bos
#Person: Second year student
#info: im new to python so thats y my code is bad :p
#also i didnt had enough time to put things in methods like draw_upvote()¨
# pls dont spam the votes :p

import ugfx, random, wifi, badge
import urequests as requests

jokes = ["The 21st century: Deleting history is more important than making it.",
         "Wikipedia: I know everything! Google: I have everything! Facebook: I know everybody! Internet: Without me you are nothing! Electricity: Keep talking bitches!",
         "How do two programmers make money? One writes viruses, the other anti-viruses.",
         "Q: How many programmers does it take to change a light bulb? A: None, that's a hardware problem.",
         "Keyboard not found... Press ENTER to continue...",
         "Internet forum rules: 1. Come 2. Ask something 3. Get banned 4. Go & Google it",
         "I was once living very actively - playing football, tennis, participating into car races. I would play poker and pool. But later somebody stole my PC...",
         "- You know, I have Google+, Facebook, Twitter, Skype accounts... - Man, and do you have life? - OMG, No! Could you send me a link?",
         "- What a freaky query - thought the database and stopped working.",
         "Where's the best place to hide a body? Page two of Google.",
         "Hide all of the desktop icons on someone's computer and replace the monitor's wallpaper with a screen-shot of their desktop.",
         "A system administrator has 2 problems: - dumb users - smart users ",
         "My wifi suddenly stop working then I realized that my neighbors have not paid the bill. How irresponsible people are.",
         "Girls are like Internet Domain names, the ones I like are already taken.",
         "The Internet: where men are men, women are men, and children are the FBI...",
         "I changed my password to ´incorrect´. So whenever I forget what it is, the computer will say ´Your password is incorrect´.",
         "If at first you don't succeed, call it version 1.0.",
         "Algorithm. Word used by programmers when they don't want to explain what they did.",
         "Funny facts about Google users: 50% of people use Google well as a search engine. The rest 50% of them use it to check if their internet is connected",
         "The code that is the hardest to debug is the code that you know cannot possibly be wrong."]

current_joke_id = -1

jokes_voted = []

def start():
    ugfx.clear(ugfx.BLACK)
    ugfx.line(0, 33, 300, 33, ugfx.WHITE)
    ugfx.string(10, 10, "SHA2017 Jokes/Memez", "DejaVuSans20", ugfx.WHITE)
    ugfx.string(20, 40, 'A: new joke', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.string(20, 65, 'Up: Upvote joke', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.string(20, 90, 'Down: Downvote joke', 'Roboto_BlackItalic24', ugfx.WHITE)


def start_screen():
    ugfx.clear(ugfx.BLACK)
    ugfx.box(170, 107, 120, 25, ugfx.WHITE)
    ugfx.string(5, 115, '', 'Roboto_Regular12', ugfx.WHITE)



def show_joke(joke_id):
    global current_joke_id
    current_joke_id = joke_id
    start_screen()
    check_for_vote()

    # rnd = random.randint(0, (len(jokes) - 1))
    text = jokes[joke_id]
    text_lenght = len(text)

    #ikr, i seems fun to up vote a post alot, but pls keep it fun. :)
    # If you have tips/tricks. I am all ears ;)  ,greetingz Ruben Bos

    url_down = "http://project1.online/sha2017-plsdonthackme/show.php?id=" + str(current_joke_id) + "&type=down"
    r_down = requests.get(url_down)

    url_up = "http://project1.online/sha2017-plsdonthackme/show.php?id=" + str(current_joke_id) + "&type=up"
    r_up = requests.get(url_up)

    #ugfx.string(200, 115, '33', 'Roboto_Regular12', ugfx.WHITE)
    ugfx.string(200,115, r_up.content, 'Roboto_Regular12', ugfx.WHITE)
    ugfx.line(180, 120, 185, 115, ugfx.WHITE)
    ugfx.line(185, 115, 190, 120, ugfx.WHITE)

    #ugfx.string(258, 115, '5', 'Roboto_Regular12', ugfx.WHITE)
    ugfx.string(258,115, r_down.content, 'Roboto_Regular12', ugfx.WHITE)
    ugfx.line(240, 115, 245, 120, ugfx.WHITE)
    ugfx.line(245, 120, 250, 115, ugfx.WHITE)

    if text_lenght < 30:
        text_style = 'PermanentMarker36'
        split_amount = 10
    elif text_lenght < 50:
        text_style = 'Roboto_BlackItalic24'
        split_amount = 15
    elif text_lenght < 70:
        text_style = 'Roboto_Regular22'
        split_amount = 20
    elif text_lenght < 90:
        text_style = 'Roboto_Regular22'
        split_amount = 20
    else:
        text_style = 'Roboto_Regular12'
        split_amount = 35

    y = 10
    i = 0
    text_words = text.split()
    while (i < len(text_words)):
        sentence = text_words[i]
        ugfx.string(10, y, sentence, text_style, ugfx.WHITE)
        i = i + 1

    ugfx.flush()

    if (i < len(text_words)):
        while (len(sentence + text_words[i]) <= split_amount):
                sentence = sentence + ' ' + text_words[i]
                ugfx.string(10, y, sentence, text_style, ugfx.WHITE)
                i = i + 1
    y += 20

def vote(vote):
    if (current_joke_id == -1):
        show_joke(random.randint(0, (len(jokes) - 1)))
    else:

        if (str(current_joke_id) + "UP" in jokes_voted) or (str(current_joke_id) + "DOWN" in jokes_voted):
            ugfx.box(0, 0, 0, 0, ugfx.BLACK)
        else:

            jokes_voted.append(str(current_joke_id) + vote)#I know its bad af :p. but could find a list<int, string> in python. or a key value pair

            if vote == 'UP':

                url_up_vote = "http://project1.online/sha2017-plsdonthackme/vote.php?id=" + str(current_joke_id) + "&type=up"
                r_up_vote = requests.get(url_up_vote)
                ugfx.string(0,0, r_up_vote.content, 'Roboto_Regular12', ugfx.BLACK)


                ugfx.circle(245, 117, 7, ugfx.BLACK)
                ugfx.circle(185, 117, 7, ugfx.WHITE)

            elif vote == 'DOWN':

                url_down_vote = "http://project1.online/sha2017-plsdonthackme/vote.php?id=" + str(current_joke_id) + "&type=down"
                r_down_vote = requests.get(url_down_vote)
                ugfx.string(0,0, r_down_vote.content, 'Roboto_Regular12', ugfx.BLACK)


                ugfx.circle(245, 117, 7, ugfx.WHITE)
                ugfx.circle(185, 117, 7, ugfx.BLACK)

def check_for_vote():
    if (str(current_joke_id) + "UP" in jokes_voted):
        ugfx.circle(245, 117, 7, ugfx.BLACK)
        ugfx.circle(185, 117, 7, ugfx.WHITE)
    elif (str(current_joke_id) + "DOWN" in jokes_voted):
        ugfx.circle(245, 117, 7, ugfx.WHITE)
        ugfx.circle(185, 117, 7, ugfx.BLACK)


ugfx.init()
badge.init()
wifi.init()
start()
ugfx.flush()


ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: vote('UP'))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: vote('DOWN'))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: show_joke(random.randint(0, (len(jokes) - 1))))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: start())