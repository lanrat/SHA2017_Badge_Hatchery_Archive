#
#
#
# Modified version of Show Nickname by Henk de Vries
#
#
#

import ugfx, badge


def setup():
    pass

def loop():
    return 0

def redraw_time():
    return 120000

def screen_width():
    return 296

def screen_height():
    return 128

def draw(y, sleep = False):
    if not sleep:
        return [redraw_time(), 0]
    return draw_going_to_sleep(y)

def draw_logo():
    cx = int(screen_width() / 2)
    cy = int(screen_height() / 2)
    badge.eink_png(cx - 25, cy - 35, '/lib/rootfs_nick_test/logo.png')

def draw_nick(nick):
    ugfx.string_box(0, 60, 296, 38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)

def clear():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def flushwait():
    ugfx.flush(ugfx.LUT_FULL)
    badge.eink_busy_wait() 

def draw_going_to_sleep(y):
    enabled = badge.nvs_get_u8("rfsnick","enable", 0)
    if enabled:
        nick = badge.nvs_get_str("owner", "name", 'Boy Zonderman')
        clear()
        draw_logo()
        draw_nick(nick)
        flushwait()
    return [redraw_time(), screen_height()]

