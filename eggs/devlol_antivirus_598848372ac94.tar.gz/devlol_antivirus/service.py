print('[devlol_antivirus] - #############################################################')

def setup():
    try:
        print('[devlol_antivirus] - devlol_antivirus started by setup')

        from devlol_antivirus import devlol_antivirus

        devlol_antivirus.full_system_check_while_boot()
    except:
        print('[devlol_antivirus] - error while setup()'

def loop():
    print('[devlol_antivirus] - loop')
    return 1000
