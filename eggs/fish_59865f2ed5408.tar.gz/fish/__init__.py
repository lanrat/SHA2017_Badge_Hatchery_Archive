import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
        
def water_fish(pushed):
    if(pushed):
        import time, ugfx, badge
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
		
        badge.eink_png(0,0,'/lib/Fish/water.png')
        ugfx.flush()
        time.sleep(2)
		
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
		
        badge.eink_png(0,0,'/lib/Fish/Fish.png')
        ugfx.flush()
        ugfx.input_attach(ugfx.BTN_B, go_home)
        ugfx.input_attach(ugfx.BTN_A, water_fish)
        
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, water_fish)
badge.eink_png(0,0,'/lib/Fish/Fish.png')
ugfx.flush()