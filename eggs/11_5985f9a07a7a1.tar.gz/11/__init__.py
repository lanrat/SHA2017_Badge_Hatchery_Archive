l = open('./boot', 'w')
l.write('blah')