import time, badge, _thread, ugfx, wifi
import usocket as socket
from machine import Pin

#try to maintain targettemp
message="Have a nice day!"
ctemp=20.0
ttemp=20.0
mtemp=0.5
burn=0
schedule=  [[[9,30,210],[23,59,180]],[[9,30,210],[23,59,180]],
  [[7,10,210],[7,45,180],[180,0,210],[23,59,180]],
[[7,10,210],[7,45,180],[180,0,210],[23,59,180]],  
[[7,10,210],[7,45,180],[180,0,210],[23,59,180]],
[[7,10,210],[7,45,180],[180,0,210],[23,59,180]],
[[7,10,210],[7,45,180],[180,0,210],[23,59,180]] ]

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

def init_hw():
  global p12
  badge.init()
  ugfx.init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  
  badge.power_sdcard_enable()
  p12=Pin(12,Pin.OUT)
  p12.value(0)
  
def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def init_web():
  global s
  #init webserver stuff
  wifi.init()
  ai = socket.getaddrinfo(wifi_up(),80)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.bind(addr)
  s.listen(5)

def main_target_temp():
  global ctemp,ttemp,mtemp,burn,p12,message
  tstatus=('idleing','burning')
  dotw=('Zaterdag','Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag')
  moty=('Jan','Feb','Mar','Mei','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  print("Target temp thread started!\n")
  
  while True:
    if ctemp<(ttemp-mtemp):
      burn=1
    else:
      burn=0
    p12.value(burn)
    #refresh the screen
    now=time.localtime() #0year,1 month,2 day,3 hour,4 minute,5 sec,6 dayoftheweek,7 dayoftheyear
    ugfx.clear(ugfx.WHITE)
    ugfx.string(10, 0, "Current Temperature is %s" % (ctemp) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(10, 14, "Target Temperature is %s" % (ttemp) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(10, 28, "Date %d %s %d Day %s" % (now[2],moty[now[1]],now[0],dotw[now[6]]) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(10, 42, "Time %d:%d" % (now[3],now[4]) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(40, 70, "Status: %s!" %(tstatus[burn]), "DejaVuSans20", ugfx.BLACK)
    ugfx.string(10, 100, " %s" % (message) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.flush()
    time.sleep(15)
  
def main_scheduler():
  global schedule
  print("Scheduler thread started!\n")
  while True:
    now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
    print("Day of the week is %d" % (now[6]))
    print("Target temperature is %f" % (round(schedule[now[6]][1][2]/10,1)  )  )
    time.sleep(60)
  
def main_handle_web():
  print("Handle web thread started!\n")
  global s,message
  global burn, ttemp,ctemp
  while True:
    res = s.accept()
    client_s = res[0]
    client_ip = str(res[1][0])
    print("Connection from ",client_ip)
    request = client_s.recv(1024)
    request = str(request)
    print("Request was : %s" % request)
    if request.find('/favicon.ico')>0:  
      client_s.close()
    else:
      if request.find('/?message=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        message=arg[1].replace('%20',' ')
        message=message.replace('%22','')
        print("change current message to %s" % message)
      if request.find('/?ctemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ctemp=round(float(arg[1])/10,1)
        print("change current temp to %s" % ctemp)
      if request.find('/?ttemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ttemp=round(float(arg[1])/10,1)
        print("change target temp to %s" % ttemp)

      #client_s.send(default_reply)
      html=default_reply+"<html><head><title>Thermostat by Tommy Faasen</title></head><body>\n<center>Status:"
      if(burn==0):
        html=html+" Not"
      html=html+" Burning!</center><br>\n<center> Target Temperature %f - Current temperature %f</center><br>\n</body></html>\n" % (round(ttemp,1),round(ctemp,1))
      client_s.send(html)
      client_s.close()
  
try:
  print("Initializing")
  init_hw()
  init_web()
  #gc.enable()
  print("Done, starting up!")
  time.sleep(1)
  _thread.start_new_thread(main_target_temp,())
  _thread.start_new_thread(main_scheduler,())
  _thread.start_new_thread(main_handle_web,())
  print("All systems go!")
  
except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()