import ugfx, wifi, appglue
import time, urandom
from umqtt.simple import MQTTClient


ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

  
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Connecting to MQTT...","Roboto_Regular12", 0)
ugfx.flush()


pizzaoven0 = "0"
pizzaoven1= "1"


def sub_cb(topic, msg):
    global pizzaoven0
    global pizzaoven1
    msg = msg.decode('utf-8')
  
    if topic.decode('utf-8') == 'pizza/temp0':
        pizzaoven0 = msg
    if topic.decode('utf-8') == 'pizza/temp1':
        pizzaoven1 = msg

    ugfx.clear(ugfx.WHITE)
    
    ugfx.string(0, 20,  "Still baking anyway", "PermanentMarker22", ugfx.BLACK)
    ugfx.string(20, 20, "Pizza oven 1: {} °C".format(pizzaoven0), "Roboto_Black22", ugfx.BLACK)
    ugfx.string(20, 40, "Pizza oven 2: {} °C".format(pizzaoven1), "Roboto_Black22", ugfx.BLACK)
    ugfx.flush()

def main(server="mqtt.sha2017.org"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"pizza/#")
    print('mqtt set')
    c.check_msg()
    while True:
        c.check_msg()
        time.sleep(0.1)
    c.disconnect()
    
def go_home(pushed):
    if pushed:
        appglue.home()


ugfx.input_attach(ugfx.BTN_B, go_home)
main()