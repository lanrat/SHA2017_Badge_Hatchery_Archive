from ballon_captains_badge import ballon_captains

ballon_captains.main()