import ugfx
import badge
import time
import math

badge.init()
ugfx.init()

#296x128px screen
screen_width=296
screen_height=128

#start with white background
ugfx.clear(ugfx.WHITE)
ugfx.flush()
time.sleep(1)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
time.sleep(1)
ugfx.clear(ugfx.WHITE)
ugfx.flush()


#draw name
name="Daan Goumans"
name_font = "Roboto_BlackItalic24"
company_name="Northwave"
company_name_font="Roboto_Regular18"

ugfx.string(math.ceil(screen_width/2-25),math.ceil(screen_height/2-25),name,name_font,ugfx.BLACK)
name_len = ugfx.get_string_width(name,name_font)
ugfx.line(math.ceil(screen_width/2-25), math.ceil(screen_height/2), math.ceil(screen_width/2-25), math.ceil(screen_height/2)+len,ugfx.BLACK)
name_len2 = ugfx.get_string_width(company_name,company_name_font)
ugfx.string((math.ceil(screen_width/2-25)+(math.ceil(name_len/2))-math.ceil(name_len2/2)),math.ceil(screen_height/2+25),company_name,company_name_font,ugfx.BLACK)
ugfx.flush()

#get and draw logo
#needs full system path to logo
img = 'lib/group_sponsor_logo_and_name/logo.png'
badge.eink_png(math.ceil(screen_width/4-25),math.ceil(screen_height/2-25), img)

ugfx.flush()