from experimental import winkekatze

wk=winkekatze()