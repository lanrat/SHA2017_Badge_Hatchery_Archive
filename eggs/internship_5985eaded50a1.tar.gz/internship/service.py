import badge, ugfx, time

ugfx.init()
badge.init()

# This function gets called by the home application at boot
def setup():
    ugfx.string(20, 90, 'Test', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()
    badge.leds_enable()
    
def loop():
    ugfx.string(20, 90, 'Test', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()
    badge.leds_enable()
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(1)
    return 4

def draw(y, sleep = 2):
  ugfx.string(0, y, 'Testing', 'Roboto_BlackItalic24', ugfx.BLACK)
  return 296