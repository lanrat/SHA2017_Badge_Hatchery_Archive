import badge
import ugfx
import wifi
import os

badge.init()
ugfx.init()
wifi.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

path = 'lib/espixelflut'
os.chdir(path)
files = os.listdir()

import re
toRemoveList = []
for file in files:
  if not re.match(r"ACKtree_([a-zA-Z0-9]+)\.py", file):
    toRemoveList.append(file)
for toRemove in toRemoveList:
  files.remove(toRemove)

pos = 0
def selectionScreen(change = 0, pressed = False):
  global pos
  global files

  if pressed and (change != -1 or pos > 0) and (change != 1 or pos < len(files) - 1):
    pos += change

    i = 0
    for file in files:
      if i == pos:
        color = ugfx.BLACK
      else:
        color = ugfx.WHITE
      ugfx.thickline(0, 6+i*12, 100, 6+i*12, color, 12, 0)
      i += 1
    i = 0
    for file in files:
      if i == pos:
        color = ugfx.WHITE
      else:
        color = ugfx.BLACK
      ugfx.string(0,i*12,file,"Roboto_Regular12",color)
      i += 1
    ugfx.flush()

def startScript(pressed = False):
  global files
  global pos

  if pressed:
    execfile(files[pos])

def setConfig(pressed = False):
  if pressed:
    pass

selectionScreen(0, True)

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: selectionScreen(-1, pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: selectionScreen(1, pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: startScript(pressed))
#ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: setConfig(pressed))

while True:
  pass