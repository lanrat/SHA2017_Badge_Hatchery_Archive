from buienradar import Buienradar

Buienradar()
