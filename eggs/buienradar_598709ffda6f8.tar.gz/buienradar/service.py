

def setup():
    pass

def loop():
    return 60000

def draw(y):
    from buienradar import Buienradar
    Buienradar.start()
    return [60000, 20]
