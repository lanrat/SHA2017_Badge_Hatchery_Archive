import badge
import ugfx
import deepsleep

# width = 296
# height = 128

tile = 20;

def snakeflut():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)

    # input
    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_LEFT, left)

    clear()

def clear():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()


def up(wut):
    clear()
    ugfx.area(tile*2, tile*1, tile*1, tile*1, ugfx.BLACK)
    ugfx.flush()

def right(wut):
    clear()
    ugfx.area(tile*3, tile*2, tile*1, tile*1, ugfx.BLACK)
    ugfx.flush()

def down(wut):
    clear()
    ugfx.area(tile*2, tile*3, tile*1, tile*1, ugfx.BLACK)
    ugfx.flush()

def left(wut):
    clear()
    ugfx.area(tile*1, tile*2, tile*1, tile*1, ugfx.BLACK)
    ugfx.flush()

def reboot(wut):
  deepsleep.reboot()

snakeflut()
