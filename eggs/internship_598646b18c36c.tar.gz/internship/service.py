import badge, ugfx, time#, network
#import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1

def check_if_locked():
    badge.vibrator_activate(0xFF)
    #sta_if = network.WLAN(network.STA_IF); sta_if.active(True); sta_if.connect("SHA2017-insecure")
    #time.sleep(3)
    #t = requests.get("http://project1.online/sha2017-plsdonthackme/test.json").json()
    badge.vibrator_activate(0xFF)
    _id = 1#t["id"]
    if _id == 3:
        global _continue
        _continue = 0

def setup():
    ugfx.init()
    badge.init()
    ugfx.flush()  
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP, no)
    ugfx.input_attach(ugfx.JOY_DOWN, no)
    ugfx.input_attach(ugfx.BTN_A, no)
    ugfx.input_attach(ugfx.BTN_SELECT, no)
    ugfx.input_attach(ugfx.BTN_B, no)
    check_if_locked()
    freez()
         
def no():
        leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        badge.leds_enable()
def freez():
    global _continue
    if (_continue):
        leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
        badge.leds_send_data(leds_array)    
        badge.leds_enable()
        while 1:
          time.sleep(9999)
    else:     
        leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        badge.leds_enable()

def draw(x,y=2):
    global _continue
    #if(_continue):
    ugfx.clear(ugfx.BLACK)
    ugfx.display_image(0, 178, '/lib/Internship/r3.png')
    ugfx.string(12, 12, "YOUR BADGE HAS", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 25, "  BEEN LOCKED.", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 37, "To unlock your badge", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 49, "find us at XXXXX", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 62, "Your unique key for", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 75, "decryption is XXXX", "Roboto_Regular12", ugfx.WHITE)
    #else:
     #   ugfx.clear(ugfx.BLACK)
      #  ugfx.display_image(0, 178, '/lib/Internship/rl.png')
       # ugfx.string(12, 12, "    SUCCESS!", "Roboto_Regular12", ugfx.WHITE)
        #ugfx.string(12, 25, " BADGE UN-LOCKED.", "Roboto_Regular12", ugfx.WHITE)
        #ugfx.string(12, 37, "Press select to enjoy", "Roboto_Regular12", ugfx.WHITE)
        #ugfx.string(12, 49, "your badge again.", "Roboto_Regular12", ugfx.WHITE)
        #ugfx.string(12, 62, "And don't install", "Roboto_Regular12", ugfx.WHITE)
        #ugfx.string(12, 75, "untrusted apps!", "Roboto_Regular12", ugfx.WHITE)
    return 296