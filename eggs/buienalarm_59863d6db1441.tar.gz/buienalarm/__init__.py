from buienalarm import buienradar

buienradar.rain_graph(0, 0, 296, 128, 1.0)
