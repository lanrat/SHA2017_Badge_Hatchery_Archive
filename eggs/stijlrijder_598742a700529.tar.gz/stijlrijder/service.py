#import utime, badge, binascii
import badge

counter = 0
direction = True
serviceMode = 0

# This function gets called by the home application at boot
def setup():
    global serviceMode, brightness, color_pick
    serviceMode = badge.nvs_get_u8('stijlrijder', 'serviceMode', 0)
    brightness  = badge.nvs_get_u8('stijlrijder', 'brightness', 50)

    # Set the appropriate color pick
    if(serviceMode<1):
        # print "STIJLRIJDER Disabled! Please enable in app!"
        return True
    elif(serviceMode==1):
        # GREEN
        color_pick = [255, 0, 0, 0]
    elif(serviceMode==2):
        # RED
        color_pick = [0, 255, 0, 0]
    elif(serviceMode==3):
        # BLUE
        color_pick = [0, 0, 255, 0]
    elif(serviceMode==4):
        # PINK
        color_pick = [0, 255, 155, 0]
    else:
        # WHITE
        color_pick = [0, 0, 0, 255]

    badge.leds_enable()

# Set led(pos) to GRBW values in the ledbuffer
def set_led(ledbuffer, pos, grbw):
    pos = pos*4
    ledbuffer[pos]   = grbw[0]
    ledbuffer[pos+1] = grbw[1]
    ledbuffer[pos+2] = grbw[2]
    ledbuffer[pos+3] = grbw[3]
    return ledbuffer

# grbw = arr[4], phase = 0-10, brightness = 0-100
def dim_pixel(grbw, phase, brightness):
    ret = [0,0,0,0]
    multiply = (phase / 10) * (brightness / 100)
    ret[0] = round(grbw[0] * multiply)
    ret[1] = round(grbw[1] * multiply)
    ret[2] = round(grbw[2] * multiply)
    ret[3] = round(grbw[3] * multiply)
    return ret

def leds(counter, direction):
    global serviceMode, brightness, color_pick
    led = 0

    led = round(counter/10)
               
    if direction:
        prevLed = max(0, led-1)
        nextLed = min(5, led+1)
    else:
        prevLed = min(5, led+1)
        nextLed = max(0, led-1)
    
    # pre-clearing output array
    output = []
    for i in range(0,24):
        output.append(0)

    # Draw current, prev and next led
    brightNext = counter % 10
    brightPrev = 10 - brightNext

    set_led(output, nextLed, dim_pixel(color_pick, brightNext, brightness))
    set_led(output, prevLed, dim_pixel(color_pick, brightPrev, brightness))
    set_led(output, led,     dim_pixel(color_pick, 10, brightness))
    
    return output


def loop():
    global serviceMode
    global direction
    global counter
        
    if (serviceMode>0): 
        if direction:
            counter = min(50, counter+1)
        else:
            counter = max(10, counter-1)
        if counter==50 or counter==10:
            direction = not direction
        values = leds(counter, direction)
        badge.leds_send_data(bytes(values),24)
        return 5
    return 0