import badge, ugfx, utime
from random import choice, randint

badge.init()
ugfx.init()

a = ['All', 'Acht', 'Are']
b = ['Cops', 'Cats', 'Bacteria', 'Bastards']
c = ['.', '!', '?']
colors = [ugfx.WHITE, ugfx.BLACK]

while(True):
    front = choice(colors)
    back = None
    font = "PermanentMarker22"
    offset_x = 10
    offset_y = 20

    if front == ugfx.BLACK:
        back = ugfx.WHITE
    else:
        back = ugfx.BLACK
        
    ugfx.clear(back)
    text = choice(a)+" "+choice(b)+" "+choice(a).lower()+" "+choice(b)+choice(c)
    text_width = ugfx.get_string_width(text, font)
    x = randint(0, 296)-text_width-offset_x
    y = randint(0, 128)-offset_y
    print(x, y)
    if x < 0:
        x = offset_x
    if y < 0:
        y = offset_y
    ugfx.string(x, y, text, font, front)
    ugfx.flush()
    utime.sleep(10)
