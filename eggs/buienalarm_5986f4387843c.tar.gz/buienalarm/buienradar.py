import easywifi
import math
import urequests
import ugfx

SHA_LAT = 52.28
SHA_LON =  5.53

TS_WIDTH = 32
TS_HEIGHT = 14

BUIENRADAR_URL = 'https://br-gpsgadget-new.azurewebsites.net/data/raintext?lat=%.2f&lon=%.2f' % (SHA_LAT, SHA_LON)

def _raw_to_mm(raw):
    raw = int(raw)
    if raw == 0: return 0.0
    return 10 ** ((raw - 109) / 32)

def get_downpour():
    """Returns a table for the downpour over the next 2 hours.

    Return value is a list of pairs of the form ('hh:mm', millimeters)
    """
    if not easywifi.status(): raise RuntimeError('WiFi is not connected')

    resp = urequests.get(BUIENRADAR_URL)
    data = []
    for line in resp.text.splitlines():
        rain, time = line.split('|')
        data.append((time, _raw_to_mm(rain)))

    if len(data) == 0: raise RuntimeError('No data')
    return data

def rain_graph(x, y, width, height, scale):
    """Draws a rain graph at the specified coordinates.

    Uses 14 pixels for the time, and then draws a graph across the full length
    of the specified area, capping values at (height / scale) - 14 millimeters
    """
    try:
        downpour = get_downpour()
    except Exception as e:
        ugfx.string_box(x, y, width, height,
                        str(e), "Roboto_Regular12",
                        ugfx.BLACK, ugfx.justifyCenter)
        return

    # How many timestmaps can we fit?
    num_items = len(downpour)
    period = math.ceil(num_items * TS_WIDTH / width)

    sample_width = int(width / (num_items - 1))
    
    prev_mm_y = 0
    text_y = y + height - TS_HEIGHT + 1
    bot_y = height - TS_HEIGHT - 1

    for i, item in enumerate(downpour):
        time, mm = item
        if i % period == 0:
            text_x = x + i * sample_width - TS_WIDTH // 2
            
            # Corner case: screen edge
            if text_x < 0:
                text_x = 0
            elif text_x + TS_WIDTH > x + width:
                text_x = x + width - TS_WIDTH

            ugfx.string(text_x, text_y, time, "Roboto_Regular12", ugfx.BLACK)

        mm_y = max(0, height - (TS_HEIGHT + 1 + int(mm * scale + .5)))
        if i > 0:
            # The right edge won't be drawn.
            ugfx.fill_polygon(x + i * sample_width, y,
                              [(0, bot_y), (0, prev_mm_y),
                               (sample_width, mm_y), (sample_width, bot_y)],
                              ugfx.BLACK)

        prev_mm_y = mm_y