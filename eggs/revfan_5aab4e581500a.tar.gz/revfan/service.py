def setup():
    import machine, badge, easydraw
    if badge.nvs_get_str('boot', 'splash', '') != 'Revfan':
      easydraw.msg("Hacking myself")
      badge.nvs_set_str('boot', 'splash', 'Revfan')
      easydraw.msg("Hacking done!")
    else:
      easydraw.msg("Al gehekt")
    
    machine.deepsleep(1)