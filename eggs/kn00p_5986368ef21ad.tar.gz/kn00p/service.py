import badge, ugfx, tim

def setup ():

def loop():
    return 60000
