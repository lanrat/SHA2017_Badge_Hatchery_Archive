import badge
import ugfx
import time
import appglue

def quit(pressed):
    if(pressed):
        appglue.start_app("")
    ugfx.flush()

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
nick = badge.nvs_get_str('owner', 'name', 'Hacker1337')
len = ugfx.get_string_width(nick,"PermanentMarker22")
center = int(len/2)
ugfx.string(110-center, 40, nick,"PermanentMarker36", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
    leds_array = bytes([255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(.2)