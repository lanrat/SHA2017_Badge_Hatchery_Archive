import ugfx
import wifi
import usocket
from time import sleep

'''
There's still werk ta do. *werk-werk*
Just usin' the Hatchery 'cause it's soo easy to deploy.
Not working yet; hang in there :3
'''

def clear_screen():
    for color in [ugfx.WHITE, ugfx.BLACK, ugfx.WHITE]:
        ugfx.clear(color)
        ugfx.flush()


def socket_create(port):
    sock = usocket.socket()
    addr_info = usocket.getaddrinfo("0.0.0.0", port)
    addr = addr_info[0][-1]
    sock.bind(addr)
    sock.listen(5)
    return sock


def pixelflood_server(sock):
    while True:
        client_sock = sock.accept()[0]
        pixelflood_handler(client_sock)


def pixelflood_handler(client_sock):
    while True:
        line = client_sock.readline()
        if line == '' or line == '\r\n':
            break

        line_parts = line.split(' ')
        if len(line_parts) != 4  or \
           line_parts[0] != 'PX' or \
           len(line_parts[3]) != 6:
            break
        try:
            int(line_parts[1])
            int(line_parts[2])
            int(line_parts[3], 16)
        except ValueError:
            break
        
        x, y = int(line_parts[1]), int(line_parts[2])
        col  = ugfx.BLACK if int(line_parts[3], 16) < 0x800000 else ugfx.WHITE

        if x in range (0, 296) and y in range(0, 128):
            ugfx.pixel(x, y, col)


ugfx.init()
wifi.init()

# connect to wifi
clear_screen()
ugfx.demo("connecting")
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
clear_screen()
current_ip = wifi.sta_if.ifconfig()[0]
ugfx.demo(current_ip)

# start server
sock = socket_create(2017)
pixelflood_server(sock)