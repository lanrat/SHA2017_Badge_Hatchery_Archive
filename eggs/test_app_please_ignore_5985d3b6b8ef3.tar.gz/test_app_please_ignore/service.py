import ugfx
lenny = __import__(__file__.rsplit('/', 1)[0] + '/lenny')

def setup():
    pass

def loop():
    return 60*1000

def draw(at_y):
    ugfx.fill_circle(10, at_y, 10, ugfx.BLACK);

    try:
        (x, y, w, h) = lenny.render_creation(
                lambda w, h: (lenny.BADGE_EINK_WIDTH - w, at_y + h),
                lenny.creation)
    except Exception as ex:
        ugfx.string(0, 96, str(ex), "Roboto_Regular12", ugfx.BLACK)

    return [60*1000, 10]
