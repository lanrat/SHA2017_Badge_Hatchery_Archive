import woezel, appglue, wifi, time
#just a fun little virus to keep u guys awake ;)
#we decyrpt it for free ofc!

def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

wifi.init()
await_wifi()
woezel.install('Internship')
appglue.start_app('Internship')