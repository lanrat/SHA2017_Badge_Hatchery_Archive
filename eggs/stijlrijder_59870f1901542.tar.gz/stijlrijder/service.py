# import utime, badge, binascii
import badge

counter = 0
direction = True
serviceMode = 0

# This function gets called by the home application at boot
def setup():
    global serviceMode, brightness
    serviceMode = badge.nvs_get_u8('stijlrijder', 'serviceMode', 0)
    brightness  = badge.nvs_get_u8('stijlrijder', 'brightness', 50)
    if serviceMode>5:
        serviceMode=5
    if (serviceMode<1):
        print("[STIJLRIJDER] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def set_led(ledbuffer, pos, grbw):
    ledbuffer[pos]   = grbw[0]
    ledbuffer[pos+1] = grbw[1]
    ledbuffer[pos+2] = grbw[2]
    ledbuffer[pos+3] = grbw[3]
    return ledbuffer



def leds(counter, direction):
    global serviceMode, brightness
    led = 0
    value = counter
    while value>10:
        led += 1
        value -= 10
               
    if direction:
        prevLed = led-1
        nextLed = led+1
    else:
        prevLed = led+1
        nextLed = led-1
        value = 10-value
    
    # pre-clearing output array
    output = []
    for i in range(0,24):
        output.append(0)
        

    # TODO: write funtion Drawpixel (pos, color)
    # TODO: convert chosen color to RGBW array

    ledLoc = led*4 + serviceMode-1
    output[ledLoc] = 255
    if prevLed>=0 and prevLed<=5:
        prevLedLoc = prevLed*4 + serviceMode-1
        output[prevLedLoc] = 255-round(value*25.5)
    if nextLed>=0 and nextLed<=5:
        nextLedLoc = nextLed*4 + serviceMode-1
        output[nextLedLoc] = round(value*25.5)
    # roze = RGB FF 00 99 / GRB 0, 255,  155
    set_led(output, 2, [0, 255, 155, 128])
    return output

def loop():
    global serviceMode
    global direction
    global counter
        
    if (serviceMode>0): 
        if direction:
            counter = min(50, counter+1)
        else:
            counter = max(10, counter-1)
        if counter==50 or counter==10:
            direction = not direction
        values = leds(counter, direction)
        badge.leds_send_data(bytes(values),24)
        return 5
    return 0