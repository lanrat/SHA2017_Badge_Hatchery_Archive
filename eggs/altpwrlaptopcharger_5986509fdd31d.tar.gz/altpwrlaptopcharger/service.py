import badge,deepsleep,urandom,wifi
from umqtt.simple import MQTTClient

psuvoltage='0.0'
psucurrent='0.0'
psutemperature='0.0'
current=['0.0','0.0', '0.0','0.0', '0.0','0.0']
notification=['','','','','','']
error=['','','','','','']
ledjes=[0,0,0,0,0,0]

server="mqtt.sha2017.org"
clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
c = MQTTClient(clientname, server)

def sub_cb(topic, msg):
    global psuvoltage
    global psucurrent
    global psutemperature
    global error
    global notification
    global ledjes
    
    global laptopChargerVolt
    global laptopChargerCurrent
    global laptopChargerWatts
    global laptopChargerTemp
    global laptopChargerHumid
    
    print((topic, msg))
    
    #lets strip all the extra characters
    message = (msg.decode('utf-8'))
    message = message.replace('\x08', '')
    message = message.replace('\x05', '')
    message = message.replace(',', '.')
    message = message.strip()
    
    if(topic.decode('utf-8')=='altpwr/psu/voltage'):
    	psuvoltage = message
    if(topic.decode('utf-8')=='altpwr/psu/current'):
        psucurrent = message
    if(topic.decode('utf-8')=='altpwr/psu/temperature'):
        psutemperature = message

    
    for x in range(0, 6):
        if(topic.decode('utf-8')=='altpwr/psu/'+str(x+1)+'/current'):
           current[x]=message
        if(topic.decode('utf-8')=='altpwr/psu/'+str(x+1)+'/message'):
           notification[x]=message
        if(topic.decode('utf-8')=='altpwr/psu/'+str(x+1)+'/error'):
           error[x]=message
           if(error[x]!=''):
               ledjes[x]=1
           else:
               ledjes[x]=0

    if(topic.decode('utf-8')=='altpwr/node/laptopChargeStation/temperature'):
    	laptopChargerTemp = message
    if(topic.decode('utf-8')=='altpwr/node/laptopChargeStation/humidity'):
        laptopChargerHumid = message
    if(topic.decode('utf-8')=='altpwr/node/laptopChargeStation/watts'):
        laptopChargerWatts = message
    if(topic.decode('utf-8')=='altpwr/node/laptopChargeStation/voltage'):
    	laptopChargerVolt = message
    if(topic.decode('utf-8')=='altpwr/node/laptopChargeStation/current'):
        laptopChargerCurrent = message

def setup():
    print("Setting wifi for the MQTT conn")
    wifi.init()
    maxtime = 10.0;
    while not wifi.sta_if.isconnected() and maxtime>0:
        usleep(250)
        maxtime = maxtime - 0.25
        pass
    print("Coneccting MQTT server")
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"altpwr/#")
    print('mqtt set')
    c.check_msg()
    print("Sleeping to alow reciving mqtt")
    usleep(10000)
    pass

def loop(c):
    print("[ALTPOWERRR]Entering Loop")
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"altpwr/#")
    print('mqtt set')
    c.check_msg()
    print("Sleeping to alow reciving mqtt")
    sleep(5)
    print("Going to sleep now")
    draw(0,0)    
    deepsleep.start_sleeping(30000)
    return False

def draw(x,y):
    print("[ALTPOWERRR]Draw")
    return 0