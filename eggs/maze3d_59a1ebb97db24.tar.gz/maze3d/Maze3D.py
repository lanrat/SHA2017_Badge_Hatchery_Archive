### Author: Leiden Tech 
### Description: Leiden Tech
### Category: Games
### License: MIT
### Appname: Maze3D
### Built-in: no

import os
import badge
import ugfx
import machine
import math
import random
import appglue
import time

def Maze3D():
    badge.init()
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP,lambda pressed: btn_up(pressed))
    ugfx.input_attach(ugfx.JOY_DOWN,lambda pressed: btn_down(pressed))
    ugfx.input_attach(ugfx.JOY_LEFT,lambda pressed: btn_left(pressed))
    ugfx.input_attach(ugfx.JOY_RIGHT,lambda pressed: btn_right(pressed))
    ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: btn_select(pressed))
    ugfx.input_attach(ugfx.BTN_START,lambda pressed: btn_start(pressed))
    ugfx.input_attach(ugfx.BTN_A,lambda pressed: btn_a(pressed))
    ugfx.input_attach(ugfx.BTN_B,lambda pressed: btn_b(pressed))

    [year, month, mday, wday, hour, minute, second, microseconds] = machine.RTC().datetime()
    random.seed(int(microseconds))
    clearScreen()
    makeMaze(w,h)
    clearStatus()
    posX = random.randrange(1, w * 2 - 1, 2)
    posY = random.randrange(1, h * 2 - 1, 2)
    grid[posX][posY][1] = 1
    ugfx.flush()
    display()
"""
Start at a random cell.
Mark the current cell as visited, and get a list of its neighbors.
    starting with a random neighbor and stepping through neighbors until a valid unvisited one is found:
            remove the wall between the current cell and that neighbor, 
            and then recurse with that neighbor as the current cell as the start.
"""
def walk(x, y, ww, hh):
    global grid
    #mark current cell as visited
    grid[x][y][1] = 1
    #get list of neighbors
    neighbors = [(x - 2, y), (x, y + 2), (x + 2, y), (x, y - 2)]
    #For each random neighbor
    #going to have to implement my own shuffle here, sigh
    neighbors = shuffle(neighbors)
    for (xx, yy) in neighbors:
        #skip if out of range
        if xx <= 0 or xx > ww or yy <= 0 or yy > hh:
            continue
        #Skip if already visited
        if grid[xx][yy][1] == 1:
            continue
        #if not previously visited, remove the connecting wall
        if xx == x:
            if grid[xx][yy][1] == 0:
                grid[xx][max(y, yy) - 1] = [False, 0]
        if yy == y:
            if grid[xx][yy][1] == 0:
                grid[max(x, xx) - 1][yy] = [False, 0]
        #recurse using neighbor as start point
        walk(xx, yy, ww, hh)

def clearStatus():
    global grid, w, h
    for i in range(0, (w * 2 + 1)):
        for j in range(0, (h * 2 + 1)):
            grid[i][j][1] = 0

def shuffle(target):
    length = len(target)
    primary=-1
    secondary=-1
    if length < 2:
        #what are you going to shuffle then moron?
        return
    for i in range(length): #maybe math.ceil(length/2)+1):
        primary = random.randint(0,length - 1)
        while secondary == primary: #no point in shuffling to itself
            secondary = random.randint(0,length - 1)
        tmp = target[primary]
        target[primary] = target[secondary]
        target[secondary] = tmp
    return target

def makeMaze( w, h):
    global grid
    """
    sets up an array of WxH grid[x][y] = [wall,status]
    wall is True/False status is numeric 
    1) position of char
    2) position of exit
    3) position of monster
    4) position of treasure
    5) etc?
    #prime grid[x][y] = [wall,status]
    #########
    # # # # #
    #########
    # # # # #
    #########
    # # # # #
    #########
    # # # # #
    #########
    """
    #Set all positions in grid to wall
    grid = [[[True, 0] for i in range( h * 2 + 1)] for j in range(w * 2 + 1)]
    #Removes every other one
    for x in range(1, w * 2 + 1, 2):
        for y in range(1, h * 2 + 1, 2):
            grid[x][y] = [False, 0]
    #start at random cell and walk
    startw = random.randrange(1, w * 2 - 1, 2)
    starth = random.randrange(1, h * 2 - 1, 2)
    #print("startx starty: ", startw, starth )
    walk(startw, starth, w * 2 - 1, h * 2 - 1)

def printMaze():
    #print out text representation to tty - wont work with badge
    global grid
    for x in range(w * 2 + 1):
        for y in range(h * 2 + 1):
            #print("x: %s y: %s " % (x, y), end=' ')
            if grid[x][y][0]:
                print("%s" % '#', end='')
            else:
                print("%s" % ' ', end='')
        print()

def draw3dView():
    global w,h,grid,screenX,screenY,font,fgcolor,bgcolor,dirOffset,direction,pixelW,pixelH,posX,posY
    viewX=screenX - (pixelW * (w * 2 + 1) ) - 6 #200
    viewY=screenY - 3 #125
    #ugfx.string(10,10,str(viewX),font,fgcolor)
    #ugfx.string(10,70,str(viewY),font,fgcolor)
    #ugfx.string(10,50,str(dirX),font,fgcolor)
    #ugfx.string(30,50,str(dirY),font,fgcolor)
    #ugfx.flush()
    #time.sleep(1)
    ugfx.box( 0, 0, viewX, viewY, fgcolor)
    ugfx.line(0, 0, viewX, viewY, fgcolor)
    ugfx.line(0, viewY, viewX, 0, fgcolor)
    """
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/5)/2),math.ceil(viewY/2)-math.ceil((viewY/5)/2),math.ceil(viewX/5),math.ceil(viewY/5), fgcolor)
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/4)/2),math.ceil(viewY/2)-math.ceil((viewY/4)/2),math.ceil(viewX/4),math.ceil(viewY/4), fgcolor)
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/3)/2),math.ceil(viewY/2)-math.ceil((viewY/3)/2),math.ceil(viewX/3),math.ceil(viewY/3), fgcolor)
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/2)/2),math.ceil(viewY/2)-math.ceil((viewY/2)/2),math.ceil(viewX/2),math.ceil(viewY/2), fgcolor)
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/1)/2),math.ceil(viewY/2)-math.ceil((viewY/1)/2),math.ceil(viewX/1),math.ceil(viewY/1), fgcolor)
    """
    #all the lines less than half
    e=1
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    #all the lines bigger than half
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)

    e=2
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    #ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)

    e=3
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    #ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    """
    e=4
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    """
    e=5
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)

    e=6
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    #ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    """
    e=7
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    e=8
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    e=9
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    """
    e=10
    ugfx.box(math.ceil(viewX/2)-math.ceil((viewX/e)/2),math.ceil(viewY/2)-math.ceil((viewY/e)/2),math.ceil(viewX/e),math.ceil(viewY/e), fgcolor)
    ugfx.box(math.ceil(viewX/e)-math.ceil((viewX/e)/2),math.ceil(viewY/e)-math.ceil((viewY/e)/2),viewX - math.ceil(viewX/e),viewY - math.ceil(viewY/e), fgcolor)
    return

def drawMaze():
    global w,h,grid,screenX,screenY,font,fgcolor,bgcolor,dirOffset,direction,pixelW,pixelH,posX,posY
    startX=screenX - (pixelW * (w * 2 + 1) )
    startY=0
    compass=dirOffset[direction][2]
    for i in range(0, (w * 2 + 1)):
        for j in range(0, (h * 2 + 1)):
            if grid[i][j][0] is True: #wall
                ugfx.area( startX + ( pixelW * i ), startY + ( pixelH * j ), pixelW, pixelH, fgcolor )
            else: #erase
                #ugfx.box( startX + ( pixelW * i ), startY + ( pixelH * j ), pixelW, pixelH, bgcolor )
                ugfx.area( startX + ( pixelW * i ), startY + ( pixelH * j ), pixelW, pixelH, bgcolor )
            if grid[i][j][1] == 1: #char
                #ugfx.box( startX + ( pixelW * i ), startY + ( pixelH * j ), pixelW, pixelH, fgcolor )
                ugfx.fill_circle(startX + ( pixelW * i ) + math.floor(pixelH/2), startY + ( pixelH * j ) + math.floor(pixelH/2)-1, math.floor(pixelH/2)-1, fgcolor)
                #TODO This is stupid
                posX=i
                posY=j
    #this works to erase
    ugfx.area(210, 100, 30, 20, bgcolor)
    ugfx.string(210,100,compass,font,fgcolor)

def display():
    draw3dView()
    drawMaze()
    ugfx.flush()
    wait()

def wait():
    while True:
       return

def quit():
    global fgcolor,font
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.string(50, 50, "Quitting", font,fgcolor)
    ugfx.flush()
    appglue.start_app("launcher",False)

def clearfg():
    global font,bgcolor,fgcolor
    ugfx.clear(fgcolor)
    ugfx.flush()

def clearbg():
    global font,bgcolor,fgcolor
    ugfx.clear(bgcolor)
    ugfx.flush()

def clearScreen():
    clearfg()
    clearbg()

def btn_a(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        display()

def btn_b(pressed):
    global grid,dirOffset,direction,posX,posY,font,fgcolor
    if pressed:
        display()

def btn_up(pressed):
    global grid,dirOffset,direction,posX,posY,font,fgcolor
    if pressed:
        #math.sum doesn't work
        dirX=posX - dirOffset[direction][0]
        dirY=posY - dirOffset[direction][1]
        #dirX=dirOffset[direction][0]
        #dirY=dirOffset[direction][1]
        #ugfx.string(10,30,str(posX),font,fgcolor)
        #ugfx.string(30,30,str(posY),font,fgcolor)
        #ugfx.string(10,50,str(dirX),font,fgcolor)
        #ugfx.string(30,50,str(dirY),font,fgcolor)
        #ugfx.flush()
        #time.sleep(1)
        if grid[dirX][dirY][0] == False:
            #ugfx.string(10,10,"valid move",font,fgcolor)
            #ugfx.flush()
            grid[posX][posY][1] = 0
            grid[dirX][dirY][1] = 1
            posX = dirX
            posY = dirY
        display()

def btn_down(pressed):
    global dirOffset,direction
    if pressed:
        for i in range(2):
            direction = direction + 1
            if direction >= len(dirOffset):
                direction = 0
        display()

def btn_left(pressed):
    global dirOffset,direction
    if pressed:
        direction = direction - 1
        if direction < 0:
            direction = len(dirOffset) - 1
        display()

def btn_right(pressed):
    global dirOffset,direction
    if pressed:
        direction = direction+1
        if direction >= len(dirOffset):
            direction = 0
        display()

def btn_start(pressed):
    if pressed:
        quit()

def btn_select(pressed):
    if pressed:
        Maze3D()

########
# MAIN #
########
fgcolor=ugfx.BLACK
bgcolor=ugfx.WHITE
font="Roboto_Regular12"
grid = []
#size of maze - TODO can't be bigger than 4x5 otherwise fails with a maximum
#recursion error have to figure a non-recursive way to generate the maze - sigh
w = 4
h = 4
#character position
posX = 0
posY = 0
direction = 0
dirOffset = [ [0, 1,"N"], [-1, 0,"E"], [0, -1,"S"], [1, 0,"W"]]
compass=dirOffset[direction][2]
#size of screen
screenX = 296
screenY = 128
#size of wall bock
pixelW = 10
pixelH = 10

Maze3D()
