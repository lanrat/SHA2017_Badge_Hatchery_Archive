import badge
import ugfx

def home(pushed):
    if pushed:
        exit()

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(150,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(130,50,"Coloring","PermanentMarker22",ugfx.BLACK)
len = ugfx.get_string_width("Coloring","PermanentMarker22")
ugfx.line(130, 72, 144 + len, 72, ugfx.BLACK)
ugfx.line(140 + len, 52, 140 + len, 70, ugfx.BLACK)
ugfx.string(140,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
badge.eink_png(10,63,'/lib/sha2017colors/shrug.png')

ugfx.flush()
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: home())

sha2017 = bytes(24)

while True:
    sha2017 = bytes([87, 192, 214, 100, 106, 8, 154, 100, 77, 91, 219, 100, 126, 44, 82, 100, 154, 211, 73, 100, 185, 6, 57, 100])
    badge.leds_send_data(sha2017)

