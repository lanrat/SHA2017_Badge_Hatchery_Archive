import badge, ugfx, appglue, deepsleep

def program_main():
  try:
    badge.eink_png(0,0, '/lib/hackeriet/hackeriet.png')
  except:
    ugfx.string(0, 0, "NYANCAT LOAD ERROR hackeriet.png", "Roboto_Regular12", ugfx.BLACK)
  ugfx.flush()
  badge.eink_busy_wait()
  deepsleep.start_sleeping(5000)
  appglue.start_app("")

program_main()