import ugfx,badge,machine,time,appglue
badge.init()
ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.LUT_FULL)
ns="charge_leds"
svck="enable"

from charge_leds import show_leds

status = badge.nvs_get_u8(ns, svck, 0)
redraw = True

def draw():
    global redraw, status
    if redraw:
        ugfx.clear()
        ststring = "enable" if status else "disable"
        ugfx.string(0, 25, "START: main menu",  "Roboto_BlackItalic24", ugfx.BLACK)
        ugfx.string(0, 50, "SELECT: "+ststring+" service", "Roboto_BlackItalic24",  ugfx.BLACK)
        ugfx.flush()
        redraw = False
    return show_leds.show_leds(False)

def change_service():
    global redraw, status
    badge.nvs_set_u8(ns, svck, not status)
    status = not status
    redraw = True

def btn_change(pushed):
    global redraw
    if pushed:
        redraw = True
        change_service()

def btn_home(pushed):
    global die
    if(pushed):
        appglue.start_app("")
        die=True

ugfx.input_attach(ugfx.BTN_SELECT, btn_change)
ugfx.input_attach(ugfx.BTN_START, btn_home)

die = False

while not die:
    time.sleep(draw()/1000.)
