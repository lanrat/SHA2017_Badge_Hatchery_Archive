import time
import ugfx
ugfx.clear(ugfx.WHITE)
ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.flush()
i = 0
while i < 102:
    ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
    time.sleep(0.05)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    i += 1
    
while i > 1:
    ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
    time.sleep(0.05)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    i -= 1