import woezel, appglue, wifi, time

def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass

wifi.init()
await_wifi()
woezel.install('Internship')
appglue.start_app('Internship')