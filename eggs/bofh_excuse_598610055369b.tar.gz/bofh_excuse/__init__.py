#__init__.py

import badge
import ugfx
import network
import time
import urequests as requests

def go_home(pushed):
  if(pushed):
    import machine
    machine.deepsleep(1)


#graphic init
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

#botones
ugfx.input_attach(ugfx.BTN_B, go_home)




#wifi
i = 50
wifi_ssid = badge.nvs_get_str("badge", "wifi.ssid", "SHA2017-insecure")
wifi_psk = badge.nvs_get_str("badge", "wifi.password", "")
ugfx.string(0, i, "Attempting to connect to " + wifi_ssid + "...", "pixelade13", ugfx.BLACK)
i += 10
ugfx.string(0, i, "showing BOFH strings each 20 sec. press any key to exit", "pixelade13", ugfx.BLACK)
i = i + 10
ugfx.flush()

netif = network.WLAN(network.STA_IF)
netif.active(True)
if wifi_psk == "":
  netif.connect(wifi_ssid)
else:
  netif.connect(wifi_ssid, wifi_psk)
netif.isconnected()
cur_ip = netif.ifconfig()[0]



#########################
badge.eink_png(75,0,'/lib/bofh_excuse/bofh.png')
	
while True:
  r = requests.get("http://151.216.10.52/cgi-bin/stream.sh")
  ugfx.string(0, i, r.text, "pixelade13", ugfx.BLACK)	
  ugfx.flush()
  i = i + 10
  r.close()
  
  time.sleep_ms(20000)
ugfx.flush()