import ugfx, badge, time
import urequests as requests

import easywifi, easydraw

announcements = []

def setup():
    if not easywifi.status():
        if not easywifi.enable():
            return
    easydraw.msg("Fetching Announcements...", True)
    try:
        url = "https://wiki.sha2017.org/w/Special:Ask/-5B-5B-2DHas-20subobject::Announcements-5D-5D-20-5B-5BEnddate::-3E-3E29-20July-202017-5D-5D/-3FAnnouncement/-3FEnddate/mainlabel%3D-2D/limit%3D300/offset%3D0/format%3Djson/link%3Dall/headers%3Dshow/searchlabel%3Dcurrent-20announcements-20in-20JSON"
        r = requests.get(url)
        data = r.json()
        r.close()
        global announcements
        for result in data['results']:
            announcements.append(data['results'][result]['printouts']['Announcement'][0])
        easydraw.msg("Success!")
        easydraw.msg("Fetched "+str(len(announcements))+" announcements.")
    except:
        easydraw.msg("Failure.")
    

def loop(c):
    return False

def draw(x,y):
    ypos = y
    pixels_used = 0
    global announcements
    c = len(announcements)
    if c>0:
        for i in range(0,c):
            text = announcements[i]
            try:
                badge.eink_png(x,ypos,'/lib/announcements_test/sha.png')
            except:
                ugfx.string(x, ypos, "[SHA]",'Roboto_Regular12',ugfx.BLACK)
            ugfx.string(x+41, ypos+1, text, "Roboto_Regular12",ugfx.BLACK)
            ypos += 14
    return ypos-y



