import appglue
appglue.home()
