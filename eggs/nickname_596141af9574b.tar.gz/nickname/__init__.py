import dialogs, ugfx
nick = dialogs.prompt_text("Please enter name")
print(nick)
ugfx.clear(ugfx.WHITE)

ugfx.string(50,15,"STILL","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.string(30,50,nick,"PermanentMarker36",ugfx.WHITE)
len = ugfx.get_string_width(nick,"PermanentMarker36")
ugfx.line(30, 82, 44 + len, 72, ugfx.WHITE)
ugfx.line(40 + len, 62, 40 + len, 80, ugfx.WHITE)
ugfx.string(40,75,"Anyway","Roboto_BlackItalic24",ugfx.WHITE)

ugfx.flush(ugfx.LUT_FULL)

import deepsleep, badge
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)