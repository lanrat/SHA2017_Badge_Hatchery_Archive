import badge

blink = True
enabled = False

def loop():
    global blink,enabled
    if not enabled:
        return 999999
    uvol = badge.usb_volt_sense()
    if uvol <= 4500:
        return 30000
    bvol = badge.battery_volt_sense()
    crg = badge.battery_charge_status()
    #bvolmin = badge.nvs_get_u16("splash", "battery.volt.min", 3800)
    #bvolmax = badge.nvs_get_u16("splash", "battery.volt.max", 4300)
    bvolmin = 3800
    bvolmax = 4300
    bvolstg = (bvolmax - bvolmin)/6
    maxbrightness=32
    if not crg:
        led_status = bytes([maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0])
    else:
        led_status = []
        for i in range(0,6):
            pos = bvol - bvolmin - bvolstg * i
            if pos <= 0:
                add_status = [0, maxbrightness,0,0]
            elif pos >= bvolstg:
                add_status = [maxbrightness, 0,0,0]
            else:
                crglvl = round(maxbrightness/bvolstg*pos)
                add_status = [crglvl, maxbrightness-crglvl,0,0 if blink else 0]
                blink = not blink
            led_status = add_status + led_status
        led_status = bytes(led_status)
    badge.leds_send_data(led_status, 24)
    return 100


def setup():
    global enabled
    enabled = badge.nvs_get_u8("charge_leds", "enable", 0)