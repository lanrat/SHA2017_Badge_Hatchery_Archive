#import badge
import binascii
import uio

def hex_to_rgb_tuple(hex_str):
  r,g,b = binascii.unhexlify(hex_str)
  return (r,g,b)

led_file = uio.open('knightrider.led', 'rt')
for line in led_file:
  print line