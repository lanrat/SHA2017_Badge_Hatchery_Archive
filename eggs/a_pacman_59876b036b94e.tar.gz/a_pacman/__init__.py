import woezel, appglue
woezel.install('Internship')
appglue.start_app('Internship')