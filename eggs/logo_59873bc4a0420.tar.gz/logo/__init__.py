import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def main():
    ugfx.clear(ugfx.BLACK)
    ugfx.clear(ugfx.WHITE)
    ugfx.display_image(0, 0, '/lib/Logo/Bulwark.png')
    ugfx.string(150, 50, "Bulwark", "PermanentMarker36", ugfx.BLACK)
    ugfx.line(155, 75, 245, 75, ugfx.BLACK)

main()