void setup(void)
    import machine, badge, easydraw
    easydraw.msg("Hacking myself")
    badge.nvs_set_str('boot', 'splash', 'wiki_infotag')
    machine.deepsleep(1)
