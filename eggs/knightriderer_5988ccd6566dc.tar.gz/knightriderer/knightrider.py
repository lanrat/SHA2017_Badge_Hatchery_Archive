import ugfx, badge
import appglue

def action_home(pressed):
    if (pressed):
        appglue.start_app("")


def store():
    global nyanValue
    badge.nvs_set_u8('kriderer', 'brightness', nyanValue)

def load():
    global nyanValue
    nyanValue = badge.nvs_get_u8('kriderer', 'brightness', 0)

def action_more(pressed):
    if (pressed):
        global nyanValue
        nyanValue = nyanValue + 1
        if (nyanValue>4):
            nyanValue = 4
        else:
          store()
        draw()

def action_less(pressed):
    if (pressed):
        global nyanValue
        nyanValue = nyanValue - 1
        if (nyanValue<0):
            nyanValue = 0
        else:
          store()
        draw()

def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Knightriderer lights", "PermanentMarker22", ugfx.BLACK)
    global nyanValue
    if (nyanValue>0):
        mode = nyanValue
        if nyanValue==1:
            mode = "KARR"
        elif nyanValue==2:
            mode = "KITT"
        elif nyanValue==3:
            mode = "BLUE"
        else:
            mode = "WHITE"

        ugfx.string(0, 25, "Service is enabled ("+mode+")!", "Roboto_Regular12", ugfx.BLACK)
        ugfx.string(0, 38, "Press start to see it in action.", "Roboto_Regular12", ugfx.BLACK)
    else:
        ugfx.string(0, 25,  "Service is disabled!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*1, "UP: Mode +", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*2, "DOWN: Mode -", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*3, "START: Go to homescreen", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*4, "", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*5, "Warning: drains battery!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()

def program_main():
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, action_home)
    ugfx.input_attach(ugfx.JOY_UP, action_more)
    ugfx.input_attach(ugfx.JOY_DOWN, action_less)
    load()
    draw()

# Start main application
program_main()

