import ugfx, badge, dialogs
import ujson as json
import wifi
import gc
import urequest as requests
import time

badge.init()
ugfx.init()
wifi.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

input_string = badge.nvs_get_str("Hashtag", "hashtag", "")
hashtag = dialogs.prompt_text("What hashtag should we display?", input_string)
if hashtag:
  badge.nvs_set_str("Hashtag", "hashtag", hashtag)

tweets = []
index_counter=-1
def get_tweets(hashtag):
	gc.collect()
	try:
		data = requests.get("https://challenge.nwlab.nl/badge/twitter/get.php?hashtag="+hashtag)
	except:
		print("Could not download JSON!")
		time.sleep(1)
		return
	try:
		global tweets
		tweets = json.loads(str(data))
	except:
		data.close()
		print("Could not decode JSON!")
		time.sleep(1)
		return
	data.close()
	x=0
	tweet_array = []
	amount =  len(tweets['statuses'])
	if amount >= 1:
		for x in range(0,amount):
			tweet_user = "@" + str(tweets['statuses'][x]['user']['screen_name'].encode("utf-8"))
			tweet_text = str(tweets['statuses'][x]['text'].encode("utf-8"))
			tweet_array.append(str(tweet_user+"\r\n"+tweet_text))
		return tweet_array
	else:
		tweet_array.append("try another hashtag")
		return tweet_array

tweets = get_tweets(hashtag)


def display_next(tweets,pressed):
    global index_counter
    if (pressed):
        index_counter = index_counter+1
        ugfx.clear(ugfx.WHITE)
        tweet_text = str(tweets[index_counter])
        ugfx.string(45,85,tweet_text,"Roboto_Black22",ugfx.BLACK)
        ugfx.flush()

def display_prev(tweets,pressed):
    global index_counter
    if (pressed):
        index_counter=index_counter-1
        ugfx.clear(ugfx.WHITE)
        tweet_text=str(tweets[index_counter])
        ugfx.string(45,85,tweet_text,"Robot_Black22",ugfx.BLACK)
        ugfx.flush()

def passout():
    exit()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, lambda pressed: display_next(tweets,pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: display_prev(tweets,pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: passout())

def main():
    display_next(tweets,0)
    while True:
        pass
main()