import badge
import ugfx
import time

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()
badge.vibrator_init()

ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "LED Rainbow","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

badge.leds_send_data(bytes([
    255, 0, 0, 0,
    0, 255, 0, 0,
    0, 0, 255, 0,
    0, 0, 0, 255,
    255, 255, 255, 0,
    255, 255, 0, 0,
]))

while True:
    badge.vibrator_activate(1)
    time.sleep(1)
