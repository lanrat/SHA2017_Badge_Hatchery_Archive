import badge, ugfx, machine, deepsleep, appglue, easydraw

ugfx.clear(ugfx.WHITE)
ugfx.flush(ugfx.LUT_FULL)
badge.eink_busy_wait()

easydraw.msg("Resetting battery voltage drop calibration")

badge.nvs_set_u16('splash', 'bat.volt.drop', 5200 - 4200)

easydraw.msg("Done!")
badge.eink_busy_wait()

machine.deepsleep(1000)