import ugfx
import badge
import machine
import easywifi
import virtualtimers
from umqtt.simple import MQTTClient

AMP_MODE = "tkkrlab/amp/mode"
AMP_VOLUME = "tkkrlab/amp/volume"
AMP_RAW = "tkkrlab/amp/raw"
AMP_POWER = (1 << 0) # Amp Power enable bit
AMP_TAPE1 = (1 << 1) # Tape 1 enable bit
AMP_TAPE2 = (1 << 2) # Tape 2 enable bit
AMP_AUX_CD = (1 << 3) # togles between Aux and Cd

amp_mode = AMP_POWER | AMP_AUX_CD
amp_volume = 20
update_state = True

ugfx.input_init()
easywifi.enable()

server = "10.42.1.2"
client_id = machine.unique_id()
client = MQTTClient(("AmpControl[%s]" % (client_id)), server)

def button_select(pushed):
  global amp_mode
  global update_state
  if pushed:
  	update_state = True
  	amp_mode ^= AMP_POWER

ugfx.input_attach(ugfx.BTN_SELECT, button_select)

badge.leds_init()
led_state = False
badge.leds_enable()
badge.leds_send_data(bytes([0x01] * (6 * 4)))

# task that updates the mode and volume
def update_amp_state():
  global update_state
  global led_state
  global client
  
  led_state = not led_state
  
  # debug with leds.
  if led_state:
    badge.enable_leds()
  else:
    badge.disable_leds()
  
  if update_state:
    update_state = False
    client.connect()
    client.publish(AMP_MODE, str(amp_mode))
    client.publish(AMP_VOLUME, str(amp_volume))
    client.disconnect()
  return 1000

virtualtimers.new(1000, update_amp_state)