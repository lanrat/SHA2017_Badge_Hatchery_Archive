import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(192,53,'/lib/kglbamtlogo/kglbamt_shabadge.png')
    return 0