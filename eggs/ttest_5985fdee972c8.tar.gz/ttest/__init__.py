import ugfx, wifi, badge, deepsleep
import urequests as requests
from time import sleep

def set_message(text):
  ugfx.clear(ugfx.BLACK)
  ugfx.clear(ugfx.WHITE)
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

def runfirst():
  set_message("Init")
  badge.init()
  ugfx.init()
  ugfx.input_init()
  set_message("Setting up inputs")
  ugfx.input_attach(ugfx.BTN_A, stop)
  ugfx.input_attach(ugfx.BTN_B, vendmate)
  ugfx.input_attach(ugfx.JOY_UP, forward)
  ugfx.input_attach(ugfx.JOY_DOWN, backward)
  ugfx.input_attach(ugfx.BTN_SELECT, byebye)
  ugfx.input_attach(ugfx.BTN_START, byebye)
  # Make sure WiFi is connected
  wifi.ssid = "NW-challenge"
  wifi.password = "Northwave Treintjes"
  wifi.init()
  while not wifi.sta_if.isconnected():
      sleep(1.0)
      set_message("Waiting for NW Wifi connection")
      pass
  set_message("Connected to NW Wifi")
  set_message("Up: forward, Down: backward")

def forward(pressed):
  set_message("Forward pressed")
  data=None
  try:
    set_message("Telling train to go forward")
    url = "http://192.168.1.7/controller/process.php";
    parameters = {'uid': '1', 'id': '0', 'richting': 'forward', 'snelheid':'4'}
    data = requests.post(url, data=parameters)
    data.close()
    set_message("Up: forward, Down: backward")
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()


def stop(pressed):
  set_message("Forward pressed")
  data=None
  try:
    set_message("Telling train to go forward")
    url = "http://192.168.1.7/controller/process.php";
    parameters = {'uid': '1', 'id': '0', 'richting': 'forward', 'snelheid':'0'}
    data = requests.post(url, data=parameters)
    data.close()
    set_message("Up: forward, Down: backward")
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()


def backward(pressed):
  set_message("Backward pressed");
  data=None
  try:
    set_message("Telling train to go backward")
    url = "http://192.168.1.7/controller/process.php";
    parameters = {'uid': '1', 'id': '0', 'richting': 'reverse', 'snelheid':'4'}
    data = requests.post(url, data=parameters)
    data.close()
    set_message("Up: forward, Down: backward")
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()

def vendmate(pressed):
  set_message("Mate button pressed.")
  data = None
  try:
    set_message("You want Mate, mate?")
    url = "https://automate.nwlab.nl/api/vend";
    h = {"Authentication":"Basic YmFkZ2U6NjViY2Q0YWRhZjhiMzBjNjU3Y2QwYjUyZmFlMzE1NzY="}
    data = requests.get(url, headers=h)
    set_message("Request sent.")
    data.close()
    sleep(1)
    set_message("Get your free Club Mate at Torvalds, Northwave tent!")
  except Exception as e:
    set_message("Unexpected error: "+str(e))
    sleep(10)
    deepsleep.reboot()

def byebye(pressed):
  exit()

runfirst()
while True:
  sleep(0.1)