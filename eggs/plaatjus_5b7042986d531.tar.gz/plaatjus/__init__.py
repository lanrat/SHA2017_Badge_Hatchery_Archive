# Requires latest git pull submodule sync magic to actually work!

import badge, easywifi, ugfx, gc, easydraw, woezel

easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network","FAILURE")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(5000)

easydraw.msg("Checking for updates")
try:
    woezel.install('plaatjus')
    easydraw.msg("Updated! Rebooting now!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(1)
except:
    easydraw.msg("No update available. Starting app!")
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    import urequests as requests
    gc.collect()
    data=requests.get("https://revspace.nl/Special:Filepath/Hackerhoteltest.png")
    gc.collect()
    png_data = data.content
    data.close()
    gc.collect()
    width,height,bitdepth,colortype=badge.eink_png_info(png_data)
    gc.collect()
    badge.eink_png(0, 0, png_data)
    ugfx.flush()
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(524288)