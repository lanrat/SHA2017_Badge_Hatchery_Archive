import ugfx

ugfx.clear(ugfx.BLACK)
ugfx.string(120,50,"Press B after cleaning", "Roboto_BlackItalic18", ugfx.WHITE)
ugfx.flush()
for i in range(10):
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()

