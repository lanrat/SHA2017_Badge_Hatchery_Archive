### Author: Mattsi Jansky
### Heavily modified from Sam Delaney and Sebastius' Game of Life app.
### Description: ???
### Category: Games
### License: MIT
### Appname: GoL
### Built-in: no

import badge
import ugfx
import urandom
import deepsleep

class Position:
	
	def __init__(self, x, y):
		self.x = x
		self.y = y
		
	def add(self,x,y):
		return Position(self.x + x, self.y + y)

class Entity:
	
	def __init__(self, render, name, position):
		self.render = render
		self.name = name
		self.position = position

class Tile:
	
	def __init__(self, render):
		self.render = render
		self.entity = None
	
	def __str__(self):
		if(self.entity is not None):
			return self.entity.render
		else:
			return self.render
			
grid = [[Tile('.') for x in range(height)] for y in range(width)]
player = Entity('@','player',Position(1,1))
grid[1][1].entity = player

class Manipulator:
	
	def move(entity,position):
		grid[entity.position.x][entity.position.y].entity = None
		grid[position.x][position.y] = entity

class Input:

	def __init__(self):
		self.manipulator = Manipulator()
	
	def left(pressed):
		manipulator.move(player,player.position.add(-1,0))
		
def emj_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_RIGHT, reboot)
    ugfx.input_attach(ugfx.JOY_LEFT, reboot)
    ugfx.input_attach(ugfx.JOY_UP, reboot)
    ugfx.input_attach(ugfx.JOY_DOWN, reboot)
    ugfx.input_attach(ugfx.JOY_RIGHT, reboot)
    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    width = 36
    height = 11
    cell_width = 8
    cell_height = 12
    global grid
	global player

    def display():
        for x in range(0, width):
            for y in range(0, height):
                ugfx.text(x * cell_width,y * cell_height,str(grid[x][y]),ugfx.BLACK)
        badge.eink_busy_wait()
        ugfx.flush()

    def step():
        for x in range(width):
            for y in range(height):
                grid[x][y] = grid[x][y]

    while True:
        step()
        display()

def reboot(wut):
    deepsleep.reboot()

emj_test()