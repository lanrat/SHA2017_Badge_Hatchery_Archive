import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests

ugfx.clear(ugfx.BLACK)

# Set up starting up screen
ugfx.init()
ugfx.clear(ugfx.WHITE)

ugfx.string(10, 10, "Go to the Torvalds field for further instructions.", "Roboto_Regular12", 0)
ugfx.string(60, 10, "Checking location...", "Roboto_Regular12", 0)

ugfx.flush()

# Make sure WiFi is connected
wifi.ssid = "NW-challenge"
wifi.password = "Northwave Treintjes"
wifi.init()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

sleep(3)

ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "You have arrived! Enter the Northwave tent for further instructions.", "Roboto_Regular12", 0)
ugfx.flush()

sleep(4)

ugfx.flush(ugfx.LUT_FULL)
badge.eink_busy_wait()

machine.deepsleep(1)