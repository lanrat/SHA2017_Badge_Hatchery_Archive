# fork of sha_color

import badge
import ugfx
import appglue

def quit(pushed):
    if(pushed):
        print("go home")
        appglue.home()

brightness = 100

badge.init() 
ugfx.init()
badge.leds_init()
ugfx.input_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(170,50,"colorful","PermanentMarker22",ugfx.BLACK)
length = ugfx.get_string_width("colorful","PermanentMarker22")
ugfx.line(170, 72, 184 + length, 72, ugfx.BLACK)
ugfx.line(180 + length, 52, 180 + length, 70, ugfx.BLACK)
ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(20, 110, "SELECT: exit, START: off, A: low, B: high","Roboto_Regular12",ugfx.BLACK)
ugfx.string(255, 115, "rev. 18","Roboto_Regular12",ugfx.BLACK)
try:
    badge.eink_png(0,40,'/lib/sha2017_colors/shrug.png')
except:
    ugfx.string(100,50,"Error loading shrug.png"),ugfx.BLACK

ugfx.flush()
#ugfx.input_attach(ugfx.BTN_SELECT, quit)
ugfx.input_attach(ugfx.BTN_START, quit)
#ugfx.input_attach(ugfx.BTN_A, low)
#ugfx.input_attach(ugfx.BTN_B, high)

badge.leds_enable()

values = bytes([50, 0, 0, 0])
values += bytes([0, 50, 0, 0])
values += bytes([0, 0, 50, 0])
values += bytes([50, 50, 0, 0])
values += bytes([0, 50, 50, 0])
values += bytes([50, 0, 50, 0])

badge.leds_send_data(values)

