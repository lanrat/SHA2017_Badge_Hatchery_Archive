import utime, badge, binascii

counter = 0
direction = True
serviceEnabled = 0

# This function gets called by the home application at boot
def setup():
    global serviceEnabled
    serviceEnabled = badge.nvs_get_u8('krider', 'brightness', 0)
    if (serviceEnabled<1):
        print("[KNIGHTRIDER] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def write(values):
    badge.leds_send_data(bytes(values),24)

def leds(counter, direction):
    led = round(counter/100)
    value = counter
    while value>100:
        value -= 100
    
    ledA = 10
    ledB = 128
    
    output = []
    for i in range(0,24):
        output.append(0)
                
    if direction:
        output[led*4+1] = ledB
        output[led*4+1-4] = ledA
    else:
        output[led*4+1] = ledA
        output[led*4+1-4] = ledB
    return output

def loop():
    global serviceEnabled
    global direction
    global counter
    
    if (serviceEnabled>0): 
        if direction:
            counter += 1
        else:
            counter -= 1
        if counter>500:
            counter = 500
        if counter<0:
            counter = 0
        if counter==500 or counter==0:
            direction = not direction
        output = leds(counter, direction)
        write(output)
        return badge.nvs_get_u8('krider', 'delay', 100)
    return 0

def draw(x,y):
    # Not drawing anything
    return 0
