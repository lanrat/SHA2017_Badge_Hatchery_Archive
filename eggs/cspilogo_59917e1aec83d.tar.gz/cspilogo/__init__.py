import badge, easydraw, time, appglue

easydraw.msg("","CSPi Logo", True)

enabled = badge.nvs_get_u8("cspilogo","enable", 0)
if enabled:
    enabled = 0
    easydraw.msg("CSPi Logo disabled!")
else:
    enabled = 1
    easydraw.msg("CSPi Logo enabled!")
    easydraw.msg("Go back to the splash and wait...")
enabled = badge.nvs_set_u8("cspilogo","enable", enabled)

time.sleep(5)
appglue.home()