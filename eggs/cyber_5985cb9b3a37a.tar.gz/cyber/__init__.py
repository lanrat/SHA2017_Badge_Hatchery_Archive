import ugfx, badge, sys

def cyber():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    try:
        # Proudly stolen from https://cyber.equipment/cyber_plain.png
        badge.eink_png(0, 0, '/lib/cyber/cyber_plain.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    
def quit(pressed):
    if(pressed):
        sys.exit()
    ugfx.flush()

def program_main():
    print("--- Cyber Cyber v4 ---")
    ugfx.init()
    ugfx.input_init()
    ugfx.set_lut(ugfx.LUT_FULL)
    ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    cyber()

# Start main application
program_main()