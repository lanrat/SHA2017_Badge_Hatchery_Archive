# service.py

import badge
import ugfx
import network
import time
import urequests as requests

def setup():
    pass


def draw(x,y):

	try:
		#wifi
		wifi_ssid = badge.nvs_get_str("badge", "wifi.ssid", "SHA2017-insecure")
		wifi_psk = badge.nvs_get_str("badge", "wifi.password", "")
		#ugfx.string(0, 0, "connecting to " + wifi_ssid + "...", "pixelade13", ugfx.BLACK)
		#ugfx.flush()
		netif = network.WLAN(network.STA_IF)
		netif.active(True)
		if wifi_psk == "":
		  netif.connect(wifi_ssid)
		else:
		  netif.connect(wifi_ssid, wifi_psk)
		netif.isconnected()



		#########################

		r = requests.get("http://151.216.10.52/cgi-bin/stream.sh")
		ugfx.string(100, 50, r.text, "pixelade13", ugfx.BLACK)	
		ugfx.flush()
		r.close()

		badge.eink_png(0,50,'/lib/bofh/bofh.png')
	except:
		ugfx.string(0, 50, "ERROR... ", "Roboto_Regular12", ugfx.BLACK)
	return 0
