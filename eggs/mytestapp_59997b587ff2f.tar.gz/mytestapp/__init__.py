import time
import ugfx
ugfx.clear(ugfx.WHITE)
ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.flush()
while 1:
  for i in range(0, 102):
    ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
    time.sleep(0.05)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    
  for i in range(128, 0):
    ugfx.string(20, i, "Test", "Roboto_BlackItalic24", ugfx.BLACK)
    time.sleep(0.05)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)