import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(150, 50, "Bulwark", "PermanentMarker36", ugfx.BLACK)