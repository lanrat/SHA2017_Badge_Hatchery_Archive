#hi there, it looks like u r one of the smart ppl here. got locked out? dont want to visit us to unlock it? try rebooting it and then start spamming start. it should bypass the service
#^^^^^
#^^^^
#^^^
#^^
#^
import ugfx, badge, appglue

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.string(20, 40, "Redirecting to home...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

badge.init()
appglue.start_app("")