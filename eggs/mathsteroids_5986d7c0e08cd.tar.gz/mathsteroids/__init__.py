import ugfx

ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()

ugfx.draw_line(0,0,10,10,ugfx.WHITE)

ugfx.flush()