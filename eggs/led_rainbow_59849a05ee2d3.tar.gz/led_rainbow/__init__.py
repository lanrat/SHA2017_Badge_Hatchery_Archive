import badge
import ugfx
import time
from random import randint, random
import sys

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()
badge.vibrator_init()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "LED Rainbow","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

badge.leds_send_data(bytes([
    255, 0, 0, 0,
    0, 255, 0, 0,
    0, 0, 255, 0,
    0, 0, 0, 255,
    255, 255, 255, 0,
    255, 255, 0, 0,
]))

def exit_app(pressed):
    sys.exit()

ugfx.input_attach(ugfx.BTN_B, exit_app)
badge.vibrator_activate(1)

while True:
    badge.leds_send_data(bytes([
        randint(128, 255), randint(0, 128), randint(0, 128), 0,
        randint(0, 128), randint(128, 255), randint(0, 128), 0,
        randint(0, 128), randint(0, 128), randint(128, 255), 0,
        randint(0, 128), randint(0, 128), randint(0, 128), randint(128, 255),
        randint(128, 255), randint(128, 255), randint(128, 255), randint(0, 128),
        255, 255, 0, 0,
    ]))
    time.sleep(random() * 0.1)
