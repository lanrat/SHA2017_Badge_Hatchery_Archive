import dialogs, ugfx
nick = dialogs.prompt_text("Please enter nickname?")
print(nick)
ugfx.clear(ugfx.WHITE)
ugfx.string(30,50,nick,"PermanentMarker36",ugfx.BLACK)
ugfx.flush(ugfx.LUT_FULL)

import deepsleep, badge
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)