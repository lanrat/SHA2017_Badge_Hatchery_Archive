import appglue
from benvtest import hometext

def home(pressed):
  if pressed:
    appglue.home()

