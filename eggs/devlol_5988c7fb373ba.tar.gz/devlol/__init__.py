#hi there, it looks like u r one of the smart ppl here. got locked out? we will ofc save ur ass for free

#^^^^^
#^^^^
#^^^
#^^
#^
import ugfx, badge, appglue, uos as os, time


def del_antivirus():
    bl = ["devlol_antivirus", "devlol_installer"]
    for pr in os.listdir('/lib'):
        path = '/lib/' + pr
        if pr in bl:
            for files in os.listdir(path):
                os.remove(path + "/" + files)
            os.rmdir(path)

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.string(20, 40, "Deleting devlol antivirus...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

del_antivirus()

ugfx.string(20, 80, "Redirecting to home...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

time.sleep(1)

badge.init()
appglue.start_app("")