import badge, ugfx, time
import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1

def check_if_locked(_i):
  unlock_check_url = "http://project1.online/sha2017-plsdonthackme/show.php?id=80&type=down"
  unlock_check = requests.get(unlock_check_url)
  if unlock_check.content == "2":
    global _continue
    _continue = 0

def setup():
    ugfx.init()
    badge.init()
    ugfx.flush()

def loop():
    badge.leds_enable()
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
      
    global _continue
    while (_continue):
        time.sleep(10)  
        check_if_locked()
                
    badge.leds_disable()
    leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
    badge.leds_send_data(leds_array)    
    badge.leds_enable()
    return 15

def draw(x,y=2):
  ugfx.clear(ugfx.BLACK)
  ugfx.display_image(0, 0, '/lib/Internship/r.png')
  ugfx.string(12, 12, "YOUR BADGE HAS BEEN LOCKED.", "Roboto_Regular12", ugfx.WHITE)
  ugfx.string(12, 37, "To unlock your badge find us at ???", "Roboto_Regular12", ugfx.WHITE)
  ugfx.string(12, 62, "Your unique key for decryption is ????????", "Roboto_Regular12", ugfx.WHITE)