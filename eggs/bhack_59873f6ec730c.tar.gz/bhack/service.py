import ugfx
import badge
nick = badge.nvs_get_str('owner', 'name')

def draw(y, sleep=2):
  ugfx.clear(ugfx.WHITE)
  ugfx.area(10,10,32,32,ugfx.BLACK)
  ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
  ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)
  ugfx.string(16,45,nick,"Roboto_Black22",ugfx.BLACK)

  ugfx.flush()
  return [1000,0]