import time, appglue

time.sleep(5)
appglue.home()