import badge, ugfx, uos

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)


ugfx.string(150, 5, "Pick a file", "Roboto_BlackItalic12", ugfx.BLACK)
ugfx.flush()
options = ugfx.List(0,0,int(ugfx.width()/2),ugfx.height())

options.add_item("<- Go Dir Up")
files=uos.listdir()

#for file in files:
#	option.add_item("%s" % file)

options.selected_index(0)
#ugfx.list()


ugfx.flush()
sleep(3)
