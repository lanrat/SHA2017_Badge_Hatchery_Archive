import badge 
import ugfx
badge.init()
ugfx.init()
x = 4
y = 64

def up(yc):
 yc=yc+5
 ugfx.clear(ugfx.WHITE)
 ugfx.string(x,y,"up","PermanentMarker22",ugfx.BLACK)
 ugfx.flush()

ugfx.string(x,y,"test","PermanentMarker22",ugfx.BLACK)
ugfx.flush()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP,up(y))
while True:
 pass