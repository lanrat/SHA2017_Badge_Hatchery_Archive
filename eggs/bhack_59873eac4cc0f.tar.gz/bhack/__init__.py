import time, appglue, ugfx

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.area(10,10,32,32,ugfx.WHITE)
ugfx.string(16,15,"B","Roboto_Black22",ugfx.BLACK)
ugfx.string(42,15,"hack","Roboto_Black22",ugfx.WHITE)
ugfx.string(16,45 , "bhack enabled")

time.sleep(50)
appglue.home()