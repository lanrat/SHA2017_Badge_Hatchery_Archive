import badge, ugfx, appglue, wifi, time, woezel
# TODO:
# autoupdate on start with woezel

name = badge.nvs_get_str('owner', 'name', 'n00b')
log_messages = []
fonts = [
  'Roboto_Regular18',
  'PermanentMarker36',
  'pixelade13'
]
logo_width = 77
logo_path = '/lib/hackeriet/hackeriet-77.png'
is_updating = False

# Add 20 width to hide list scrollbars
log_ui_list = ugfx.List(logo_width, 0, ugfx.width() - logo_width + 20, ugfx.height())
log_ui_list.enabled(False)

def log(text):
  global log_messages
  log_messages.insert(0, text)

  # Keep log short
  if len(log_messages) > 10:
  	log_messages.pop()

  # Write all log lines, then flush buffer
  while (log_ui_list.count() > 0):
    log_ui_list.remove_item(0)
  for i, line in enumerate(log_messages):
    log_ui_list.add_item(line)
  ugfx.flush()

def clear_ghosting():
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()

def start_self_update():
  global is_updating
  is_updating = True
  log('+ Starting self update')
  attempts = 0
  attempts_max = 5
  wifi.init()
  while not wifi.sta_if.isconnected():
    if attempts > attempts_max:
      log('+ Giving up wifi... Skipping update!')
      is_updating = False
      return
    log('+ Waiting for wifi... (%d/%d)' % (attempts, attempts_max))
    time.sleep(1)
    pass
  # Attempt to install new version and restart the app if it succeeds
  try:
    woezel.install('hackeriet')
    appglue.start_app('hackeriet')
  except:
    log('+ woezel.install failed. May already be up to date.')
  is_updating = False

def exit_app():
  log('+ Exiting app...')
  appglue.home()

def program_main():
  ugfx.init()
  ugfx.clear(ugfx.WHITE)
  
  try:
    badge.eink_png(0, 0, logo_path)
  except:
    log('+ Failed to load graphics')
  
  # Name tag
  ugfx.string(ugfx.width() - ugfx.get_string_width(name, fonts[1]), ugfx.height() - 36, name, fonts[1], ugfx.BLACK)
  
  # Button info
  ugfx.string(0, ugfx.height() - 13, '[FLASH to update] [B to exit]', fonts[2], ugfx.BLACK)
  ugfx.flush()
  
  ugfx.input_init()
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit_app())
  ugfx.input_attach(ugfx.BTN_FLASH, lambda pressed: start_self_update())
  
  iterations = 0
  while True:
    log('last loop on iteration %d' % (iterations))
    time.sleep(1)
    iterations += 1

program_main()