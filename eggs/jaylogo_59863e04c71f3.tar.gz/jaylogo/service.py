import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(0,25,'/lib/Jaylogo/jay2k1.png')
    return 0