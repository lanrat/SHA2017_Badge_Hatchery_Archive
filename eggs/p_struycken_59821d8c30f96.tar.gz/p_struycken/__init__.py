### Author: Frans Faase
### Category: Art animation
### License: MIT
### Appname: P.Struycken

import ugfx
import urandom
import time
import appglue
import badge

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
font = "Roboto_Regular12"
ugfx.string(5,5,"Animation based on Komputerstrukturen 1969 by",font,ugfx.BLACK)
ugfx.string(5,20,"Peter Struycken, Dutch artist most famous for",font,ugfx.BLACK)
ugfx.string(5,35,"designing the Queen Beatrix stamp. He was one",font,ugfx.BLACK)
ugfx.string(5,50,"of the first artist using computer programs.",font,ugfx.BLACK)
ugfx.string(50,100,"[Start: start][LEFT,RIGHT:switch]",font,ugfx.BLACK)
ugfx.flush()

grid = [[0] * 12 for _ in range(25)]
ks1 = [[4,0,0,1,1,3],[4,0,1,1,3,3],[5,1,1,1,3,3,3,7],[4,1,3,3,7,7],[3,3,3,7,7],[2,3,7,15],[3,3,7,7,7,7,7,15,15,15,15]]
ks1a = [[4,0,0,1,1,3],[4,0,0,1,1,1,3,3,3,3],[6,1,1,1,1,3,3,3,3,7],[5,1,3,3,3,7,7,7],[3,3,3,3,7,7,15],[3,3,7,7,7,7,15,15,15]]
ks2 = [[25,1,2,4,8]]
ks3 = [[25,6,12,10]]
ks4 = [[5,1,2,2,2,2,2,2,2,2,8,7,11],[5,1,1,2,2,2,2,2,8,7,7,11,11],[5,1,2,8,8,7,7,7,7,11,11,11,11],[5,1,8,3,9,7,7,7,7,7,11,11,11,11,11],[5,8,3,3,3,9,9,9,7,7,7,11,11,11]]
ks4a = [[5,1,1,1,1,1,1,1,1,8,8,4,13,11],[5,1,1,1,1,4,4,8,8,13,13,11,11,11],[5,1,1,4,4,8,13,13,13,11,11,11,11],[5,4,8,12,13,13,13,13,13,13,13,11,11,11,11],[1,8,9,12,13,13,13,13,13,13,11,11,11,11,11],[4,4,12,12,12,9,9,9,13,13,13,11,11,11]]
kss = [ks1,ks1a,ks2,ks3,ks4,ks4a]
curks = 1
arrow_pressed = False

def keypress(keyname):
    ugfx.area(0,0,10,10,ugfx.WHITE)
    ugfx.string(0,0,keyname,"Roboto_Regular12",ugfx.BLACK)

def animate(pressed):
    if (pressed==False):
        return
    global grid
    global kss
    global curks
    global arrow_pressed
    arrow_pressed = False
    def setgrid(x,y,val):
        if(val):
            ugfx.area(268-x*5, 2+y*5,5,5,ugfx.BLACK)
        else:
            ugfx.area(268-x*5, 2+y*5,5,5,ugfx.WHITE)
    def setgrid4(x,y,val):
        setgrid(x,y,val&1==1)
        setgrid(x+1,y,val&2==2)
        setgrid(x+1,y+1,val&4==4)
        setgrid(x,y+1,val&8==8)
    def value(x,ks):
        i = 0
        for i in range(len(ks)):
            if x < ks[i][0]:
                return ks[i][1 + urandom.getrandbits(30) % (len(ks[i])-1)]
            x -= ks[i][0]
        return 0

    while True:     
        for x in range(25):
            for y in range(12):
                grid[x][y] = value(x,kss[curks])
        ugfx.clear(ugfx.WHITE)
        keypress("S")
        for x in range(25):
            for y in range(12):
                setgrid4(2*x,2*y,grid[x][y])
        ugfx.flush()
        time.sleep_ms(300)
        while (arrow_pressed == False):
            x = urandom.getrandbits(30) % 25
            y = urandom.getrandbits(30) % 12
            newval = value(x,kss[curks])
            if grid[x][y]!=newval:
                grid[x][y] = newval 
                setgrid4(2*x,2*y,newval)
                ugfx.flush()
                time.sleep_ms(300)

def right(pressed):
    if (pressed==False):
        return
    keypress("R")
    global curks
    global arrow_pressed
    curks = (curks+1) % len(kss)
    arrow_pressed = True

def left(pressed):
    if (pressed==False):
        return
    keypress("L")
    global curks
    global arrow_pressed
    curks = (curks+len(kss)-1) % len(kss)
    arrow_pressed = True

def exitapp(pressed):
    if (pressed==False):
        return
    keypress("E")
    time.sleep(2)
    appglue.home()
    
ugfx.input_attach(ugfx.BTN_A, animate)
ugfx.input_attach(ugfx.JOY_RIGHT, right)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.BTN_START, exitapp)

#time.sleep_ms(200)
#animate()
while True:
#    curks = (curks+1) % len(kss)
    #badge.eink_busy_wait()
    time.sleep_ms(200)
#    animate()