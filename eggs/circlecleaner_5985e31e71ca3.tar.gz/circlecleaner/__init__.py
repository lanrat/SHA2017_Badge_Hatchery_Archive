import badge
import ugfx
import time
import random

W = 280
H = 130
a = 100
b = 25
Nm = 3
N0 = Nm
NM = 7

MAIN = 1
PLAY = 2
WON = 3
QUIT = 4


def init_draw():
 ugfx.clear(ugfx.WHITE)

 for n in range(0, N):
  for k in range(0, N):
   redraw_cell(n, k)

 ugfx.flush()

def up(pressed):
 global x, y, N
 if not pressed: return
 if state == MAIN:
  if N < NM: N = N + 1
 elif state == PLAY:
  redraw_cell(x, y)
  if y > 0: y = y - 1

def down(pressed):
 global x, y, N
 if not pressed: return
 if state == MAIN:
  if N > Nm: N = N - 1
 elif state == PLAY:
  redraw_cell(x, y)
  if y < N - 1: y = y + 1

def left(pressed):
 global x, y
 if not pressed: return
 redraw_cell(x, y)
 if x > 0: x = x - 1

def right(pressed):
 global x, y
 if not pressed: return
 redraw_cell(x, y)
 if x < N - 1: x = x + 1

def click(pressed):
 global x, y, state
 if not pressed: return
 if state == MAIN:
  state = PLAY
 elif state == PLAY:
  cross(x, y)
 elif state == WON:
  state = MAIN

def quit(pressed):
 global state
 if not pressed: return
 if state == PLAY:
  state = MAIN
 elif state == MAIN:
  state = QUIT

def cross(x, y, redraw = True): 
 cells[x][y] = 1 - cells[x][y]
 if redraw: redraw_cell(x, y)
 
 if x < N - 1:
  cells[x + 1][y] = 1 - cells[x + 1][y]
  if redraw: redraw_cell(x + 1, y)
 
 if x > 0:
  cells[x - 1][y] = 1 - cells[x - 1][y]
  if redraw: redraw_cell(x - 1, y)
 
 if y < N - 1:
  cells[x][y + 1] = 1 - cells[x][y + 1]
  if redraw: redraw_cell(x , y + 1)
 
 if y > 0:
  cells[x][y - 1] = 1 - cells[x][y - 1]
  if redraw: redraw_cell(x , y - 1)

def redraw_cell(x, y, color = None):
 r = R if color is None else int(R / 2)
 if (color is not None and color) or (color is None and cells[x][y]):
  ugfx.fill_circle(L * x + a, L * y + b, r, ugfx.BLACK)
 else:
  ugfx.fill_circle(L * x + a, L * y + b, r, ugfx.WHITE)
  ugfx.circle(L * x + a, L * y + b, r, ugfx.BLACK)
 ugfx.flush()

def check():
 global state
 won = True
 for n in range(0, N):
  for k in range(0, N):
    if cells[n][k]:
     won = False
     break
  
 if won:
  state = WON
  ugfx.clear(ugfx.WHITE)
  ugfx.string(50, 30, "Perfect!!", "PermanentMarker36", ugfx.BLACK)
  ugfx.flush()

def newGame():
 global x, y, cells, state, N, R, L
 
 # init array
 cells = [[0]*N for i in range(N)]
 
 # random initial values
 for i in range(0, 20):
  cross(random.randint(0, N-1), random.randint(0, N-1), False)
  
 # curson in the center
 x = 1
 y = 1
 
 # circles distance and radius
 L = int((W - 2*a) / (N - 1))
 R = int(L / 3)

 # initiial draw
 init_draw()

 # blink with the current dot
 while state == PLAY:
  redraw_cell(x, y, 1)
  time.sleep(0.1)
  redraw_cell(x, y, 0)
  time.sleep(0.1)
  check()

def welcome():
 global N
 ugfx.clear(ugfx.WHITE)
 ugfx.string(10,  10, "Circle Cleaner", "PermanentMarker36", ugfx.BLACK)
 ugfx.string(110, 50, "Field size is " + str(N), "Roboto_Regular12", ugfx.BLACK)
 ugfx.string(35,  70, "A: start, Up/Down: change field size, B: quit", "Roboto_Regular12", ugfx.BLACK)
 ugfx.string(10,   90, "During the game: Up/Down/Right/Left to navigate", "Roboto_Regular12", ugfx.BLACK)
 ugfx.string(35,  110, "During the game: A to click and B to abort", "Roboto_Regular12", ugfx.BLACK)
 ugfx.flush()


# init hardware
badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

# attach button handlers
ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)
ugfx.input_attach(ugfx.JOY_RIGHT, right)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.BTN_A, click)
ugfx.input_attach(ugfx.BTN_B, quit)

N = N0
state = MAIN

while state != QUIT:
 if state == MAIN:
  welcome()
 if state == PLAY:
  newGame()
 print(state)

