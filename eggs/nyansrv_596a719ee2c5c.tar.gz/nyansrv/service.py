# Nyancat as a service
# Renze Nicolai 2017

import utime, badge, binascii

nyanCnt = 0
nyanLeds = []
nyanEnabled = False

def hex_to_grbw_list(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    w = 0
    while (r>0) and (g>0) and (b>0):
        r = r - 1
        g = g - 1
        b = b - 1
        w = w + 1
    return [g,r,b,w]

white = hex_to_grbw_list("ffffff")
yellow = hex_to_grbw_list("fffc0b")
green = hex_to_grbw_list("5bff0b")
orange = hex_to_grbw_list("ffb70b")
red = hex_to_grbw_list("ff0b50")
blue = hex_to_grbw_list("330bff")

colorList = [white, yellow, green, orange, red, blue]

# This function gets called by the home application at boot
def setup():
    global nyanEnabled
    nyanEnabledString = badge.nvs_get_str('nyansrv', 'state', '0')
    if (nyanEnabledString=='1'):
        nyanEnabled = True
    else:
        print("Nyancat: Disabled! Please enable in the app!")
    if (nyanEnabled):
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            badge.leds_enable()
            badge.leds_set_state(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]))
            global nyanLeds
            ledValue = [0,0,0,0]
            for i in range(0,6):
                nyanLeds.append(ledValue)
            print("Nyancat: Leds enabled!")
        else:
            badge.leds_disable()
            print("Nyancat: battery low...")
            return False # Do not prevent sleep

def loop(sleepCnt):
    global nyanEnabled
    if (nyanEnabled):
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            print("Nyancat: Loop!")
            global nyanCnt
            global colorList
            nyanCnt = nyanCnt + 1
            if nyanCnt >= len(colorList):
                nyanCnt = 0
            
            ledValue = colorList[nyanCnt]
                
            for i in range(0,5):
            nyanLeds[i] = nyanLeds[i+1]
            nyanLeds[5] = ledValue
            output = []
            for i in range(0,6):
                output = output + nyanLeds[i]
            badge.leds_set_state(bytes(output))
            return True # Prevent sleep
        else:
            badge.leds_disable()
            print("Nyancat: battery low...")
            return False # Do not prevent sleep
    return False
