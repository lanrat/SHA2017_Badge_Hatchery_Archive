import badge
import ugfx
import dialogs
import urequests as requests

api_key = badge.nvs_get_str("engel", "key", "")
if not api_key:
    api_key = dialogs.prompt_text("Your engelsystem api key")

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()


ugfx.string(10, 10, api_key, "Roboto_Regular12", ugfx.BLACK)

ugfx.flush()

ugfx.input_attach(ugfx.BTN_A, lambda pressed: print("pressed"))
