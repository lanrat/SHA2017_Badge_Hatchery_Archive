from badg_e_book_alpha import badgebook
badgebook.read('/lib/alice_in_wonderland/19033.txt')