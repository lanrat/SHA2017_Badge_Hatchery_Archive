import ugfx, wifi
import json
from time import *
import urequests as requests

ugfx.init()
# Make sure WiFi is connected
wifi.init()
#wait for wifi msg
ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
#Clean Display
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
#Fetch json with btc currency
data = requests.get('https://blockchain.info/es/ticker?')
binary = data.content
output = json.loads(binary)
#Nice clean screen
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
#Paint btc price
ugfx.string_box(0,10,296,26, "BTC Price(15m)", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(0,45,296,38, str(output['EUR']['15m']), "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(0,94,296,26, "EUR", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.flush()