import badge
import ugfx
from umqtt.simple import MQTTClient
import binascii
import hashlib
import machine

'''
Service construction:
- check for message on MQTT every serviceTime
- when message received vibrate / blink leds / get attention and show message on main screen until acked by user
- user can ack by pressing konami code
- ACK is sent back to sender

BenV:
>>> machine.unique_id()
b'$\n\xc4\x12\xdd\xcc
-> binascii.hexlify(hashlib.sha256(machine.unique_id()).digest())[0:4].decode()
-> 6068

Lotjuh:
>>> machine.unique_id()
b'$\n\xc4\x12\xe3\x88'
-> binascii.hexlify(hashlib.sha256(b'$\n\xc4\x12\xe3\x88').digest())[0:4].decode()
-> 71eb

'''

def setup():
    global serviceEnabled
    global serviceMessage
    global serviceTime
    global serviceID
    global serviceFont

    ugfx.init()
    badge.init()
    ugfx.input_init()

    serviceID = binascii.hexlify(hashlib.sha256(machine.unique_id()).digest())[0:4].decode()
    serviceFont = badge.nvs_get_str('junepager', 'font', 'Roboto_Regular12')
    serviceMessage = None
    serviceEnabled = badge.nvs_get_u8('junepager', 'service', 1)
    serviceTime = badge.nvs_get_u8('junepager', 'time', 300)

    if (serviceEnabled<1) or len(serviceID) < 8:
        print("[JuNePager] Disabled! Please enable in the app!")
        return
    print("[JuNePager] Enabled! Checking ID " + serviceID + " every " + str(serviceTime) + " seconds.")

def loop():
    global serviceTime
    global serviceEnabled
    global serviceMessage
    if not serviceEnabled:
        return [9999999, 0]
    # Check for messages
    # TODO
    return serviceTime*1000
    if newMessage:
        showMessage(newMessage)
        ackMessage(newMessage)
    return serviceTime*1000

def ackMessage(msg):
     # __init__(self, client_id, server, port=0, user=None, password=None, keepalive=0, ssl=False, ssl_params={}):
    # ID -> machine.unique_id()
    c = MQTTClient("pixelSnake", "mqtt.sha2017.org", clean_session=False)
     # c.publish(self, topic, msg, retain=False, qos=0):
    c.publish("python {} playing as {} joined the arena".format(self.name, self.color))
    c.disconnect()

def showMessage(msg):
    # ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    badge.leds_init()
    badge.vibrator_init()
    badge.vibrator_activate(7)
    ugfx.string_box(0, y - 72, 250, 72, serviceMessage, serviceFont, ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()

def draw(y, sleep = 2):
    # t = easyrtc.string()
    global serviceEnabled
    global serviceMessage
    global serviceFont
    global serviceTime
    if (serviceEnabled<1):
        print("[JuNePager] Disabled. Jammer.")
        return [999999999, 0]
    ugfx.string_box(0,0,280,20, self.serviceID ,"Roboto_Regular12",ugfx.BLACK,ugfx.justifyRight)
    ugfx.flush()

    if serviceMessage == None:
        return [serviceTime*1000, 0]

    print("[JuNePager] " + " Y: " + str(y) + " Text: " + serviceMessage)
    # Align center
    ugfx.string_box(0, y - 72, 250, 72, serviceMessage, serviceFont, ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()
    return [serviceTime*1000, 36]

