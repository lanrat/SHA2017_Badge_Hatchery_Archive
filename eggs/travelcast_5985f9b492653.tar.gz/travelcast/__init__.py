import ugfx, gc, wifi, badge, deepsleep, utime, appglue, sys
from time import *
import urequests as requests

CHECKUP_INTERVAL = 10
next_checkup = utime.time() + CHECKUP_INTERVAL
message_displayed_flag = False

def home():
    """return to launcher"""
    badge.eink_busy_wait()
    appglue.home()

ugfx.init()

# set cancel button
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_START, lambda pressed: home())

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
ugfx.string(15, 70, "Press START to exit", "Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass


# loading screen
ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "Getting latest updates from the Travellers Village ...", "Roboto_Regular12", 0)
ugfx.string(15, 70, "Press START to exit", "Roboto_Regular12", 0)
ugfx.flush()

# fetching data
data = []
next_message_timestamp = sys.maxsize

while True:

    # displaying data if next message timestamp is now or in the past and messages are saved
    if next_message_timestamp <= utime.time() and not len(data) <= 0:
        # find youngest message
        youngest_message = (0, sys.maxsize)
        for ind, message in data:
            if message["showAt"] < youngest_message[1]:
                youngest_message = (ind, message["showAt"])

        message_to_display = data[youngest_message[0]]

        # display youngest message
        ugfx.clear()
        ugfx.string(15, 5, message_to_display["title"], "Roboto_Regular22", 0)
        ugfx.string(15, 30, message_to_display["content"], "Roboto_Regular22", 0)
        ugfx.string(15, 70, "Press START to exit", "Roboto_Regular12", 0)
        ugfx.flush(ugfx.LUT_FULL)

        message_displayed_flag = True

        # remove youngest message
        del data[youngest_message[0]]

    elif message_displayed_flag:
        # display "no new messages" if no message is due
        ugfx.clear()
        ugfx.string(15, 5, "No new messages", "Roboto_Regular22", 0)
        ugfx.string(15, 70, "Press START to exit", "Roboto_Regular12", 0)
        ugfx.flush(ugfx.LUT_FULL)

    try:
        # get new messages
        url = "http://badge.jonasleitner.de"
        r = requests.get(url)
        gc.collect()
        newdata = r.json()
        r.close()

    except:
        ugfx.clear(ugfx.WHITE)
        ugfx.string(10, 10, "Failed to retrieve message!", "Roboto_Regular12", 0)
        ugfx.flush()
        utime.sleep(5)
        appglue.home()

    if newdata["messages"]:
        # only save data if it is not empty, else keep old data
        data = newdata["messages"]
        # find and save next message timestamp
        for message in data:
            if message["showAt"] < next_message_timestamp:
                next_message_timestamp = message["showAt"]

    # calculate sleep time
    sleep_until = utime.time() + CHECKUP_INTERVAL
    sleep_time = CHECKUP_INTERVAL

    if next_message_timestamp < sleep_until:
        sleep_time = max(next_message_timestamp - utime.time(), 1)

    sleep(sleep_time)
    #badge.eink_busy_wait()
    #deepsleep.start_sleeping(5000)