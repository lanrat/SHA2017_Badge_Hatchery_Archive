import badge
from show_leds import show_leds

def loop():
    if badge.nvs_get_u8("charge_leds", "enable", 0):
        return 999999
    uvol = badge.usb_volt_sense()
    if uvol <= 4500:
        return 30000
    return show_leds()


def setup():
    if badge.nvs_get_u8("charge_leds", "enable", 0):
        badge.leds_init()
        badge.power_init()