import badge

blink = True

def show_leds():
    global blink
    bvol = badge.battery_volt_sense()
    crg = badge.battery_charge_status()
    #bvolmin = badge.nvs_get_u16("splash", "battery.volt.min", 3800)
    #bvolmax = badge.nvs_get_u16("splash", "battery.volt.max", 4300)
    bvolmin = 3800
    bvolmax = 4300
    bvolstg = (bvolmax - bvolmin)/6
    maxbrightness=32
    if not crg:
        led_status = bytes([maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0])
        rv = 30000
    else:
        led_status = []
        for i in range(0,6):
            pos = bvol - bvolmin - bvolstg * i
            if pos <= 0:
                add_status = [0, maxbrightness,0,0]
            elif pos >= bvolstg:
                add_status = [maxbrightness, 0,0,0]
            else:
                lb = maxbrightness if blink else 0
                crglvl = round(lb/bvolstg*pos)
                add_status = [crglvl, lb-crglvl,0,0]
                blink = not blink
            led_status = add_status + led_status
        led_status = bytes(led_status)
        rv = 100
    badge.leds_send_data(led_status, 24)    
    return rv