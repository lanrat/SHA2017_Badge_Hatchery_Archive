import ugfx, badge
import appglue

def action_home(pressed):
    if (pressed):
        appglue.start_app("")
        
        
def store():
    global serviceMode, brightness
    badge.nvs_set_u8('stijlrijder', 'serviceMode', serviceMode)
    badge.nvs_set_u8('stijlrijder', 'brightness', brightness)

    
def load():
    global serviceMode, brightness
    serviceMode = badge.nvs_get_u8('stijlrijder', 'serviceMode', 0)
    brightness  = badge.nvs_get_u8('stijlrijder', 'brightness', 50)
    
def action_mode_up(pressed):
    if (pressed):
        global serviceMode
        serviceMode = serviceMode + 1
        if (serviceMode>5):
            serviceMode = 5
        else:
          store()
        draw()

def action_mode_down(pressed):
    if (pressed):
        global serviceMode
        serviceMode = serviceMode - 1
        if (serviceMode<0):
            serviceMode = 0
        else:
          store()
        draw()

def action_bri_less(pressed):
    if(pressed):
        global brightness
        brightness = max(0, brightness-5)
        store()
        draw()

def action_bri_more(pressed):
    if(pressed):
        global brightness
        brightness = min(100,brightness+5)
        store()
        draw()


def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Stijlrijder lights", "PermanentMarker22", ugfx.BLACK)
    global serviceMode,brightness
    if (serviceMode>0):
        mode = serviceMode
        if serviceMode==1:
            mode = "KARR"
        elif serviceMode==2:
            mode = "KITT"
        elif serviceMode==3:
            mode = "BLUE"
        elif serviceMode==4:
            mode = "PINK"
        else:
            mode = "WHITE"
        
        ugfx.string(0, 25, "Service is enabled ("+mode+") ("+brightness+")!", "Roboto_Regular12", ugfx.BLACK)
        ugfx.string(0, 38, "Press start to see it in action.", "Roboto_Regular12", ugfx.BLACK)
    else:
        ugfx.string(0, 25,  "Service is disabled!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0,   38+13*1, "UP:   Mode   +")
    ugfx.string(100, 38+13*1, "DOWN: Mode -", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0,   38+13*2, "LEFT: Bright -", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(100, 38+13*2, "RIGHT: Bright +", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*3, "START: Go to homescreen", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*4, "", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*5, "Warning: drains battery!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()

def program_main():  
    ugfx.init()
    ugfx.input_init()   
    ugfx.input_attach(ugfx.BTN_START, action_home)
    ugfx.input_attach(ugfx.JOY_UP, action_mode_up)
    ugfx.input_attach(ugfx.JOY_DOWN, action_mode_down)
    load()
    draw()
          
# Start main application
program_main()