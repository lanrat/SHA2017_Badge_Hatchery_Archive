import ugfx
import json
import sys

ugfx.init()

with open('%s/ComicNeue_Bold48.json' % sys.path[1], 'r') as f:
    ugfx.fonts_load(json.loads(f.read()))

ugfx.clear(ugfx.BLACK)
ugfx.string(5,25,"Hackers","ComicNeue_Bold48",ugfx.WHITE)
ugfx.string(140,55,"Gonna","ComicNeue_Bold48",ugfx.WHITE)
ugfx.string(15,75,"Hack","ComicNeue_Bold48",ugfx.WHITE)
ugfx.flush()