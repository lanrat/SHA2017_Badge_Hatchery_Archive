###Lights Egg
### Author: f0x
### License: GPLv3

## A flashlight app which does red and white light, and allows you to change the brightness

import badge, ugfx
import binascii
badge.leds_enable()
ugfx.input_init()

red = binascii.unhexlify("00ff00")
white = binascii.unhexlify("ffffff")

on = False
night_mode = False

def toggle(pressed):
	global on
	if pressed:
		if on:
			on = False
			badge.leds_send_data(''.join(['\0' for i in range(24)]), 24)
			print("off")
		else :
			on = True
			if night_mode:
				colors = [red, red, red, red, red, red]
			else :
				colors = [white, white, white, white, white, white]
			all_leds = ''.join([''.join(["{0:02x}".format(int(x)) for x in [r, g, b, 0]]) for (r, g, b) in colors])
			badge.leds_send_data(binascii.unhexlify(all_leds), 24)
			print("on")

def mode(pressed):
	global night_mode
	if pressed:
		if night_mode:
			night_mode = False
		else :
			night_mode = True
		ugfx.string(20, 20, "Night Mode: " + night_mode, "Roboto_Regular18", ugfx.BLACK)

ugfx.input_attach(ugfx.BTN_A, toggle)
ugfx.input_attach(ugfx.JOY_LEFT, mode)
ugfx.input_attach(ugfx.JOY_RIGHT, mode)