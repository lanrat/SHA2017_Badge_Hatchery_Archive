# SPONSORS APPLICATION
# SHOWN ONCE AFTER SETUP

import ugfx, badge, utime

def cyber():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    try:
        # Proudly stolen from https://cyber.equipment/cyber_plain.png
        badge.eink_png(0, 0, 'cyber_plain.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)
        raise
    ugfx.flush()

def program_main():
    print("--- Cyber Cyber ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    cyber()

# Start main application
program_main()
