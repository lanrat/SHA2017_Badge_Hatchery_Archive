import sys
vcBhj=range
vcBhy=True
vcBGh=OSError
vcBGQ=False
vcBGS=len
vcBGq=open
vcBhL=sys.path
import gc
vcBhF=gc.collect
import network
vcBhR=network.WLAN
vcBhm=network.STA_IF
vcBhr=network.AP_IF
import machine
vcBhY=machine.unique_id
import usocket as socket
vcBhH=socket.getaddrinfo
vcBhV=socket.socket
import badge
vcBhA=badge.nvs_set_str
vcBhE=badge.nvs_get_str
import ugfx
vcBhp=ugfx.BLACK
vcBhf=ugfx.clear
vcBhI=ugfx.input_attach
vcBhx=ugfx.string
vcBht=ugfx.WHITE
vcBhM=ugfx.flush
vcBhd=ugfx.BTN_A
vcBhk=ugfx.BTN_B
vcBhO=ugfx.input_init
import appglue
vcBhe=appglue.start_app
vcBhK=appglue.home
import time
vcBhD=time.sleep
import dialogs
vcBhg=dialogs.prompt_boolean
vcBhs=dialogs.prompt_text
import machine
vcBhY=machine.unique_id
vcBhL.append('/lib/SHA2017Game')
import game_common
vcBhw=game_common.determineLeague
import callsign
vcBhP=callsign.callsign
vcBhG=["red","fuchsia","blue","green","yellow","orange"]
def get_fragments():
 vcBhQ=[]
 for i in vcBhj(0,25):
  vcBhS=vcBhE('SHA2017Game',"fragment_%d"%i)
  if vcBhS:
   vcBhQ.append(vcBhS.replace('\n','').replace('\r',''))
 return vcBhQ
def add_fragment(newfragment):
 for i in vcBhj(0,25):
  vcBhS=vcBhE('SHA2017Game',"fragment_%d"%i)
  if vcBhS:
   if vcBhS.strip()==newfragment.strip():
    return
  else:
   vcBhA('SHA2017Game',"fragment_%d"%i,newfragment)
   return
def leaguename():
 vcBhq=vcBhw()
 return vcBhG[vcBhq]
def receiveData(vcBhu,cb,errcb):
 w=vcBhR(vcBhr)
 w.active(vcBhy)
 w.config(essid=vcBhu,channel=11)
 s=vcBhV()
 ai=vcBhH("0.0.0.0",2017)
 print("Bind address info:",ai)
 vcBhb=ai[0][-1]
 s.bind(vcBhb)
 s.listen(5)
 print('Listening at',vcBhu)
 s.settimeout(120)
 try:
  vcBha=s.accept()
  vcBhN=vcBha[0]
  vcBhC=vcBha[1]
  print("Client address:",vcBhC)
  print("Client socket:",vcBhN)
  vcBhz=vcBhN
  print("Request:")
  vcBhT=vcBhz.readline()
  print(vcBhT)
  vcBhz.send('OK\r\n')
  vcBhJ=cb(vcBhT)
  vcBhz.close()
  print("Done.")
 except vcBGh:
  print("Error")
  vcBhJ=errcb()
 s.close()
 w.active(vcBGQ)
 if vcBhJ:
  vcBhe('SHA2017Game')
def gotOracleData(data):
 vcBhA('SHA2017Game','fragment_0',data)
 return vcBhy
def listenForOracle(leaguename):
 vcBhf(vcBht)
 vcBhx(0,0,"Find the oracle!","PermanentMarker22",vcBhp)
 vcBhx(0,30,"Welcome, brave traveller of league %s. Your quest"%leaguename,"Roboto_Regular12",vcBhp)
 vcBhx(0,50,"starts once you have found the oracle. When you are","Roboto_Regular12",vcBhp)
 vcBhx(0,70,"near she will call out for you and provide further","Roboto_Regular12",vcBhp)
 vcBhx(0,90,"instructions. You have 30 seconds per attempt.","Roboto_Regular12",vcBhp)
 vcBhM()
 receiveData('OracleSeeker',gotOracleData,vcBhK)
def send_to(recv):
 vcBhf(vcBht)
 vcBhx(0,0,"Share your fragments!","PermanentMarker22",vcBhp)
 vcBhx(0,30,"Connecting to other player...","Roboto_Regular12",vcBhp)
 vcBhM()
 n=0
 try:
  w=vcBhR(vcBhm)
  w.active(vcBhy)
  ap="Gamer %s %s"%(leaguename(),recv)
  print('Connecting to',ap)
  w.connect(ap)
  while not w.isconnected()and n<30:
   vcBhD(1)
   n=n+1
 except msg:
  print("error!",msg)
  vcBhx(0,50,"Error connecting to other player...","Roboto_Regular12",vcBhp)
  vcBhM()
  vcBhO()
  vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
  return
 if n==30:
  print('No connection after sleeping 30 seconds')
  vcBhx(0,50,"Error connecting to other player...","Roboto_Regular12",vcBhp)
  vcBhM()
  vcBhO()
  vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
  return
 vcBhx(0,50,"Sending fragments...","Roboto_Regular12",vcBhp)
 vcBhM()
 s=vcBhV()
 ai=vcBhH("192.168.4.1",2017)
 vcBhb=ai[0][-1]
 s.connect(vcBhb)
 s.send('#'.join(get_fragments()))
 s.send("\r\n")
 s.readline()
 s.close()
 w.active(vcBGQ)
 print('Done sending')
 vcBhx(0,70,"Sent fragments. Press A.","Roboto_Regular12",vcBhp)
 vcBhM()
 vcBhO()
 vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
def gotFragmentData(data):
 print('Got fragment data: ',data)
 for vcBhS in data.decode().split('#'):
  add_fragment(vcBhS.replace('\n','').replace('\r',''))
 vcBhi=get_fragments()
 if vcBGS(vcBhi)>=25:
  vcBhe('SHA2017Game')
 vcBhx(0,70,"You now own %d unique fragments, %d to go!"%(vcBGS(vcBhi),25-vcBGS(vcBhi)),"Roboto_Regular12",vcBhp)
 vcBhx(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",vcBhp)
 vcBhM()
 vcBhO()
 vcBhI(vcBhk,lambda pressed:vcBhK()if pressed else 0)
 vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
 return vcBGQ;
def receive_fragments_failed():
 vcBhx(0,70,"Failed to receive fragments. Press A.","Roboto_Regular12",vcBhp)
 vcBhM()
 vcBhO()
 vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
def receive_fragments():
 receiveData("Gamer %s %03d%03d"%(leaguename(),vcBhY()[4],vcBhY()[5]),gotFragmentData,receive_fragments_failed)
def send_or_recv(send):
 if send:
  vcBhf(vcBht)
  vcBhs("Receiver address:",cb=send_to)
 else:
  vcBhf(vcBht)
  vcBhx(0,0,"Share your fragments!","PermanentMarker22",vcBhp)
  vcBhx(0,30,"Tell the other player of your league your address,","Roboto_Regular12",vcBhp)
  vcBhx(0,50,"which is %03d%03d. Waiting..."%(vcBhY()[4],vcBhY()[5]),"Roboto_Regular12",vcBhp)
  vcBhM()
  receive_fragments()
def initiate_sharing():
 vcBhf(vcBht)
 vcBhx(0,0,"Share your fragments!","PermanentMarker22",vcBhp)
 vcBhg("Do you want to send or receive?",true_text="Send",false_text="Receive",height=100,cb=send_or_recv)
def won():
 vcBhf(vcBht)
 vcBhx(0,0,"Congratulations!","PermanentMarker22",vcBhp)
 vcBhx(0,30,"Cool! You've unlocked your league's secret. As a reward","Roboto_Regular12",vcBhp)
 vcBhx(0,50,"the signal shown by your badge LEDs will now sparkle.","Roboto_Regular12",vcBhp)
 vcBhx(0,70,"Is this the end? That is up to you! Contact raboof for","Roboto_Regular12",vcBhp)
 vcBhx(0,90,"the game code and design new challenges!","Roboto_Regular12",vcBhp)
 vcBhx(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",vcBhp)
 vcBhM()
 vcBhO()
 vcBhI(vcBhk,lambda pressed:vcBhK()if pressed else 0)
 vcBhI(vcBhd,lambda pressed:initiate_sharing()if pressed else 0)
def main():
 vcBhF()
 vcBhq=vcBhw()
 vcBhP(vcBhq)
 if vcBGQ:
  vcBhf(vcBht)
  vcBhx(0,0,"Welcome, early bird!","PermanentMarker22",vcBhp)
  vcBhx(0,30,"Welcome to the SHA2017Game! You are in league","Roboto_Regular12",vcBhp)
  vcBhx(0,50,"%s, as your 'callsign' shows if you soldered on your"%leaguename(),"Roboto_Regular12",vcBhp)
  vcBhx(0,70,"LEDs. The game starts when the oracle is on the field,","Roboto_Regular12",vcBhp)
  vcBhx(0,90,"keep an eye on https://twitter.com/SHA2017Game.","Roboto_Regular12",vcBhp)
  vcBhx(5,113,"B: Back to home","Roboto_Regular12",vcBhp)
  vcBhM()
  vcBhO()
  vcBhI(vcBhk,lambda pressed:vcBhK()if pressed else 0)
  return
 vcBhi=get_fragments()
 print('number of fragments so far',vcBGS(vcBhi))
 vcBhW=vcBGQ
 if vcBGS(vcBhi)>=25:
  vcBhA('SHA2017Game','fragment_0',vcBhi[0].strip())
  vcBhf(vcBht)
  try:
   import os
   os.stat('/lib/SHA2017game/sparkle.py')
   won()
  except:
   import wifi
   import urequests
   import shards
   wifi.init()
   while not wifi.sta_if.isconnected():
    vcBhD(1)
   vcBhn=[]
   for vcBhS in vcBhi:
    vcBhn.append(vcBhS.replace('\n','').replace('\r',''))
   vcBhl=shards.key_from_shards(vcBhn)
   print('Collecting shards.py with key',vcBhl)
   r=urequests.get("http://pi.bzzt.net/%s/sparkle.py"%vcBhl)
   f=vcBGq('/lib/SHA2017game/sparkle.py','w')
   f.write(r.content)
   f.close()
   won()
 elif vcBGS(vcBhi)>1:
  vcBhA('SHA2017Game','fragment_0',vcBhi[0].strip())
  vcBhf(vcBht)
  vcBhx(0,0,"Share your fragments!","PermanentMarker22",vcBhp)
  vcBhx(0,30,"By sharing you have now brought together %d"%vcBGS(vcBhi),"Roboto_Regular12",vcBhp)
  vcBhx(0,50,"fragments of league %s. Sharing will send them all."%leaguename(),"Roboto_Regular12",vcBhp)
  vcBhx(0,70,"Unlock your league %s key with 25 fragments!"%leaguename(),"Roboto_Regular12",vcBhp)
  vcBhx(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",vcBhp)
  vcBhM()
  vcBhO()
  vcBhI(vcBhk,lambda pressed:vcBhK()if pressed else 0)
  vcBhI(vcBhd,lambda pressed:initiate_sharing()if pressed else 0)
 elif vcBGS(vcBhi)==1:
  vcBhf(vcBht)
  vcBhx(0,0,"Share your fragments!","PermanentMarker22",vcBhp)
  vcBhx(0,30,"The oracle gave you a fragment of a relic of the "+leaguename(),"Roboto_Regular12",vcBhp)
  vcBhx(0,50,"league. 25 such fragments must be brought together","Roboto_Regular12",vcBhp)
  vcBhx(0,70,"to unlock its potential. Find other league members to","Roboto_Regular12",vcBhp)
  vcBhx(0,90,"share fragments along with a story or Mate.","Roboto_Regular12",vcBhp)
  vcBhx(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",vcBhp)
  vcBhM()
  vcBhO()
  vcBhI(vcBhk,lambda pressed:vcBhK()if pressed else 0)
  vcBhI(vcBhd,lambda pressed:initiate_sharing()if pressed else 0)
 elif vcBhW:
  def oracle_selection_made(value):
   vcBhP(vcBhq)
   if value:
    listenForOracle(leaguename())
   else:
    vcBhK()
  def dialog_title():
   return "SHA2017Game - you are in league "+leaguename()
  vcBhg('Are you ready to start your quest?',title=dialog_title(),true_text='Search for the oracle',false_text='Back to home screen',height=100,cb=oracle_selection_made)
 else:
  vcBhf(vcBht)
  vcBhx(0,0,"Retrieving fragment!","PermanentMarker22",vcBhp)
  vcBhx(0,30,"Welcome player of league "+leaguename(),"Roboto_Regular12",vcBhp)
  vcBhx(0,50,"Fetching your initial fragment!","Roboto_Regular12",vcBhp)
  vcBhM()
  import wifi
  import urequests
  wifi.init()
  n=0
  while not wifi.sta_if.isconnected()and n<30:
   vcBhD(1)
   n=n+1
  if n==30:
   vcBhx(0,70,"Failed! Press A.","Roboto_Regular12",vcBhp)
   vcBhO()
   vcBhI(vcBhd,lambda pressed:vcBhe('SHA2017Game')if pressed else 0)
   return
  vcBhU=(vcBhY()[3]+vcBhY()[4]+vcBhY()[5])%700
  r=urequests.get("http://pi.bzzt.net/oracle/%d/%d"%(vcBhq,vcBhU))
  gotOracleData(r.content)
  vcBhe('SHA2017Game')
main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)

