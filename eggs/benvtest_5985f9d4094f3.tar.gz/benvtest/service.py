import badge
import ugfx

def setup():
    global serviceEnabled
    global serviceText
    serviceText = badge.nvs_get_str('hometext', 'text', '')
    serviceEnabled = badge.nvs_get_u8('hometext', 'service', 0)
    if (serviceEnabled<1):
        print("[HOMETEXT] Disabled! Please enable in the app!")
    else:
        print("[HOMETEXT] Enabled! Drawing text: " + serviceText)

def loop():
    # Updates not really needed .... for now.
    return 600000

def draw(y, sleep = 2):
    # t = easyrtc.string()
    # ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    global serviceEnabled
    global serviceText
    if (serviceEnabled<1):
        print("[HOMETEXT] Disabled. Jammer.")
        return [600000, 0]
    print("[HOMETEXT] " + " Y: " + str(y) + " Text: " + serviceText)
    # Align right, last line.
    # ugfx.string(ugfx.width() - ugfx.get_string_width(serviceText) , y,serviceText,"PermanentMarker36",ugfx.BLACK)
    # Align left, at specced position
    if y > (ugfx.height() - 36):
        print("Y is too low, we'll just overwrite the lowest line, fsck this.")
        ugfx.string(0, y - 36, serviceText,"PermanentMarker36", ugfx.BLACK)
    ugfx.string(0, y, serviceText,"PermanentMarker36", ugfx.BLACK)
    ugfx.flush()
    return [600000, 36]

