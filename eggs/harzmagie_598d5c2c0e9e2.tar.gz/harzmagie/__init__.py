import ugfx, time, appglue, badge

sleeptime = 0.200

ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_A, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.home() if pushed else 0)

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

try:
  badge.eink_png(0,0,'/lib/harzmagie/harzmagie.png')
except:
  ugfx.string(100, 50, "Error loading icon.png", ugfx.BLACK)
ugfx.flush()

badge.leds_enable()
while True:
  #badge.leds_send_data(bytes([0,84,56, 0,98,65, 0,112,75, 0,116,84, 0,140,93, 0,153,102, 23,162,73, 46,171,129]), 24)
  badge.leds_send_data(bytes([10,10,0,0, 0,10,10,0, 0,10,10,0, 0,10,10,0, 0,10,10,0, 0,10,10,0]), 24)
  time.sleep(sleeptime)
#  badge.leds_send_data(bytes([0,98,65,0, 0,112,75,0, 0,116,84,0, 0,140,93,0, 0,153,102,0, 0,84,56,0]), 24)
#  time.sleep(sleeptime)
#  badge.leds_send_data(bytes([0,112,75,0, 0,116,84,0, 0,140,93,0, 0,153,102,0, 0,84,56,0, 0,98,65,0]), 24)
#  time.sleep(sleeptime)
#  badge.leds_send_data(bytes([0,116,84,0, 0,140,93,0, 0,153,102,0, 0,84,56,0, 0,98,65,0, 0,112,75,0]), 24)
#  time.sleep(sleeptime)
#  badge.leds_send_data(bytes([0,140,93,0, 0,153,102,0, 0,84,56,0, 0,98,65,0, 0,112,75,0, 0,116,84,0]), 24)
#  time.sleep(sleeptime)
#  badge.leds_send_data(bytes([0,153,102,0, 0,84,56,0, 0,98,65,0, 0,112,75,0, 0,116,84,0, 0,140,93,0]), 24)
#  time.sleep(sleeptime)