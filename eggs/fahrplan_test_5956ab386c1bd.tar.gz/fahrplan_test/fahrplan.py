### Fahrplan Egg
### Author: f0x
### License: GPLv3


import ugfx, badge


display_width  = 295 
display_height = 128
line_width     = 3

column_width = int((display_width - 2*line_width)/3)

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

def draw_gui():
    ugfx.thickline(column_width, 0, column_width, display_height, ugfx.BLACK, line_width, 5)
    ugfx.thickline(2*column_width, 0, 2*column_width, display_height, ugfx.BLACK, line_width, 5)
    ugfx.line(0, 18, 295, 18, ugfx.BLACK)

def track_header(string, pos):
    ## Write a stage header [string], where pos is column 0, 1 or 2
    stage_len = ugfx.get_string_width(string,"Roboto_Regular12")
    position  = int((column_width-stage_len)/2)
    ugfx.string(position + pos*column_width, 3, string, "Roboto_Regular12", ugfx.BLACK)

def scroll_right(pressed):
    if pressed:
        ugfx.clear(ugfx.WHITE)
        draw_gui()
        track_header("$track2", 0)
        track_header("$track3", 1)
        track_header("$track4", 2)
        ugfx.flush()
        print("JOY_RIGHT")

draw_gui()
track_header("$track1", 0)
track_header("$track2", 1)
track_header("$track3", 2)


ugfx.flush()

ugfx.input_attach(ugfx.JOY_RIGHT, scroll_right)
