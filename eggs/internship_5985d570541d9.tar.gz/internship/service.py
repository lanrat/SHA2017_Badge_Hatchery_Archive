import badge, ugfx

ugfx.init()
badge.init()

# This function gets called by the home application at boot
def setup():
    ugfx.string(20, 90, 'Test', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()
    
def draw():
    ugfx.string(20, 90, 'Test', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()

def loop():
    ugfx.string(20, 90, 'Test', 'Roboto_BlackItalic24', ugfx.WHITE)
    ugfx.flush()