import ugfx, badge

def start():
    ugfx.init()
    badge.init()
    ugfx.string(20, 40, 'Hi there :p', 'Roboto_BlackItalic24', ugfx.WHITE)


start()