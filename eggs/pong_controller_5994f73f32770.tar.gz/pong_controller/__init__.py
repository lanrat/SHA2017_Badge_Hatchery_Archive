import badge
import ugfx
import appglue
import socket
import wifi

rev = "rev. 11"
UDP_HOST="83.133.179.207"
UDP_PORT=5555
player = ""

def home(pushed):
    if(pushed):
        print("go home")
        appglue.home()

def reset(pushed):
    if(pushed):
        print("reset")
        #s.shutdown(SHUT_RDWR)
        #s.close()
        global player
        player = ""
        clean()
        screen(player)
        ugfx.flush()

def player1(pushed):
    if(pushed):
        print("join game as player1")
        command = "left"
	global player
        player = "player1"
        clean()
        screen("Player 1")
        ugfx.flush()
        sendCommand(s, player, command)

def player2(pushed):
    if(pushed):
        print("join game as player2")
        command = "right"
        global player
        player = "player2"
        clean()
        screen("Player 2")
        ugfx.flush()
        sendCommand(s, player, command)

def up(pushed):
    print("player:", player)
    if((pushed) and (player)):
        print(player, "up")
	command = "up"
        sendCommand(s, player, command)
    else:
	print("player not set")

def down(pushed):
    print("player:", player)
    if((pushed) and (player)):
        print(player, "down")
	command = "down"
        sendCommand(s, player, command)
    else:
        print("player not set")

def sendCommand(s, player_id, command):
    s.sendto(bytearray([ord(x) for x in player_id] + [ord(" ")] + [ord(x) for x in command.upper()]), (UDP_HOST,UDP_PORT))

def wait_wifi():
    ugfx.string(50, 25, "STILL", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.string(30, 50, "Connecting to wifi", "PermanentMarker22", ugfx.WHITE)
    le = ugfx.get_string_width("Connecting to wifi", "PermanentMarker22")
    ugfx.line(30, 72, 30 + 14 + le, 72, ugfx.WHITE)
    ugfx.string(140, 75, "Anyway", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.flush()

def clean():
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def screen(player_name):
    ugfx.string(50, 10, player_name ,"Roboto_Regular16",ugfx.BLACK)
    ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(190,50,"Pong","PermanentMarker22",ugfx.BLACK)
    len = ugfx.get_string_width("Pong","PermanentMarker22")
    ugfx.line(190, 72, 204 + len, 72, ugfx.BLACK)
    ugfx.line(200 + len, 52, 200 + len, 70, ugfx.BLACK)
    ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(20, 110, "SELECT: exit, A: P1, B: P2, U/D","Roboto_Regular12",ugfx.BLACK)
    ugfx.string(255, 115, rev ,"Roboto_Regular12",ugfx.BLACK)
    try:
        badge.eink_png(0,40,'/lib/pong_controller/shrug.png')
    except:
        ugfx.string(30,50,"Error loading shrug.png","Roboto_Regular16",ugfx.BLACK)

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.set_lut(ugfx.LUT_NORMAL)
clean()
wifi.init()
wait_wifi()
clean()
screen(player)
ugfx.flush()

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

ugfx.input_attach(ugfx.BTN_SELECT, home)
ugfx.input_attach(ugfx.BTN_START, reset)
ugfx.input_attach(ugfx.BTN_A, player1)
ugfx.input_attach(ugfx.BTN_B, player2)
ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)

