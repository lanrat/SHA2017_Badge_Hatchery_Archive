import ugfx

ugfx.init()
ugfx.display_image(0,0,'altpwr.png')
ugfx.flush()