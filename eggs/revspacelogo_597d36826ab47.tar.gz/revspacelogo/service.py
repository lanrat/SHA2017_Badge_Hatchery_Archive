import ugfx, badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(150,25,'/lib/revspacelogo/revspace.png')
    return 0