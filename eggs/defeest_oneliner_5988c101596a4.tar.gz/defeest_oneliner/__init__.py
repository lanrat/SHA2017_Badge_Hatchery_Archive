from badge_oneliner import oneliner

