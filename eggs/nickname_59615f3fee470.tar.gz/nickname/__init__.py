import dialogs, ugfx
nick = dialogs.prompt_text("Please enter name")
print(nick)

ugfx.clear(ugfx.WHITE)

ugfx.string(150,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(130,50,nick,"PermanentMarker22",ugfx.BLACK)
len = ugfx.get_string_width(nick,"PermanentMarker22")
ugfx.line(130, 72, 144 + len, 72, ugfx.BLACK)
ugfx.line(140 + len, 52, 140 + len, 70, ugfx.BLACK)
ugfx.string(140,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)

ugfx.flush(ugfx.LUT_FULL)

import deepsleep, badge
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)