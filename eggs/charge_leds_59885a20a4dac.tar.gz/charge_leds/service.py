import badge

def show_leds(nousb):
    bvol = badge.battery_volt_sense()
    crg = badge.battery_charge_status()
    uvol = badge.usb_volt_sense()
    try:
        bvolmin = badge.nvs_get_u16("splash", "battery.volt.min", 3800)
    except:
        bvolmin = 3800
    try:
        bvolmax = badge.nvs_get_u16("splash", "battery.volt.max", 4300)
    except:
        bvolmax = 4300
    bvolstg = (bvolmax - bvolmin)/6
    maxbrightness=32
    ledson = True
    if nousb and uvol < 4500:
        led_status = bytes([0]*24)
        ledson = False
    elif (uvol >= 4500 and not crg) or bvol >= bvolmax:
        led_status = bytes([maxbrightness, 0, 0, 0]*6)
    elif bvol <= bvolmin:
        led_status = bytes([0, maxbrightness, 0, 0]*6)
    else:
        use_led = int((bvol-bvolmin)/bvolstg)
        lb = maxbrightness
        crglvl = round(lb*((bvol-bvolmin)/bvolstg-use_led))
        led_status = bytes(
                     [0, maxbrightness,0,0] * (5-use_led) + 
                     [crglvl, lb-crglvl,0,0] +
                     [maxbrightness, 0,0,0] * use_led
                     )
    if ledson:
        badge.leds_enable()
    else:
        badge.leds_disable()
    badge.leds_send_data(led_status, 24)    

def loop():
    print("Showing led status")
    show_leds(True)
    if badge.usb_volt_sense() <= 4500:
        return 300000
    else:
        return 1000

def setup():
    global loop
    print("Initializing Charge LEDs service")
    if badge.nvs_get_u8("charge_leds", "enable", 0):
        badge.leds_init()
        badge.power_init()
    else:
        loop = lambda: return 86400000
