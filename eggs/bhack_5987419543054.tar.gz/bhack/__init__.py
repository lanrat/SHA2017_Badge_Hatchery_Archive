import appglue, ugfx, badge

nick = badge.nvs_get_str('owner', 'name')


ugfx.init()

ugfx.clear(ugfx.WHITE)


ugfx.area(10,10,32,32,ugfx.BLACK)

ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)
ugfx.string(16,45,nick,"Roboto_Black22",ugfx.BLACK)


ugfx.flush()

def render(text, pushed):
    if(pushed):
      if(text == 'A'):
        ugfx.clear(ugfx.BLACK)
        ugfx.area(10,10,32,32,ugfx.WHITE)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.BLACK)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.WHITE)
        ugfx.string(16,45,nick,"Roboto_Black22",ugfx.WHITE)
      else:
        ugfx.clear(ugfx.WHITE)
        ugfx.area(10,10,32,32,ugfx.BLACK)
        ugfx.string(16,15,"B","Roboto_Black22",ugfx.WHITE)
        ugfx.string(42,15,"hack","Roboto_Black22",ugfx.BLACK)
        ugfx.string(16,45,nick,"Roboto_Black22",ugfx.BLACK)
    ugfx.flush()
    
def buzz(speed, pushed):
  if(pushed):
    badge.vibrator_activate(speed)

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: buzz(0x22, pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: buzz(0x55, pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: buzz(0x99, pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: buzz(0xFF, pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: render('A', pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: render('B', pressed))
ugfx.input_attach(ugfx.BTN_START, lambda x: appglue.home())
ugfx.input_attach(ugfx.BTN_SELECT, lambda x: appglue.home())

while True:
    pass