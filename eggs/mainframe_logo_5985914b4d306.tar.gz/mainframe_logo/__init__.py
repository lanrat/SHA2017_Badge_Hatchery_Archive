import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.string_box(0,5,296,26, "Mainfrage the beasty Hackspace in the north", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,25,296,26, "if it happens to you to be in Oldenburg/GERMANY", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,45,296,26, "please come to visit us. We are open daily", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,65,296,26, "from 9:00pm to midnight!", "Roboto_BlackItalic22", ugfx.BLACK, ugfx.justifyLeft)
badge.eink_png(180,45,'/lib/Mainframe_Logo/mainframe_shabadge.png')
ugfx.string_box(0,90,296,26, "mainframe.io", "PermanentMarker36", ugfx.BLACK, ugfx.justifyLeft)

ugfx.flush()