import ugfx, badge, dialogs
import uos as os

ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

uninstall = dialogs.prompt_boolean('Are you sure you want to remove all your apps?')
print(uninstall)
if uninstall:
    for rm_folder in os.listdir("lib"):
        ugfx.clear(ugfx.WHITE)
        ugfx.string_box(0, 25, 296, 25,"Uninstalling:","Roboto_BlackItalic24",ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0, 51, 296, 23, rm_folder, "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.flush()
        for rm_file in os.listdir("lib/%s" % (rm_folder)):
            os.remove("lib/%s/%s" % (rm_folder, rm_file))
        os.rmdir("lib/%s" % (rm_folder))                                          
    ugfx.clear(ugfx.WHITE)
    ugfx.string_box(0, 25, 296, 25,"Uninstalling:","Roboto_BlackItalic24",ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0, 51, 296, 23, "DONE", "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()
    badge.eink_busy_wait()
import deepsleep
deepsleep.reboot()