import ugfx, gc, wifi, badge, deepsleep
#, io, xmltok
from time import sleep
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()
badge.eink_busy_wait()
sleep(2)

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

#url = "https://poc.sha2017.org/phonebook.xml"
#r = requests.get(url)
#gc.collect()
#xml_data = r.text()
#r.close()


#tokenized = xmltok.tokenize(io.StringIO(xml_data))
#while True:
#  extension = xmltok.gfind(tokenized, 'extension')
#  if extension == None:
#    break;
#  ugfx.clear()
#  ugfx.string(10,10,extension,"Robot_Regular12", 0)
#  ugfx.flush()
#  badge.eink_busy_wait()

ugfx.clear()
ugfx.string(10,10,"End","Robot_Regular12", 0)
ugfx.flush()
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)