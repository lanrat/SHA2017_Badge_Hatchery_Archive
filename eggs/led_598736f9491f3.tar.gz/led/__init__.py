import badge
import ugfx
import time
from random import randint
import deepsleep

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

def home(pressed):
  if pressed:
    deepsleep.reboot()

ugfx.input_attach(ugfx.JOY_RIGHT, home)
ugfx.input_attach(ugfx.JOY_LEFT, home)
ugfx.input_attach(ugfx.JOY_UP, home)
ugfx.input_attach(ugfx.JOY_DOWN, home)
ugfx.input_attach(ugfx.JOY_RIGHT, home)
ugfx.input_attach(ugfx.BTN_A, home)
ugfx.input_attach(ugfx.BTN_B, home)
ugfx.input_attach(ugfx.BTN_START, home)
ugfx.input_attach(ugfx.BTN_SELECT, home)

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "LED Rainbow","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[1:] + bytes([randint(128, 255), randint(0, 255), randint(0, 128), 0])
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[1:] + bytes([randint(0, 128), randint(0, 255), randint(128, 255), 0])