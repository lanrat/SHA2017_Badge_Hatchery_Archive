### Fahrplan Egg
### Author: f0x
### License: GPLv3

### Screen is divided in three columns, each representing a track
### each column has rows of 


import ugfx, badge
import network, json
import utime as time
import urequests as requests

display_width  = 295 
display_height = 128
line_width     = 3


selected       = 0 # number of leftmost track currently displayed
day            = 1 # day to display data for TODO: get from user input
room_list      = []

column_width = int((display_width - 2*line_width)/3)


badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

# Make sure WiFi is connected
sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
badge.wifi_init()

# Fetch schedule, UPDATE URL IN FUTURE
string = "Getting schedule data for day "+str(day)
text_len = ugfx.get_string_width(string,"Roboto_Regular22")
position  = int((display_width-text_len)/2)
ugfx.string(position, 3, string, "Roboto_Regular22", ugfx.BLACK)

# Wait for WiFi connection
while not sta_if.isconnected():
    time.sleep(0.1)
    pass

url = "https://badge.sha2017.org/schedule/day/" + str(day)
r = requests.get(url)
schedule = r.json()
r.close()

for room in schedule["rooms"]:
    room_list.append(room)


def draw_gui():
    ugfx.thickline(column_width, 0, column_width, display_height, ugfx.BLACK, line_width, 5)
    ugfx.thickline(2*column_width, 0, 2*column_width, display_height, ugfx.BLACK, line_width, 5)
    ugfx.line(0, 18, 295, 18, ugfx.BLACK)
    draw_headers()

def draw_headers():
    for room in schedule["rooms"]:
        print(room)
    draw_header(room_list[selected], 0)
    draw_header(room_list[selected+1], 1)
    draw_header(room_list[selected+2], 2)


def draw_header(string, pos):
    ## Write a stage header [string], where pos is column 0, 1 or 2
    stage_len = ugfx.get_string_width(string,"Roboto_Regular12")
    position  = int((column_width-stage_len)/2)
    ugfx.string(position + pos*column_width, 3, string, "Roboto_Regular12", ugfx.BLACK)


#def draw_block(string, col, row):
    


def scroll_right(pressed):
    global selected
    if pressed:
        selected = selected + 1
        scroll(selected)
        print("JOY_RIGHT")

def scroll_left(pressed):
    global selected
    if pressed:
        selected = selected - 1
        scroll(selected)
        print("JOY_LEFT")

def scroll(selected):
        ugfx.clear(ugfx.WHITE)
        draw_gui()
        ugfx.flush()

scroll(selected)

ugfx.flush()

ugfx.input_attach(ugfx.JOY_RIGHT, scroll_right)
ugfx.input_attach(ugfx.JOY_LEFT, scroll_left)