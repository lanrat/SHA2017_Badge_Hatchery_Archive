import ugfx, gc, wifi, badge
import urequests as requests
from time import *

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()

# Make sure WiFi is connected
wifi.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
#badge.eink_png(0,0,'urad3.png')
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE)
#badge.eink_png(0,0,'urad3.png')
ugfx.flush()

headers = {'X-User-id': 'sha2017', 'X-User-hash': 'badge'}
url = 'https://data.uradmonitor.com/api/v1'
unit, duration = {0: 64000024, 1: 64000025, 2: 82000065}, 36000
counter_unit, counter_meas = 0, 8

def get_uradData(pushed):
    if(pushed):
        ugfx.string_box(0,50,296,26, "Push Up or Down to Select Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,76,296,26, "Push Left or Right for Measurements on Current Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,102,296,26, "Push A to go Home and Refresh, B to Power Down", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.flush()
        gc.collect()
        try:
            if ugfx.JOY_UP:
                counter_unit += counter_unit
                for k,v in unit.items():
                    k = counter_unit
                    if counter_unit > 2:
                        counter_unit = 0
                    unit_val = v
                    ugfx.clear(ugfx.WHITE)
                    ugfx.flush()
                    ugfx.string_box(0,50,296,26, "You Will Select Unit # "+counter_unit, " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    ugfx.string_box(0,76,296,26, "Push Up or Down to Select Different Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    ugfx.string_box(0,102,296,26, "Push Select to Confirm Selected Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    badge.eink_png(0,0,'/lib/uradmonitor/urad3.png')
                    ugfx.flush()
            
            if ugfx.JOY_DOWN:
                counter_unit -= counter_unit
                for k,v in unit.items():
                    k = counter_unit
                    if counter_unit < 0:
                        counter_unit = 2
                    unit_val = v
                    ugfx.clear(ugfx.WHITE)
                    ugfx.flush()
                    ugfx.string_box(0,50,296,26, "You Will Select Unit # "+counter_unit, " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    ugfx.string_box(0,76,296,26, "Push Up or Down to Select Different Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    ugfx.string_box(0,102,296,26, "Push Select to Confirm Selected Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
                    badge.eink_png(0,0,'/lib/uradmonitor/urad3.png')
                    ugfx.flush()

            screen_1 = url+'/chart/'+unit_val+'/temperature/'+duration
            screen_2 = url+'/chart/'+unit_val+'/pressure/'+duration
            screen_3 = url+'/chart/'+unit_val+'/humidity/'+duration
            screen_4 = url+'/chart/'+unit_val+'/pm25/'+duration
            screen_5 = url+'/chart/'+unit_val+'/voc/'+duration
            screen_6 = url+'/chart/'+unit_val+'/cpm/'+duration
            screen_7 = url+'/chart/'+unit_val+'/formaldehyde/'+duration
            screen_8 = url+'/chart/'+unit_val+'/carbondioxide/'+duration
            screen_9 = url+'/devices/'+unit_val+'/all/last'

            screen = {0: screen_1, 1: screen_2, 2: screen_3, 3: screen_4, 4: screen_5, 5: screen_6, 6: screen_7, 7: screen_8, 8: screen_9}

            if ugfx.BTN_SELECT:
                data = requests.get(screen_9, headers=headers)
                ugfx.clear(ugfx.WHITE)
                ugfx.flush()
                badge.eink_png(0,0,'data')
                ugfx.flush()

            if ugfx.JOY_LEFT:
                counter_meas -= counter_meas
                for k,v in screen.items():
                    k = counter_meas
                    if counter_meas < 0:
                        counter_meas = 8
                    chosen_screen = v 
                    data = requests.get(chosen_screen, headers=headers)
                    ugfx.clear(ugfx.WHITE)
                    ugfx.flush()
                    badge.eink_png(0,0,'data')
                    ugfx.flush()

            if ugfx.JOY_RIGHT:
                counter_meas += counter_meas
                for k,v in screen.items():
                    k = counter_meas
                    if counter_meas > 8:
                        counter_meas = 0
                    chosen_screen = v
                    data = requests.get(chosen_screen, headers=headers)
                    ugfx.clear(ugfx.WHITE)
                    ugfx.flush()
                    badge.eink_png(0,0,'data')
                    ugfx.flush()

        except:
            ugfx.string(10,10,"Could not download JSON","Roboto_Regular12", 0)
            ugfx.flush()
            sleep(1)
            go_home(1)
            return
        try:
            global output
            output = screen_9.json()
        except:
            data.close()
            ugfx.string(10,10,"Data cannot be processed!","Roboto_Regular12", 0)
            ugfx.flush()
            sleep(1)
            go_home(1)
            return
        data.close()
        show_alarmleds()

def main():
    get_uradData(1)

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

def show_alarmleds():
    if output['cpm'] >= 200:
        led_val = 5
        badge.leds_enable()
        badge.leds_send_data(bytes([0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0,0,led_val,0,0]), 24)
    else:
        badge.leds_disable()

ugfx.input_attach(ugfx.BTN_A, get_uradData)
ugfx.input_attach(ugfx.BTN_B, go_home)

main()