from sha2017_event_program import event_alarm
event_alarm.alarm_notify()
