import dialogs, ugfx
nick = dialogs.prompt_text("Please enter name")
print(nick)
ugfx.clear(ugfx.WHITE)
ugfx.string(50,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(30,50,nick,"PermanentMarker36",ugfx.BLACK)
len = ugfx.get_string_width(nick,"PermanentMarker36")
ugfx.line(30, 82, 44 + len, 82, ugfx.BLACK)
ugfx.line(40 + len, 62, 40 + len, 80, ugfx.BLACK)
ugfx.string(40,85,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)

ugfx.flush(ugfx.LUT_FULL)

import deepsleep, badge
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)