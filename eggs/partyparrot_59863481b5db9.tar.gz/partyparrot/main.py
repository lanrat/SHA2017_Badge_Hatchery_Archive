import ugfx, badge 

ugfx.init()

while True:
    for x in range(0, 3)
        badge.eink_png(0,0 '/lib/parrot/parrot0%s.png' % x)
        ugfx.flush()
