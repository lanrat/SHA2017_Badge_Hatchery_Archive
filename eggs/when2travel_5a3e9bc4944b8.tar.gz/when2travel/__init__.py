import ugfx, time, wifi, badge, utime, ujson
#import machine
#from machine import RTC

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Waiting for wifi...","Roboto_Regular22", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Getting times...","Roboto_Regular22", 0)
ugfx.flush()

def open_json():
  fname = "/lib/When2Travel/times.json"
  with open(fname, 'r') as f:
    times = ujson.load(f)
  return times

def process_json(times):
  shortlist, middlelist, longlist, combolist = [], [], [], []
  for i in times:
    if ("departure","short19") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            shortlist.append(float(i))
    elif ("departure","short18") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            middlelist.append(float(i))
    elif ("departure","long22") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            longlist.append(float(i))
  combolist.append([shortlist, middlelist, longlist])
  combolist = combolist[0]
  return combolist

def populate_details_list(times):
    minute_dif, raw_list, counter = 99, [], 0
    combolist = process_json(times)
    year, month, day, hour, minute, second, ms, dayinyear = utime.localtime()
    while counter < 3:
        for i in combolist[counter]:
            hours = int(i//1)
            minutes =  int((i - int(i)) * 100)
            if counter == 0:
                route_code = 1000
            elif counter == 1:
                route_code = 2000
            else:
                route_code = 3000
            if hours == hour:
                minute_dif = minutes - minute
                if minute_dif >= 0:
                    raw_list.append(["%.2f" % i, route_code])
            if hours == hour + 1:
                minute_dif = minutes - minute + 60
                raw_list.append(["%.2f" % i, route_code])
        counter += 1
    return raw_list

def remove_empty_lists(details_list):
    sorted_list = []
    for i in details_list:
        if len(i) > 0:
            sorted_list.append(i)
    #sorted_list = sorted(sorted_list)
    return sorted_list

def define_nearest_times(seconds_list):
  detailed_list, counter = [], 0
  while counter < 3:
    nearest_times_list = min(seconds_list)
    nearest_time = min(nearest_times_list)
    del nearest_times_list[0]
    for i in seconds_list:
      if len(i) % 2 != 0:
        if 1000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '18 Minutes', 'S-Bahnhof Messe', 'NA', 'NA', 'Hauptbahnhof (Gleis 2)'])
          del nearest_times_list[0]
        elif 2000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '20 Minutes', 'S-Bahnhof Messe', 'Line 11', 'Chausseehaus', 'Hauptbahnhof (Gleis 2)'])
          del nearest_times_list[0]
        elif 3000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '22 Minutes', 'S-Bahnhof Messe', 'NA', 'NA', 'Hauptbahnhof (Westseite)'])
          del nearest_times_list[0]
    counter += 1
  return detailed_list

def refresh_data(pushed):
    if(pushed):
        show_screen()

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

def show_screen():
    times = open_json()
    details_list = populate_details_list(times)
    sorted_list = remove_empty_lists(details_list)
    currenttime = utime.localtime()
    formattedtime = "{:02d}:{:02d}".format(currenttime[3], currenttime[4])
    nick = badge.nvs_get_str("owner", "name", 'PLEASESETNICK')
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    #ugfx.string_box(0,78,296,52, sorted_list[0][0]+" H ", 
    #          "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,0,296,15, "Last Refresh:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,15,80,22, str(formattedtime), "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(80,0,296,15, "If Refresh Time doesn't match the actual time,", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(80,15,296,13, "please unplug and reconnect your battery.", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,40,296,15, "When2Travel:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(80,30,296,32, "  "+sorted_list[0][0]+"  "+sorted_list[1][0]+"  "+sorted_list[2][0],
              "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,60,296,20, "Departure:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(80,60,296,20, "S-Bahnhof Messe - Line ", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,57,294,22, "16", "PermanentMarker22", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(0,85,296,20, "Destination:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(80,83,296,19, "Hauptbahnhof", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(200,98,296,15, "Push A to Refresh", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(200,113,206,13, "Push Start to Exit", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,105,296,25, nick, "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
    #ugfx.string_box(0,0,148,50, str(formattedtime), "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()

def go2sleep():
  show_screen()
  time.sleep(300)
  restart()

def restart():
  go2sleep()

#go2sleep()
show_screen()

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_START, go_home)