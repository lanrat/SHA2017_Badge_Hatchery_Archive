# Service file for SHA2017 event program app
# Renze Nicolai 2017

# FOR NEW API

import machine, utime, ugfx, appglue, badge, easyrtc

# Prepare libs
event_alarm = __import__('lib/event_schedule/event_alarm')

# Global variables
next_event_title = ""
next_event_room = ""
next_event_timestamp = 999999999999

# This function gets called by the home application at boot
def setup():
    print("Event program service setup!")
    alarm_notify()

def loop():
    print("Event program service loop!")
    alarm_notify()
    return 5*60*1000 #Allow for 5 minutes of sleep, the minimum required for BPP to function

def draw(y):
    print("Event program service draw!")
    global next_event_title
    global next_event_timestamp
    global next_event_room
    pixels_used = 0
    if (next_event_timestamp<999999999999):
        next_event_title_short = next_event_title
            
        timestr = easyrtc.string(True, True, next_event_timestamp)
        
        if (len(next_event_title_short)>19):
            next_event_title_short = next_event_title_short[0:16]+"..."
        text = next_event_title_short+"' in '"+next_event_room+"' at "+timestr
        ypos = y-13
        badge.eink_png(0,ypos,'/lib/event_schedule/icon.png')
        ugfx.string(41, ypos+1, text, "Roboto_Regular12",ugfx.BLACK)
        pixels_used = 14
    return [60*1000, pixels_used] #Draw once per minute

def alarm_notify():
    global event_alarm
    event_alarm.alarms_read()
    current_datetime = utime.time()
    
    amount_of_alarms = len(event_alarm.alarms)
    
    for i in range(0, amount_of_alarms):
        alarm = event_alarm.alarms[i]
        c = int(alarm['timestamp']) + 2*60*60 - 10*60 #10 minutes before start
        if (c < current_datetime):
            diff = c - current_datetime
            print("[EVSCH] Alarm time reached for "+alarm['title']+" ("+str(diff)+")")
            appglue.start_app("event_schedule")
        else:
            countdown = abs(c - current_datetime)
            print("[EVSCH] Alarm time will be reached in "+str(countdown)+" for "+alarm['title'])
            global next_event_timestamp
            global next_event_title
            global next_event_room
            if next_event_timestamp>alarm['timestamp']:
                next_event_timestamp = alarm['timestamp']
                next_event_title = alarm['title']
                next_event_room = alarm['room']
                print("[EVSCH] Alarm over "+str(countdown)+"s: "+alarm['title']+" in "+alarm['room']+" at "+str(next_event_timestamp))
