import easydraw, ugfx, appglue

easydraw.msg("","Magic 8-Ball", True)

def home(pressed):
  if pressed:
    appglue.home()
    
    
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_START, home)
ugfx.clear(ugfx.WHITE)
ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)