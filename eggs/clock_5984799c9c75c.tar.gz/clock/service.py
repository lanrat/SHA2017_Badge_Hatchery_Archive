import easyrtc
import ugfx

def init():
    pass
  
def loop(counter):
    return False

def draw(x, y):
    t = easyrtc.string()
    ugfx.string(100, 0, t, "Roboto_Regular12", ugfx.BLACK)
    return 0