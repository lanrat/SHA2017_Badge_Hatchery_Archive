import appglue

appglue.home()