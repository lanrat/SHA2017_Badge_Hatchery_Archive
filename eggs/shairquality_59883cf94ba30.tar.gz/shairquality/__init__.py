import ugfx, gc, wifi, badge, time
import urequests as requests

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Getting info from uRadMonitor ...","Roboto_Regular12", 0)
ugfx.string(110,100,"https://uradmonitor.com/","Roboto_Regular12", 0)
ugfx.flush()

def show_screen(output):
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    badge.eink_png(0,0,'/lib/SHAirQuality/urad3.png')
    ugfx.string_box(88,0,208,25, "Push A to Refresh Data", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(88,25,208,25, "Push B to Put Badge to Sleep", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(90,102,206,26, "Push Right for Mobile Monitor #2", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.flush()
    # https://fukushimahounds.freeforums.net/thread/373/radiation-conversion-dose-sieverts-year
    radi = int(output[0]['cpm']) * 3 / 1000
    #ugfx.string_box(88,0,208,13, "Refreshed at", "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(88,14,208,24, easyrtc.string(True, True,output['time']) "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(88,37,208,13, "Press A to refresh data, B to power down", "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,50,296,26, "pressure  humidity  pm25       voc      radiation    temp", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,76,49,26, str(output[0]['pressure']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,102,49,26, "Pa", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(49,50,49,26, "humidity", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(49,76,49,26, str(output[0]['humidity']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(49,102,49,26, "% RH", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(98,50,49,26, "pm25", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(98,76,49,26, str(output[0]['pm25']), " Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(98,102,49,26, "ug m3", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(147,50,49,26, "voc", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(147,76,49,26, str(output[0]['voc']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(147,102,49,26, "air", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(198,50,49,26, "radiation", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(198,76,49,26, str(radi), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(198,102,49,26, "mSv/h", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    # Outside temperature deviates from internal Urad temperature
    # TODO calculate the deviation
    #ugfx.string_box(247,50,49,26, "temperature", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(247,76,49,26,str(output[0]['temperature']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(247,102,49,26, "C", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)   
    #if not output['formaldehyde'] in output:
    #    output['formaldehyde'], output['carbondioxide'] = "###"
    #ugfx.string_box(185,50,49,26, "formaldehyde CH2O", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(185,76,49,26, str(output[0]['formaldehyde']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(185,102,49,26, "ppm", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(222,50,49,26, "carbondioxide CO2", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(222,76,49,26, str(output[0]['carbondioxide']), "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    #ugfx.string_box(222,102,49,26, "ppm", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()

def refresh_data(pushed):
    if(pushed):
        show_screen(output)

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

#Json request info
headers = {'X-User-id': 'sha2017', 'X-User-hash': 'badge'}
url = 'https://data.uradmonitor.com/api/v1'
#unit = {0: '64000024', 1: '64000025', 2: '82000065'}
#duration = '36000'
#counter_unit = 0
#counter_meas = 8

#ugfx.clear(ugfx.WHITE)
#badge.eink_png(0,0,'/lib/SHAirQuality/urad3.png')
#ugfx.flush()
# fetching data
r = requests.get(url+'/devices/64000025/all/last', headers=headers)
gc.collect()
output = r.json()
r.close()
show_screen(output)



#def startscreen():
#    ugfx.string_box(0,50,296,26, "Push Up or Down to Select Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(0,76,296,26, "Push Left or Right for Measurements on Current Unit", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.string_box(0,102,296,26, "Push A to go Home and Refresh, B to Power Down", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.flush()
#    gc.collect()
#        
#def a_select():
#    ugfx.string_box(0,50,296,26, "A selected", " Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
#    ugfx.flush()
#    gc.collect()
    
    
#startscreen()
#url+'/devices/'+unit_val+'/all/last'

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)
#ugfx.input_attach(ugfx.BTN_START, go_home)
#ugfx.input_attach(ugfx.BTN_SELECT, go_home)
#ugfx.input_attach(ugfx.JOY_UP, up_pushed)
#ugfx.input_attach(ugfx.JOY_DOWN, down_pushed)
#ugfx.input_attach(ugfx.JOY_LEFT, left_pushed)
#ugfx.input_attach(ugfx.JOY_RIGHT, right_pushed)