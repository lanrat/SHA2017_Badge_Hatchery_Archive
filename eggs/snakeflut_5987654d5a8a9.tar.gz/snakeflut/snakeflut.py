import badge
import ugfx
import deepsleep

# width = 296
# height = 128

def snakeflut():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)

    # input
    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_LEFT, left)

    clear()

def clear(arg):
    ugfx.clear(ugfx.WHITE)
    badge.eink_busy_wait()
    ugfx.flush()


def up():
    clear()
    ugfx.area(100, 50, 50, 50, ugfx.BLACK)
    badge.eink_busy_wait()
    ugfx.flush()

def right():
    clear()
    ugfx.area(150, 100, 50, 50, ugfx.BLACK)
    badge.eink_busy_wait()
    ugfx.flush()

def down():
    clear()
    ugfx.area(100, 150, 50, 50, ugfx.BLACK)
    badge.eink_busy_wait()
    ugfx.flush()

def left():
    clear()
    ugfx.area(50, 100, 50, 50, ugfx.BLACK)
    badge.eink_busy_wait()
    ugfx.flush()

def reboot(wut):
  deepsleep.reboot()

snakeflut()
