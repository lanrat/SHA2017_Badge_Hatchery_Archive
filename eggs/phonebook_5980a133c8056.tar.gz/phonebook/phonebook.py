import ugfx, wifi, badge, deepsleep, re, sys
from time import sleep
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

set_message("Waiting for wifi...")
  
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

set_message("Got wifi loading data")

xml_data=None
try:
  url = "http://ifconfig.co/ip"
  r = requests.get(url)
  xml_data = r.text()
  r.close()
except:
  set_message("Unexpected error")
  sys.exit()

set_message("Got data. Parsing...")

exp=re.compile('.*?<extension>([0-9]+)</extension>.*?<name>(.*?)</name>', re.DOTALL);
data=exp.sub(r'\1;\2\n', xml_data)
data=re.sub('\n[^0-9].*', '', data)

for entry in data.split('\n'):
  extension = entry.split(';')[0]
  name = entry.split(';')[1]
  ugfx.clear()
  ugfx.string(10,10,extension+' -> '+name,"Robot_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()
  sleep(0.5)

ugfx.clear()
ugfx.string(10,10,"End","Robot_Regular12", 0)
ugfx.flush()
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)