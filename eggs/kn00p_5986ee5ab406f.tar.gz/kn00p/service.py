import badge, ugfx, time

def kn00p():
	badge.init()
	ugfx.init()

	ugfx.clear(ugfx.WHITE)
	ugfx.flush()


	badge.leds_init()
	badge.leds_enable()
	leds_array=[0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10]
	while 1==1:
		leds_array=[0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
		leds_array=[10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0,10,0,0,0]
		badge.leds_send_data(bytes(leds_array),24)
		time.sleep(5)
	y=5
	for x in range(1,5):
		light=255/y
		y=y-1
		leds_array=[0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light),0,0,0,int(light)]
		badge.leds_send_data(bytes(leds_array),24)
        time.sleep(0.2)
        badge.leds_disable()
        time.sleep(0.2)
        
	ugfx.string(45,35,"testing...","PermanentMarker36",ugfx.BLACK)
	ugfx.flush()
	time.sleep(3)
    
	leds_array=[185,6,57,0,154,211,73,0,126,44,82,0,77,91,219,0,106,8,154,0,87,192,214,0]
	badge.leds_send_data(bytes(leds_array),24)
	time.sleep(30)
	badge.leds_disable()

    
def setup():
    kn00p()

def loop():
    return 60*1000