import uos

def install():
    # We do want to be able to uninstall ourselves
    with open("/boot.py", "r") as f:
        with open("/rboot.py", "w") as r:
            r.write(f.read())
    with open("/boot.py", "w") as f:
        f.write("""\
import ugfx, time
try:
    badge.eink_png(0,0,'/lib/pixel_porn/dickbutt.png')
    time.sleep(5)
except:
    pass
__import__('pixel_porn')
        """)
            
def remove():
    with open("/rboot.py", "r") as f:
        with open("/boot.py", "w") as r:
            r.write(f.read())
