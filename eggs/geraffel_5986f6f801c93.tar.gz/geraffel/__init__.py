import ugfx, badge, appglue, deepsleep

def program_main():
    print("--- GERAFFEL APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    
    ugfx.input_attach(ugfx.JOY_UP, lambda pushed: appglue.start_app("") if pushed else False)
    ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.JOY_LEFT, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.JOY_RIGHT, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.BTN_A, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.BTN_B, lambda pushed: ugfx.flush() if pushed else False)
  
    try:
        badge.eink_png(0,0,'/lib/geraffel/geraffel.png')
    except:
        ugfx.string(0, 0, "GERAFFEL LOAD ERROR geraffel.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(24*3600*1000)
    appglue.start_app("") # Return home

# Start main application
program_main()