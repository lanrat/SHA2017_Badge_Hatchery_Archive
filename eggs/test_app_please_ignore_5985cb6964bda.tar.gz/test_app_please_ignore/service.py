import lenny_face_generator as lenny
import ugfx

def setup():
    pass

def loop():
    return 60*1000

def draw(at_y):
    ugfx.fill_circle(0, at_y, 5, ugfx.BLACK);

#    (x, y, w, h) = lenny.render_creation(
#            lambda w, h: (lenny.BADGE_EINK_WIDTH - w, at_y + h),
#            lenny.creation)
    return [60*1000, 5]
