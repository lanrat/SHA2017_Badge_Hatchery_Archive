import ugfx
import time
from math import sin,cos,floor,pi
import dialogs
import deepsleep

class Game:
    def __init__(self):

        self.SCREEN_Y = 126
        self.SCREEN_X = 295
        self.SPEED = 10
        self.ROTATION = pi/8
        self.FRAMERATE = 0.2

        self.surface = 0

        self.x = 30
        self.y = 30
        self.r = 0

        ugfx.init()

        ugfx.input_init()
        ugfx.input_attach(ugfx.JOY_LEFT, self.take)
        ugfx.input_attach(ugfx.JOY_RIGHT, self.add)
        ugfx.input_attach(ugfx.BTN_START, self.exit)

    def exit(self, press):
        deepsleep.reboot()

    def draw_line(self, x1, y1, x2, y2):
        x1_ = int(floor(self.x+(x1-self.x)*cos(self.r) - (y1-self.y)*sin(self.r)))
        y1_ = int(floor(self.y+(y1-self.y)*cos(self.r) + (x1-self.x)*sin(self.r)))
        x2_ = int(floor(self.x+(x2-self.x)*cos(self.r) - (y2-self.y)*sin(self.r)))
        y2_ = int(floor(self.y+(y2-self.y)*cos(self.r) + (x2-self.x)*sin(self.r)))
        ugfx.line(x1_,y1_,x2_,y2_,ugfx.BLACK)

    def draw_ship(self):
        ugfx.clear(ugfx.WHITE)

        self.draw_line(self.x,   self.y, self.x-10, self.y-5)
        self.draw_line(self.x,   self.y, self.x-10, self.y+5)
        self.draw_line(self.x-7, self.y, self.x-10, self.y-5)
        self.draw_line(self.x-7, self.y, self.x-10, self.y+5)

        ugfx.flush()


    def add(self, press):
        self.r += self.ROTATION

    def take(self, press):
        self.r -= self.ROTATION

    def select_surface(self):
        options = ["4D flat torus","flat Klein bottle"]
        surface = None
        #surface = dialogs.prompt_option(options, text="Please choose the surface you want to play Asteroids on:")
        for i,s in enumerate(options):
            if surface == s:
                self.surface = i

    def start(self):
        self.select_surface()

        self.main_loop()

    def main_loop(self):
        while True:
            self.x += self.SPEED*cos(self.r)
            self.y += self.SPEED*sin(self.r)

            self.wrap()

            self.draw_ship()
            time.sleep(self.FRAMERATE)

    def wrap(self):
        if self.surface == 0: # 4D flat torus
            if self.y < -5:
                self.y += self.SCREEN_Y+8
            if self.y > self.SCREEN_Y+5:
                self.y -= self.SCREEN_Y+8
            if self.x < -5:
                self.x += self.SCREEN_X+8
            if self.x > self.SCREEN_X+5:
                self.x -= self.SCREEN_X+8

        if self.surface == 1: # ?D flat Klein bottle
            if self.y < -5:
                self.y += self.SCREEN_Y+8
                self.x = self.SCREEN_X - self.x
                self.r = pi - self.r
            if self.y > self.SCREEN_Y+5:
                self.y -= self.SCREEN_Y+8
                self.x = self.SCREEN_X - self.x
                self.r = pi - self.r
            if self.x < -5:
                self.x += self.SCREEN_X+8
            if self.x > self.SCREEN_X+5:
                self.x -= self.SCREEN_X+8

