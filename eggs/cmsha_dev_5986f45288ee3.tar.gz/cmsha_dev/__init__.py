import ugfx, wifi, appglue, time, badge
import urequests as requests

badge.init()
badge.leds_enable()

options = None
data = {}

def trim_size(text, width):
    str_len = ugfx.get_string_width(text, "Roboto_Regular12")
    if str_len > width:
        return text[:(width-2)]
    return text

def populate_menu():
    global options
    global data

    width = int(ugfx.width()/2)

    if options:
        ugfx.fill_rounded_box(0, 0, width, ugfx.height(), ugfx.WHITE, ugfx.WHITE)
        ugfx.string(0, int(ugfx.height()/2)-22, "Checking Colours...", "PermanentMarker22", ugfx.BLACK)
        ugfx.flush()
        options.destroy()

    apiurl = "https://whoopsie.nl/SHA2017/test.json"
    data = requests.get(apiurl).json()
    data = {trim_size(entry['node'], width): entry['colour'] for entry in data.values() if entry['node']}

    options = ugfx.List(0, 0, width, ugfx.height())

    for key in data.keys():
        options.add_item(key)
    ugfx.flush()

def select_item(pressed):
    global options
    if not pressed:
        return

    selected = options.selected_text()
    
    try:
        item = data[selected]
        
    except KeyError:
        item = "STILL Unknown Anyway"

    ugfx.fill_rounded_box(148,23,148,23, ugfx.WHITE, ugfx.WHITE)
    ugfx.string_box(148,23,148,23, item, "Roboto_BlackItalic12", ugfx.BLACK, ugfx.justifyCenter)
    badge.leds_send_data(bytes([item, 10, item, 10, item, 10, item, 10, item, 10, item, 10]), 24)
    
    ugfx.flush()

def main():
    wifi.init()
    
    ugfx.clear(ugfx.WHITE);
    ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
    ugfx.flush()

    # Wait for WiFi connection
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
  
    ugfx.input_init()
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

    ugfx.string_box(148,0,148,26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(148,23,148,23, "Colouring", "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(148,48,148,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

    # The line under the text
    str_len = ugfx.get_string_width("Colouring","PermanentMarker22")
    line_begin = 148 + int((148-str_len)/2)
    line_end = str_len+line_begin
    ugfx.line(line_begin, 46, line_end, 46, ugfx.BLACK)

    # The cursor past the text
    cursor_pos = line_end+5
    ugfx.line(cursor_pos, 22, cursor_pos, 44, ugfx.BLACK)

    # Instructions
    ugfx.line(148, 78, 296, 78, ugfx.BLACK)
    ugfx.string_box(148,78,148,18, " A: Refresh status", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(148,92,148,18, " B: Return to home", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.flush()

    populate_menu()
    
    ugfx.input_attach(ugfx.JOY_UP, select_item)
    ugfx.input_attach(ugfx.JOY_DOWN, select_item)
    ugfx.input_attach(ugfx.BTN_A, lambda pushed: populate_menu() if pushed else 0)
    ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.home() if pushed else 0)

main()