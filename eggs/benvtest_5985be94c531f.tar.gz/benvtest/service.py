import badge
import time
import dialogs
import ugfx

def setup():
    global serviceEnabled
    global serviceText
    serviceText = badge.nvs_get_u8('hometext', 'text', '')
    serviceEnabled = badge.nvs_get_u8('hometext', 'service', 0)
    if (serviceEnabled<1):
        print("[HOMETEXT] Disabled! Please enable in the app!")

def loop():
    # Updates not really needed .... for now.
    return 600000

def draw(x, y):
    # t = easyrtc.string()
    # ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    global serviceEnabled
    global serviceText
    if (serviceEnabled<1):
        return [600000, 0]
    ugfx.string(0,y - 12,serviceText,"PermanentMarker36",ugfx.BLACK)
    ugfx.flush()
    return [600000, 72]

