import ugfx, badge, math
#import deepsleep

nick = badge.nvs_get_str("owner","name", "Hacker1337")

#ugfx.init()

#Nice black screen
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()

pointCount = 10
freqX = 11
freqY = 13
phi = 90
margin = 5
width = 296
height = 128

factorX = width/2-margin
factorY = height/2-margin

for c in range(pointCount):
	angle=2*math.pi*(c/(pointCount*math.pi/180))
	x = math.sin(angle*freqX + (phi*math.pi/180))
	y = math.sin(angle*freqY)
	x = int(x * factorX)
	y = int(y * factorY)
	ugfx.pixel(x+int(width/2), y+int(height/2), ugfx.WHITE)

ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.WHITE, ugfx.justifyCenter)
ugfx.flush()
badge.eink_busy_wait()

#deepsleep.start_sleeping(60000)