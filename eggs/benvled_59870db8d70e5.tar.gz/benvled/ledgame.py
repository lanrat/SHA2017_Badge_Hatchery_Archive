import ugfx, badge, time, random
# import appglue

#def action_home(pressed):
#    if (pressed):
#        appglue.home()

def action_up(pressed):
    if pressed:
        print("[LEDGAME] UP")
        checkLedHit("UP")

def action_down(pressed):
    if pressed:
        print("[LEDGAME] DOWN")
        checkLedHit("DOWN")

def action_left(pressed):
    if pressed:
        print("[LEDGAME] LEFT")
        checkLedHit("LEFT")

def action_right(pressed):
    if pressed:
        print("[LEDGAME] RIGHT")
        checkLedHit("RIGHT")

def action_select(pressed):
    if pressed:
        print("[LEDGAME] SELECT")
        checkLedHit("SELECT")

def action_start(pressed):
    if pressed:
        print("[LEDGAME] START")
        checkLedHit("START")

def action_b(pressed):
    if pressed:
        print("[LEDGAME] B")
        checkLedHit("B")

def action_a(pressed):
    if pressed:
        print("[LEDGAME] A")
        checkLedHit("A")

def action_instructions(pressed):
    if pressed:
        print("[LEDGAME] Instructions request")
        instructions()

def instructions():
    print("[LEDGAME] instructions.")
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"Instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"A random LED will light up","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"The objective is to press the corresponding button before it dies out","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"Have fun! Press A/B to start, SELECT to quit.","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()

def program_init():
    print("[LEDGAME] init.")
    ugfx.init()
    ugfx.input_init()
    badge.init()
    badge.leds_init()
    badge.vibrator_init()
    global leddata
    leddata = bytearray([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

def action_quit(pressed):
    if pressed:
        print("[LEDGAME] Quit.")
        import launcher

def action_start_game(pressed):
    if pressed:
        print("[LEDGAME] Start game!")
        game_start()

def action_start(pressed):
    if pressed:
        print("[LEDGAME] Start!")
        game_start()

def leds_off():
    badge.leds_send_data(bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), 24)

def leds_on(brightness = 255):
    badge.leds_send_data(bytes([brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness, brightness]), 24)

def light_led(led, r, g, b, w):
    if led > 5:
        print("[LEDGAME] BUG - NO SUCH LED " + str(led))
        return
    global leddata
    if len(leddata) != 24:
        leddata = bytearray([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    print("[LEDGAME] Led " + str(led) + " to RGBW %d/%d/%d/%d" % (r, g, b, w))
    # GRBW
    leddata[led * 4 + 0] = g
    leddata[led * 4 + 1] = r
    leddata[led * 4 + 2] = b
    leddata[led * 4 + 3] = w
    badge.leds_send_data(bytes(leddata), len(leddata))

def checkLedHit(button):
    # Check button map and if led was active
    global lives
    global score
    global ledsactive
    global ledsmap
    global lastbuttontime
    if lives <= 0:
        print("[LEDGAME] Lives 0 -- no score check.")
        return
    lednumber = ledsmap[button]
    if ledsactive[lednumber] > 0:
        print("[LEDGAME] SCORE! Button " + button + " mapped to led " + str(lednumber) + " which was active for " + str(ledsactive[lednumber]) + " points!")
        score = score + ledsactive[lednumber]
        ledsactive[lednumber] = 0
        # TODO: Bonus system / combo? Light more leds?
    else:
        print("[LEDGAME] MISS! Button " + button + " mapped to led " + str(lednumber) + " which was NOT active! Lost 1 point!")
        score = score - 1
    # Detect last button press
    lastbuttontime = time.time()

def game_start():
    print("[LEDGAME] Game start.")
    # rehook buttons for game
    ugfx.input_attach(ugfx.BTN_B, action_b)
    ugfx.input_attach(ugfx.BTN_A, action_a)
    ugfx.input_attach(ugfx.BTN_SELECT, action_select)
    ugfx.input_attach(ugfx.BTN_START, action_start)

    # Bookkeeping
    global score
    global ledtime
    global ledsactive
    global ledsmap
    global lives
    global lastbuttontime
    score = 0
    lastbuttontime = 0
    lives = 3
    ledtime = 2
    ledsactive = [0] * 6
    ledsmap = {
        "LEFT"  : 0,
        "RIGHT" : 1,
        "SELECT": 2,
        "START" : 3,
        "B"     : 4,
        "A"     : 5
    }

    # Draw button connections
    ugfx.clear(ugfx.BLACK)
    # We'll assume 296 for now. 296 / 6 =~ 49
    ugfx.line(03, 0, 03, ugfx.height(), ugfx.WHITE)
    ugfx.line(50, 0, 50, ugfx.height(), ugfx.WHITE)
    ugfx.line(111, 0, 111, ugfx.height(), ugfx.WHITE)
    ugfx.line(163, 0, 163, ugfx.height(), ugfx.WHITE)
    ugfx.line(219, 0, 219, ugfx.height(), ugfx.WHITE)
    ugfx.line(280, 0, 296, ugfx.height(), ugfx.WHITE)
    ugfx.flush()

    # Main loop
    while lives > 0:
        # Light a random LED
        led = random.randint(0,5)
        ledsactive[led] = 10
        light_led(led, 255, 255, 255, 255)
        ugfx.flush()
        time.sleep(ledtime / 8)
        ledsactive[led] = 5
        light_led(led, 128, 128, 128, 128)
        ugfx.flush()
        time.sleep(ledtime / 4)
        ledsactive[led] = 2
        light_led(led, 128, 64, 64, 0)
        ugfx.flush()
        time.sleep(ledtime / 2)
        ledsactive[led] = 1
        light_led(led, 256, 0, 0, 0)
        ugfx.flush()
        time.sleep(ledtime / 8)
        ledsactive[led] = 0
        light_led(led, 0, 0, 0, 0)
        badge.vibrator_activate(1)
        lives = lives - 1
    game_over()

def game_over():
    global score
    print("[LEDGAME] main menu.")
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"GAME OVER","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"Start : instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"Select: Quit game ","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"A/B   : Start new game","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,80,280,50,"You scored " + str(score) + " points.", "Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()
    leds_off()
    leds_on()
    badge.vibrator_activate(7)
    time.sleep(0.1)
    leds_off()
    badge.vibrator_activate(3)
    time.sleep(0.1)
    leds_on()
    badge.vibrator_activate(7)
    time.sleep(0.1)
    leds_off()
    badge.vibrator_activate(0)
    ugfx.input_attach(ugfx.BTN_B, action_start_game)
    ugfx.input_attach(ugfx.BTN_A, action_start_game)

def program_main_menu():
    print("[LEDGAME] main menu.")
    ugfx.input_attach(ugfx.JOY_UP, action_up)
    ugfx.input_attach(ugfx.JOY_DOWN, action_down)
    ugfx.input_attach(ugfx.JOY_LEFT, action_left)
    ugfx.input_attach(ugfx.JOY_RIGHT, action_right)
    ugfx.input_attach(ugfx.BTN_SELECT, action_quit)
    ugfx.input_attach(ugfx.BTN_START, action_instructions)
    ugfx.input_attach(ugfx.BTN_B, action_start_game)
    ugfx.input_attach(ugfx.BTN_A, action_start_game)
    # ugfx.input_attach(ugfx.BTN_B, action_b)
    # ugfx.input_attach(ugfx.BTN_A, action_a)
    ugfx.clear(ugfx.BLACK)
    ugfx.string_box(0,0,300,20,"Menu","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,20,280,20,"Start: instructions","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,30,280,45,"Select: Quit game ","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.string_box(0,65,280,50,"B or A: Start game","Roboto_Regular12",ugfx.WHITE,ugfx.justifyCenter)
    ugfx.flush()
    while True:
        pass

# Start game
program_init()
program_main_menu()
