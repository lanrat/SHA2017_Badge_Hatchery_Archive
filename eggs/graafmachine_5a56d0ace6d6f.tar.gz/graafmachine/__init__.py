import easywifi, easydraw, woezel, badge, machine, ugfx, time
from time import ticks_ms, ticks_diff, sleep_ms

starttime = ticks_ms()
amount = 0
newamount = 0

easywifi.enable(True)
if easywifi.state == True:
  easydraw.msg("Checking for updates")
  try:
    woezel.install("Graafmachine")
    easydraw.msg("Updated! Rebooting now!")
    badge.eink_busy_wait()
    machine.deepsleep(1)
  except:
    easydraw.msg("No update available.")
    easywifi.enable(False)

def update_amount():
    ugfx.clear(ugfx.BLACK); ugfx.flush(); time.sleep_ms(20);
    ugfx.clear(ugfx.WHITE); ugfx.flush(); time.sleep_ms(20);
    ugfx.string_box(0, 25, 296, 38, "%.2f euro" % amount, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter);

while True:
    x = ticks_ms()
    elapsed = int(ticks_diff(ticks_ms(), starttime) / 1000);
    newamount = 2.5 * (1 + int(int(elapsed / 60) / 15))
    hour = int(elapsed / 3600)
    elapsed = elapsed % 3600
    min = int(elapsed / 60)
    sec = elapsed % 60
    s = "%02d:%02d:%02d" % (hour, min, sec)
    ugfx.flush()
    if newamount != amount:
        amount = newamount
        update_amount();
    ugfx.area(100, 70, 100, 22, ugfx.BLACK if sec % 2 else ugfx.WHITE);
    ugfx.string_box(100, 70, 100, 22, s, "Roboto_Regular18", ugfx.WHITE if sec % 2 else ugfx.BLACK, ugfx.justifyCenter)

    sleep_ms(1000 - ticks_diff(ticks_ms(), x))