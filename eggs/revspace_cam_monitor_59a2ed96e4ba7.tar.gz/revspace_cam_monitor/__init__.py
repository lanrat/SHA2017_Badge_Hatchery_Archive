import easywifi, easydraw, urandom, gc, ugfx, badge
from time import *

easydraw.msg("Connecting to WiFi", title = 'Still Connecting Anyway...', reset = True)
easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(5000)

easydraw.msg("Connecting to MQTT")

from umqtt.simple import MQTTClient

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    print((topic, msg))
    
    gluurders=list(map(int, msg.decode('utf-8').split(" ")[:]))
    
    ugfx.clear(ugfx.WHITE)
    
    if(gluurders[0]>0):
        ugfx.string(0,0,"Gluurders: "+str(gluurders[0]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(0,22,"Cam01: "+str(gluurders[1]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(0,44,"Cam02: "+str(gluurders[2]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(0,66,"Cam03: "+str(gluurders[3]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(0,88,"Cam04: "+str(gluurders[4]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(0,110,"Cam05: "+str(gluurders[5]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(148,22,"Cam06: "+str(gluurders[6]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(148,44,"Cam07: "+str(gluurders[7]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(148,66,"Cam08: "+str(gluurders[8]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(148,88,"Cam09: "+str(gluurders[9]),"Roboto_Black22",ugfx.BLACK)
        ugfx.string(148,110,"Cam10: "+str(gluurders[10]),"Roboto_Black22",ugfx.BLACK)
    else:
        ugfx.flush()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.string(20,53,"Still Peeping Anyway","PermanentMarker22", ugfx.BLACK)
    ugfx.flush()

def main(server="revspace.nl"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"revspace/cams")
    easydraw.msg("MQTT Connected", title = 'Still MQTT Anyway...', reset = True)
    c.check_msg()
    while True:
        gc.collect()
        c.check_msg()
        sleep(1)
    c.disconnect()

main()