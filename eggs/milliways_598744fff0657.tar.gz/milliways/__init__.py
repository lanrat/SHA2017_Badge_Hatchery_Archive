import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.display_image(int(ugfx.width()/2. - 62.5),int(ugfx.height()/2. - 62.5), "/lib/milliways/milliways.png")

ugfx.flush()