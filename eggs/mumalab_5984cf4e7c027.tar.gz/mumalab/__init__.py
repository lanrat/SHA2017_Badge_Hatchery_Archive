import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

owner = badge.nvs_get_str("owner")

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)

ugfx.string(100, 50,  owner, "PermanentMarker22", ugfx.BLACK)

badge.eink_png(10,63,'/lib/mumalab/logo.png')
ugfx.flush()
