# NYANCAT APPLICATION
# SHOWN ONCE AFTER SETUP

import ugfx, badge, appglue, time

def program_main():
    print("--- NYANCAT APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    try:
        badge.eink_png(0,0,'/lib/nyancat/nyancat.png')
    except:
        ugfx.string(0, 0, "NYANCAT LOAD ERROR nyancat.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    time.sleep(5)
    appglue.start_app("") # Return home

# Start main application
program_main()