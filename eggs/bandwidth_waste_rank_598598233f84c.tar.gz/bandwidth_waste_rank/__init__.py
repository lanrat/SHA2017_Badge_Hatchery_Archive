import ugfx
import network
import time
import badge
try:
    import usocket as socket
except:
    import socket
from struct import unpack

HOST = "sha2017.schaeffer.tk"
PORT = 2017
FONT = "PermanentMarker22"
FONTSIZE = 22

rank = -1
score = 0
total = 0

def print_status(MSG):
    global rank
    global score
    global total
    ugfx.clear(ugfx.WHITE)
    #ugfx.string(0, 0, MSG, FONT, ugfx.BLACK)
    ugfx.string(0, 1*FONTSIZE,"Rank: %d"%(rank), FONT, ugfx.BLACK)
    ugfx.string(0, 2*FONTSIZE,"Score: %d"%(score), FONT, ugfx.BLACK)
    ugfx.string(0, 3*FONTSIZE,"total bytes: %d"%(total), FONT, ugfx.BLACK)
    #ugfx.flush()


def btn_event(pressed):
    global nick
    global rank
    global score
    global total

    if not pressed: return
    print_status("SENDING DATA")
    MESSAGE = bytearray(str(nick))
    sock.sendto(MESSAGE, remote_addr)
    print_status("RECEIVING DATA")
    data, addr = sock.recvfrom(1024)
    rank, score, total = unpack('!QQQ', data)
    print_status("DONE")

buttons = [ugfx.JOY_UP, ugfx.JOY_DOWN, ugfx.JOY_LEFT, ugfx.JOY_RIGHT,
    ugfx.BTN_SELECT, ugfx.BTN_START, ugfx.BTN_A, ugfx.BTN_B]

badge.init()
badge.eink_init()
ugfx.init()
ugfx.clear(ugfx.WHITE)

sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.scan()
sta_if.connect("SHA2017-insecure")

while not sta_if.isconnected():
    time.sleep(0.1)

#ugfx.set_lut(ugfx.LUT_FASTEST)

ugfx.input_init()
for button in buttons:
    ugfx.input_attach(button, btn_event)

mac = network.WLAN().config('mac')
nick = b"XX" + mac
#nick = badge.nvs_get_str("owner","name", "Hacker1337")
ugfx.string(0, 0, "Press button to", FONT, ugfx.BLACK)
ugfx.string(0, FONTSIZE, "waste bandwidth", FONT, ugfx.BLACK)
ugfx.flush()

local_addr = socket.getaddrinfo("0.0.0.0", PORT)[0][-1]
remote_addr = socket.getaddrinfo(HOST, PORT)[0][-1]
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind(local_addr)