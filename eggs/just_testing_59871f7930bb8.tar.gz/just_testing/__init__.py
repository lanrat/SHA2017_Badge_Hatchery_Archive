import ugfx, badge,time
from random import randint

# GLOBALS
led = 0

def clear_ghosting():
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()

badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()

badge.leds_init()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def up_pushed(pushed):
	print("up")
	if(pushed):
		led_rainbow()

def down_pushed(pushed):
	print("down")
	if(pushed):
		display_troll()

def re_draw():
	print("redraw")

def led_rainbow():
	count = 0
	leds_array = bytes(24)
	badge.leds_enable()
	while (count < 10):
		print("Counter: %d" % (count))
		#ugfx.string_box(0,60,296,26, "counter: " + str(count), "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyLeft)
		badge.leds_send_data(leds_array)
		#ugfx.flush()
		time.sleep(0.1)
		leds_array = leds_array[4:] + bytes([randint(128, 255), randint(0, 255), randint(0, 128), 0])
		badge.leds_send_data(leds_array)
		time.sleep(0.1)
		leds_array = leds_array[4:] + bytes([randint(0, 128), randint(0, 255), randint(128, 255), 0])
		count = count + 1
		time.sleep(0.1)
	badge.leds_disable()

def display_troll():
	clear_ghosting()
	ugfx.string_box(0,10,296,26, "Just testing anyway", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
	ugfx.string_box(0,40,296,26, "test - test - test", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyLeft)
	badge.eink_png(180,10,'/lib/just_testing/logo.png')
	ugfx.flush()

display_troll()

ugfx.input_attach(ugfx.BTN_A, display_troll)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_START, go_home)
ugfx.input_attach(ugfx.BTN_SELECT, go_home)
ugfx.input_attach(ugfx.JOY_UP, up_pushed)
ugfx.input_attach(ugfx.JOY_DOWN, down_pushed)
ugfx.input_attach(ugfx.JOY_LEFT, go_home)
ugfx.input_attach(ugfx.JOY_RIGHT, go_home)