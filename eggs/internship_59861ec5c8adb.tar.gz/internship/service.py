import badge, ugfx, time
import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1

def check_if_locked():
    badge.vibrator_activate(0xFF)
    t = requests.get("http://project1.online/sha2017-plsdonthackme/show.php?id=80&type=down")
    badge.vibrator_activate(0xFF)
    if t.content.startswith('3'):
        global _continue
        _continue = 0

def setup():
    ugfx.init()
    badge.init()
    ugfx.flush()  
    check_if_locked()
         
def loop():
    global _continue
    while (_continue):
        time.sleep(10) 
        leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
        badge.leds_enable()
     
    leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
    badge.leds_send_data(leds_array)    
    badge.leds_enable()
    return 10

def draw(x,y=2):
    ugfx.clear(ugfx.BLACK)
    ugfx.display_image(0, 178, '/lib/Internship/r3.png')
    ugfx.string(12, 12, "YOUR BADGE HAS", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 25, "  BEEN LOCKED.", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 37, "To unlock your badge", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 49, "find us at ???", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 62, "Your unique key for", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 75, "decryption is ????????", "Roboto_Regular12", ugfx.WHITE)
    return 296