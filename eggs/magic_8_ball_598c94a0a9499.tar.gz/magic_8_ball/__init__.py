import easydraw, ugfx, appglue

easydraw.msg("","Magic 8-Ball", True)

def home(pressed):
  if pressed:
    appglue.home()
    
def program_main():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)
    ugfx.string(20, 80, "Testing", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
  
def eightball_simple():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Magic 8-Ball | Simple", "PermanentMarker22", ugfx.BLACK)
    ugfx.string(0, 25, "Not implemented yet!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()

def eightball_advanced():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Magic 8-Ball | Advanced", "PermanentMarker22", ugfx.BLACK)
    ugfx.string(0, 25, "Not implemented yet!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    
def program_init():
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, home)
    ugfx.input_attach(ugfx.BTN_A, eightball_simple)
    ugfx.input_attach(ugfx.BTN_B, eightball_advanced)
    program_main()

program_init()