import ugfx, badge
import time
from random import randint

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

badge.init()
badge.leds_init()
badge.leds_enable()

def clearGhosting():
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
       
def rainbow():
    leds_array = bytes(24)

    while True:
        badge.leds_send_data(leds_array)
        time.sleep(0.1)
        leds_array = leds_array[4:] + bytes([randint(128, 255), randint(0, 255), randint(0, 128), 0])
        badge.leds_send_data(leds_array)
        time.sleep(0.1)
        leds_array = leds_array[4:] + bytes([randint(0, 128), randint(0, 255), randint(128, 255), 0])

clearGhosting()
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, rainbow)
badge.eink_png(0,0,'/lib/poflove/pofloveshafancy.png')
ugfx.flush(ugfx.GREYSCALE)