from angel import make_qr
import badge

qr = None

def setup():
	name="angel-{}".format(badge.nvs_get_str("owner", "name", ""))
	qr = make_qr(name)

def loop():
	return 300000

def draw(y, sleep=2):
	height=draw_qr(qr, y)
	return [300000, height]