import ugfx, gc, wifi, badge, time
import urequests as requests

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
#ugfx.set_lut(ugfx.GREYSCALE)
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
badge.eink_png(0,0,'/lib/TestGraph/basescreen.png')
ugfx.string(10,60,"Waiting for wifi...","Roboto_Regular22", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
badge.eink_png(0,0,'/lib/TestGraph/basescreen.png')
ugfx.string(10,60,"Getting uRadMonitor data...","Roboto_Regular22", 0)
ugfx.string(40,100,"https://uradmonitor.com/","Roboto_Regular22", 0)
ugfx.flush()

def show_graph(output):
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    gc.collect()
    badge.eink_png(0,0,output.content)
    ugfx.flush()

def show_screen(output):
    ugfx.set_lut(ugfx.GREYSCALE)
    badge.eink_png(0,0,'/lib/TestGraph/basescreen3.png')
    radi = int(output[0]['cpm']) * 3 / 1000
    ugfx.string_box(0,78,296,52, str(output[0]['temperature'])+' '+str(output[0]['humidity'])+' '
                    +str(output[0]['pm25']), "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,78,296,52, str(output[0]['voc'])+' '+str(output[0]['pressure']), "PermanentMarker22", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(88,22,90,26, str(radi), "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.flush()

def refresh_data(pushed):
    if(pushed):
        get_data()

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)
        
#Json request info
headers = {'X-User-id': 'sha2017', 'X-User-hash': 'badge'}
url = 'https://data.uradmonitor.com/api/v1'
    
def get_data():
    r = requests.get(url+'/devices/64000025/all/last', headers=headers)
    gc.collect()
    global output
    output = r.json()
    r.close()
    show_screen(output)
    
#unit = {0: '64000024', 1: '64000025', 2: '82000065'}
unit_val = '64000025'
duration = '36000'
counter_meas = 5
screen_1 = url+'/chart/'+unit_val+'/temperature/'+duration
screen_2 = url+'/chart/'+unit_val+'/pressure/'+duration
screen_3 = url+'/chart/'+unit_val+'/humidity/'+duration
screen_4 = url+'/chart/'+unit_val+'/pm25/'+duration
screen_5 = url+'/chart/'+unit_val+'/voc/'+duration
screen_6 = url+'/chart/'+unit_val+'/cpm/'+duration
#screen_7 = url+'/chart/'+unit_val+'/formaldehyde/'+duration
#screen_8 = url+'/chart/'+unit_val+'/carbondioxide/'+duration

screen = {0: screen_1, 1: screen_2, 2: screen_3, 3: screen_4, 4: screen_5, 5: screen_6} #, 6: screen_7, 7: screen_8}

def show_left(pushed):
    global counter_meas
    if pushed:
        counter_meas = counter_meas - 1
        if counter_meas < 0:
            counter_meas = 5
        output = requests.get(screen[counter_meas], headers=headers)
        gc.collect
        show_graph(output)
        
def show_right(pushed): 
    global counter_meas
    if pushed:
        counter_meas = counter_meas + 1
        if counter_meas > 5:
            counter_meas = 0
        output = requests.get(screen[counter_meas], headers=headers)
        gc.collect
        show_graph(output)
        
get_data()

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_START, go_home)
#ugfx.input_attach(ugfx.BTN_SELECT, go_home)
#ugfx.input_attach(ugfx.JOY_UP, up_pushed)
#ugfx.input_attach(ugfx.JOY_DOWN, down_pushed)
ugfx.input_attach(ugfx.JOY_LEFT, show_left)
ugfx.input_attach(ugfx.JOY_RIGHT, show_right)