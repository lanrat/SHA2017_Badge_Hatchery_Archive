import urequests, appglue, ugfx, badge, easydraw, wifi, time

# A lot of credit goes to the maker(Klondike) of the porn app, I used it as an example.

easydraw.msg('', 'waiting for wifi')

wifi.init()
while not wifi.sta_if.isconnected():
    time.sleep(0.1)

req = urequests.get('https://upload.wikimedia.org/wikipedia/en/c/c1/Zombocom.png')
ugfx.clear()
badge.eink_png(0,0,req.content)
ugfx.flush()
req.close()

while True:
	ugfx.input_attach(ugfx.BTN_SELECT, lambda x: appglue.home() if x else '')