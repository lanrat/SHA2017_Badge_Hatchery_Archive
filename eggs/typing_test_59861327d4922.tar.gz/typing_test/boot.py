import badge 
badge.init()
ugfx.ugfx_demo("funny")