### Author: Frans Faase
### Category: Art animation
### License: MIT
### Appname: P.Struycken

import ugfx
import urandom
import time
import appglue
import badge


class PStruycken:
    def __init__(self):
        self.grid = [[0] * 12 for _ in range(25)]
        ks1 = [[4,0,0,1,1,3],[4,0,1,1,3,3],[5,1,1,1,3,3,3,7],[4,1,3,3,7,7],[3,3,3,7,7],[2,3,7,15],[3,3,7,7,7,7,7,15,15,15,15]]
        ks1a = [[4,0,0,1,1,3],[4,0,0,1,1,1,3,3,3,3],[6,1,1,1,1,3,3,3,3,7],[5,1,3,3,3,7,7,7],[3,3,3,3,7,7,15],[3,3,7,7,7,7,15,15,15]]
        ks2 = [[25,1,2,4,8]]
        ks3 = [[25,6,12,10]]
        ks4 = [[5,1,2,2,2,2,2,2,2,2,8,7,11],[5,1,1,2,2,2,2,2,8,7,7,11,11],[5,1,2,8,8,7,7,7,7,11,11,11,11],[5,1,8,3,9,7,7,7,7,7,11,11,11,11,11],[5,8,3,3,3,9,9,9,7,7,7,11,11,11]]
        ks4a = [[5,1,1,1,1,1,1,1,1,8,8,4,13,11],[5,1,1,1,1,4,4,8,8,13,13,11,11,11],[5,1,1,4,4,8,13,13,13,11,11,11,11],[5,4,8,12,13,13,13,13,13,13,13,11,11,11,11],[1,8,9,12,13,13,13,13,13,13,11,11,11,11,11],[4,4,12,12,12,9,9,9,13,13,13,11,11,11]]
        self.kss = [ks1,ks1a,ks2,ks3,ks4,ks4a]
        self.curks = 1
        self.arrow_pressed = False
        
        badge.init()
        ugfx.init()
        ugfx.input_init()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        font = "Roboto_Regular12"
        ugfx.string(5,5,"Animation based on Komputerstrukturen 1969 by",font,ugfx.BLACK)
        ugfx.string(5,20,"Peter Struycken, Dutch artist most famous for",font,ugfx.BLACK)
        ugfx.string(5,35,"designing the Queen Beatrix stamp. He was one",font,ugfx.BLACK)
        ugfx.string(5,50,"of the first artist using computer programs.",font,ugfx.BLACK)
        ugfx.string(50,100,"[A: start, LEFT,RIGHT: switch]",font,ugfx.BLACK)
        ugfx.flush()
        ugfx.input_attach(ugfx.BTN_A, lambda pressed: self.animate(pressed))
        ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: self.right(pressed))
        ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: self.left(pressed))
        ugfx.input_attach(ugfx.BTN_START, lambda pressed: self.exitapp(pressed))
        
        while True:
            time.sleep_ms(200)
    
    def keypress(keyname):
        ugfx.area(0,0,10,10,ugfx.WHITE)
        ugfx.string(0,0,keyname,"Roboto_Regular12",ugfx.BLACK)
        ugfx.flush()
    
    def animate(self,pressed):
        if (pressed==False):
            return
        self.arrow_pressed = False
        
        def setgrid(x,y,val):
            if(val):
                ugfx.area(268-x*5, 2+y*5,5,5,ugfx.BLACK)
            else:
                ugfx.area(268-x*5, 2+y*5,5,5,ugfx.WHITE)
        def setgrid4(x,y,val):
            setgrid(x,y,val&1==1)
            setgrid(x+1,y,val&2==2)
            setgrid(x+1,y+1,val&4==4)
            setgrid(x,y+1,val&8==8)
        def value(x,ks):
            i = 0
            for i in range(len(ks)):
                if x < ks[i][0]:
                    return ks[i][1 + urandom.getrandbits(30) % (len(ks[i])-1)]
                x -= ks[i][0]
            return 0
        
        while True:     
            for x in range(25):
                for y in range(12):
                    self.grid[x][y] = value(x,self.kss[self.curks])
            ugfx.clear(ugfx.WHITE)
            self.keypress("S")
            for x in range(25):
                for y in range(12):
                    setgrid4(2*x,2*y,self.grid[x][y])
            ugfx.flush()
            time.sleep_ms(300)
            while (self.arrow_pressed == False):
                x = urandom.getrandbits(30) % 25
                y = urandom.getrandbits(30) % 12
                newval = value(x,self.kss[self.curks])
                if self.grid[x][y]!=newval:
                    self.grid[x][y] = newval 
                    setgrid4(2*x,2*y,newval)
                    ugfx.flush()
                    time.sleep_ms(300)
    
    def right(self,pressed):
        if (pressed==False):
            return
        self.keypress("R")
        self.curks = (self.curks+1) % len(self.kss)
        self.arrow_pressed = True
    
    def left(self,pressed):
        if (pressed==False):
            return
        self.keypress("L")
        self.curks = (self.curks+len(self.kss)-1) % len(self.kss)
        self.arrow_pressed = True
    
    def exitapp(self,pressed):
        if (pressed==False):
            return
        self.keypress("E")
        time.sleep(2)
        appglue.home()

pstruycke = PStruycken()