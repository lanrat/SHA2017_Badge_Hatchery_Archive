import buienradar

buienradar.Buienradar()
