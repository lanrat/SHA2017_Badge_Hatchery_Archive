### Fahrplan Egg
### Author: f0x
### License: GPLv3


import ugfx, badge


display_width  = 295 
display_height = 128
line_width     = 3

column_width = (display_width - 2*line_width)/3

badge.eink_init()
ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()


ugfx.thickline(column_width, 0, column_width, display_height, ugfx.BLACK, line_width, 5)
ugfx.thickline(2*column_width, 0, 2*column_width, display_height, ugfx.BLACK, line_width, 5)
ugfx.flush()
