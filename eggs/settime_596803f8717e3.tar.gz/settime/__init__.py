from setclock import settime
