import math
import urequests
import ugfx

SHA_LAT = 52.28
SHA_LON =  5.53

TS_WIDTH = 32
TS_HEIGHT = 14

BUIENRADAR_URL = 'https://br-gpsgadget-new.azurewebsites.net/data/raintext?lat=%.2f&lon=%.2f' % (SHA_LAT, SHA_LON)

def _raw_to_mm(raw):
    raw = int(raw)
    if raw == 0: return 0.0
    return 10 ** ((raw - 109) / 32)

def get_downpour():
    """Returns a LUT for the downpour over the next 2 hours.

    Return value is a list of pairs of the form ('hh:mm', millimeters)
    """
    try:
        resp = urequests.get(BUIENRADAR_URL)
        data = []
        for line in resp.text.splitlines():
            rain, time = line.split('|')
            data.append((time, _raw_to_mm(rain)))

    except Exception as e:
        return [('error', e)]

    if len(data) == 0: return [('error', 'No data')]
    return data

def rain_graph(x, y, width, height, scale):
    """Draws a rain graph at the specified coordinates.

    Uses 14 pixels for the time, and then draws a graph across the full length
    of the specified area, capping values at (height / scale) - 14 millimeters
    """
    downpour = get_downpour()
    if 'error' == downpour[0][0]:
        ugfx.string_box(x, y, width, height,
                        str(downpour[0][1]), "Roboto_Regular12",
                        ugfx.BLACK, ugfx.justifyLeft)
        return

    # How many timestmaps can we fit?
    num_items = len(downpour)
    num_ts = width / TS_WIDTH
    period = math.ceil(num_items / num_ts)
    
    prev_mm_height = 0
    for i, item in enumerate(downpour):
        time, mm = item
        if i % period == 0:
            ugfx.string_box(x + i * period, y, TS_HEIGHT, TS_WIDTH,
                            time, "Roboto_Regular12",
                            ugfx.BLACK, ugfx.justifyCenter)

        mm_height = max(height - TS_HEIGHT, int(mm) * scale)
        if i > 0:
            ugfx.fill_polygon(x + (i - 1) * period, y + TS_HEIGHT,
                              [
                                  (x + (i - 1) * period, y + TS_HEIGHT + prev_mm_height),
                                  (x + i * period, y + TS_HEIGHT + mm_height),
                                  (x + i * period, y + TS_HEIGHT)
                              ],
                              ugfx.BLACK)

        prev_mm_height = mm_height
