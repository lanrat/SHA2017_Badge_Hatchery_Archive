import easyrtc
import ugfx

def setup():
    pass

def loop():
    return 60000

def draw(y):
    try:
        data = requests.get("https://blockchain.info/es/ticker?")
    except:
        ugfx.string(10,10,"Could not download JSON","Roboto_Regular12", 0)
        ugfx.flush()
        sleep(1)
        go_home(1)
        return
    try:
        global output
        output = data.json()
    except:
        data.close()
        ugfx.string(10,10,"Cannot understand shit","Roboto_Regular12", 0)
        ugfx.flush()
        sleep(1)
        go_home(1)
        return
    data.close()
            
    t = easyrtc.string()
    ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    return [60000, 14]