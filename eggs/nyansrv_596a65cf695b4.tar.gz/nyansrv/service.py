# Service file for SHA2017 event program app
# Renze Nicolai 2017

import utime, badge

nyanCnt = 0
nyanLeds = []

# This function gets called by the home application at boot
def setup():
    badge.leds_enable()
    badge.leds_set_state(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]))
    global nyanLeds
    ledValue = [0,0,0,0]
    for i in range(0,6):
      nyanLeds.append(ledValue)
    print("Nyancat: Leds enabled!")

def loop(sleepCnt):
    print("Nyancat: Loop!")
    global nyanCnt
    nyanCnt = nyanCnt + 1
    if nyanCnt > 255:
        nyanCnt = 0
    ledValue = [0,0,0,nyanCnt]
    for i in range(0,5):
      nyanLeds[i] = nyanLeds[i+1]
    nyanLeds[5] = ledValue
    
    output = []
    for i in range(0,6):
        output = output + nyanLeds[i]
    badge.leds_set_state(bytes(output))
    
    
    
    return False # Do not prevent sleep
