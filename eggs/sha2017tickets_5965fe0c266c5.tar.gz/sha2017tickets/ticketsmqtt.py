import ugfx, gc, wifi, badge, deepsleep, urandom
from time import *

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
  
ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Connecting to MQTT...","Roboto_Regular12", 0)
ugfx.flush()

from umqtt.simple import MQTTClient

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    print((topic, msg))

    links, rechts = msg.decode('utf-8').split(';')
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.string(50,10,links,"Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.string(10,40,rechts,"PermanentMarker36",ugfx.BLACK)
    ugfx.string(40,90,"tickets.sha2017.org","Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.flush()

def main(server="test.mosquitto.org"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"tickets.sha2017.org")
    print('mqtt set')
    c.check_msg()
    while True:
        c.check_msg()
        sleep(1)
    c.disconnect()
    
def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
        
ugfx.input_attach(ugfx.BTN_B, go_home)
main()