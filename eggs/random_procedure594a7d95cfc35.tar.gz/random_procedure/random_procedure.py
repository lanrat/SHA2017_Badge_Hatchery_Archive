import badge
import ugfx
import urandom
import math

def pixel(x, y, color = ugfx.BLACK):
    ugfx.pixel(x, y, color)

def randint(num):
    return round(urandom.getrandbits(20)/10^20*num, 0)


sizeX = 296
sizeY = 128

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)
#random.seed()
action = 2
i = 0
x = 145
y = 64

while True:
    #c = randint(100)
    if urandom.getrandbits(20) > 1000000:
        #action = random.randint(1,8)
        #else:
        action = action + 1
        if action == 9:
            action = 1
    if action == 1:
        y = y - 1
    elif action == 2:
        x = x + 1
        y = y - 1
    elif action == 3:
        x = x + 1
    elif action == 4:
        x = x + 1
        y = y + 1
    elif action ==  5:
        y = y + 1
    elif action == 6:
        x = x - 1
        y = y + 1
    elif action == 7:
        x = x - 1
    elif action == 8:
        x = x - 1
        y = y - 1
    pixel(x, y)
    print(urandom.getrandbits(20))
    i = i + 1
    if i > 100:
        i = 0
        ugfx.flush()
