import umqtt.simple
import easywifi
from machine import UART
clnt = ""
uart = UART(2,9600)
def write_step(step,val):
  uart.write("%i %i\n")

def handle_co2(step,a):
  write_step(step, (a/4000.0)*256.0)

def sub_cb(topic, msg):
    print((topic, msg))
    try:
        tp = topic.decode("utf-8")
        ms = msg.decode("utf-8")
        s = ms.split(" ")[0]
        a = float(s)
        print(topic,"=",a)
        if tp == "revspace/sensors/co2":
           handle_co2(0,a)  
    except:
    	print("boohbooh")
  
  
def main():
  print("WIFI")
  easywifi.enable()
  print("Init")
  clnt = umqtt.simple.MQTTClient("umqtt_client","revspace.nl")
  clnt.set_callback(sub_cb)
  print("Connect")
  clnt.connect()
  clnt.subscribe(b"revspace/#")
  while True:
    clnt.wait_msg()