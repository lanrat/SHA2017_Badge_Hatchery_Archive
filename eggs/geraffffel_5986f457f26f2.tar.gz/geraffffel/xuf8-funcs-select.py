import ugfx
import time
import urandom
import badge

badge.init()
ugfx.init()

def logo():
    ugfx.clear(ugfx.WHITE)
    ugfx.display_image(35,0,"GERAFFEL20.png")
    ugfx.flush()

def writetext(colour, pos, high):
    ugfx.string(pos+30,high,"XUF","Roboto_BlackItalic24",colour)
    ugfx.string(pos+10,high+35,"Geraffel","DejaVuSans20",colour)
    ugfx.string(pos,high+75,"making noise since 1999","pixelade13",colour)
    ugfx.flush()

def diana(colour1, colour2):
    rad = 60
    colour = colour2
    while (rad > 2):
        if(colour == colour1):
            colour = colour2
        else:
            colour = colour1
        ugfx.fill_circle(60, 60, rad, colour)
        rad = rad - 3
    ugfx.fill_circle(60, 60, 5, colour2)
    ugfx.flush()

def star(colour, width):
    ugfx.thickline(60,10,95,95,colour,width,0)
    ugfx.thickline(95,95,15,40,colour,width,0)
    ugfx.thickline(15,40,105,40,colour,width,0)
    ugfx.thickline(105,40,20,95,colour,width,0)
    ugfx.thickline(20,95,60,10,colour,width,0)
    ugfx.flush()

def ScreenBlinkingDiana(colortext, colorbg):
    ugfx.clear(colorbg)
    writetext(colortext,130, 25)
    count = 0;
    while count < 30:
        diana(ugfx.BLACK,ugfx.WHITE)
        ugfx.flush()
        time.sleep(0.05)
        diana(ugfx.WHITE,ugfx.BLACK)
        ugfx.flush()
        time.sleep(0.05)
        count = count +1
    ugfx.flush()

# X: 0 - 240
# Y: 0 - 120
def ScreenRandomLine(colortext, colorbg):
    xi = 120
    yi = 60
    ugfx.clear(colorbg)
    writetext(colortext,100,25)
    ugfx.flush()
    time.sleep(2)
    count = 0
    while count < 1000:
        xo = urandom.getrandbits(9) - 50
        yo = urandom.getrandbits(7)
        ugfx.line(xi,yi,xo,yo,colortext)
        xi = xo
        yi = yo
        time.sleep(0.01)
        count = count + 1
    writetext(colorbg,100,25)
    ugfx.flush()

# X: 0 - 240
# Y: 0 - 120
def ScreenRandomText(colortext, colorbg):
    ugfx.clear(colorbg)
    writetext(colortext,100,25)
    ugfx.flush()
    time.sleep(1)
    count = 0
    while count < 40:
        x = int(round(160 - (urandom.getrandbits(9) - 50)/2))
        y = int(round(60 - (urandom.getrandbits(7))/2))
        writetext(colortext,x,y)
        time.sleep(0.5)
        count = count + 1
    ugfx.clear(colortext)
    writetext(colorbg,100,25)
    ugfx.flush()

def ScreenRandomDots(colortext, colorbg):
    ugfx.clear(colorbg)
    writetext(colortext,100,25)
    ugfx.flush()
    time.sleep(2)

    count = 0
    while count < 1000:
        x = urandom.getrandbits(9) - 50
        y = urandom.getrandbits(7)
        ugfx.line(x,y,x+1,y+1,colortext)
        time.sleep(0.01)
        count = count + 1
    ugfx.clear(colortext)
    writetext(colorbg,100,25)
    ugfx.flush()

def ScreenBlinkingStar(colortext, colorbg):
    count = 0
    ugfx.clear(colorbg)
    writetext(colortext,130,25)
    while count < 5:
        star(colortext,3)
        time.sleep(0.5)
        star(colorbg,3)
        time.sleep(0.5)
        count = count + 1
    star(colortext,3)
    ugfx.flush()

def ScreenGrowingStar(colortext, colorbg):
    count = 1
    ugfx.clear(colorbg)
    writetext(colortext,130,25)
    while count < 15:
        star(colortext,count)
        time.sleep(1)
        count = count + 1
    ugfx.clear(colorbg)
    writetext(colortext,130,25)
    star(colortext,3)
    ugfx.flush()

def bt_up(pushed):
    print("pressed UP")
    if(pushed):
        print("1 - UP: ScreenRandomLine(ugfx.WHITE,ugfx.BLACK)")
        ScreenRandomLine(ugfx.WHITE,ugfx.BLACK)
        print("2 - UP: ScreenRandomLine(ugfx.BLACK,ugfx.WHITE)")
        ScreenRandomLine(ugfx.BLACK,ugfx.WHITE)
    else:
        print("no pushed")

def bt_down(pushed):
    print("pressed DOWN")
    if(pushed):
        print("ScreenBlinkingDiana")
        ugfx.clear(ugfx.BLACK)
        ScreenBlinkingDiana(ugfx.WHITE,ugfx.BLACK)
        time.sleep(1)
        ScreenBlinkingDiana(ugfx.BLACK,ugfx.WHITE)

    else:
        print("no pushed")

def bt_right(pushed):
    print("pressed RIGHT")
    if(pushed):
        print ("1 - ScreenRandomDots(ugfx.WHITE,ugfx.BLACK)")
        ScreenRandomDots(ugfx.WHITE,ugfx.BLACK)
        print ("2 - ScreenRandomDots(ugfx.BLACK,ugfx.WHITE)")
        ScreenRandomDots(ugfx.BLACK,ugfx.WHITE)
    else:
        print("no pushed")

def bt_left(pushed):
    print("pressed LEFT")
    if(pushed):
        print ("1 - ScreenBlinkingStar(ugfx.WHITE,ugfx.BLACK)")
        ScreenBlinkingStar(ugfx.WHITE,ugfx.BLACK)
        print ("2 - ScreenBlinkingStar(ugfx.BLACK,ugfx.WHITE)")
        ScreenBlinkingStar(ugfx.BLACK,ugfx.WHITE)
    else:
        print("no pushed")

def bt_A(pushed):
    print("pressed A")
    if(pushed):
        print ("1 - ScreenGrowingStar(ugfx.WHITE,ugfx.BLACK)")
        ScreenGrowingStar(ugfx.WHITE,ugfx.BLACK)
        print ("2 - ScreenGrowingStar(ugfx.BLACK,ugfx.WHITE)")
        ScreenGrowingStar(ugfx.BLACK,ugfx.WHITE)
    else:
        print("no pushed")
def bt_B(pushed):
    print("pressed B")
    if(pushed):
        print ("1 - ScreenRandomText(ugfx.WHITE,ugfx.BLACK)")
        ScreenRandomText(ugfx.WHITE,ugfx.BLACK)
        print ("2 - ScreenRandomText(ugfx.BLACK,ugfx.WHITE)")
        ScreenRandomText(ugfx.BLACK,ugfx.WHITE)

def bt_select(pushed):
    print("pressed SELECT")
    if(pushed):
        print ("not implemented")

def bt_start(pushed):
#    ugfx.clear(ugfx.WHITE)
#    ugfx.display_image(55,0,"GERAFFEL15.png")
#    ugfx.string(105,100,"xuf","Roboto_BlackItalic24", ugfx.BLACK)
#    ugfx.flush()
    if(pushed):
        logo()

def render(text, pushed):
    if(pushed):
        ugfx.string(100,10,text,"PermanentMarker22",ugfx.BLACK)
    else:
        ugfx.string(100,10,text,"PermanentMarker22",ugfx.WHITE)
    ugfx.flush()

# Start app
bt_start(1)

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: bt_up(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: bt_down(pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: bt_left(pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: bt_right(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: bt_A(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: bt_B(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: bt_start(pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: bt_select(pressed))

while True:
    pass
