import badge, ugfx

global x, y

width = 4350
height = 3600

x = int((296 - width) / 2)
y = int((128 - height) / 2)

try:
    with open('/media/map.png') as f:
        f.close()
except:
    import easywifi, woezel
    easywifi.enable()
    s = woezel.url_open('https://badge.sha2017.org/map.png')
    with open('/media/map.png', 'wb') as f:
        buf = s.read(1024)
        while buf != b'':
            f.write(buf)
            buf = s.read(1024)

badge.init()
ugfx.init()

def display():
    badge.eink_png(x,y,'/media/map.png')
    ugfx.flush(ugfx.GREYSCALE)

def go_left(pressed):
    global x
    if pressed and x < 0:
        x += 222
        if x > 0:
            x = 0
        display()

def go_right(pressed):
    global x
    if pressed and x > 296 - width:
        x -= 222
        if x < 296 - width:
            x = 296 - width
        display()

def go_up(pressed):
    global y
    if pressed and y < 0:
        y += 96
        if y > 0:
            y = 0
        display()

def go_down(pressed):
    global y
    if pressed and y > 128 - height:
        y -= 96
        if y < 128 - height:
            y = 128 - height
        display()

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_LEFT, go_left)
ugfx.input_attach(ugfx.JOY_RIGHT, go_right)
ugfx.input_attach(ugfx.JOY_UP, go_up)
ugfx.input_attach(ugfx.JOY_DOWN, go_down)

display()