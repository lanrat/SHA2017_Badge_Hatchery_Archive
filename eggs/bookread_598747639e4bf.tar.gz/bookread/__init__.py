import badge, ugfx, uos, appglue

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)

path='lib/bookread'

def test_file():
  global files
  global options
  
  index = options.selected_index()
  if files[index]> 0:	
    fpath=path+'/'+files[index]
    ugfx.string(150, 20, "t%d:%s" % (index,str(uos.stat(fpath))), "Roboto_BlackItalic12", ugfx.BLACK)
  else:
  	ugfx.string(150, 20, "Directory back ", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  
def select_file():
  global files
  global options
  global path
  
  index = options.selected_index()
  if files[index]> 0:
    ugfx.string(150, 5, files[index], "Roboto_BlackItalic12", ugfx.BLACK)
    
  else:
    ugfx.string(150, 5, "Going up", "Roboto_BlackItalic12", ugfx.BLACK)
    #uos.chdir('..')
    #filepick()
  ugfx.flush()
  
def filepick():
  global options
  global files

  #ugfx.flush()
  options = ugfx.List(0,0,int(ugfx.width()/2),ugfx.height())

  options.add_item("<- Go Dir Up")
  ugfx.string(150, 0, "Use A to select file %d" % (options.selected_index()), "Roboto_BlackItalic12", ugfx.BLACK)
  uos.chdir(path)
  files=uos.listdir()

  for file in files:
      options.add_item("%s" % file)

  #options.selected_index(0)

  ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.BTN_A,  select_file() )
  ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.start_app("launcher", False) if pushed else False)

  ugfx.flush()
  ugfx.set_lut(ugfx.LUT_NORMAL)

try:
  ugfx.clear(ugfx.WHITE)
  ugfx.set_lut(ugfx.LUT_FASTER)
  filepick()

except Exception as e: 
  #probably a bug:
  ugfx.string(150, 15,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  #dont re-raise it in the hope the user can continue
  #raise e