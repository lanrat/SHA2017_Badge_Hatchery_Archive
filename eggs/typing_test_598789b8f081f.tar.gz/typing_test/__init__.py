import badge 
import ugfx
badge.init()
ugfx.init()
ugfx.string(4, 64, "test", "pixelade13", "BLACK")
ugfx.flush()