import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests


# Set up starting up screen
ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "Setting variables and connecting to wifi...", "Roboto_Regular12", 0)
ugfx.flush()

# Make sure WiFi is connected
wifi.ssid = "NW-challenge"
wifi.password = "Northwave Treintjes"
wifi.init()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "Wifi connected!", "Roboto_Regular12", 0)
ugfx.flush()

sleep(1)

ugfx.clear(ugfx.WHITE)