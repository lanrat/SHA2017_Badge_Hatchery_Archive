import badge
import ugfx
import appglue
import dialogs, network, deepsleep


def quit(pressed):
    if(pressed):
        appglue.start_app("")
    ugfx.flush()

badge.init()
badge.vibrator_init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = sta_if.scan()

ssidList = []
for AP in scanResults:
    ssidList.append(AP[0])
ssidSet = set(ssidList)

#clearGhosting()
ugfx.clear(ugfx.WHITE)
ugfx.string(25,20,'Found','Roboto_Regular18',ugfx.BLACK)
ugfx.string(40,40,str(len(ssidSet)),'Roboto_Regular18',ugfx.BLACK)
ugfx.string(10,60,'Networks','Roboto_Regular18',ugfx.BLACK)
options = ugfx.List(ugfx.width()-int(ugfx.width()/1.5),0,int(ugfx.width()/1.5),ugfx.height())

ugfx.string(50, 50, "popcorn","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()