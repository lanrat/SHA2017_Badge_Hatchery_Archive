import ugfx
import time

ugfx.clear(ugfx.BLACK)
ugfx.string(120,50,"Press B after cleaning", "Roboto_BlackItalic18", ugfx.WHITE)
ugfx.flush()
time.sleep(1)
for i in range(10):
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
exit(0)