"""
Based on Nickname rev. 18 (by Henk de Vries)
Hacked together by Harm "Urth" Geerts 
"""
import sys
import badge
import ugfx

base_path = '/lib'
left_path = base_path + '/ossobadge/left.png'
osso_path = base_path + '/ossobadge/osso.png'
name = badge.nvs_get_str('owner', 'name', 'Hacker1337')

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

# Display is 296x128
# left logo is 91x128
# osso name is 157x38
text_offset = 100
badge.eink_png(0, 0, left_path)
badge.eink_png(115, 0, osso_path)
x, w = text_offset, 296 - text_offset
ugfx.string_box(x, 40, w, 24, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(x, 60, w, 36, name, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(x, 100, w, 24, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.flush()

#the line under the text
str_len = ugfx.get_string_width(name,"PermanentMarker36")
line_begin = text_offset + int((w - str_len) / 2)
line_end = str_len + line_begin
ugfx.line(line_begin, 96, line_end, 96, ugfx.BLACK)

#the cursor past the text
cursor_pos = line_end + 5
ugfx.line(cursor_pos, 64, cursor_pos, 96, ugfx.BLACK)

ugfx.flush(ugfx.LUT_FULL)

import deepsleep
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)
