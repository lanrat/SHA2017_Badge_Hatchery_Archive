import dialogs, ugfx, network, esp, badge, deeplseep

ugfx.init()
ugfx.input_init()


ugfx.clear(ugfx.WHITE)
ugfx.string(100,50,'Scanning...','Roboto_Regular18',ugfx.BLACK)
ugfx.flush()

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = sta_if.scan()

ugfx.clear(ugfx.WHITE)
options = ugfx.List(ugfx.width()-int(ugfx.width()/1.5),0,int(ugfx.width()/1.5),ugfx.height())

for AP in scanResults:
    options.add_item(AP[0])

def connectClick(pushed):
    if pushed:
        selected = options.selected_index()
        options.destroy()

        ugfx.clear(ugfx.WHITE)
        ugfx.string(100,50,scanResults[selected][0],'Roboto_Regular18',ugfx.BLACK)
        ugfx.flush()
        if scanResults[selected][4] == 5:
            ugfx.clear(ugfx.WHITE)
            ugfx.string(20,50,'WPA Enterprise unsupported...','Roboto_Regular18',ugfx.BLACK)
            ugfx.flush()
            badge.eink_busy_wait()
            esp.start_sleeping(1)
        elif scanResults[selected][4] > 0:
            dialogs.prompt_text("WiFi password", cb = passInputDone)
        badge.nvs_set_str("badge", "wifi.ssid", scanResults[selected][0])
        esp.start_sleeping(1)
        
def passInputDone(passIn):
    badge.nvs_set_str("badge", "wifi.password", passIn)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(100,50,'Restarting!','Roboto_Regular18',ugfx.BLACK)
    ugfx.flush()
    deeplseep.start_sleeping(1)

ugfx.input_attach(ugfx.BTN_A, connectClick)
ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else 0)
ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else 0)

ugfx.set_lut(ugfx.LUT_FULL)
ugfx.flush()
ugfx.set_lut(ugfx.LUT_FASTER)