import ugfx
import badge

def pong():

    badge.init()
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    paddle_l = int(127 / 2)
    ball_x = int(295 / 2)
    ball_y = int(127 / 2)
    ball_vx = 3
    ball_vy = 3

    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.set_lut(ugfx.LUT_FASTEST)

    def pad_l_down(pressed):
      if paddle_l <= 118:
      	paddle_l = paddle_l + 4

    def pad_l_up(pressed):
      if paddle_l >= 19:
      	paddle_l = paddle_l - 4

    ugfx.input_attach(ugfx.JOY_UP, pad_l_up)
    ugfx.input_attach(ugfx.JOY_DOWN, pad_l_down)

    while True: 
        ugfx.clear(ugfx.WHITE)
        ball_x = ball_x + ball_vx
        ball_y = ball_y + ball_vy
        if ball_x >= 293:
            ball_vx = -ball_vx
        if ball_x <= 8 and ball_y >= paddle_l - 15 and ball_y <= paddle_l + 15:
            ball_vx = -ball_vx
        elif ball_x <= 8:
            paddle_l = int(127 / 2)
            ball_x = int(295 / 2)
            ball_y = int(127 / 2)
            ball_vx = 3
            ball_vy = 3
        if ball_y >= 125 or ball_y <= 2:
            ball_vy = -ball_vy
        ugfx.area(ball_x, ball_y, 4, 4, ugfx.BLACK)
      	ugfx.area(0, paddle_l - 15, 6, 30, ugfx.BLACK)
        ugfx.flush()

pong()