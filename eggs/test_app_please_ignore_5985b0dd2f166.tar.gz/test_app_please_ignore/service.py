import lenny_face_generator as lenny

def draw(y):
    lenny.render_creation(
            lambda w, h: (lenny.BADGE_EINK_WIDTH - w, y),
            lenny.creation)
