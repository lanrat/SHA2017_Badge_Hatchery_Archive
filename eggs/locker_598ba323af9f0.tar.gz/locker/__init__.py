import badge, easydraw, ugfx, appglue

# Setting the lock screen as the default screen.
badge.nvs_set_str('boot','splash','locker')

easydraw.msg('your screen is locked.')
code = ['up', 'up', 'down', 'down', 'left', 'right', 'left', 'right', 'b', 'a']
# how do global vars in python?
index = [0]

def handleInput(x, button):
  # Check if there actually was input.
  if(x):
    if(code[index[0]] == button):
      index[0] += 1
      if(index[0] == len(code)):
        appglue.home()
        
    else:
      index[0] = 0

# Setting listeners
ugfx.input_attach(ugfx.JOY_UP, lambda x: handleInput(x,'up'))
ugfx.input_attach(ugfx.JOY_DOWN, lambda x: handleInput(x,'down'))
ugfx.input_attach(ugfx.JOY_LEFT, lambda x: handleInput(x,'left'))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda x: handleInput(x,'right'))
ugfx.input_attach(ugfx.BTN_A, lambda x: handleInput(x,'a'))
ugfx.input_attach(ugfx.BTN_B, lambda x: handleInput(x,'b'))
ugfx.input_attach(ugfx.BTN_START, lambda x: handleInput(x,'start'))
ugfx.input_attach(ugfx.BTN_SELECT, lambda x: handleInput(x,'select'))