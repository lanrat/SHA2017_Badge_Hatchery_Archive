import ugfx, badge
import appglue

def action_home(pressed):
    if (pressed):
        appglue.start_app("")
        
def action_enable(pressed):
    if (pressed):
        badge.nvs_set_str('nyansrv', 'state', '1')
        draw()

def action_disable(pressed):
    if (pressed):
        badge.nvs_set_str('nyansrv', 'state', '0')
        draw()

def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Nyancat service", "PermanentMarker22", ugfx.BLACK)
    nyanEnabledString = badge.nvs_get_str('nyansrv', 'enabled', 'false')
    if (nyanEnabledString=="true"):
        ugfx.string(0, 25, "Service is enabled!", "Roboto_Regular12", ugfx.BLACK)
        ugfx.string(0, 38, "Press start to see it in action.", "Roboto_Regular12", ugfx.BLACK)
    else:
        ugfx.string(0, 25,  "Service is disabled!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*1, "A: Enable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*2, "B: Disable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*3, "START: Go to homescreen", "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()

def program_main():  
    ugfx.init()
    ugfx.input_init()   
    ugfx.input_attach(ugfx.BTN_START, action_home)
    ugfx.input_attach(ugfx.BTN_A, action_enable)
    ugfx.input_attach(ugfx.BTN_B, action_disable)
    draw()
          
# Start main application
program_main()
 
