import ugfx, wifi, appglue, badge, mvg

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass


ugfx.clear(ugfx.WHITE);
ugfx.flush()

station_raw = 5

station = mvg.Station(station_raw)

def main():
    print ("updating")
    ugfx.string(0,0,".","Roboto_Regular12", 0)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE);
    ugfx.string(0, 5,  "Koeniglich Bayrisches ", "PermanentMarker22", ugfx.BLACK)
    departures = station.get_departures()
    c = 0
    for departure in departures:
        c += 1
        ugfx.string(5,15+c*5,".","Roboto_Regular12", 0)
    ugfx.flush()
    time.sleep(20)

def go_home(pushed):
    if pushed:
        appglue.home()


ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.clear(ugfx.WHITE);
ugfx.flush()
while True:
    main()
