import easywifi, easydraw, urandom, gc, ugfx, badge
from time import *

easydraw.msg("Connecting to WiFi", title = 'Still Connecting Anyway...', reset = True)
easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(5000)

easydraw.msg("Connecting to MQTT")

from umqtt.simple import MQTTClient

co2 = 0;
humi = 100;
fan = 0;

def update_display():
  ugfx.clear(ugfx.WHITE)
  ugfx.string(0,  0, humi, "Roboto_Black22", ugfx.BLACK)
  ugfx.string(0, 25, co2,  "Roboto_Black22", ugfx.BLACK)

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    global co2
    global humi
    
    print((topic, msg))
    
    if topic == "revspace/sensors/humidity":
        humi = float(msg.decode('utf-8').split(' ')[0])
    
    if topic == "revspace/sensors/co2":
        co2 = float(msg.decode('utf-8').split(' ')[0])

def main(server="mosquitto.space.revspace.nl"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"revspace/sensors/humidity")
    c.subscribe(b"revspace/sensors/co2")
    
    easydraw.msg("MQTT Connected", title = 'Still MQTT Anyway...', reset = True)
    c.check_msg()
    while True:
        gc.collect()
        c.check_msg()
        sleep(1)
    c.disconnect()

main()