import badge
import ugfx
import appglue
import time

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

def draw_screen():
  ugfx.clear(ugfx.WHITE)
  ugfx.clear(ugfx.BLACK)
  
  #ugfx.thickline(1, 1, 100, 100, ugfx.WHITE, 10, 5)
  #ugfx.box(30, 30, 50, 50, ugfx.WHITE)
  
  ugfx.string(150, 25, "FERDI's", "Roboto_BlackItalic24", ugfx.WHITE)
  ugfx.string(140, 50, "Hacking", "PermanentMarker22", ugfx.WHITE)
  ugfx.string(170, 75, "App", "Roboto_BlackItalic24", ugfx.WHITE)
  #len = ugfx.get_string_width("App", "Roboto_BlackItalic24")

  try:
      badge.eink_png(32,32,'/lib/just_my_test_app/icon-bw.png')
  except:
      pass

  ugfx.flush()
  badge.eink_busy_wait()


def nightrider():
  for i in range(6):
    badge.leds_send_data(b''.join([ b'\0\5\0\0' if i == j else b'\0\0\0\0' for j in range(6)]), 24)
    time.sleep(.2)

  for i in range(5,-1,-1):
    badge.leds_send_data(b''.join([ b'\0\5\0\0' if i == j else b'\0\0\0\0' for j in range(6)]), 24)
    time.sleep(.2)

def home(pressed):
  if pressed:
    badge.vibrator_init()
    appglue.home()

ugfx.input_attach(ugfx.BTN_A, home)
ugfx.input_attach(ugfx.BTN_B, home)

draw_screen()

while True:
  nightrider()
