import easyrtc
import ugfx

def setup():
    pass
  
def loop(counter):
    return False

def draw(y):
    t = easyrtc.string()
    ugfx.string(0, 50, t, "PermanentMarker36", ugfx.BLACK)

    return [60000, 0]