import ugfx, badge

def cyber():
    cyber_cyber(0, 0)

def cyber_cyber(x, y):
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    try:
        # Proudly stolen from https://cyber.equipment/cyber_plain.png
        badge.eink_png(x, y, '/lib/cyber/cyber_plain.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()