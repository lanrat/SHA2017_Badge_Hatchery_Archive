def setup():
    pass

def loop():
    return 30*1000