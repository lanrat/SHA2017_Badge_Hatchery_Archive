import badge
import ugfx
from appglue import home

hint = "Press <Start> to go to Home Screen"
hint_font = "Roboto_Regular18"
hint_x = int((296-ugfx.get_string_width(hint, hint_font))/2)
hint_y = 128-22-5

delay = 3

def clear_paper():
  for i in range(2):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def draw_hint():
  ugfx.string(hint_x, hint_y, hint, hint_font, ugfx.BLACK)

def delay_mm(pressed):
  global delay
  if pressed and (delay > 0):
    delay -= 1
  
def delay_pp(pressed):
  global delay
  if pressed:
    delay += 1

def center_text(y, string, font, color):
  x=int((296-ugfx.get_string_width(string, font))/2)
  ugfx.string(x, y, string, font, color)

badge.init()
ugfx.init()
badge.eink_init()
ugfx.input_init()

ugfx.input_attach(ugfx.BTN_START, lambda pressed: home() if pressed else True)
ugfx.input_attach(ugfx.JOY_UP, delay_mm)
ugfx.input_attach(ugfx.JOY_DOWN, delay_pp)

clear_paper()
center_text(5, "Vibrator", "PermanentMarker36", ugfx.BLACK)
draw_hint()
ugfx.flush()

while 1:
  badge.vibrator_activate(1<<delay)