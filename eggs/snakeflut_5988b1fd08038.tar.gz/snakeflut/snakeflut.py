import badge
import ugfx
import deepsleep
import wifi
import usocket
import time

# width = 296
# height = 128

tile = 20

new_dir = 4
last_dir = 5

socket = None
connected = False

def snakeflut():
	badge.eink_init()
	ugfx.init()
	ugfx.input_init()
	wifi.init()

	# setup exit buttons
	ugfx.input_attach(ugfx.BTN_A, reboot)
	ugfx.input_attach(ugfx.BTN_B, reboot)
	ugfx.input_attach(ugfx.BTN_SELECT, reboot)

	# reset screen
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()

	# wait for wifi
	ugfx.clear(ugfx.WHITE)
	ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
	ugfx.flush()
	reconnect()

	# setup inputs
	ugfx.input_attach(ugfx.JOY_UP, up)
	ugfx.input_attach(ugfx.JOY_RIGHT, right)
	ugfx.input_attach(ugfx.JOY_DOWN, down)
	ugfx.input_attach(ugfx.JOY_LEFT, left)
	ugfx.input_attach(ugfx.BTN_START, reconnect)

	# done
	ugfx.clear(ugfx.WHITE)
	ugfx.string(10, 10, "Use Up/Down/Left/Right Buttons", "Roboto_Regular12", 0)
	ugfx.string(10, 10, "Start to reconnect / restart", "Roboto_Regular12", 0)
	ugfx.flush()

	update()

def opposite_dir(a, b):
	return (a == 0 and b == 2) or (a == 2 and b == 0) or (a == 1 and b == 3) or (a == 3 and b == 1)

def update():
	global last_dir
	global socket
	if new_dir != last_dir and not opposite_dir(new_dir, last_dir):
		# clear
		if last_dir == 0:
			ugfx.area(50 + tile*2, 20 + tile*1, tile, tile, ugfx.WHITE)
		if last_dir == 1:
			ugfx.area(50 + tile*3, 20 + tile*2, tile, tile, ugfx.WHITE)
		if last_dir == 2:
			ugfx.area(50 + tile*2, 20 + tile*3, tile, tile, ugfx.WHITE)
		if last_dir == 3:
			ugfx.area(50 + tile*1, 20 + tile*2, tile, tile, ugfx.WHITE)

		# box
		ugfx.box(50 + tile*2, 20 + tile*1, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*3, 20 + tile*2, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*2, 20 + tile*3, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*1, 20 + tile*2, tile+1, tile+1, ugfx.BLACK)

		# paint
		if new_dir == 0:
			ugfx.area(50 + tile*2, 20 + tile*1, tile, tile, ugfx.BLACK)
			socket.write(b"w")
		if new_dir == 1:
			ugfx.area(50 + tile*3, 20 + tile*2, tile, tile, ugfx.BLACK)
			socket.write(b"d")
		if new_dir == 2:
			ugfx.area(50 + tile*2, 20 + tile*3, tile, tile, ugfx.BLACK)
			socket.write(b"s")
		if new_dir == 3:
			ugfx.area(50 + tile*1, 20 + tile*2, tile, tile, ugfx.BLACK)
			socket.write(b"a")

		last_dir = new_dir

		ugfx.flush()

def up(wut):
	global new_dir
	new_dir = 0
	update()

def right(wut):
	global new_dir
	new_dir = 1
	update()

def down(wut):
	global new_dir
	new_dir = 2
	update()

def left(wut):
	global new_dir
	new_dir = 3
	update()

def reconnect():
	global socket
	global connected

	if connected:
		socket.write(b"x");
		socket = None
		connected = False

	wifi.init();

	while not wifi.sta_if.isconnected():
		time.sleep(0.1)

	socket = usocket.socket()
	socket.connect(('151.216.214.145', 36987))
	connected = True

def reboot(wut):
	if connected:
		socket.write(b"x");
	deepsleep.reboot()

snakeflut()