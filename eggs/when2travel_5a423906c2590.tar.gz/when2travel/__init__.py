import ugfx, time, wifi, badge, utime, ujson

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Waiting for wifi...","Roboto_Regular22", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Getting times...","Roboto_Regular22", 0)
ugfx.flush()

def open_json():
  fname = "/lib/When2Travel/times.json"
  with open(fname, 'r') as f:
    times = ujson.load(f)
  return times

def process_json(times):
  combolist = []
  for i in times:
    for k,v in i.items():
      if "times" == k:
        for i in v:
          combolist.append(float(i))
  return combolist

def populate_details_list(times):
    minute_dif, raw_list = 99, []
    combolist = process_json(times)
    year, month, day, hour, minute, second, ms, dayinyear = utime.localtime()
    for i in combolist:
        hours = int(i//1)
        minutes =  int((i - int(i)) * 100)
        if hours == hour:
            minute_dif = minutes - minute
            if minute_dif >= 0:
                raw_list.append(["%.2f" % i])
        if hours == hour + 1:
            minute_dif = minutes - minute + 60
            raw_list.append(["%.2f" % i])
    return raw_list

def refresh_data(pushed):
    if(pushed):
        show_screen()

def go_home(pushed):
    if(pushed):
        import machine as m
        m.deepsleep(1)

def info_screen():
  clear_ghosting()
  ugfx.clear(ugfx.WHITE)
  ugfx.string_box(0,0,296,20, "This app shows departure times of", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,25,296,25, "Tram Line 16", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,55,296,20, "Departure:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(79,55,296,20, "S-Bahnhof Messe", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(0,78,296,20, "Destination:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(80,78,296,19, "Hauptbahnhof", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(0,101,296,20, "Travel Time:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(80,101,296,19, "Approx. 20 mins", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(235,76,296,13, "To Continue", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(235,87,296,13, "Press A", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(235,102,296,13, "To Exit", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.string_box(235,113,296,13, "Press B", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.flush()  

def options_screen():
  clear_ghosting()
  ugfx.clear(ugfx.WHITE)  
  ugfx.string_box(0,0,296,25, "Choose your Mode", "Roboto_Regular22", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,25,296,20, "Option One: Interactive Mode", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,45,296,20, "For Option One: Press A", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,70,296,20, "Option Two: Auto Refresh", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,90,296,20, "For Option One: Press A", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
  ugfx.string_box(0,113,296,13, "NOTE: If you choose Auto Refresh you will need to reset to exit app", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
  ugfx.flush()      
  
def show_screen():
    times = open_json()
    sorted_list = populate_details_list(times)
    currenttime = utime.localtime()
    formattedtime = "{:02d}:{:02d}".format(currenttime[3], currenttime[4])
    nick = badge.nvs_get_str("owner", "name", 'PLEASESETNICK')
    clear_ghosting()
    ugfx.clear(ugfx.WHITE)
    ugfx.string_box(0,0,296,15, "Last Refresh:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,15,80,22, str(formattedtime), "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.string_box(0,0,296,15, "If Refresh Time doesn't match actual time,", "pixelade13", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(0,15,296,13, "please unplug and reconnect your battery.", "pixelade13", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(0,44,296,15, "When2Travel:  ", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,34,293,31, "  "+sorted_list[0][0]+"  "+sorted_list[1][0]+"  "+sorted_list[2][0],"PermanentMarker22", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(0,113,296,13, "Press A to Refresh", "pixelade13", ugfx.BLACK, ugfx.justifyLeft)
    ugfx.string_box(0,113,296,13, "Press B to Exit", "pixelade13", ugfx.BLACK, ugfx.justifyRight)
    ugfx.string_box(0,47,296,82, nick, "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
    ugfx.flush()

def go2sleep():
  show_screen()
  times = open_json()
  sorted_list = populate_details_list(times)
  time_difference = float(sorted_list[1][0]) - float(sorted_list[0][0])
  sleep_time = int((time_difference - int(time_difference)) * 100 * 60)
  time.sleep(sleep_time)
  restart()

def restart():
  go2sleep()

#go2sleep()
#show_screen()
info_screen()

ugfx.input_attach(ugfx.BTN_A, refresh_data)
ugfx.input_attach(ugfx.BTN_B, go_home)