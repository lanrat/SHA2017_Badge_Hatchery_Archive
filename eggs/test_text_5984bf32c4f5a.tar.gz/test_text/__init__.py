import usocket as socket
import network
import badge
import ugfx
from time import sleep


# init screen
badge.init()
ugfx.init()
ugfx.clear(ugfx.BLACK)


def showMsg(msg):
    ugfx.clear(ugfx.BLACK)

    ugfx.thickline(1, 1, 100, 100, ugfx.WHITE, 10, 5)
    ugfx.box(30, 30, 50, 50, ugfx.WHITE)

    ugfx.string(150, 25, msg, "Roboto_BlackItalic24", ugfx.WHITE)

    ugfx.flush()
    sleep(1)

showMsg("Test1")

sta_if = network.WLAN(network.STA_IF)
showMsg("Test2")
sta_if.active(True)
showMsg("Test3")
sta_if.connect("SHA2017-insecure")
showMsg("Test4")
sta_if.isconnected()
showMsg("Test5")

CONTENT = "GET /foo.txt HTTP/1.0\r\nHost: www.graa.nl\r\n\r\n"

HOST = 'www.graa.nl'    # The remote host
PORT = 8008              # The same port as used by the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
s.sendall(CONTENT)
data = s.recv(1024)
s.close()
showMsg (data)