import dialogs, badge, easydraw, time, appglue

easydraw.msg("","Dating++", True)

enabled = badge.nvs_get_u8("datingpp","enable", 0)

if enabled:
    disable = dialogs.prompt_boolean("Active, want to disable?")
    if disable:
        enabled = badge.nvs_set_u8("datingpp","enable",0)
        enabled = 0
else:
    enable = dialogs.prompt_boolean("Disabled, want to enable?")
    if enable:
        enabled = badge.nvs_set_u8("datingpp","enable",1)
        enabled = 1


ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

if enabled:
    savedchoice = badge.nvs_get_str("datingpp", "datingchoice", "")
    datingchoice = dialogs.prompt_text("Looking for?", savedchoice)
    if datingchoice:
        badge.nvs_set_str("datingpp", "datingchoice", datingchoice)

    easydraw.msg("Setup Dating++ successfully!")
    easydraw.msg("Go back to the splash and wait...")

time.sleep(3)
appglue.home()

