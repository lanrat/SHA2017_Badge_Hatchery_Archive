import sys
ADQLS=range
ADQLg=True
ADQLp=OSError
ADQLR=False
ADQLd=len
ADQrL=open
ADQLX=sys.path
import gc
ADQLx=gc.collect
import network
ADQLt=network.WLAN
ADQLH=network.STA_IF
ADQLo=network.AP_IF
import machine
ADQLj=machine.unique_id
import usocket as socket
ADQLe=socket.getaddrinfo
ADQLB=socket.socket
import badge
ADQLC=badge.nvs_set_str
ADQLE=badge.nvs_get_str
import ugfx
ADQLb=ugfx.BLACK
ADQLM=ugfx.clear
ADQLF=ugfx.input_attach
ADQLT=ugfx.string
ADQLm=ugfx.WHITE
ADQLG=ugfx.flush
ADQLv=ugfx.BTN_A
ADQLO=ugfx.BTN_B
ADQLP=ugfx.input_init
import appglue
ADQLV=appglue.start_app
ADQLi=appglue.home
import time
ADQLy=time.sleep
import dialogs
ADQLY=dialogs.prompt_boolean
ADQLz=dialogs.prompt_text
import machine
ADQLj=machine.unique_id
ADQLX.append('/lib/SHA2017Game')
import game_common
ADQLW=game_common.determineLeague
import callsign
ADQLf=callsign.callsign
ADQLr=["red","fuchsia","blue","green","yellow","orange"]
def get_fragments():
 ADQLn=[]
 for i in ADQLS(0,25):
  ADQLu=ADQLE('SHA2017Game',"fragment_%d"%i)
  if ADQLu:
   ADQLn.append(ADQLu)
 return ADQLn
def add_fragment(newfragment):
 for i in ADQLS(0,25):
  ADQLu=ADQLE('SHA2017Game',"fragment_%d"%i)
  if ADQLu:
   if ADQLu==newfragment:
    return
  else:
   ADQLC('SHA2017Game',"fragment_%d"%i,newfragment)
   return
def leaguename():
 ADQLJ=ADQLW()
 return ADQLr[ADQLJ]
def receiveData(ADQLU,cb,errcb):
 w=ADQLt(ADQLo)
 w.active(ADQLg)
 w.config(essid=ADQLU,channel=11)
 s=ADQLB()
 ai=ADQLe("0.0.0.0",2017)
 print("Bind address info:",ai)
 ADQLK=ai[0][-1]
 s.bind(ADQLK)
 s.listen(5)
 print('Listening at',ADQLU)
 s.settimeout(30)
 try:
  ADQLI=s.accept()
  ADQLh=ADQLI[0]
  ADQLs=ADQLI[1]
  print("Client address:",ADQLs)
  print("Client socket:",ADQLh)
  ADQLl=ADQLh
  print("Request:")
  ADQLa=ADQLl.readline()
  print(ADQLa)
  ADQLl.send('OK\r\n')
  ADQLc=cb(ADQLa)
  ADQLl.close()
  print("Done.")
 except ADQLp:
  print("Error")
  ADQLc=errcb()
 s.close()
 w.active(ADQLR)
 if ADQLc:
  ADQLV('SHA2017Game')
def gotOracleData(data):
 ADQLC('SHA2017Game','fragment_0',data)
 return ADQLg
def listenForOracle(leaguename):
 ADQLM(ADQLm)
 ADQLT(0,0,"Find the oracle!","PermanentMarker22",ADQLb)
 ADQLT(0,30,"Welcome, brave traveller of league %s. Your quest"%leaguename,"Roboto_Regular12",ADQLb)
 ADQLT(0,50,"starts once you have found the oracle. When you are","Roboto_Regular12",ADQLb)
 ADQLT(0,70,"near she will call out for you and provide further","Roboto_Regular12",ADQLb)
 ADQLT(0,90,"instructions. You have 30 seconds per attempt.","Roboto_Regular12",ADQLb)
 ADQLG()
 receiveData('OracleSeeker',gotOracleData,ADQLi)
def send_to(recv):
 ADQLM(ADQLm)
 ADQLT(0,0,"Share your fragments!","PermanentMarker22",ADQLb)
 ADQLT(0,30,"Connecting to other player...","Roboto_Regular12",ADQLb)
 ADQLG()
 n=0
 try:
  w=ADQLt(ADQLH)
  w.active(ADQLg)
  ap="Gamer %s %s"%(leaguename(),recv)
  print('Connecting to',ap)
  w.connect(ap)
  while not w.isconnected()and n<30:
   ADQLy(1)
   n=n+1
 except msg:
  print("error!",msg)
  ADQLT(0,50,"Error connecting to other player...","Roboto_Regular12",ADQLb)
  ADQLG()
  ADQLP()
  ADQLF(ADQLv,lambda pressed:ADQLV('SHA2017Game')if pressed else 0)
  return
 if n==30:
  print('No connection after sleeping 30 seconds')
  ADQLT(0,50,"Error connecting to other player...","Roboto_Regular12",ADQLb)
  ADQLG()
  ADQLP()
  ADQLF(ADQLv,lambda pressed:ADQLV('SHA2017Game')if pressed else 0)
  return
 ADQLT(0,50,"Sending fragments...","Roboto_Regular12",ADQLb)
 ADQLG()
 s=ADQLB()
 ai=ADQLe("192.168.4.1",2017)
 ADQLK=ai[0][-1]
 s.connect(ADQLK)
 s.send('#'.join(get_fragments()))
 s.send("\r\n")
 s.readline()
 s.close()
 w.active(ADQLR)
 print('Done sending')
 ADQLT(0,70,"Sent fragments. Press A.","Roboto_Regular12",ADQLb)
 ADQLG()
 ADQLP()
 ADQLF(ADQLv,lambda pressed:ADQLV('SHA2017Game')if pressed else 0)
def gotFragmentData(data):
 print('Got fragment data: ',data)
 for ADQLu in data.decode().replace('\n','').replace('\r','').split('#'):
  add_fragment(ADQLu)
 ADQLN=get_fragments()
 if ADQLd(ADQLN)>=25:
  ADQLV('SHA2017Game')
 ADQLT(0,70,"You now own %d unique fragments, %d to go!"%(ADQLd(ADQLN),25-ADQLd(ADQLN)),"Roboto_Regular12",ADQLb)
 ADQLT(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",ADQLb)
 ADQLG()
 ADQLP()
 ADQLF(ADQLO,lambda pressed:ADQLi()if pressed else 0)
 ADQLF(ADQLv,lambda pressed:ADQLV('SHA2017Game')if pressed else 0)
 return ADQLR;
def receive_fragments_failed():
 ADQLT(0,70,"Failed to receive fragments. Press A.","Roboto_Regular12",ADQLb)
 ADQLG()
 ADQLP()
 ADQLF(ADQLv,lambda pressed:ADQLV('SHA2017Game')if pressed else 0)
def receive_fragments():
 receiveData("Gamer %s %03d%03d"%(leaguename(),ADQLj()[4],ADQLj()[5]),gotFragmentData,receive_fragments_failed)
def send_or_recv(send):
 if send:
  ADQLM(ADQLm)
  ADQLz("Receiver address:",cb=send_to)
 else:
  ADQLM(ADQLm)
  ADQLT(0,0,"Share your fragments!","PermanentMarker22",ADQLb)
  ADQLT(0,30,"Tell the other player of your league your address,","Roboto_Regular12",ADQLb)
  ADQLT(0,50,"which is %03d%03d. Waiting..."%(ADQLj()[4],ADQLj()[5]),"Roboto_Regular12",ADQLb)
  ADQLG()
  receive_fragments()
def initiate_sharing():
 ADQLM(ADQLm)
 ADQLT(0,0,"Share your fragments!","PermanentMarker22",ADQLb)
 ADQLY("Do you want to send or receive?",true_text="Send",false_text="Receive",height=100,cb=send_or_recv)
def won():
 ADQLM(ADQLm)
 ADQLT(0,0,"Congratulations!","PermanentMarker22",ADQLb)
 ADQLT(0,30,"Cool! You've unlocked your league's secret. As a reward","Roboto_Regular12",ADQLb)
 ADQLT(0,50,"the signal shown by your badge LEDs will now sparkle.","Roboto_Regular12",ADQLb)
 ADQLT(0,70,"Is this the end? That is up to you! Contact raboof for","Roboto_Regular12",ADQLb)
 ADQLT(0,90,"the game code and design new challenges!","Roboto_Regular12",ADQLb)
 ADQLT(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",ADQLb)
 ADQLG()
 ADQLP()
 ADQLF(ADQLO,lambda pressed:ADQLi()if pressed else 0)
 ADQLF(ADQLv,lambda pressed:initiate_sharing()if pressed else 0)
def main():
 ADQLx()
 ADQLJ=ADQLW()
 ADQLf(ADQLJ)
 ADQLM(ADQLm)
 ADQLT(0,0,"Welcome, early bird!","PermanentMarker22",ADQLb)
 ADQLT(0,30,"Welcome to the SHA2017Game! You are in league","Roboto_Regular12",ADQLb)
 ADQLT(0,50,"%s, as your 'callsign' shows if you soldered on your"%leaguename(),"Roboto_Regular12",ADQLb)
 ADQLT(0,70,"LEDs. The game starts when the oracle is on the field,","Roboto_Regular12",ADQLb)
 ADQLT(0,90,"keep an eye on https://twitter.com/SHA2017Game.","Roboto_Regular12",ADQLb)
 ADQLT(5,113,"B: Back to home","Roboto_Regular12",ADQLb)
 ADQLG()
 ADQLP()
 ADQLF(ADQLO,lambda pressed:ADQLi()if pressed else 0)
 return
 ADQLN=get_fragments()
 print('number of fragments so far',ADQLd(ADQLN))
 if ADQLd(ADQLN)>=25:
  ADQLM(ADQLm)
  try:
   import os
   os.stat('/lib/SHA2017game/sparkle.py')
   won()
  except:
   import wifi
   import urequests
   import shards
   wifi.init()
   while not wifi.sta_if.isconnected():
    ADQLy(1)
   ADQLw=shards.key_from_shards(ADQLN)
   print('Collecting shards.py with key',ADQLw)
   r=urequests.get("http://pi.bzzt.net/%s/sparkle.py"%ADQLw)
   f=ADQrL('/lib/SHA2017game/sparkle.py','w')
   f.write(r.content)
   f.close()
   won()
 elif ADQLd(ADQLN)>0:
  ADQLM(ADQLm)
  ADQLT(0,0,"Share your fragments!","PermanentMarker22",ADQLb)
  ADQLT(0,30,"The oracle gave you a fragment of a relic of the "+leaguename(),"Roboto_Regular12",ADQLb)
  ADQLT(0,50,"league. 25 such fragments must be brought together","Roboto_Regular12",ADQLb)
  ADQLT(0,70,"to unlock its potential. Find other league members to","Roboto_Regular12",ADQLb)
  ADQLT(0,90,"share fragments along with a story or Mate.","Roboto_Regular12",ADQLb)
  ADQLT(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",ADQLb)
  ADQLG()
  ADQLP()
  ADQLF(ADQLO,lambda pressed:ADQLi()if pressed else 0)
  ADQLF(ADQLv,lambda pressed:initiate_sharing()if pressed else 0)
 else:
  def oracle_selection_made(value):
   ADQLf(ADQLJ)
   if value:
    listenForOracle(leaguename())
   else:
    ADQLi()
  def dialog_title():
   return "SHA2017Game - you are in league "+leaguename()
  ADQLY('Are you ready to start your quest?',title=dialog_title(),true_text='Search for the oracle',false_text='Back to home screen',height=100,cb=oracle_selection_made)
main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)

