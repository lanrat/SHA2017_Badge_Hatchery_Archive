import badge, ugfx

interval = 300000

def setup():
    pass

def loop(c):
    global interval
    enabled = badge.nvs_get_u8("frubar","enable", 0)
    if enabled:
        return 9999999999
    else:
        return 0

def draw(x,y):
    enabled = badge.nvs_get_u8("frubar","enable", 0)
    if enabled:
        name = badge.nvs_get_str("frubar", "name", "Frubar")
      
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

        badge.eink_png(0,30,'/lib/frubar/frubar.png')
      
        ugfx.string_box(0,45,296,38, name, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(0,94,296,26, "Frubar", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.flush() 
	return 0