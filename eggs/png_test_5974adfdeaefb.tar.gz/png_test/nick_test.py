import ugfx, badge, deepsleep

ugfx.init()

#Nice clean screen
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()

nick = badge.nvs_get_str("owner","name", "Artdanion")
pointCount = 4000
freqX = 11
freqY = 13
phi = 90
margin = 15
width = 296
height = 128

factorX = width/2-margin
factorY = height/2-margin

for y in range(pointCount):
	x = sin(angle*freqX + radians(phi))
    y = sin(angle*freqY)
	
	x = x * factorX
    y = y * factorY
	
	ugfx.pixel(x, y, ugfx.WHITE)

ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.WHITE, ugfx.justifyCenter)

ugfx.flush()

badge.eink_busy_wait()

deepsleep.start_sleeping(60000)