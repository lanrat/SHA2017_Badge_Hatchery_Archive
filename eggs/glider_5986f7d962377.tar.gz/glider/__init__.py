import ugfx
import time
import badge

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)

baselength = 125
horizontalMargins = int((296-125)/2)

ugfx.thickline(horizontalMargins, 1, horizontalMargins+baselength, 1, ugfx.BLACK, 5,3)
ugfx.thickline(horizontalMargins, 1+int(baselength/3), horizontalMargins+baselength, 1+int(baselength/3), ugfx.BLACK, 5,3)
ugfx.thickline(horizontalMargins, 1+int((baselength/3)*2), horizontalMargins+baselength, 1+int((baselength/3)*2), ugfx.BLACK, 5,3)
ugfx.thickline(horizontalMargins, 1+baselength, horizontalMargins+baselength, 1+baselength, ugfx.BLACK, 5,3)
ugfx.thickline(horizontalMargins, 1, horizontalMargins, 125,ugfx.BLACK, 5,3) 
ugfx.thickline(horizontalMargins+int(baselength/3), 1, horizontalMargins+int(baselength/3), 125,ugfx.BLACK, 5,3) 
ugfx.thickline(horizontalMargins+int((baselength/3)*2), 1, horizontalMargins+int((baselength/3)*2), 125,ugfx.BLACK, 5,3) 
ugfx.thickline(horizontalMargins+int(baselength), 1, horizontalMargins+int(baselength), 125,ugfx.BLACK, 5,3) 
ugfx.fill_circle(horizontalMargins+int(1/6*baselength)-1, 1+int((5/6)*baselength), 14, ugfx.BLACK)
ugfx.fill_circle(horizontalMargins+int(3/6*baselength)-1, 1+int((5/6)*baselength), 14, ugfx.BLACK)
ugfx.fill_circle(horizontalMargins+int(5/6*baselength)-1, 1+int((5/6)*baselength), 14, ugfx.BLACK)
ugfx.fill_circle(horizontalMargins+int(5/6*baselength)-1, 1+int((3/6)*baselength), 14, ugfx.BLACK)
ugfx.fill_circle(horizontalMargins+int(3/6*baselength)-1, 1+int((1/6)*baselength), 14, ugfx.BLACK)

ugfx.flush()
while True:
	pass
