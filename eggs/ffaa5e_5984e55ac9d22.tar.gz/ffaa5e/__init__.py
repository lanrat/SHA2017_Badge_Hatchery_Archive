import urandom, usocket, appglue, badge, wifi, utime

badge.init()
badge.leds_init()
badge.leds_enable()

wifi.init()
        
ssid = badge.nvs_get_str('badge', 'wifi.ssid', 'SHA2017-insecure')
print("Loading...", "WiFi: connecting to '"+ssid+"'...")
timeout = 100
while not wifi.sta_if.isconnected():
    utime.sleep(0.1)
    timeout = timeout - 1
    if (timeout<1):
        print("Error", "Timeout while connecting!")
        utime.sleep(5)
        appglue.home()
        break
    else:
        pass

sock = usocket.socket()
addr = usocket.getaddrinfo("151.216.93.210", 2342)
sock.connect(addr[0][-1])

#while True:
for i in range(0, 10):
  ledinfo = [0] * 24;
  pos = 4 * (urandom.getrandbits(10) % 6)
  ledinfo[pos+1] = 0xFF
  ledinfo[pos] = 0xAA
  ledinfo[pos+2] = 0x5E
  badge.leds_send_data(bytes(ledinfo), 24)
  for j in range(0, 1000):
    x = urandom.getrandbits(30) % 600
    y = urandom.getrandbits(30) % 400
    sock.send("PX {:d} {:d} FFAA5E\n".format(x,y).encode('utf-8'))

sock.close()

badge.leds_disable()
appglue.home()