import ugfx, time, wifi, badge, utime, ujson

def clear_ghosting():
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()
        badge.eink_busy_wait()
        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        badge.eink_busy_wait()
    
badge.init()
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
clear_ghosting()

# Make sure WiFi is connected
wifi.init()
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Waiting for wifi...","Roboto_Regular22", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

# loading screen
clear_ghosting()
ugfx.clear(ugfx.WHITE);
ugfx.string(10,60,"Getting times...","Roboto_Regular22", 0)
ugfx.flush()

def open_json():
  fname = "/lib/When2Travel/times.json"
  with open(fname, 'r') as f:
    times = ujson.load(f)
  return times

def process_json(times):
  shortlist, middlelist, longlist, combolist = [], [], [], []
  for i in times:
    if ("departure","short18") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            shortlist.append(float(i))
    elif ("departure","middle20") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            middlelist.append(float(i))
    elif ("departure","long22") in i.items():
      for k,v in i.items():
        if "times" == k:
          for i in v:
            longlist.append(float(i))
  combolist.append([shortlist, middlelist, longlist])
  combolist = combolist[0]
  return combolist

def populate_seconds_list(times):
    minute_dif = 99
    combolist = process_json(times)
    shortlist, middlelist, longlist = [], [], []
    year, month, day, hour, minute, second, ms, dayinyear = utime.localtime()
    for i in combolist[0]:
        hours = int(i//1)
        minutes =  int((i - int(i)) * 100)
        if hours == hour:
            minute_dif = minutes - minute
            if minute_dif >= 0:
                print(minute_dif)
                print(i)
                shortlist.append([minute_dif, i, 1000])
        if hours == hour + 1:
            minute_dif = minutes - minute + 60
            print(minute_dif)
            print(i)
            shortlist.append([minute_dif, i, 1000])
        if hours != hour and hours != hour + 1 and hours > hour:
            shortlist.append([500])
    for i in combolist[1]:
        hours = int(i//1)
        minutes =  int((i - int(i)) * 100)
        if hours == hour:
            minute_dif = minutes - minute
            if minute_dif >= 0:
                print(minute_dif)
                print(i)
                middlelist.append([minute_dif, i, 2000])
        if hours == hour + 1:
            minute_dif = minutes - minute + 60
            print(minute_dif)
            print(i)
            middlelist.append([minute_dif, i, 2000])
        if hours != hour and hours != hour + 1 and hours > hour:
            middlelist.append([500])
    for i in combolist[2]:
        hours = int(i//1)
        minutes =  int((i - int(i)) * 100)
        if hours == hour:
            minute_dif = minutes - minute
            if minute_dif >= 0:
                print(minute_dif)
                print(i)
                longlist.append([minute_dif, i, 3000])
        if hours == hour + 1:
            minute_dif = minutes - minute + 60
            print(minute_dif)
            print(i)
            longlist.append([minute_dif, i, 3000])
        if hours != hour and hours != hour + 1 and hours > hour:
            longlist.append([500])
    combolist = []
    combolist.append([shortlist, middlelist, longlist])
    combolist = combolist[0]
    return combolist

def define_nearest_times(seconds_list):
  detailed_list, counter = [], 0
  while counter < 3:
    nearest_times_list = min(seconds_list)
    nearest_time = min(nearest_times_list)
    del nearest_times_list[0]
    for i in seconds_list:
      if len(i) % 2 != 0:
        if 1000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '18 Minutes', 'S-Bahnhof Messe', 'NA', 'NA', 'Hauptbahnhof (Gleis 2)'])
          del nearest_times_list[0]
          ugfx.string_box(0,78,296,52, detailed_list[0][0], 
                    "PermanentMarker22", ugfx.BLACK, ugfx.justifyLeft)
          ugfx.flush()
        elif 2000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '20 Minutes', 'S-Bahnhof Messe', 'Line 11', 'Chausseehaus', 'Hauptbahnhof (Gleis 2)'])
          del nearest_times_list[0]
        elif 3000 in i:
          detailed_list.append([str(nearest_time), 'Line 16', '22 Minutes', 'S-Bahnhof Messe', 'NA', 'NA', 'Hauptbahnhof (Westseite)'])
          del nearest_times_list[0]
    counter += 1
  return detailed_list


times = open_json()
combolist = process_json(times)
seconds_list = populate_seconds_list(times)
nearest_times = define_nearest_times(seconds_list)