import ugfx, machine

i2c = machine.I2C( sda=machine.Pin(26), scl=machine.Pin(27), freq=100000 )
slaves = i2c.scan()

ugfx.clear( ugfx.WHITE )
ugfx.string( 0, 0, "Still Scanning Anyway", "PermanentMarker22", ugfx.BLACK )
len = 24
for slave in slaves:
    ugfx.string( 0, 0 + len, hex( slave ), "Roboto_Regular12", ugfx.BLACK )
    len = len + 20

ugfx.flush()
