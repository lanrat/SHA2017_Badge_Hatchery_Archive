import badge
import ugfx
import time
import deepsleep

badge.init()
ugfx.init()

lyrics = ["We're no strangers to love, you know the rules and so do I",
"A full commitments what I'm thinking of",
"You wouldn't get this from any other guy.",
"I just wanna tell you how I'm feeling, gotta make you understand.",
"",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you.",
"",
"We've known each other for so long",
"Your heart's been aching, but you're too shy to say it",
"Inside we both know what's been going on",
"We know the game and we're gonna play it.",
"And if you ask me how I'm feeling, don't tell me you're too blind to see.",
"",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you.",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you.",
"",
"(Ooh, give you up, ooh, give you up)",
"Never gonna give, never gonna give (Give you up)",
"Never gonna give, never gonna give (Give you up)",
"",
"We've known each other for so long",
"Your heart's been aching, but you're too shy to say it",
"Inside we both know what's been going on",
"We know the game and we're gonna play it.",
"I just wanna tell you how I'm feeling, gotta make you understand.",
"",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you.",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you.",
"Never gonna give you up, never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry, never gonna say goodbye",
"Never gonna tell a lie and hurt you."]


ugfx.clear(ugfx.BLACK)
ugfx.flush
ugfx.clear(ugfx.WHITE)
ugfx.flush

for line in lyrics:
    words = line.split()
    for word in words:
        ugfx.clear(ugfx.WHITE)
        ugfx.string(10,25,word,"DejaVuSans20",ugfx.BLACK)
        ugfx.flush()
        time.sleep(0.2)
deepsleep.reboot()