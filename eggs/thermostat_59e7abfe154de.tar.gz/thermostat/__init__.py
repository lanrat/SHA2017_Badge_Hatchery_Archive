import time, badge, _thread, ugfx, wifi, appglue,gc, onewire, ds18x20, machine, json
import usocket as socket
import urequests as requests
#from machine import Pin

#try to maintain targettemp

settings=json.loads('{"settings":{"offset":"-0.5","margin":"0.5","loglevel":"0","default_screen":"0","store_data":"0"}}')

message="Have a nice day!"
message2=""
message3=""
readings=''
ctemp=20.0
ttemp=20.0
margin=-0.5
offset=0.5
loglevel=0
screen=0
burn=0
buitentemp=0.0
windsnelheid=0.0
description="wacht op data"
zonop=0
zonneer=0
dotw=('','Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag','Zaterdag')
schedule='' 

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

html_bootstrap="""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Thermostat Tommy Faasen 2017</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body> <nav class=\"navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top\">
  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="#">Thermostat</a>
      <div class=\"collapse navbar-collapse\" id=\"navbarsExampleDefault\">
        <ul class="nav navbar-nav">
          <li class=\"nav-item active\"><a class=\"nav-link\" href=\"/\">Home</a></li>
          <li class=\"nav-item\"><a class=\"nav-link\" href=\"/?schema\">Schema</a></li>
          <li class=\"nav-item\"><a class=\"nav-link\" href=\"/?settings\">Settings</a></li>
        </ul>
      </div>
    </nav>"""

def store_settings():
  global offset,margin,screen,openweatherkey,loglevel
  badge.nvs_set_str('thermostat','offset',offset)
  badge.nvs_set_str('thermostat','margin',margin)
  badge.nvs_set_str('thermostat','owkey',openweatherkey)
  badge.nvs_set_str('thermostat','screen',screen)
  badge.nvs_set_str('thermostat','loglevel',loglevel)
  
def read_settings():
  global offset,margin,screen,openweatherkey,loglevel
  badge.nvs_get_str('thermostat','offset',offset)
  badge.nvs_get_str('thermostat','margin',margin)
  badge.nvs_get_str('thermostat','owkey',openweatherkey)
  badge.nvs_get_str('thermostat','screen',screen)
  badge.nvs_get_str('thermostat','loglevel',loglevel)
  
def init_hw():
  global p12, ds, roms
  badge.init()
  ugfx.init()
  ugfx.input_init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.string(40, 30, "Initializing!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(40, 70, "THERMOSTAT!" , "DejaVuSans20", ugfx.BLACK)

  ugfx.flush()
  #p12 for relay switch
  #p33 for temp sensor
  badge.power_sdcard_enable()
  p12=machine.Pin(12,machine.Pin.OUT)
  p12.value(0)
  

  # create the onewire object
  dat = machine.Pin(33)
  ds = ds18x20.DS18X20(onewire.OneWire(dat))
  # scan for devices on the bus
  roms = ds.scan()
  ds.read_temp(roms[0])
  time.sleep(0.75)
  ds.read_temp(roms[0])

def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def init_web():
  global s
  #init webserver stuff
  wifi.init()
  ai = socket.getaddrinfo(wifi_up(),80)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.bind(addr)
  s.listen(5)

def main_target_temp():
  global ctemp,ttemp,margin,burn,p12,message,dotw, ds, roms, offset
  global buitentemp,windsnelheid,description,zonop,zonneer
  tstatus=('idleing','burning')
 
  moty=('','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  print("Target temp thread started!")
 
  while True:
    ds.convert_temp()
    ctemp=round(float(ds.read_temp(roms[0]))+offset,1)
    if ctemp<(ttemp-margin):
      burn=1
    else:
      burn=0
    p12.value(burn)
    #refresh the screen
    now=time.localtime() #0year,1 month,2 day,3 hour,4 minute,5 sec,6 dayoftheweek,7 dayoftheyear
    if now[4]<10:
      mytime="%d:0%d"%(now[3],now[4])
    else:
      mytime="%d:%d"%(now[3],now[4])
    ugfx.clear(ugfx.WHITE)
    ugfx.string(4, 0, "Huidige temperatuur is %.1f , Gewenste temperatuur is %.1f" % (ctemp,ttemp) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(4, 14, "Buiten temperatuur is %s, Windsnelheid %.1f " % (buitentemp,float(windsnelheid)) , "Roboto_BlackItalic12", ugfx.BLACK)
    
    ugfx.string(4, 28, "Het is %s %d %s %d en buiten is het %s" % (dotw[now[6]],now[2],moty[now[1]],now[0],description) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(4, 42, "Tijd %s Donker %s Zon opkomst %s" % (mytime,zonneer,zonop) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(40, 66, "Status: %s!" %(tstatus[burn]), "DejaVuSans20", ugfx.BLACK)
    ugfx.string(4, 90, " %s" % (message) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(4, 104, " %s" % (message2) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.string(4, 118, " %s" % (message3) , "Roboto_BlackItalic12", ugfx.BLACK)
    ugfx.input_attach(ugfx.JOY_UP, lambda pushed: new_temp(0.5) if pushed else False)
    ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: new_temp(-0.5) if pushed else False)
    ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_TIL() if pushed else False)
    ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.start_app('launcher') if pushed else False)
    ugfx.flush()
    time.sleep(10)

def new_temp(delta):
  global ttemp
  ttemp+=delta
  ttemp=round(ttemp,1)
  ugfx.clear(ugfx.WHITE)
  ugfx.string(80, 35, "%.1f" %(ttemp), "DejaVuSans20", ugfx.BLACK)
  if ttemp>24.0:
    if ttemp<26.0:
      ugfx.string(80, 55, "Een beetje warm???", "DejaVuSans20", ugfx.BLACK)
    else:
      ugfx.string(80, 55, "Doe niet zo gek!!", "DejaVuSans20", ugfx.BLACK)
  ugfx.flush()
  time.sleep_ms(200)

def main_scheduler():
  global schedule,ttemp
  print("Scheduler thread started!")
  while True:
    #now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
    #print("Day of the week is %d" % (now[6]))
    sleep=current_schedule()
    print("Target temperature set to %.1f, sleeping for %d minutes" % (ttemp,sleep  )  )
    time.sleep(sleep*60)
  
def current_schedule():
  global ttemp,schedule,dotw
  #dotw=('','Zaterdag','Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag')
  now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
  t=0
  try:
    if len(schedule['schedule'][dotw[now[6]]])>0:
      for s in schedule['schedule'][dotw[now[6]]]:
        if int(s['hour'])<now[3] and int(s['min'])<now[4]:
          ttemp=round(float(s['temp'])/10,1)
        t+=1
  except Exception as e:
    print("Error in current_schedule: %s"%(str(e)))
    ttemp=18.0
    return 300  # wait for 5 minutes
  if t==len(schedule['schedule'][dotw[now[6]]]):
    return((23-now[3])*60+60-now[4])
  else:
  	return((int(schedule['schedule'][dotw[now[6]]][t]['hour'])-int(s['hour']))*60+abs((int(schedule['schedule'][dotw[now[6]]][t]['hour'])-now[4])))
  return 60 
  
def main_handle_web():
  print("Handle web thread started!")
  global s,message,dotw
  global burn, ttemp,ctemp,buitentemp
  while True:
    res = s.accept()
    client_s = res[0]
    client_ip = str(res[1][0])
    print("Connection from ",client_ip)
    request = client_s.recv(1024)
    request = str(request)
    print("Request was : %s" % request)
    if request.find('/favicon.ico')>0:  
      client_s.close()
    else:
      if request.find('/?message=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        message=arg[1].replace('%20',' ')
        message=message.replace('%22','')
        print("change current message to %s" % message)
      elif request.find('/?ctemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ctemp=round(float(arg[1])/10,1)
        print("change current temp to %s" % ctemp)
      elif request.find('/?ttemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ttemp=round(float(arg[1])/10,1)
      elif request.find('/?tempup')>0:
        ttemp+=0.5
      elif request.find('/?tempdown')>0:
        ttemp-=0.5
        print("change target temp to %s" % ttemp)
      elif request.find('/?schedule')>0:
        get_schedule()

      #client_s.send(default_reply)
      html=default_reply+html_bootstrap+"<div class=\"container\"><div class=\"starter-template\">"
      if request.find('/settings')>0:
      	html+="<h1>Instellingen:</h1><p class=\"lead\">"
        html+="Marge <input type=\"text\" name=\"margin\""%(margin)
        html+="Offset <input type=\"text\" name=\"offset\""%(offset)
        html+="Openweatherkey <input type=\"text\" name=\"openweatherkey\""%(openweatherkey)
        html+="Loglevel <input type=\"text\" name=\"loglevel\""%(loglevel)
        html+="Screen <input type=\"text\" name=\"screen\""%(screen)
        html+="</p>"
      elif request.find('/schedule')>0:
        html+="<h1>Schedule:</h1>"
        for d in len(dotw):
          if d>0:
            print("<p class=\"lead\"><h1>%s</h1><br>"%(dotw[d]))
            if len(schedule['schedule'][dotw[d]])>0:
      			for s in schedule['schedule'][dotw[d]]:
        			print("Tijd %s:%s - %.1f °C<br>"%(s['hour'],s['min'],float(s['temp']/10)))
            html+="</p>"
      else:
        html+="<h1>Status:</h1><p class=\"lead\">"
        if(burn==0):
          html+="Niet"
        else:
          html+="Wel"
        html+=" verwarmen!<br>\nGewenste temperatuur %.1f °C<br> Huidige temperatuur %.1f °C<br> Buiten temperatuur %.1f °C<br></p>\n" % (float(ttemp),float(ctemp),float(buitentemp))
        html+="<a class=\"btn btn-lg btn-success\" role=\"button\" href=\"/?tempup\">Warmer</a> "
        html+="<a class=\"btn btn-lg btn-primary\" role=\"button\" href=\"/?tempdown\">Kouder</a><br>"
      
      
      html+="</div></div></body></html>\n"
      client_s.send(html)
      client_s.close()

def get_weather():
  global buitentemp,windsnelheid,description,zonop,zonneer
  #get the weather
  openweatherUrl="http://api.openweathermap.org/data/2.5/weather?q=Breda,nl&lang=nl&units=metric&appid=e8d05fb1070a4eeee6ce99f689fa1aef"
  try: 
    rw = requests.get(openweatherUrl)
    w=rw.json()
    rw.close()
    buitentemp=w['main']['temp']
    windsnelheid=float(w['wind']['speed'])
    description=w['weather'][0]['description']
    zonop="%d:%d" %(time.localtime(w['sys']['sunrise'])[3],time.localtime(w['sys']['sunrise'])[4])
    zonneer="%d:%d" %(time.localtime(w['sys']['sunset'])[3],time.localtime(w['sys']['sunset'])[4])
  except:
    ugfx.string(10, 10, "Could not get the weather", "Roboto_Regular12", 0)
    ugfx.flush()
    print('openweather fail')
    time.sleep(5)
    return
  
def get_TIL():
  global message,message2,message3,TIL
  #get top post reddit TIL
  #redditUrl="https://www.reddit.com/r/todayilearned/new.json?limit=1"
  redditUrl="https://www.reddit.com/r/worldnews/new.json?limit=1"

  try: 
    rw = requests.get(redditUrl)
    TIL=rw.json()
    rw.close()
 
  except:
    ugfx.string(10, 10, "Could not get the top post from reddit", "Roboto_Regular12", 0)
    ugfx.flush()
    print('reddit fail')
    time.sleep(5)
    return
  message=TIL['data']['children'][0]['data']['title']
  message2=""
  message3=""
  if len(message)>55:
    message2=message[55:]
    message=message[:55]
  if len(message2)>55:
    message3=message2[55:]
    message2=message2[:55]
  
def get_schedule():
  global schedule
  print("Getting schedule!")
  #get schedule
  scheduleUrl="http://192.168.2.11/tempsense/index.cgi?action=schedule"
  try: 
    rw = requests.get(scheduleUrl)
    schedule=rw.json()
    rw.close()
  except:
    ugfx.string(10, 10, "Could not get the schedule", "Roboto_Regular12", 0)
    ugfx.flush()
    print('schedule fail')
    time.sleep(5)
    return
  
def store_temp():
  global ctemp
  webUrl="http://192.168.2.11/tempsense/index.cgi?action=new&reading=%.1f&type=1" % (ctemp)
  try:
    rw = requests.get(webUrl)
    rw.close()
  except:
    print("Could not store reading!")

def main_internet_info():
  print("Internet info thread started!\n")
  while True:
    time.sleep(900)
    get_weather()
    get_TIL()
    store_temp()
    gc.collect()

def store_reading():
  global readings
  if len(readings)>480:
    del readings[0]
  readings.append(ctemp)

def main_temp_logger():
  #store a temperarture in memory every 3 minutes
  print("Temperature logger thread started!\n")
  while True:
    store_reading()
    time.sleep(180)
    
try:
  gc.collect()
  print("Free mem: %d" %(gc.mem_free()))
  print("Initializing")
  init_hw()
  read_settings()
  init_web()
  #gc.enable()
  print("Done, starting up!\n")
  time.sleep(1)
  get_schedule()
  get_weather()
  get_TIL()
  _thread.start_new_thread(main_target_temp,())
  _thread.start_new_thread(main_scheduler,())
  _thread.start_new_thread(main_handle_web,())
  _thread.start_new_thread(main_internet_info,())
  _thread.start_new_thread(main_temp_logger(),())
  print("All systems go!")
  time.sleep(5)
  gc.collect()
  print("Free mem: %d" %(gc.mem_free()))
  
except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()