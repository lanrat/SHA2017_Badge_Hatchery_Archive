# NYANCAT APPLICATION
# SHOWN ONCE AFTER SETUP

import ugfx, badge, appglue, deepsleep, sys

def program_main():
  while(1):
    vbatt = badge.battery_volt_sense()
    if (vbatt<4000):
      print("Battery below 3.7V")
      sys.exit()
    print("--- NYANCAT APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    badge.leds_init()
    badge.leds_send_data(bytes([25, 51, 102, 0,
                            76, 0, 102, 0,
                            102, 25, 0, 0,
                            102, 102, 0, 0,
                            76, 102, 0, 0,
                            0, 102, 0, 0]), 24)
    try:
        badge.eink_png(0,0,'/lib/nyancat/nyancat.png')
    except:
        ugfx.string(0, 0, "NYANCAT LOAD ERROR nyancat.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(5000000)
    appglue.start_app("") # Return home

# Start main application
program_main()