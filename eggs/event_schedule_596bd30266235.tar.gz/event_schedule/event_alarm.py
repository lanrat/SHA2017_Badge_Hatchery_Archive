import machine, ujson, utime, ugfx, badge

#Globals
alarms = []

# Management

def alarms_add(timestamp,guid,title):
    global alarms
    alarm = {"timestamp":timestamp, "guid":guid, "title":title}
    alarms.append(alarm)
    
def alarm_exists(guid):
    global alarms
    for alarm in alarms:
        if (alarm['guid']==guid):
            return True
    return False
    
def alarms_remove(id):
    global alarms
    if (id<0):
        print("Whoops, this shouldn't happen...")
    else:
        alarms.pop(id)
    
def alarms_read():
    global alarms
    try:
        f = open('event_alarms.json', 'r')
        data = f.read()
        f.close()
    except:
        data = ""
    try:
        alarms = ujson.loads(data)
    except:
        alarms = []
    
def alarms_write():
    global alarms
    data = ujson.dumps(alarms)
    f = open('event_alarms.json', 'w')
    f.write(data)
    f.close()
