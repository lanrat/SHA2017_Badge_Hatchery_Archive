### Author: Mattsi Jansky
### Description: Testing network functionality
### Category: Unpublished
### License: MIT
### Appname: nettest
### Built-in: no

import badge
import ugfx
import deepsleep
import wifi
import time
import urequests as requests
import gc

testDict = {"foo":"bar", "pos": {"x": 1, "y": 2}, "name":"barry", "items":["fish", "barry"]}

def network_test():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()
    wifi_up()
    cleanScreen()
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.text(10, 10, "Testing network", ugfx.BLACK)
    ugfx.flush()

    #Test GET
    result = sendGET("https://jsonplaceholder.typicode.com/posts/1", debug = True )
    #Test POST
    result = sendPOST("http://ptsv2.com/t/emjay/post", testDict, debug = True)

def cleanScreen():
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

def reboot(wut):
    deepsleep.reboot()

def wifi_up():
  wifi.init()
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  return wifi.sta_if.ifconfig()[0]

def sendGET(url, debug = False):
    r = requests.get(url)
    gc.collect()
    data = r.json()
    r.close()

    if(debug):
        print("Response from GET " + url)
        print(data)
    return data

def sendPOST(url, data, debug = False):
    r = requests.post(url, json = data)
    gc.collect()
    response = r.status_code
    r.close()

    if(debug):
        print("Status code from POST " + url)
        print(response)
    return response

network_test()