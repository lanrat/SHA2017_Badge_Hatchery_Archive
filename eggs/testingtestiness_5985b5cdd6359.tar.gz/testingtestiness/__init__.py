import ugfx, gc, wifi, badge, deepsleep
from time import *
import urequests as requests

ugfx.clear(ugfx.BLACK)

# Set up starting up screen
ugfx.init()
ugfx.clear(ugfx.WHITE)

#ugfx.string(10, 10, "Go to the Torvalds field for further instructions.", "Roboto_Regular12", 0)
#ugfx.string(100, 10, "Checking location...", 1)

# ugfx.string(200, 115, '33', 'Roboto_Regular12', ugfx.WHITE)
ugfx.string(200, 115, 'Go to the Torvalds field for further instructions', 'Roboto_Regular12', ugfx.WHITE)
ugfx.line(180, 120, 185, 115, ugfx.WHITE)
ugfx.line(185, 115, 190, 120, ugfx.WHITE)

# ugfx.string(258, 115, '5', 'Roboto_Regular12', ugfx.WHITE)
ugfx.string(258, 115, 'Checking location...', 'Roboto_Regular12', ugfx.WHITE)
ugfx.line(240, 115, 245, 120, ugfx.WHITE)
ugfx.line(245, 120, 250, 115, ugfx.WHITE)

ugfx.flush()

# Make sure WiFi is connected
wifi.ssid = "NW-challenge"
wifi.password = "Northwave Treintjes"
wifi.init()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

sleep(3)

ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "You have arrived! Enter the Northwave tent for further instructions.", "Roboto_Regular12", 0)
ugfx.flush()

sleep(4)

ugfx.flush(ugfx.LUT_FULL)
badge.eink_busy_wait()

machine.deepsleep(1)