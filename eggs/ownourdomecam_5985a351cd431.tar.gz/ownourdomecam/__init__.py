import ugfx
import badge
import appglue

badge.init()
badge.vibrator_init()

ugfx.init()

ugfx.clear(ugfx.BLACK)

ugfx.string(15,15,"Dutchpicknick","Roboto_BlackItalic24",ugfx.WHITE)

ugfx.string(15,40,"tentcam.dutchpicknick.nl","Roboto_BlackItalic24",ugfx.WHITE)

ugfx.flush()
        
def home(pressed):
  if pressed:
    appglue.home()

def render(text, pushed):
    if(pushed):
        badge.vibrator_activate()

ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: render('UP', pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: render('DOWN', pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: render('LEFT', pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: render('RIGHT', pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: render('A', pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: render('B', pressed))
ugfx.input_attach(ugfx.BTN_START, home)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: render('Select', pressed))

while True:
    pass