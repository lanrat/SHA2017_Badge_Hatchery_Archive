from angel import (
	make_qr,
	draw_qr,
)
import badge

qr = None

def setup():
	global qr
	name="angel-{}".format(badge.nvs_get_str("owner", "name", ""))
	qr = make_qr(name)
	return qr

def loop():
	return 300000

def draw(y, sleep=2):
	global qr
	if qr is None:
		qr = setup()
	height=draw_qr(qr, y)
	return [300000, height]