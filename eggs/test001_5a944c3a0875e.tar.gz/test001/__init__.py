import ugfx
ugfx.string(40, 110, "hi", "Roboto_Regular12", ugfx.BLACK)