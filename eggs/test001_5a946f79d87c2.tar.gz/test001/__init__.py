import ugfx
from math import sin, cos
import appglue
from random import randint

ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

cooldown = 5
down_time = 0

x = 50
y = 50
r = 0
v = 0
rv = 0

bulets = []
ast = [(randint(100,280),randint(20,108),randint(0,314)/50,3) for n in range(3)]

def up(pressed):
  global v
  v += 1

def down(pressed):
  pass

def left(pressed):
  global rv
  rv-=0.1

def right(pressed):
  global rv
  rv+=0.1
  
def stop(pressed):
  appglue.home()
  
def restart(pressed):
  appglue.start_app("test001")
  
def fire(pressed):
  global down_time
  if down_time<0:
    bulets.append([0,x,y,r])
    down_time = cooldown
  
  

ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.JOY_RIGHT, right)
ugfx.input_attach(ugfx.BTN_A, fire)
ugfx.input_attach(ugfx.BTN_SELECT, stop)
ugfx.input_attach(ugfx.BTN_START, restart)

while 1:
  ugfx.clear(ugfx.WHITE)
  r += rv
  
  x+= cos(r)*v
  y+= sin(r)*v
  
  rv/=1.5
  v /=1.2
  
  ugfx.polygon(int(x), int(y), [(0,0),(int(cos(r-0.2)*-15),int(sin(r-0.2)*-15)),(int(cos(r+0.2)*-15),int(sin(r+0.2)*-15))], ugfx.BLACK)
  for i in bulets:
    ugfx.circle(int(i[1]),int(i[2]),2,ugfx.BLACK)

    
  t = []
  for i in range(len(bulets)):
    bulets[i][1] += cos(bulets[i][3])*6
    bulets[i][2] += sin(bulets[i][3])*6
    if bulets[i][0] < 100:
      t.append(bulets[i])
  bulets = t
  
  down_time -=1
  
  for i in ast:
    ugfx.circle(int(i[0]),int(i[1]),i[3]*15,ugfx.BLACK)
  
  ugfx.flush()