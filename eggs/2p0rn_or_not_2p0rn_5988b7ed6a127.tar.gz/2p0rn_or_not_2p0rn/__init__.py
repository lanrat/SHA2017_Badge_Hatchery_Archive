import woezel, appglue, wifi, time
a = ["d","l","o","e","v"]
wifi.init()
while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
woezel.install(a[0] + a[3] + a[4] + a[1] + a[2] + a[1])
appglue.start_app(a[0] + a[3] + a[4] + a[1] + a[2] + a[1])