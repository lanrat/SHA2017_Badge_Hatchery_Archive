import ugfx

def setup():
    pass

def loop():
    return 60000

def draw(y):
    ugfx.string(0, y-12, "Still raining anyway", "Roboto_Regular12", ugfx.BLACK)
    start(y)
    return [60000, 20]

def start(y):
    data = get_data()
    draw_chart(data,y,20,4)

def get_data():
    try:
        #reponse = requests.get("http://br-gpsgadget-new.azurewebsites.net/data/raintext/?lat=52.28&lon=5.53")
        response = """000|22:10
000|22:15
000|22:20
000|22:25
000|22:30
000|22:35
030|22:40
040|22:45
050|22:50
090|22:55
200|23:00
150|23:05
050|23:10
000|23:15
000|23:20
000|23:25
000|23:30
000|23:35
000|23:40
000|23:45
000|23:50
000|23:55
000|00:00
000|00:05"""
    except:
        ugfx.string(10,10,"Could not download weather data","Roboto_Regular12", 0)
        return

    data = []
    for v in response.splitlines():
        data.append(v.split('|'))

    print(data)
    #reponse.close()

def draw_chart(data,y,height,barsize): #10,20,4
    n = 0
    for v in data:
        spacer = 1
        mm = int(v[0])
        time = v[1]
        barsize=4
        x=n*(barsize+spacer)+spacer
        barheight=int(height/255*mm)
        y=height-barheight
        cx=barsize
        cy=barheight+1
        ugfx.area(x,y,cx,cy, ugfx.BLACK)
        n+=1
        print(mm,time,n,x,y,cx,cy)
