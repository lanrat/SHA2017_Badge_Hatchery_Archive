import badge

def show_leds(nousb):
    bvol = badge.battery_volt_sense()
    crg = badge.battery_charge_status()
    #bvolmin = badge.nvs_get_u16("splash", "battery.volt.min", 3800)
    #bvolmax = badge.nvs_get_u16("splash", "battery.volt.max", 4300)
    bvolmin = 3800
    bvolmax = 4300
    bvolstg = (bvolmax - bvolmin)/6
    maxbrightness=32
    uvol = badge.usb_volt_sense()
    if nousb and uvol < 4500:
        return 30000
    if uvol >= 4500 and not crg:
        led_status = bytes([maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0, maxbrightness, 0, 0, 0])
        rv = 30000
    else:
        led_status = []
        for i in range(0,6):
            pos = bvol - bvolmin - bvolstg * i
            if pos <= 0:
                add_status = [0, maxbrightness,0,0]
            elif pos >= bvolstg:
                add_status = [maxbrightness, 0,0,0]
            else:
                lb = maxbrightness
                crglvl = round(lb/bvolstg*pos)
                add_status = [crglvl, lb-crglvl,0,0]
            led_status = add_status + led_status
        led_status = bytes(led_status)
        rv = 5000
    badge.leds_send_data(led_status, 24)    
    return rv

