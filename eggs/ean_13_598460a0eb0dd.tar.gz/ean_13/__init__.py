import ugfx
from time import sleep

def main():
  ugfx.clear(ugfx.BLACK)
  sleep(1)