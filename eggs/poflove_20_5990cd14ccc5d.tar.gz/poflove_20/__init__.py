import badge, ugfx, deepsleep, time
badge.leds_enable()
ugfx.input_init()
ugfx.init()

direction = 1
count = 0 
speed = 0.05


def home(pressed):
  if pressed:
    deepsleep.reboot()
    
def speed_up(pressed):
  global speed
  if pressed:
    speed -= 0.02
    if speed < 0.166666: speed = 0.166666

def speed_down(pressed):
  global speed
  if pressed:
    speed += 0.02
    if speed > 1 : speed = 1

def setleds():
	global count
	if count == 0:
	    badge.leds_send_data(''.join(['\0\5\0\0' for i in range(6)]), 24)
	elif count == 1:
	    badge.leds_send_data(''.join(['\0\25\0\0' for i in range(6)]), 24)
	elif count == 2:
	    badge.leds_send_data(''.join(['\0\45\0\0' for i in range(6)]), 24)
	elif count == 3:
	    badge.leds_send_data(''.join(['\0\75\0\0' for i in range(6)]), 24)
	elif count == 4:
	    badge.leds_send_data(''.join(['\0\100\0\0' for i in range(6)]), 24)
	elif count == 5:
	    badge.leds_send_data(''.join(['\0\177\0\0' for i in range(6)]), 24)


ugfx.input_attach(ugfx.BTN_START, home)
#ugfx.input_attach(ugfx.JOY_UP, bright_up)
#ugfx.input_attach(ugfx.JOY_DOWN, bright_down)
ugfx.input_attach(ugfx.JOY_LEFT, speed_down)
ugfx.input_attach(ugfx.JOY_RIGHT, speed_up)

while count <= 6:
	if count == 6:
		direction = -1
	elif count == 0:
		direction = 1
	count = count + direction
	setleds()
	time.sleep(speed)