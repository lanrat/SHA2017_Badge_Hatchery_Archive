from service import kn00p
kn00p()