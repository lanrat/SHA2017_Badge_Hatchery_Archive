# Original author: Llll
import badge, binascii, time, ugfx, dialogs

def hex_to_rgb_tuple(hex_str):
    r,g,b = binascii.unhexlify(hex_str)
    return (g,r,b)

white = hex_to_rgb_tuple("ffffff")
off = hex_to_rgb_tuple("000000")

# Desaturate, or else things just look white
pastel_pink = hex_to_rgb_tuple("441010")
pastel_blue = hex_to_rgb_tuple("101044")

red = hex_to_rgb_tuple("e40303")
orange = hex_to_rgb_tuple("ff8c00")
yellow = hex_to_rgb_tuple("ffed00")
green = hex_to_rgb_tuple("008026")
blue = hex_to_rgb_tuple("004dff")
purple = hex_to_rgb_tuple("750787")

# pastel colours are too light and just look white
trans_pride_colours = [off, pastel_pink, pastel_blue, white, pastel_blue, pastel_pink]
lgbt_pride_colours = [red, orange, yellow, green, blue, purple]
lgbt_pride_colours.reverse()

def show_codes(allcolours):
  for i in range(0, 6):
     print(allcolours[i * 8:i*8+8])

def show_colours(colours, how_long=5):
    allcolours = ''.join([''.join(["{0:02x}".format(int(x)) for x in [r,g,b,0]]) for (r,g,b) in colours])
    #show_codes(allocolours)
    badge.leds_send_data(binascii.unhexlify(allcolours), 24)
    time.sleep(how_long)

while True:
    show_colours(trans_pride_colours, 5)
    show_colours(lgbt_pride_colours, 2)
    
name = badge.nvs_get_str("dating", "name", "")
nick = dialogs.prompt_text("What will you date?", name)
if nick:
  badge.nvs_set_str("dating", "name", nick)

#Nice clean screen
#ugfx.clear(ugfx.BLACK)
#ugfx.flush()
#ugfx.clear(ugfx.WHITE)
#ugfx.flush()

ugfx.string_box(0,0,296,26, "Still looking for", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(0,94,296,26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

#the line under the text
str_len = ugfx.get_string_width(nick,"PermanentMarker36")
line_begin = int((296-str_len)/2)
line_end = str_len+line_begin
ugfx.line(line_begin, 83, line_end, 83, ugfx.BLACK)

#the cursor past the text
cursor_pos = line_end+5
ugfx.line(cursor_pos, 46, cursor_pos, 81, ugfx.BLACK)

ugfx.flush(ugfx.LUT_FULL)