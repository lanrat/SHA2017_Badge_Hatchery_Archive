# Service file for SHA2017 event program app
# Renze Nicolai 2017

import machine, utime, ugfx, appglue

# Prepare libs
event_alarm = __import__('lib/event_schedule/event_alarm')

# Global variables
next_event_title = ""
next_event_room = ""
next_event_countdown = 9999999999

# This function gets called by the home application at boot
def setup():
    print("Event program service setup!")

def loop(sleepCnt):
    alarm_notify()
    return False # Do not prevent sleep

def draw(x,y):
    global next_event_title
    global next_event_countdown
    global next_event_room
    pixels_used = 0
    if (next_event_countdown<9999999999):
        next_event_countdown_minutes = round(next_event_countdown/60)+10
        next_event_title_short = next_event_title
        
        timestr = str(next_event_countdown_minutes)+"m"
        
        if (next_event_countdown_minutes>999):
            next_event_countdown_hours = next_event_countdown_minutes/60
            timestr = str(next_event_countdown_hours)+"h"
            if (next_event_countdown_hours>999):
                next_event_countdown_days = next_event_countdown_hours/24
                timestr = str(next_event_countdown_days)+"d"
        
        if (len(next_event_title_short)>19):
            next_event_title_short = next_event_title_short[0:16]+"..."
        text = "Next event '"+next_event_title_short+"' in '"+next_event_room+"' starts over "+timestr
        
        ypos = y
        
        import version
        if version.build<2: # Legacy versions use different drawing location
            ypos = y-13
            
        
        ugfx.string(x, ypos, text, "Roboto_Regular12",ugfx.BLACK)
        pixels_used = 14
    return pixels_used

def alarm_notify():
    global event_alarm
    event_alarm.alarms_read()
    current_datetime = utime.time()
    
    amount_of_alarms = len(event_alarm.alarms)
    
    for i in range(0, amount_of_alarms):
        alarm = event_alarm.alarms[i]
        c = int(alarm['timestamp']) + 2*60*60 - 10*60 #10 minutes before start
        if (c < current_datetime):
            diff = c - current_datetime
            print("[EVSCH] Alarm time reached for "+alarm['title']+" ("+str(diff)+")")
            appglue.start_app("event_schedule")
        else:
            countdown = abs(c - current_datetime)
            global next_event_countdown
            global next_event_title
            global next_event_room
            if (next_event_countdown>countdown):
                next_event_countdown = countdown
                next_event_title = alarm['title']
                next_event_room = alarm['room']
                print("[EVSCH] Alarm over "+str(countdown)+"s: "+alarm['title']+" in "+alarm['room'])
