import ugfx, gc, wifi, badge, deepsleep, urandom, network
import urequests as requests
from time import *

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

def load_tickets(pushed):
    if(pushed):
        print("Downloading JSON...")
        gc.collect()
        try:
            data = requests.get("https://tickets.sha2017.org/status.json")
        except:
            print("Could not download JSON!")
            sleep(1)
            return
        try:
            global ticketsales
            ticketsales = data.json()
        except:
            data.close()
            print("Could not decode JSON!")
            sleep(1)
            return
        data.close()
    
    print("Rendering list...")
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.string(0, 13*0, str(ticketsales['ordered'])+" sold", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 13*1, str(ticketsales['tickets_left'])+" left", "Roboto_Regular12", ugfx.BLACK)
    
    lastorder = str(ticketsales['last_order'])
    lastorder,leftover = lastorder.split('.')
    lastdate,lasttime=lastorder.split(' ')
    
    ugfx.string(0, 13*2, lastdate, "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 13*3, lasttime, "Roboto_Regular12", ugfx.BLACK)    
    ugfx.flush()

def main():
    load_tickets(1)
    
def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
        
ugfx.input_attach(ugfx.BTN_A, load_tickets)
ugfx.input_attach(ugfx.BTN_B, go_home)
main()