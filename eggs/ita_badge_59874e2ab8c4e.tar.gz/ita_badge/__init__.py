import ugfx, wifi, badge, os
from time import sleep
import urequests as requests

ita_flag = bytes([0, 180, 0, 0,    0, 180, 0, 0,     0, 0, 0, 180,     180, 180, 180, 0,    180, 0, 0, 0,   180, 0, 0, 0])

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()


nick = badge.nvs_get_str('owner', 'name', '')
if  ugfx.get_string_width(nick, "PermanentMarker36") < 180 :
    nick_font = "PermanentMarker36"
elif ugfx.get_string_width(nick, "PermanentMarker22") < 180 :
    nick_font = "PermanentMarker22"
elif ugfx.get_string_width(nick, "Roboto_Regular18") < 180 :
    nick_font = "Roboto_Regular18"
else:
    nick_font = "Roboto_Regular12"

pix_name = nick.replace(" ","%20").lower() + '.png'
full_pix_name = '/lib/ita_badge/' + pix_name

files = os.listdir('/lib/ita_badge')
if pix_name not in files:
    ugfx.string(10,10, "Pix missing, trying to get: " + pix_name,"Roboto_Regular12",ugfx.WHITE)

# Download pix
    wifi.init()
    ugfx.string(10,20,"Waiting for wifi...","Roboto_Regular12", ugfx.WHITE)
    ugfx.flush()

# Wait for WiFi connection
    xstep = 10
    while not wifi.sta_if.isconnected():
        sleep(1)
        ugfx.pixel(xstep, 28, ugfx.WHITE)
        xstep = xstep + 4
        ugfx.flush()

# fetching and saving pix
    ugfx.string(10,30,"got wifi, connecting...","Roboto_Regular12", ugfx.WHITE)
    sleep(10)
    url = "http://shaserver.bofh.it/"

    r = requests.get(url+pix_name)
    if r.status_code == 200:
        f = open( full_pix_name,'wb')
        pix_data = r.content
        f.write( pix_data)
        f.close()
        ugfx.string(10,40,"got pix, writing file...","Roboto_Regular12", ugfx.WHITE)
    else:
        full_pix_name = '/lib/ita_badge/miss.png'
        ugfx.string(10,40,"no pix! STILL GRAPPA ANYWAY ¯\_(ツ)_/¯","Roboto_Regular12", ugfx.WHITE)

badge.eink_png(0,15, full_pix_name)

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, go_home)

while True:
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.clear(ugfx.BLACK)
    badge.eink_png(0,15, full_pix_name)
    ugfx.string(115,53, nick, nick_font, ugfx.WHITE)
    ugfx.flush()

    sleep(7)
    badge.leds_init()
    badge.leds_send_data(ita_flag, 24)
    sleep(0.3)
    badge.leds_disable()
    sleep(0.3)
    badge.leds_init()
    badge.leds_send_data(ita_flag, 24)
    sleep(0.3)
    badge.leds_disable()
    sleep(0.3)
    badge.leds_init()
    badge.leds_send_data(ita_flag, 24)
    sleep(0.3)
    badge.leds_disable()
    sleep(3)

    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.clear(ugfx.BLACK)
    badge.eink_png(0,15, full_pix_name)
    ugfx.string(115,53, nick, nick_font, ugfx.WHITE)
    badge.eink_png(95,35,'/lib/ita_badge/ITAemb.png')
    ugfx.flush()
    ugfx.string(3,190,"SHA2017 ¯\_(ツ)_/¯","pixelade13", ugfx.WHITE)
    ugfx.flush()
    sleep( 2)