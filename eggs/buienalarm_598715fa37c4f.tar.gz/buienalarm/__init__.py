import easywifi
import ugfx

from . import buienradar

easywifi.enable()

ugfx.set_lut(ugfx.LUT_FULL)
ugfx.clear(ugfx.WHITE)
buienradar.draw_rain_graph(0, 0, 296, 128, 1.0, ugfx.BLACK)
ugfx.flush()