import ugfx
import time
import badge
import urandom 

# Basic implementation of tetris, feel free to adapt!
# Only tested on emulator, hope it works on the real thing...

ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

class Tetris:
    def __init__(self):
        self.font = "fixed_10x20"
        self.game_step_time = 500

        # nr of unique rotations per piece
        self.piece_rotations = [1, 2, 2, 2, 4, 4, 4]

        # Piece data: [piece_nr * 32 + rot_nr * 8 + brick_nr * 2 + j]
        # with rot_nr between 0 and 4
        # with the brick number between 0 and 4
        # and j == 0 for X coord, j == 1 for Y coord
        self.piece_data = [
            # square block
            0, 0, -1, 0, -1, -1, 0, -1, 
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,

            # line block
            0, 0, -2, 0, -1, 0, 1, 0,
            0, 0, 0, 1, 0, -1, 0, -2,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,

            # S-block
            0, 0, -1, -1, 0, -1, 1, 0, 
            0, 0, 0, 1, 1, 0, 1, -1, 
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,

            # Z-block
            0, 0, -1, 0, 0, -1, 1, -1, 
            0, 0, 1, 1, 1, 0, 0, -1, 
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,

            # L-block
            0, 0, -1, 0, -1, -1, 1, 0, 
            0, 0, 0, 1, 0, -1, 1, -1, 
            0, 0, -1, 0, 1, 0, 1, 1, 
            0, 0, -1, 1, 0, 1, 0, -1, 

            # J-block
            0, 0, -1, 0, 1, 0, 1, -1, 
            0, 0, 0, 1, 0, -1, 1, 1, 
            0, 0, -1, 1, -1, 0, 1, 0, 
            0, 0, 0, 1, 0, -1, -1, -1, 

            # T-block
            0, 0, -1, 0, 0, -1, 1, 0,  
            0, 0, 0, 1, 0, -1, 1, 0, 
            0, 0, -1, 0, 0, 1, 1, 0, 
            0, 0, -1, 0, 0, 1, 0, -1
        ]


        badge.init()

        ugfx.init()
        ugfx.set_lut(ugfx.LUT_FASTEST)
        ugfx.clear(ugfx.WHITE)
        #self.draw_field_lines()
        ugfx.flush()

        ugfx.input_init()
        ugfx.input_attach(ugfx.JOY_UP,lambda pressed: self.btn_up(pressed))
        ugfx.input_attach(ugfx.JOY_DOWN,lambda pressed: self.btn_down(pressed))
        ugfx.input_attach(ugfx.JOY_LEFT,lambda pressed: self.btn_left(pressed))
        ugfx.input_attach(ugfx.JOY_RIGHT,lambda pressed: self.btn_right(pressed))
        ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: self.btn_select(pressed))
        ugfx.input_attach(ugfx.BTN_START,lambda pressed: self.btn_start(pressed))
        ugfx.input_attach(ugfx.BTN_A,lambda pressed: self.btn_a(pressed))
        ugfx.input_attach(ugfx.BTN_B,lambda pressed: self.btn_b(pressed))
    
        self.game_init()
        self.draw_updated_score()

        while True:
            self.game_update()
            self.draw()

    def game_init(self):
        # Init game state
        self.spawn_new_piece()
        self.field = [[0 for i in range(10)] for j in range(20)]
        self.last_update = time.ticks_ms()
        self.score = 0


    def spawn_new_piece(self):
        self.piece_type = urandom.getrandbits(8) % 7
        self.piece_x = 4
        self.piece_y = 0
        self.piece_rot = 0


    def game_update(self):
        cur_ticks = time.ticks_ms()
        if cur_ticks - self.last_update > self.game_step_time:
            # Move piece down
            self.lower_piece()
            self.last_update = cur_ticks

    def rotate_piece(self):
        self.piece_rot += 1
        if self.piece_rot >= self.piece_rotations[self.piece_type]:
            self.piece_rot = 0

    def is_side_collision(self):
        for square in range(4):
            x_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 0]
            y_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 1]

            abs_x = self.piece_x + x_off
            abs_y = self.piece_y + y_off

            # collision with walls
            if abs_x < 0 or abs_x >= 10:
                return True

            # collision with field blocks
            if self.field[abs_y][abs_x]:
                return True

        return False


    def move_left(self):
        self.piece_x -= 1

        # check collision with walls
        if self.is_side_collision():
            self.piece_x += 1

    def move_right(self):
        self.piece_x += 1

        # check collision with walls
        if self.is_side_collision():
            self.piece_x -= 1


    def lower_piece(self):
        self.piece_y += 1

        # check for collisions
        collision = False
        for square in range(4):
            x_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 0]
            y_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 1]

            abs_x = self.piece_x + x_off
            abs_y = self.piece_y + y_off

            if abs_y >= 20 or self.field[abs_y][abs_x]:
                collision = True
                break

        if collision:
            # if at the top, game over
            if self.piece_y == 1:
                self.draw_game_over()
                time.sleep(10)
                self.game_init()

            # add to field
            self.piece_y -= 1
            for square in range(4):
                x_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 0]
                y_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 1]

                abs_x = self.piece_x + x_off
                abs_y = self.piece_y + y_off

                self.field[abs_y][abs_x] = True

            # check for line clears
            self.check_for_filled_lines()

            # Spawn new piece
            self.spawn_new_piece()


    def check_for_filled_lines(self):
        for row in range(20):
            fill_count = 0
            for column in range(10):
                fill_count += self.field[row][column]
            if fill_count == 10:
                # Increase score
                self.score += 10
                self.draw_updated_score()

                # Remove line
                for row2 in range(row, 0, -1):
                    for column2 in range(10):
                        self.field[row2][column2] = self.field[row2-1][column2]




    def draw(self):
        #ugfx.clear(ugfx.WHITE)
        #ugfx.string(20,20,"Hello world",self.font,ugfx.WHITE)
        
        self.draw_field()
        self.draw_current_piece()
        ugfx.flush()

    def draw_updated_score(self):
        # draw box, draw score
        # ugfx.area(10, 110, 100, 130, ugfx.WHITE)
        ugfx.string(10, 110, "Score: {:04d}".format(self.score), self.font, ugfx.BLACK)
        # TODO

    def draw_game_over(self):
        ugfx.clear(ugfx.WHITE)
        ugfx.string(70, 50, "GAME OVER :(", "PermanentMarker22", ugfx.BLACK)
        ugfx.flush()

    def draw_field_lines(self):
        #ugfx.box(10,10,200,100,ugfx.WHITE)

        # Draw grid
        for column in range(10):
            ugfx.line(10, 10 + 10 * column, 200, 10 + 10 * column, ugfx.WHITE)

        for row in range(20):
            ugfx.line(10 + 10 * row, 10, 10 + 10 * row, 100, ugfx.WHITE)
            pass

    def draw_field(self):
        for column in range(10):
            for row in range(20):
                self.draw_square(row, column, self.field[row][column])

    def draw_current_piece(self):
        for square in range(4):
            # [piece_nr * 32 + rot_nr * 8 + brick_nr * 2 + j]
            x_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 0]
            y_off = self.piece_data[self.piece_type * 32 + self.piece_rot * 8 + square * 2 + 1]

            abs_x = self.piece_x + x_off
            abs_y = self.piece_y + y_off

            self.draw_square(abs_y, abs_x, True)


    def draw_square(self, row, column, filled=True):
        if row < 0 or column < 0 or row >= 20 or column >= 10:
            return
        ugfx.box(10 + 10 * (19-row), 10 + 10 * column, 10, 10, ugfx.BLACK if filled else ugfx.WHITE)
        # filled in bricks: s/box/area/


    # Controls are rotated to the left
    # UP button = left
    # DOWN button = right
    # RIGHT button = up
    # LEFT button = down

    def btn_a(self,pressed):
        if pressed:
            print("Rotating piece")
            self.rotate_piece()

    def btn_b(self,pressed):
        if pressed:
            print("Rotating piece")
            self.rotate_piece()

    def btn_up(self,pressed):
        if pressed:
            print("Moving piece left")
            self.move_left()

    def btn_down(self,pressed):
        if pressed:
            print("Moving piece right")
            self.move_right()

    def btn_left(self,pressed):
        if pressed:
            print("Moving piece down")
            self.lower_piece()

    def btn_right(self,pressed):
        if pressed:
            print("Rotating piece")
            self.rotate_piece()

    def btn_start(self,pressed):
        if pressed:
            print("Resetting game")
            self.game_init()

    def btn_select(self,pressed):
        if pressed:
            pass


tetris = Tetris()