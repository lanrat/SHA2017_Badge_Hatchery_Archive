# Service file for SHA2017 event program app
# Renze Nicolai 2017

# This function gets called by the home application at boot
def event_program_timer_callback(tmr):
    print("Event program service timer!")

def service(tmr, cstate, percent):
    event_alarm = __import__('lib/sha2017_event_program/event_alarm')
    print("Event program service entered!")
    
    alarms_scheduled = 1 #FIXME
    
    if (alarms_scheduled>0):
      import machine
      event_program_timer = machine.Timer(-1)
      event_program_timer.init(period=500, mode=machine.Timer.PERIODIC, callback=event_program_timer_callback)
    
    #event_alarm.alarm_notify()
    
    print("Event program service finished!")
