import sys
lJgsa=range
lJgsX=True
lJgsT=OSError
lJgbs=False
lJgbr=len
lJgbS=open
lJgsC=sys.path
import gc
lJgsI=gc.collect
import network
lJgsF=network.WLAN
lJgsj=network.STA_IF
lJgsx=network.AP_IF
import machine
lJgsU=machine.unique_id
import usocket as socket
lJgsR=socket.getaddrinfo
lJgsf=socket.socket
import badge
lJgso=badge.nvs_set_str
lJgse=badge.nvs_get_str
import ugfx
lJgsn=ugfx.BLACK
lJgsw=ugfx.clear
lJgsi=ugfx.input_attach
lJgsW=ugfx.string
lJgsO=ugfx.WHITE
lJgsp=ugfx.flush
lJgsM=ugfx.BTN_A
lJgsy=ugfx.BTN_B
lJgsk=ugfx.input_init
import appglue
lJgsB=appglue.start_app
lJgsY=appglue.home
import time
lJgsz=time.sleep
import dialogs
lJgsd=dialogs.prompt_boolean
lJgsQ=dialogs.prompt_text
import machine
lJgsU=machine.unique_id
lJgsC.append('/lib/SHA2017Game')
import game_common
lJgsE=game_common.determineLeague
import callsign
lJgsA=callsign.callsign
lJgsb=["red","fuchsia","blue","green","yellow","orange"]
def get_fragments():
 lJgsr=[]
 for i in lJgsa(0,25):
  lJgsS=lJgse('SHA2017Game',"fragment_%d"%i)
  if lJgsS:
   lJgsr.append(lJgsS)
 return lJgsr
def add_fragment(newfragment):
 for i in lJgsa(0,25):
  lJgsS=lJgse('SHA2017Game',"fragment_%d"%i)
  if lJgsS:
   if lJgsS==newfragment:
    return
  else:
   lJgso('SHA2017Game',"fragment_%d"%i,newfragment)
   return
def leaguename():
 lJgsV=lJgsE()
 return lJgsb[lJgsV]
def receiveData(lJgsq,cb,errcb):
 w=lJgsF(lJgsx)
 w.active(lJgsX)
 w.config(essid=lJgsq,channel=11)
 s=lJgsf()
 ai=lJgsR("0.0.0.0",2017)
 print("Bind address info:",ai)
 lJgsN=ai[0][-1]
 s.bind(lJgsN)
 s.listen(5)
 print('Listening at',lJgsq)
 s.settimeout(30)
 try:
  lJgsG=s.accept()
  lJgst=lJgsG[0]
  lJgsm=lJgsG[1]
  print("Client address:",lJgsm)
  print("Client socket:",lJgst)
  lJgsD=lJgst
  print("Request:")
  lJgsL=lJgsD.readline()
  print(lJgsL)
  lJgsD.send('OK\r\n')
  lJgsv=cb(lJgsL)
  lJgsD.close()
  print("Done.")
 except lJgsT:
  print("Error")
  lJgsv=errcb()
 s.close()
 w.active(lJgbs)
 if lJgsv:
  lJgsB('SHA2017Game')
def gotOracleData(data):
 lJgso('SHA2017Game','fragment_0',data)
 return lJgsX
def listenForOracle(leaguename):
 lJgsw(lJgsO)
 lJgsW(0,0,"Find the oracle!","PermanentMarker22",lJgsn)
 lJgsW(0,30,"Welcome, brave traveller of league %s. Your quest"%leaguename,"Roboto_Regular12",lJgsn)
 lJgsW(0,50,"starts once you have found the oracle. When you are","Roboto_Regular12",lJgsn)
 lJgsW(0,70,"near she will call out for you and provide further","Roboto_Regular12",lJgsn)
 lJgsW(0,90,"instructions. You have 30 seconds per attempt.","Roboto_Regular12",lJgsn)
 lJgsp()
 receiveData('OracleSeeker',gotOracleData,lJgsY)
def send_to(recv):
 lJgsw(lJgsO)
 lJgsW(0,0,"Share your fragments!","PermanentMarker22",lJgsn)
 lJgsW(0,30,"Connecting to other player...","Roboto_Regular12",lJgsn)
 lJgsp()
 n=0
 try:
  w=lJgsF(lJgsj)
  w.active(lJgsX)
  ap="Gamer %s %s"%(leaguename(),recv)
  print('Connecting to',ap)
  w.connect(ap)
  while not w.isconnected()and n<30:
   lJgsz(1)
   n=n+1
 except msg:
  print("error!",msg)
  lJgsW(0,50,"Error connecting to other player...","Roboto_Regular12",lJgsn)
  lJgsp()
  lJgsk()
  lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
  return
 if n==30:
  print('No connection after sleeping 30 seconds')
  lJgsW(0,50,"Error connecting to other player...","Roboto_Regular12",lJgsn)
  lJgsp()
  lJgsk()
  lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
  return
 lJgsW(0,50,"Sending fragments...","Roboto_Regular12",lJgsn)
 lJgsp()
 s=lJgsf()
 ai=lJgsR("192.168.4.1",2017)
 lJgsN=ai[0][-1]
 s.connect(lJgsN)
 s.send('#'.join(get_fragments()))
 s.send("\r\n")
 s.readline()
 s.close()
 w.active(lJgbs)
 print('Done sending')
 lJgsW(0,70,"Sent fragments. Press A.","Roboto_Regular12",lJgsn)
 lJgsp()
 lJgsk()
 lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
def gotFragmentData(data):
 print('Got fragment data: ',data)
 for lJgsS in data.decode().replace('\n','').replace('\r','').split('#'):
  add_fragment(lJgsS)
 lJgsu=get_fragments()
 if lJgbr(lJgsu)>=25:
  lJgsB('SHA2017Game')
 lJgsW(0,70,"You now own %d unique fragments, %d to go!"%(lJgbr(lJgsu),25-lJgbr(lJgsu)),"Roboto_Regular12",lJgsn)
 lJgsW(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",lJgsn)
 lJgsp()
 lJgsk()
 lJgsi(lJgsy,lambda pressed:lJgsY()if pressed else 0)
 lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
 return lJgbs;
def receive_fragments_failed():
 lJgsW(0,70,"Failed to receive fragments. Press A.","Roboto_Regular12",lJgsn)
 lJgsp()
 lJgsk()
 lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
def receive_fragments():
 receiveData("Gamer %s %03d%03d"%(leaguename(),lJgsU()[4],lJgsU()[5]),gotFragmentData,receive_fragments_failed)
def send_or_recv(send):
 if send:
  lJgsw(lJgsO)
  lJgsQ("Receiver address:",cb=send_to)
 else:
  lJgsw(lJgsO)
  lJgsW(0,0,"Share your fragments!","PermanentMarker22",lJgsn)
  lJgsW(0,30,"Tell the other player of your league your address,","Roboto_Regular12",lJgsn)
  lJgsW(0,50,"which is %03d%03d. Waiting..."%(lJgsU()[4],lJgsU()[5]),"Roboto_Regular12",lJgsn)
  lJgsp()
  receive_fragments()
def initiate_sharing():
 lJgsw(lJgsO)
 lJgsW(0,0,"Share your fragments!","PermanentMarker22",lJgsn)
 lJgsd("Do you want to send or receive?",true_text="Send",false_text="Receive",height=100,cb=send_or_recv)
def won():
 lJgsw(lJgsO)
 lJgsW(0,0,"Congratulations!","PermanentMarker22",lJgsn)
 lJgsW(0,30,"Cool! You've unlocked your league's secret. As a reward","Roboto_Regular12",lJgsn)
 lJgsW(0,50,"the signal shown by your badge LEDs will now sparkle.","Roboto_Regular12",lJgsn)
 lJgsW(0,70,"Is this the end? That is up to you! Contact raboof for","Roboto_Regular12",lJgsn)
 lJgsW(0,90,"the game code and design new challenges!","Roboto_Regular12",lJgsn)
 lJgsW(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",lJgsn)
 lJgsp()
 lJgsk()
 lJgsi(lJgsy,lambda pressed:lJgsY()if pressed else 0)
 lJgsi(lJgsM,lambda pressed:initiate_sharing()if pressed else 0)
def main():
 lJgsI()
 lJgsV=lJgsE()
 lJgsA(lJgsV)
 if lJgbs:
  lJgsw(lJgsO)
  lJgsW(0,0,"Welcome, early bird!","PermanentMarker22",lJgsn)
  lJgsW(0,30,"Welcome to the SHA2017Game! You are in league","Roboto_Regular12",lJgsn)
  lJgsW(0,50,"%s, as your 'callsign' shows if you soldered on your"%leaguename(),"Roboto_Regular12",lJgsn)
  lJgsW(0,70,"LEDs. The game starts when the oracle is on the field,","Roboto_Regular12",lJgsn)
  lJgsW(0,90,"keep an eye on https://twitter.com/SHA2017Game.","Roboto_Regular12",lJgsn)
  lJgsW(5,113,"B: Back to home","Roboto_Regular12",lJgsn)
  lJgsp()
  lJgsk()
  lJgsi(lJgsy,lambda pressed:lJgsY()if pressed else 0)
  return
 lJgsu=get_fragments()
 print('number of fragments so far',lJgbr(lJgsu))
 lJgsc=lJgbs
 if lJgbr(lJgsu)>=25:
  lJgsw(lJgsO)
  try:
   import os
   os.stat('/lib/SHA2017game/sparkle.py')
   won()
  except:
   import wifi
   import urequests
   import shards
   wifi.init()
   while not wifi.sta_if.isconnected():
    lJgsz(1)
   lJgsh=shards.key_from_shards(lJgsu)
   print('Collecting shards.py with key',lJgsh)
   r=urequests.get("http://pi.bzzt.net/%s/sparkle.py"%lJgsh)
   f=lJgbS('/lib/SHA2017game/sparkle.py','w')
   f.write(r.content)
   f.close()
   won()
 elif lJgbr(lJgsu)>0:
  lJgsw(lJgsO)
  lJgsW(0,0,"Share your fragments!","PermanentMarker22",lJgsn)
  lJgsW(0,30,"The oracle gave you a fragment of a relic of the "+leaguename(),"Roboto_Regular12",lJgsn)
  lJgsW(0,50,"league. 25 such fragments must be brought together","Roboto_Regular12",lJgsn)
  lJgsW(0,70,"to unlock its potential. Find other league members to","Roboto_Regular12",lJgsn)
  lJgsW(0,90,"share fragments along with a story or Mate.","Roboto_Regular12",lJgsn)
  lJgsW(5,113,"B: Back to home                                A: Share fragments","Roboto_Regular12",lJgsn)
  lJgsp()
  lJgsk()
  lJgsi(lJgsy,lambda pressed:lJgsY()if pressed else 0)
  lJgsi(lJgsM,lambda pressed:initiate_sharing()if pressed else 0)
 elif lJgsc:
  def oracle_selection_made(value):
   lJgsA(lJgsV)
   if value:
    listenForOracle(leaguename())
   else:
    lJgsY()
  def dialog_title():
   return "SHA2017Game - you are in league "+leaguename()
  lJgsd('Are you ready to start your quest?',title=dialog_title(),true_text='Search for the oracle',false_text='Back to home screen',height=100,cb=oracle_selection_made)
 else:
  lJgsw(lJgsO)
  lJgsW(0,0,"Retrieving fragment!","PermanentMarker22",lJgsn)
  lJgsW(0,30,"Welcome player of league "+leaguename(),"Roboto_Regular12",lJgsn)
  lJgsW(0,50,"Fetching your initial fragment!","Roboto_Regular12",lJgsn)
  lJgsp()
  import wifi
  import urequests
  wifi.init()
  n=0
  while not wifi.sta_if.isconnected()and n<30:
   lJgsz(1)
   n=n+1
  if n==30:
   lJgsW(0,70,"Failed! Press A.","Roboto_Regular12",lJgsn)
   lJgsk()
   lJgsi(lJgsM,lambda pressed:lJgsB('SHA2017Game')if pressed else 0)
   return
  lJgsK=(lJgsU()[3]+lJgsU()[4]+lJgsU()[5])%700
  r=urequests.get("http://pi.bzzt.net/oracle/%d/%d"%(lJgsV,lJgsK))
  gotOracleData(r.content)
  lJgsB('SHA2017Game')
main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)

