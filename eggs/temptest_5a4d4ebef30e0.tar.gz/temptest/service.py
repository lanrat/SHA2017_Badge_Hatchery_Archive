import machine, onewire, ds18x20
import badge, ugfx, wifi

def setup():
  global ds
  global roms
  
  #init badge stuff
  badge.init()
  wifi.init()
  
  #init gfx stuff
  ugfx.init()
  ugfx.input_init()
  
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()

  #setup pins for tempurature senspr

  #provide power to the header expansion
  badge.power_sdcard_enable()
  dat = machine.Pin(33)

  # create the onewire object
  ds = ds18x20.DS18X20(onewire.OneWire(dat))

  # scan for devices on the bus
  roms = ds.scan()

def loop():
  Temperature()
  return [60000, 0]

def draw(y):
  Temperature()
  return [60000, 0]
  
def draw_going_to_sleep(y):
  Temperature()
  return [60000, 0]

def Temperature():
  global roms
  global ds
  print("%.2f"%ds.read_temp(roms[0]))
  ds.convert_temp()
  ugfx.area(49,30,200,100,ugfx.WHITE)
  ugfx.string(50, 30, "Temp is %.2f" % (ds.read_temp(roms[0])) , "Roboto_BlackItalic24", ugfx.BLACK) 
  ugfx.flush()