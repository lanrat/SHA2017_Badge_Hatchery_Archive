import ugfx
import badge
import random
import time
import appglue


HELP_TEXT = "start : finish game | up : Scissor | left : Stone | down : Paper"

def init():
	badge.init()
	ugfx.init()
	ugfx.input_init()
	
	ugfx.input_attach(ugfx.JOY_UP,lambda pressed: btn_up(pressed))
	ugfx.input_attach(ugfx.JOY_DOWN,lambda pressed: btn_down(pressed))
	ugfx.input_attach(ugfx.JOY_LEFT,lambda pressed: btn_left(pressed))
	ugfx.input_attach(ugfx.JOY_RIGHT,lambda pressed: btn_right(pressed))
	ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: btn_select(pressed))
	ugfx.input_attach(ugfx.BTN_START,lambda pressed: btn_start(pressed))
	ugfx.input_attach(ugfx.BTN_A,lambda pressed: btn_a(pressed))
	ugfx.input_attach(ugfx.BTN_B,lambda pressed: btn_b(pressed))

def draw_line(xstart,ystart,xend,yend,xoffset,yoffset,fgcolor):
	ugfx.line(xstart+xoffset,ystart+yoffset,xend+xoffset,yend+yoffset,fgcolor)
	

def get_xoffset(position):
	if position == 0:
		xoffset = 40
	else:
		xoffset = 180

	return xoffset	

def draw_stone(fgcolor,position):
	
	# draw stone
	xoffset = get_xoffset(position)
	yoffset = 30

	draw_line(0,20,0,60,xoffset,yoffset,fgcolor)
	draw_line(0,60,30,80,xoffset,yoffset,fgcolor)
	draw_line(30,80,40,85,xoffset,yoffset,fgcolor)
	draw_line(40,85,60,90,xoffset,yoffset,fgcolor)
	draw_line(40,90,60,95,xoffset,yoffset,fgcolor)
	draw_line(60,95,80,85,xoffset,yoffset,fgcolor)
	draw_line(80,80,80,50,xoffset,yoffset,fgcolor)
	draw_line(80,50,70,45,xoffset,yoffset,fgcolor)
	draw_line(70,45,60,35,xoffset,yoffset,fgcolor)
	draw_line(60,35,57,25,xoffset,yoffset,fgcolor)
	draw_line(57,25,37,33,xoffset,yoffset,fgcolor)
	draw_line(37,33,2,20,xoffset,yoffset,fgcolor)

	draw_line(70,45,50,35,xoffset,yoffset,fgcolor)
	draw_line(50,35,20,35,xoffset,yoffset,fgcolor)
	draw_line(20,35,0,20,xoffset,yoffset,fgcolor)

	ugfx.string(15+xoffset, 40+yoffset, "Stone", "PermanentMarker22",fgcolor)


def draw_paper(fgcolor,position):
	xoffset = get_xoffset(position)
	yoffset = 30

	draw_line(10,20,70,20,xoffset,yoffset,fgcolor)
	draw_line(70,20,70,95,xoffset,yoffset,fgcolor)
	draw_line(70,95,10,95,xoffset,yoffset,fgcolor)
	draw_line(10,95,10,20,xoffset,yoffset,fgcolor)

	ugfx.string(15+xoffset, 40+yoffset, "Paper", "PermanentMarker22",fgcolor)

def draw_scissor(fgcolor,position):
	xoffset = get_xoffset(position)
	yoffset = 30

	ugfx.string(15+xoffset, 40+yoffset, "Scissor", "PermanentMarker22",fgcolor)

def draw_vs(fgcolor):
	ugfx.string(160, 70, ":", "PermanentMarker22",fgcolor)

def draw_topbox(fgcolor):
	ugfx.box(2,2,292,25,ugfx.BLACK)

def draw_help_menu(fgcolor):
	global HELP_TEXT
	ugfx.string(10, 10, HELP_TEXT, "PermanentMarker24",fgcolor)

def	draw_score(playerscore,cpuscore,fgcolor):
	ugfx.string(5, 115, str(playerscore), "PermanentMarker20",fgcolor)
	ugfx.string(280, 115, str(cpuscore), "PermanentMarker20",fgcolor)

def draw_decision(d,pos):
	global fgcolor
	if d == 1:
		draw_stone(fgcolor,pos)
	if d == 2:
		draw_paper(fgcolor,pos)
	if d == 3:
		draw_scissor(fgcolor,pos)

def draw():
	global fgcolor
	global player_decision
	global playerscore
	global cpuscore

	STONE = 1
	PAPER = 2
	SCISSOR = 3 

	while( player_decision == 0 ):
		ugfx.clear(ugfx.WHITE)

		draw_topbox(fgcolor)
		draw_help_menu(fgcolor)
		draw_vs(fgcolor)
		draw_score(playerscore,cpuscore,fgcolor)

		ugfx.flush()

	draw_decision(player_decision,0)
	ugfx.flush()

	time.sleep(0.6)
	cpu_decision = random.randint(1, 3) 
	draw_decision(cpu_decision,1)
	ugfx.flush()

	time.sleep(0.8)

	if cpu_decision == player_decision:
		pass
	
	elif (cpu_decision == STONE and player_decision == PAPER) \
	or (cpu_decision == SCISSOR and player_decision == STONE) \
	or (cpu_decision == PAPER and player_decision == SCISSOR):
		playerscore+=1
		ugfx.string(100, 15, "YOU WON", "PermanentMarker22",fgcolor)
		ugfx.flush()
	
	elif (cpu_decision == STONE and player_decision == SCISSOR) \
	or (cpu_decision == SCISSOR and player_decision == PAPER) \
	or (cpu_decision == PAPER and player_decision == STONE):
		cpuscore+=1
		ugfx.string(100, 15, "YOU LOSE", "PermanentMarker22",fgcolor)
		ugfx.flush()

	time.sleep(0.6)
	player_decision = 0 


def draw_init():
	global to_press_select
	global fgcolor

	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	time.sleep(1)
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	time.sleep(1)

	draw_topbox(fgcolor)
	ugfx.string(20, 0, "::: Stone Scissor Paper :::", "PermanentMarker22",fgcolor)

	draw_stone(fgcolor,0)
	draw_paper(fgcolor,1)
	draw_vs(fgcolor)
	ugfx.flush()

	time.sleep(2)

	while(to_press_select):
		ugfx.string(120, 100, "press Select", "PermanentMarker16",ugfx.BLACK)
		ugfx.flush()
		time.sleep(0.5)
		ugfx.string(120, 100, "press Select", "PermanentMarker16",ugfx.WHITE)
		ugfx.flush()
		time.sleep(0.5)



def btn_a(pressed):
    if pressed:
	    print("Rotating piece")

def btn_b(pressed):
	if pressed:
		print("Rotating piece")

def btn_up(pressed):
   	global player_decision
	if pressed:
		print("Moving piece left")
		player_decision = 3

def btn_down(pressed):
	global player_decision
	if pressed:
		print("Moving piece right")
		player_decision = 2 

def btn_left(pressed):
	global player_decision
	if pressed:
		print("Moving piece down")
		player_decision = 1

def btn_right(pressed):
	if pressed:
		print("Rotating piece")

def btn_start(pressed):
	if pressed:
		ugfx.string(50, 50, "START", "PermanentMarker22",fgcolor)
		ugfx.flush()
        appglue.start_app("launcher",False)

def btn_select(pressed):
	global to_press_select 
	if pressed:
		print("Resetting game")
		to_press_select = False


playerscore = 0
cpuscore = 0
to_press_select = True
fgcolor = ugfx.BLACK
player_decision = 0

init()
draw_init()
# main loop
while(True):
	draw()

	