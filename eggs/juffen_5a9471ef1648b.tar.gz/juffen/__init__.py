import ugfx
n=0       

def juf(var):
	jufs=0
	if((var%7)==0):
		jufs=jufs+1
	p=0
	m=int(var/(10**p))
	while(m!=0):
		#string=string+str(m)+" "
		if((m%10)==7):
			jufs=jufs+1
		p=p+1
		m=int(var/(10**p))
	if(jufs!=0):
		return 1
	else:
		return 0

def A(pressed):
	if(pressed):
		C(0)

def B(pressed):
	if(pressed):
		C(1)
def START(pressed):
	if(pressed):
		n=0
		printnext()

def C(wajo):
	global n
	n=n+1
	if(wajo!=juf(n)):
		printnext()
	else:
		printdrink()

 
def printnext():
	stringA="previous:"
	if(juf(n)):
		stringA=stringA+"JUF"
	else:
		stringA=stringA+str(n)

	stringB="B:"+str(n+1)+" A: JUF"

	ugfx.clear(ugfx.BLACK)        	                                 # Clear screen
	ugfx.string(20, 30, stringA , "Roboto_BlackItalic24", ugfx.WHITE) # Write a string to the center of the screen
	ugfx.string(20, 70, stringB , "Roboto_BlackItalic24", ugfx.WHITE) # Write a string to the center of the screen
	ugfx.flush(ugfx.LUT_NORMAL) 

def printdrink():
	global n
	ugfx.clear(ugfx.BLACK)        	                                 # Clear screen
	ugfx.string(50, 50, "DRINKEN!!" , "Roboto_BlackItalic24", ugfx.WHITE) # Write a string to the center of the screen
	ugfx.flush(ugfx.LUT_NORMAL) 
	n=0

ugfx.input_init()                                                # Initialize button callbacks
ugfx.input_attach(ugfx.BTN_A, A)   # Connect button callback function
ugfx.input_attach(ugfx.BTN_B, B)   # Connect button callback function
ugfx.input_attach(ugfx.BTN_START, START)   # Connect button callback function