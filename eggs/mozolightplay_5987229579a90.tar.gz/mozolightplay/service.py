import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(175,45,'/lib/mozolightplay/mozo.png')
    return 0