import ugfx, badge, appglue
settings = ["WiFi: SSID", "WiFi: password"]

settings_json = "";

def draw_msg(title, desc):
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, title, "PermanentMarker22", ugfx.BLACK)
    ugfx.string(0, 25, desc, "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()
    
def start_home(pushed):
    if(pushed):
        appglue.home()
        
def edit(name):
    print("EDIT: "+name)
        
def menu_change(pressed):
    if (pressed):
        global options
        global settings
        selected = options.selected_index()
        print("CHANGE: "+settings[selected])
     
def menu_submit(pressed):
    if (pressed):
        global options
        global settings
        selected = options.selected_index()
        options.destroy()
        print("SUBMIT: "+settings[selected])
        edit(settings[selected])
        menu()
        
     
def menu():
    global options
    global settings
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "SETTINGS", "Roboto_Regular12", ugfx.BLACK)
    options = ugfx.List(0,15,round(ugfx.width()/2),ugfx.height())
    for event in range(0, len(settings)):
        options.add_item(settings[i])
    ugfx.input_attach(ugfx.JOY_UP, menu_change)
    ugfx.input_attach(ugfx.JOY_DOWN, menu_change)
    ugfx.input_attach(ugfx.JOY_LEFT, menu_change)
    ugfx.input_attach(ugfx.JOY_RIGHT, menu_change)
    ugfx.input_attach(ugfx.BTN_SELECT, menu_change)
    ugfx.input_attach(ugfx.BTN_A, menu_submit)
    ugfx.input_attach(ugfx.BTN_B, menu_change )
    ugfx.flush()
    
    
ugfx.init()
menu()
