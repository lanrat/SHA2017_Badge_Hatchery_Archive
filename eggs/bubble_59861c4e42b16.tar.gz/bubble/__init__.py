import ugfx

ugfx.init()
ugfx.LUT_FASTEST
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)
        
ugfx.input_attach(ugfx.BTN_B, go_home)

def main():
  ugfx.fill_circle(10, 10, 4, ugfx.BLACK)