import badge
import ugfx

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def main():
    ugfx.clear(ugfx.BLACK)
    ugfx.clear(ugfx.WHITE)
    ugfx.string(150, 50, "Bulwark", "PermanentMarker36", ugfx.BLACK)
    ugfx.line(155, 75, 245, 75, ugfx.BLACK)

main()