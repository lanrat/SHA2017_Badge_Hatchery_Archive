from png_test import png_test

pn= png_test()