import dialogs, ugfx
nick = dialogs.prompt_text("Please enter name")
print(nick)

ugfx.clear(ugfx.WHITE)

ugfx.string(80,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(60,50,nick,"PermanentMarker36",ugfx.BLACK)
str_len = ugfx.get_string_width(nick,"PermanentMarker36")
ugfx.line(60, 86, 74 + str_len, 86, ugfx.BLACK)
ugfx.line(70 + str_len, 52, 70 + str_len, 84, ugfx.BLACK)
ugfx.string(70,90,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)


ugfx.flush(ugfx.LUT_FULL)

import deepsleep, badge
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)