print("HI THERE, I AM GOING TO CRASH NOW...")

a = b
b = a