import badge, ugfx, time

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1
i = 1

def check_if_locked(i):
  if i > 5:
    global _continue
    _continue = 0

def setup():
    ugfx.init()
    badge.init()

def loop():
    badge.leds_enable()
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
  
    check_if_locked(i)
    global _continue
    while (_continue):
        time.sleep(1)  
        global i
        i += 1
        
    badge.leds_disable()
    return 15

def draw(y, sleep = 2):
  ugfx.string(0, y, 'Testing', 'Roboto_BlackItalic24', ugfx.BLACK)
  return 296