import ugfx, badge
import appglue
import dialogs

def action_home(pressed):
    if (pressed):
        appglue.home()

def action_tekst(pressed):
    if (pressed):
        global serviceText
        print "[HOMETEXT] Prompt started."
        serviceText = dialogs.prompt_text("Enter text:", serviceText)
        print "[HOMETEXT] Prompt finished."
        store()
    draw()

def store():
    global serviceText
    global serviceEnabled
    print "[HOMETEXT] Storing to NVRAM."
    badge.nvs_set_str("hometext", "text", serviceText)
    badge.nvs_set_u8('hometext', 'service', serviceEnabled)
    print "[HOMETEXT] Store complete."

def load():
    global serviceText
    global serviceEnabled
    serviceText = badge.nvs_get_str('hometext', 'text', '')
    serviceEnabled = badge.nvs_get_u8('hometext', 'service', 0)

def action_enable(pressed):
    if (pressed):
        global serviceEnabled
        serviceEnabled = 1
        store()
        draw()

def action_disable(pressed):
    if (pressed):
        global serviceEnabled
        serviceEnabled = 0
        store()
        draw()

def draw():
    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0, "Homescreen text", "PermanentMarker22", ugfx.BLACK)
    global serviceText
    if (len(serviceText)>0):
        ugfx.string(0, 25, "Service is " + ("enabled!" if serviceEnabled else "disabled."), "Roboto_Regular12", ugfx.BLACK)
        ugfx.string(0, 38, "Press start to " + ("" if serviceEnabled else "not ") + "see it in action.", "Roboto_Regular12", ugfx.BLACK)
    else:
        ugfx.string(0, 25,  "No text! Setup with SELECT", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*1, "UP: Enable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*2, "DOWN: Disable service", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*3, "START: Go to homescreen", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*4, "SELECT: Enter text", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(0, 38+13*5, "Warning: je moeder!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.set_lut(ugfx.LUT_FASTER)
    ugfx.flush()

def program_main():
    ugfx.init()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_SELECT, action_tekst)
    ugfx.input_attach(ugfx.BTN_START, action_home)
    ugfx.input_attach(ugfx.JOY_UP, action_enable)
    ugfx.input_attach(ugfx.JOY_DOWN, action_disable)
    load()
    draw()

# Start main application
program_main()
