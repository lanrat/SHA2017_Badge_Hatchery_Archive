### Author: Peter Wagenaar
### Description: Rock Paper Scissors Lizard Spock
### Category: Games
### License: MIT
### Appname: RPSLS
### Built-in: no

import os
import badge
import ugfx

names = ("rock", "Spock", "paper", "lizard", "scissors")
keys = (ugfx.JOY_UP, ugfx.JOY_LEFT, ugfx.JOY_DOWN, ugfx.JOY_RIGHT, ugfx.BTN_A)
key_names = ('UP', 'LEFT', 'DOWN', 'RIGHT', 'A')
stage = 0
NUM_STAGES = 3
player1_choice = -1
player2_choice = -1

def ask_player(prompt):
    # screen size 296*128
    ugfx.clear(ugfx.WHITE)
    ugfx.display_image(0, 0, '/lib/rpslS/small_rock.png')
    ugfx.string(25, 6, " => UP", "Roboto_Regular18", ugfx.BLACK)
    ugfx.display_image(0, 25, '/lib/rpslS/small_spock.png')
    ugfx.string(25, 31, " => LEFT", "Roboto_Regular18", ugfx.BLACK)
    ugfx.display_image(0, 50, '/lib/rpslS/small_paper.png')
    ugfx.string(25, 56, " => DOWN", "Roboto_Regular18", ugfx.BLACK)
    ugfx.display_image(0, 75, '/lib/rpslS/small_lizzard.png')
    ugfx.string(25, 81, " => RIGHT", "Roboto_Regular18", ugfx.BLACK)
    ugfx.display_image(0, 100, '/lib/rpslS/small_scissors.png')
    ugfx.string(25, 106, " => A", "Roboto_Regular18", ugfx.BLACK)

    ugfx.string(170, 0, prompt + ':', "Roboto_Regular18", ugfx.BLACK)
    ugfx.string(170, 18, "Press key", "Roboto_Regular18", ugfx.BLACK)
    ugfx.string(170, 36, "to choose", "Roboto_Regular18", ugfx.BLACK)
    ugfx.string(170, 72, "SELECT: help", "Roboto_Regular18", ugfx.BLACK)
    ugfx.string(170, 90, "START: exit", "Roboto_Regular18", ugfx.BLACK)
    ugfx.flush()

def show_winner():
    global player1_choice, player2_choice
    print('p1', player1_choice, 'p2', player2_choice)
    ugfx.clear(ugfx.WHITE)
    diff = ((player2_choice - player1_choice) % 5)
    # lizard, spock, lizard should win
    if not diff:
        # Tie
        ugfx.string(0, 0, 'Tie!', "Roboto_Regular18", ugfx.BLACK)
    elif diff => 3:
        # Player 1 wins
        ugfx.string(0, 0, 'Player 1 wins!', "Roboto_Regular18", ugfx.BLACK)
    elif diff < 3:
        # Player 2 wins
        ugfx.string(0, 0, 'Player 2 wins!', "Roboto_Regular18", ugfx.BLACK)
    ugfx.flush()

defajkfldshow_rules():
    global stage
    ugfx.clear(ugfx.WHITE)
    ugfx.display_image(0, 0, '/lib/rpslS/instructions.png')
    ugfx.string(160, 0,"Rock, Paper, Scissors", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 12,"Lizard, Spock is similar", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 24,"to 'normal' Rock Paper", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 36,"Scissors, but with", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 48,"additional rules as", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 60,"shown on the left.", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 72,"Arrows show what beats", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 84,"what.", "Roboto_Regular12", ugfx.BLACK)
    ugfx.string(160, 108,"Have fun!", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    # Reset game after showing rules
    if stage > 0:
        stage = 0

def render(key, pressed):
    global stage, NUM_STAGES, player1_choice, player2_choice
    print(stage)
    if pressed:
        return

    if (stage % NUM_STAGES) == 0:
        # ask player 1
        ask_player('Player 1')
    elif (stage % NUM_STAGES) == 1:
        # set player 1 choice
        player1_choice = keys.index(key)
        print('Player 1 picked', names[keys.index(key)])
        # ask player 2
        ask_player('Player 2')
    elif (stage % NUM_STAGES) == 2:
        # set player 2 choice
        player2_choice = keys.index(key)
        print('Player 2 picked', names[keys.index(key)])
        # declare winner, rinse, repeat
        show_winner()
    stage += 1

def exit():
    import machine
    machine.deepsleep(1)

def rpsls(): 
    badge.eink_init()
    ugfx.init()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP, lambda pressed: render(ugfx.JOY_UP, pressed))
    ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: render(ugfx.JOY_LEFT, pressed))
    ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: render(ugfx.JOY_DOWN, pressed))
    ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: render(ugfx.JOY_RIGHT, pressed))
    ugfx.input_attach(ugfx.BTN_A, lambda pressed: render(ugfx.BTN_A, pressed))
    ugfx.input_attach(ugfx.BTN_SELECT, lambda _: show_rules())
    ugfx.input_attach(ugfx.BTN_START, lambda _: exit())
    show_rules()

    while True:
        pass

rpsls()
