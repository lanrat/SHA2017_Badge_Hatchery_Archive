import badge
import ugfx
import time

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)

time.sleep(1)
ugfx.fill_circle(100, 10, 8, ugfx.BLACK)
time.sleep(1)
ugfx.fill_circle(100, 10, 6, ugfx.WHITE)
time.sleep(1)
ugfx.fill_circle(150, 20, 8, ugfx.BLACK)
time.sleep(1)
ugfx.fill_circle(150, 20, 6, ugfx.WHITE)

ugfx.flush()