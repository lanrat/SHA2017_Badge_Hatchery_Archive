import badge, easydraw, appglue,  ugfx

def setLogo(y):
    badge.eink_png(0,0,y)
    ugfx.string(50,100,badge.nvs_get_str("owner", "name", 'Boy Zonderman'),"PermanentMarker22",ugfx.BLACK)

    badge.nvs_set_u8("cspilogo","logo", 2)
    
    ugfx.flush(ugfx.LUT_FULL)
    ugfx.flush(ugfx.LUT_FULL)
    badge.eink_busy_wait() 

easydraw.msg("","CSPi Logo", True)

enabled = badge.nvs_get_u8("cspilogo","enable", 0)
if enabled:
    enabled = 0
    easydraw.msg("CSPi Logo disabled!")
else:
    enabled = 1
    easydraw.msg("CSPi Logo enabled!")
    easydraw.msg("Go back to the splash and wait...")
enabled = badge.nvs_set_u8("cspilogo","enable", enabled)

badge.eink_init()
ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.input_init()
#ugfx.input_attach(ugfx.JOY_UP, lambda pressed: printerr("cspi app"))
#ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: paintff())
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: setLogo("/cspilogo.png"))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: setLogo("/dorecologo.png"))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: badge.leds_send_data(bytes([100, 0, 0, 20, 100, 0, 0, 20, 100, 0, 0, 20, 100, 0, 0, 20, 100, 0, 0, 20, 100, 0, 0, 20]), 24))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: badge.leds_send_data(bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), 24))

#ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: appglue.start_app(""))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: appglue.start_app(""))
#ugfx.input_attach(ugfx.BTN_FLASH, lambda pressed: appglue.start_app(""))

badge.eink_busy_wait()