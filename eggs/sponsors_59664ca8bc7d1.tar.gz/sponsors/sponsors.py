import ugfx
import badge
import sys
from machine import Timer

def sponsors_draw():
    global sponsorsScreen
    
    imgpath = sys.path[1] + "/sponsors/"+str(sponsorsScreen)+".png"
    print("DRAW: "+imgpath)
    ugfx.display_image(0, 0, imgpath)
    
    sponsorsScreen = sponsorsScreen + 1
    if (sponsorsScreen > 3):
        sponsorsScreen = 0
        
def sponsorsTimer_callback(tmr):
    sponsors_draw()
        
def reboot(pressed):
    if (pressed):
        ugfx.clear(ugfx.WHITE)
        ugfx.string(0,  0, "Starting launcher...","Roboto_Regular12",ugfx.BLACK)
        ugfx.flush()
        import time
        time.sleep(0.5)
        import esp
        esp.rtcmem_write_string("launcher")
        esp.start_sleeping(1)

def sponsors_main():
    ugfx.init()
    
    # Accept input
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, reboot)
    
    # Start timer
    global sponsorsTimer
    sponsorsTimer.init(period=500, mode=Timer.PERIODIC, callback=sponsorsTimer_callback)
    
    # Display first screen
    sponsors_draw()

# Globals
sponsorsTimer = Timer(-1)
sponsorsScreen = 0

#Run main application
sponsors_main()
