import badge, ugfx
badge.leds_enable()
ugfx.input_init()

ugfx.input_attach(ugfx.BTN_A, lambda pressed: button_a(pressed))

def button_a(pressed):
    badge.leds_send_data(''.join([('\xff' if pressed else '\0') for i in range(24)]), 24)