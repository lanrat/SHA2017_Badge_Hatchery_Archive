import badge
import ugfx

badge.init()
ugfx.init()
ugfx.input_init()

for x in range(2):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  
ugfx.fill_circle(10,10,10, ugfx.BLACK)
ugfx.flush()