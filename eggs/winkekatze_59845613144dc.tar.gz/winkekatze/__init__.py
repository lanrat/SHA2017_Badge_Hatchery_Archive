from winkekatze import winkekatze

wk=winkekatze()