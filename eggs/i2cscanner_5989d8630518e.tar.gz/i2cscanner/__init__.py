import ugfx, badge
from appglue import home
from machine import I2C, Pin
from time import sleep

i2c = I2C( sda=Pin(26), scl=Pin(27), freq=100000 )
slaves = i2c.scan()

ugfx.clear( ugfx.WHITE )
ugfx.string( 0, 0, "Still Scanning Anyway", "PermanentMarker22", ugfx.BLACK )
line_start = 26
for slave in slaves:
    ugfx.string( 0, line_start, hex( slave ), "Roboto_Regular12", ugfx.BLACK )
    line_start += 20

char_start = 0
for second in range( 5, 0, -1 ):
    ugfx.string( char_start, 115, second, "Roboto_Regular12", ugfx.BLACK )
    ugfx.flush()
    sleep( 1 )
    char_start += ugfx.get_char_width( second, "Roboto_Regular12" ) + 5

ugfx.string( char_start, 115, "Returning to home screen...", "Roboto_Regular12", ugfx.BLACK )
home()
