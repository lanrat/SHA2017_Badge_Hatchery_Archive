import buienradar

buienradar.br.start()
