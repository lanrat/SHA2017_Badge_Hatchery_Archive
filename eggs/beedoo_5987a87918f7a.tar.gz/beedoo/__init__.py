import badge
import time
import random
import math

badge.init()
badge.leds_init()

pos = 0
direction = 1

while True:
    m = 10
    w = 0
    pos = pos+direction
    if pos == 5:
        direction = -1
    if pos == 0:
        direction = 1
    duration = abs(math.cos(pos/5.0*math.pi))/5

    r = int(duration*5*200) if pos <= 3 else 0
    b = int(duration*5*200) if pos >= 2 else 0
    g = 0

    pad1 = [0]*pos*4
    pad2 = [0]*(5-pos)*4
    badge.leds_send_data(bytes(pad1+[g, r, b, w]+pad2), 24)

    time.sleep(duration)