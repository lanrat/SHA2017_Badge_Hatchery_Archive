import ugfx

def setup():
    pass

def loop():
    return False

def draw(y):
    ugfx.display_image(296-80, 24, 'fhbbw.png')
    return 0
