import badge

def setup():
    pass

def task():
    badge.eink_png(100,50,'/lib/makespacemadridlogo/makespacemadrid.png')
    return 0