import time, badge

valueindex = 1
lightarray = [0]*24
intensity = 32
direction = True

# This function starts
def setup():
  vbatt = badge.battery_volt_sense()
  if (vbatt>4000):
    badge.leds_enable()
    badge.leds_send_data(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]), 24)
    time.sleep(2)
    badge.leds_send_data(bytes([32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0]), 24)
    time.sleep(2)
    badge.leds_send_data(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]), 24)
  else:
    badge.leds_disable()
    print("Badge battery low ("+str(vbatt)+" < 4000)...")
    
def loop(sleepCnt):
  global valueindex
  global lightarray
  global intensity
  global direction
  while(1): 
    lightarray[valueindex]=intensity
    badge.leds_send_data(bytes(lightarray),24)
    lightarray[valueindex]=16
    valueindexold=valueindex
    valueindexold=valueindexold-4 if direction else valueindex+4
    lightarray[valueindexold]=0
    valueindex=valueindex+4 if direction else valueindex-4
    if valueindex==21:
      direction = False
    if valueindex==1:
      direction = True
    time.sleep_ms(200)