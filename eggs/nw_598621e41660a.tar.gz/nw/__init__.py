import machine,ugfx, badge

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
nickname = badge.nvs_set_str("owner", "name", "test")
ugfx.display_image(0,0,'NW-Logo.png')
nickname = badge.nvs_set_str("owner", "name", "test1")
ugfx.string_box(0,45,296,38, nickname, "PermanentMarker28", ugfx.BLACK, ugfx.justifyRight)
nickname = badge.nvs_set_str("owner", "name", "test2")
ugfx.line(155, 75, 245, 75, ugfx.BLACK)
ugfx.flush()

def back(go):
    if(go):
        machine.deepsleep(1)

ugfx.input_attach(ugfx.BTN_B, back)