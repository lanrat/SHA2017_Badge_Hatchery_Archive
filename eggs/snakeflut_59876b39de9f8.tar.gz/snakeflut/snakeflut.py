import badge
import ugfx
import deepsleep

# width = 296
# height = 128

tile = 20

def snakeflut():
    badge.eink_init()
    ugfx.init()
    ugfx.input_init()

    ugfx.input_attach(ugfx.BTN_A, reboot)
    ugfx.input_attach(ugfx.BTN_B, reboot)
    ugfx.input_attach(ugfx.BTN_START, reboot)
    ugfx.input_attach(ugfx.BTN_SELECT, reboot)

    ugfx.input_attach(ugfx.JOY_UP, up)
    ugfx.input_attach(ugfx.JOY_RIGHT, right)
    ugfx.input_attach(ugfx.JOY_DOWN, down)
    ugfx.input_attach(ugfx.JOY_LEFT, left)

    clear()

    new_dir = 4
    last_dir = 4

    def display():
        if new_dir != last_dir:
            clear()

            if new_dir == 0:
                ugfx.area(tile*2, tile*1, tile*1, tile*1, ugfx.BLACK)
            if new_dir == 1:
                ugfx.area(tile*3, tile*2, tile*1, tile*1, ugfx.BLACK)
            if new_dir == 2:
                ugfx.area(tile*2, tile*3, tile*1, tile*1, ugfx.BLACK)
            if new_dir == 3:
                ugfx.area(tile*1, tile*2, tile*1, tile*1, ugfx.BLACK)

            last_dir = new_dir

            badge.eink_busy_wait()
            ugfx.flush()

    def up(wut):
        new_dir = 0
        display()

    def right(wut):
        new_dir = 1
        display()

    def down(wut):
        new_dir = 2
        display()

    def left(wut):
        new_dir = 3
        display()


def clear():
    ugfx.clear(ugfx.WHITE)
    badge.eink_busy_wait()
    ugfx.flush()


def reboot(wut):
  deepsleep.reboot()

snakeflut()
