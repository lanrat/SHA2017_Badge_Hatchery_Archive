import badge
import ugfx
from time import sleep


# init screen
badge.init()
ugfx.init()
ugfx.clear(ugfx.BLACK)


def showMsg(msg, x, y):
    ugfx.clear(ugfx.BLACK)

    ugfx.string(x, y, msg, "Roboto_BlackItalic24", ugfx.WHITE)

    ugfx.flush()
    sleep(0.2)


for i in range(200):
    showMsg(i,25,str(i)+"marquee")