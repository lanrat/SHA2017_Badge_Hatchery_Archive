import badge

def setup():
    pass

def loop(c):
    return False

def draw(x,y):
    badge.eink_png(180,45,'/lib/revspacelogo/revspace.png')
    return 0