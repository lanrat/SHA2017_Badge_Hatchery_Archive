import badge

try:
  badge.mount_sdcard()
except:
  print("failed to mount /sdcard")

__import__('/sdcard/sdcard')