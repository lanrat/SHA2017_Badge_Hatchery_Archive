import ugfx, wifi, network, ubinascii
from time import sleep
ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"wifi is connected. Start scanning...","Roboto_Regular12", 0)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
scanResults = sta_if.scan()
sorted(scanResults, key=lambda net: net[3], reverse=True)
ugfx.clear(ugfx.WHITE);
foo = ""
for AP in scanResults:
  bssid = ubinascii.hexlify(AP[1]).upper()
  foo = foo + "," + str(bssid)
foo = foo[1:]
ugfx.string(0, 5, 256, foo, "Roboto_Regular12", 0)
ugfx.flush()
ugfx.input_attach(ugfx.BTN_B, go_home)