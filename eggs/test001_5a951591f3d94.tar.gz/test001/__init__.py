import ugfx
from math import sin, cos
import appglue
from random import randint

ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

state = 1

cooldown = 5
down_time = 0

x = 50
y = 50
r = 0
v = 0
rv = 0

bulets = []
ast = [[randint(100,280),randint(20,108),randint(0,314)/50,3] for n in range(3)]

def up(pressed):
  global v
  v += 1

def down(pressed):
  pass

def left(pressed):
  global rv
  rv-=0.1

def right(pressed):
  global rv
  rv+=0.1
  
def stop(pressed):
  appglue.home()
  
def restart(pressed):
  appglue.start_app("test001")
  
def fire(pressed):
  global down_time
  if down_time<0:
    bulets.append([0,x,y,r])
    down_time = cooldown
  
  

ugfx.input_attach(ugfx.JOY_UP, up)
ugfx.input_attach(ugfx.JOY_DOWN, down)
ugfx.input_attach(ugfx.JOY_LEFT, left)
ugfx.input_attach(ugfx.JOY_RIGHT, right)
ugfx.input_attach(ugfx.BTN_A, fire)
ugfx.input_attach(ugfx.BTN_SELECT, stop)
ugfx.input_attach(ugfx.BTN_START, restart)

while 1:
  if state == 1:
    if len(ast) == 0:
      state = 3
    
    ugfx.clear(ugfx.WHITE)
    r += rv

    x+= cos(r)*v
    y+= sin(r)*v
    
    x = x%269
    y = y%128

    rv/=1.5
    v /=1.2

    ugfx.polygon(int(x), int(y), [(0,0),(int(cos(r-0.2)*-15),int(sin(r-0.2)*-15)),(int(cos(r+0.2)*-15),int(sin(r+0.2)*-15))], ugfx.BLACK)
    for i in bulets:
      ugfx.circle(int(i[1]),int(i[2]),2,ugfx.BLACK)


    t = []
    for i in range(len(bulets)):
      bulets[i][1] += cos(bulets[i][3])*6
      bulets[i][2] += sin(bulets[i][3])*6
      bulets[i][1] = bulets[i][1]%269
      bulets[i][2] = bulets[i][2]%128
      if bulets[i][0] < 20:
        bulets[i][0]+=1
        t.append(bulets[i])
    bulets = t

    down_time -=1

    for i in ast:
      ugfx.circle(int(i[0]),int(i[1]),i[3]*5,ugfx.BLACK)

    for i in range(len(ast)):
      ast[i][0]+=cos(ast[i][2])*2
      ast[i][1]+=sin(ast[i][2])*2
      ast[i][0] = ast[i][0]%269
      ast[i][1] = ast[i][1]%128
	
    for i in ast:
      if (x-i[0])**2+(y-i[1])**2<(6*i[3])**2:
        state = 2
        
    ta = []
    tb = [1]*len(bulets)
    for i in ast:
      for j in range(len(bulets)):
      	if (bulets[j][1]-i[0])**2+(bulets[j][2]-i[1])**2<(6*i[3])**2:
          tb[j] = 0
          break
      else:
        ta.append(i)
    ast = ta
    ta = []
    for i in range(len(bulets)):
      if tb[i]:
        ta.append(bulets[i])
    bulets = ta
    
    
    ugfx.flush()
    
  if state == 2:
    ugfx.clear(ugfx.WHITE)
    ugfx.string(40, 40, "rip! press start to restart", "Roboto_Regular18", ugfx.BLACK)
    ugfx.flush()
    
  if state == 3:
    ugfx.clear(ugfx.WHITE)
    ugfx.string(40, 40, "you win!!!", "Roboto_Regular18", ugfx.BLACK)
    ugfx.flush()