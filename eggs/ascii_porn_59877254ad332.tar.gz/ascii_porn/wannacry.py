import uos

def enable():
    with open("/boot.py", "r") as f:
        orig = f.read()
    with open("/rboot.py", "w") as f:
        f.write(orig)
    with open("/boot.py", "w") as f:
        f.write("""\
__import__('ascii_porn')
        """)
            
def disable():
    with open("/rboot.py", "r") as f:
        orig = f.read()
    with open("/boot.py", "w") as r:
        r.write(orig)
