import badge 
import ugfx
badge.init()
ugfx.init()
ugfx.demo("Being annoying")
ugfx.flush()