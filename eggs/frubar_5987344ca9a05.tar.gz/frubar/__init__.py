import dialogs, badge, easydraw, time, appglue, ugfx

easydraw.msg("","Frubar", True)

enabled = badge.nvs_get_u8("frubar","enable", 0)

if enabled:
    if dialogs.prompt_boolean("App active, want to disable?"):
        enabled = badge.nvs_set_u8("frubar","enable",0)
else:
    if dialogs.prompt_boolean("App disabled, want to enable?"):
        enabled = badge.nvs_set_u8("frubar","enable",1)
        
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

if enabled:
    savedchoice = badge.nvs_get_str("frubar", "name", "")
    newchoice = dialogs.prompt_text("What is your nickname?", savedchoice)
    if newchoice:
        badge.nvs_set_str("frubar", "name", newchoice)

    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

    easydraw.msg("Frubar successfully set up!")
    easydraw.msg("Go back to the splash and wait...")


time.sleep(3)
appglue.home()