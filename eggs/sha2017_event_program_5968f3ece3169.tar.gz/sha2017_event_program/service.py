# Service file for SHA2017 event program app
# Renze Nicolai 2017

import machine

# Prepare libs
event_alarm = __import__('lib/sha2017_event_program/event_alarm')

# Prepare variables
counter = 0

# This function gets called by the home application at boot
def setup():
    print("Event program service setup!")

def loop(sleepCnt):
    global counter
    print("Event program service loop: "+str(counter))
    counter = counter + 1
    #event_alarm.alarm_notify()
    return False # Do not prevent sleep
