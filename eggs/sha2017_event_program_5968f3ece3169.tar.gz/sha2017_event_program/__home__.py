def run_service_continuous():
    event_alarm = __import__('lib/sha2017_event_program/event_alarm')
    event_alarm.alarm_notify()
