import badge
import ugfx
import time
import sys

def quit(pressed):
    if(pressed):
        sys.exit()
    ugfx.flush()

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(50, 50, "LED Color Test","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)
inten = 0

while True:
    leds_array = bytes([255, 0, 0, 10, 255, 0, 0, 1, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(5)
    leds_array = bytes([0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(5)