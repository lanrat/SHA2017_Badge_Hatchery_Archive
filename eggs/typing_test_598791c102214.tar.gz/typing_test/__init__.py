import badge 
import ugfx
badge.init()
ugfx.init()
x = 4
y = 64
ugfx.string(x,y,"test","PermanentMarker22",ugfx.BLACK)
ugfx.flush()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP,y = y + 5)