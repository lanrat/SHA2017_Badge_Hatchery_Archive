import ugfx, gc, wifi, badge, deepsleep, utime, appglue
from time import *
import urequests as requests

def home():
    """return to launcher"""
    badge.eink_busy_wait()
    appglue.home()

ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass


# loading screen
ugfx.clear(ugfx.WHITE);
ugfx.string(10, 10, "Getting latest updates from the Travel Village ...", "Roboto_Regular12", 0)
ugfx.flush()

# fetching data
title = "not found"
content = ""

while True:
    try:
        url = "http://badge.jonasleitner.de"
        r = requests.get(url)
        gc.collect()
        data = r.json()
        r.close()

        title = data["title"]
        content = data["content"]
    except:
            ugfx.clear(ugfx.WHITE)
            ugfx.string(10, 10, "Failed to retrieve message!", "Roboto_Regular12", 0)
            ugfx.flush()
            utime.sleep(5)
            appglue.home()

    # displaying data
    ugfx.clear()
    ugfx.string(15, 5, title, "Roboto_Regular22", 0)
    ugfx.string(15, 30, content, "Roboto_Regular22", 0)
    ugfx.string(15, 70, "Press START to exit", "Roboto_Regular12", 0)
    ugfx.flush(ugfx.LUT_FULL)

    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: home())

    sleep(5000)
    #badge.eink_busy_wait()
    #deepsleep.start_sleeping(5000)