import gc,socket
import urequests as requests
import time, badge, _thread, ugfx, wifi, appglue, onewire, ds18x20, machine, json, esp
gc.collect()
#try to maintain targettemp

settings=json.loads('{"settings":{"offset":"-0.5","margin":"0.5","loglevel":"0","default_screen":"0","store_data":"0","openweatherkey":""}}')

message="Have a nice day!"
message2=""
message3=""

readings=bytearray(50)
#readingcounter=0
storecount=29 # eerste 2 waardes kunnen onzin zijn
lasttime=0
uptime=0
ctemp=20.0
ttemp=20.0
itemp=0
pc=4
screen=0
burn=0
buitentemp=0.0
windsnelheid=0.0

description="wacht op data"
zonop=0
zonneer=0
dotw=('','Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag','Zaterdag')
schedule='' 

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

default_cookie_reply="HTTP/1.0 200 OK\nServer: SHA2017 Badge\nCookie: ThermostatKey=%s\nContent-Type: text/html\n\n"

notfound_reply = """\
HTTP/1.0 404 Not Found
Server: SHA2017 Badge
Content-Type: text/html

"""

def store_settings():
  global settings
  for p in settings['settings']:
    badge.nvs_set_str('thermostat',p,settings['settings'][p])
  
def read_settings():
  global settings
  settings['settings']['offset']=badge.nvs_get_str('thermostat','offset',settings['settings']['offset'])
  settings['settings']['margin']=badge.nvs_get_str('thermostat','margin',settings['settings']['margin'])
  settings['settings']['openweatherkey']=badge.nvs_get_str('thermostat','openweatherkey')
  settings['settings']['default_screen']= badge.nvs_get_str('thermostat','screen',settings['settings']['default_screen'])
  settings['settings']['loglevel']=badge.nvs_get_str('thermostat','loglevel',settings['settings']['loglevel'])
  
  
def init_hw():
  global p33, ds, roms, uptime
  badge.init()
  ugfx.init()
  #ugfx.input_init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.string(40, 30, "Initializing!" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(40, 70, "THERMOSTAT!" , "DejaVuSans20", ugfx.BLACK)

  ugfx.flush()
  #p33 for relay switch
  #p12 for temp sensor
  badge.power_sdcard_enable()
  p33=machine.Pin(33,machine.Pin.OUT)
  p33.value(0)

  # create the onewire object
  dat = machine.Pin(4)
  ds = ds18x20.DS18X20(onewire.OneWire(dat))
  # scan for devices on the bus
  roms = ds.scan()
  if roms:
    print("I2C ROM 0 Serial:%s"%( roms[0]))
    ds.read_temp(roms[0])
    time.sleep(0.75)
    ds.read_temp(roms[0])
  else:
    print("Couldn't init temp sensor, using internal cpu temp")
  #init reading array
  for x in range(50):
	readings[x]=0
  uptime=time.time()

def init_bmp280():
  global device,QNH
  global dig_T1,dig_T2,dig_T3,dig_P1,dig_P2,dig_P3,dig_P4,dig_P5,dig_P6,dig_P7,dig_P8,dig_P9
  i2c = machine.I2C(scl=machine.Pin(22), sda=machine.Pin(21))
  device=i2c.get_i2c_device(0x77) # address of BMP

  # this value is necessary to calculate the correct height above sealevel
  # its also included in airport wheather information ATIS named as QNH
  # unit is hPa
  QNH=1020
  print("QNH:{:.0f}".format(QNH)+" hPA")

  # power mode
  # POWER_MODE=0 # sleep mode
  # POWER_MODE=1 # forced mode
  # POWER_MODE=2 # forced mode
  POWER_MODE=3 # normal mode

  # temperature resolution
  # OSRS_T = 0 # skipped
  # OSRS_T = 1 # 16 Bit
  # OSRS_T = 2 # 17 Bit
  # OSRS_T = 3 # 18 Bit
  # OSRS_T = 4 # 19 Bit
  OSRS_T = 5 # 20 Bit

  # pressure resolution
  # OSRS_P = 0 # pressure measurement skipped
  # OSRS_P = 1 # 16 Bit ultra low power
  # OSRS_P = 2 # 17 Bit low power
  # OSRS_P = 3 # 18 Bit standard resolution
  # OSRS_P = 4 # 19 Bit high resolution
  OSRS_P = 5 # 20 Bit ultra high resolution

  # filter settings
  # FILTER = 0 #
  # FILTER = 1 #
  # FILTER = 2 #
  # FILTER = 3 #
  FILTER = 4 #
  # FILTER = 5 #
  # FILTER = 6 #
  # FILTER = 7 #

  # standby settings
  # T_SB = 0 # 000 0,5ms
  # T_SB = 1 # 001 62.5 ms
  # T_SB = 2 # 010 125 ms
  # T_SB = 3 # 011 250ms
  T_SB = 4 # 100 500ms
  # T_SB = 5 # 101 1000ms
  # T_SB = 6 # 110 2000ms
  # T_SB = 7 # 111 4000ms


  CONFIG = (T_SB <<5) + (FILTER <<2) # combine bits for config
  CTRL_MEAS = (OSRS_T <<5) + (OSRS_P <<2) + POWER_MODE # combine bits for ctrl_meas

  # print ("CONFIG:",CONFIG)
  # print ("CTRL_MEAS:",CTRL_MEAS)

  BMP280_REGISTER_DIG_T1 = 0x88
  BMP280_REGISTER_DIG_T2 = 0x8A
  BMP280_REGISTER_DIG_T3 = 0x8C
  BMP280_REGISTER_DIG_P1 = 0x8E
  BMP280_REGISTER_DIG_P2 = 0x90
  BMP280_REGISTER_DIG_P3 = 0x92
  BMP280_REGISTER_DIG_P4 = 0x94
  BMP280_REGISTER_DIG_P5 = 0x96
  BMP280_REGISTER_DIG_P6 = 0x98
  BMP280_REGISTER_DIG_P7 = 0x9A
  BMP280_REGISTER_DIG_P8 = 0x9C
  BMP280_REGISTER_DIG_P9 = 0x9E
  BMP280_REGISTER_CHIPID = 0xD0
  
  BMP280_REGISTER_SOFTRESET = 0xE0
  BMP280_REGISTER_CONTROL = 0xF4
  BMP280_REGISTER_CONFIG  = 0xF5


  if (device.readS8(BMP280_REGISTER_CHIPID) == 0x58): # check sensor id 0x58=BMP280
      device.write8(BMP280_REGISTER_SOFTRESET,0xB6) # reset sensor
      time.sleep(0.2) # little break
      device.write8(BMP280_REGISTER_CONTROL,CTRL_MEAS) #
      time.sleep(0.2) # little break
      device.write8(BMP280_REGISTER_CONFIG,CONFIG)  #
      time.sleep(0.2)
      # register_control = device.readU8(BMP280_REGISTER_CONTROL) # check the controll register again
      # register_config = device.readU8(BMP280_REGISTER_CONFIG)# check the controll register again
      # print("config:",register_config)
      # print("control:",register_control)

      dig_T1 = device.readU16LE(BMP280_REGISTER_DIG_T1) # read correction settings
      dig_T2 = device.readS16LE(BMP280_REGISTER_DIG_T2)
      dig_T3 = device.readS16LE(BMP280_REGISTER_DIG_T3)
      dig_P1 = device.readU16LE(BMP280_REGISTER_DIG_P1)
      dig_P2 = device.readS16LE(BMP280_REGISTER_DIG_P2)
      dig_P3 = device.readS16LE(BMP280_REGISTER_DIG_P3)
      dig_P4 = device.readS16LE(BMP280_REGISTER_DIG_P4)
      dig_P5 = device.readS16LE(BMP280_REGISTER_DIG_P5)
      dig_P6 = device.readS16LE(BMP280_REGISTER_DIG_P6)
      dig_P7 = device.readS16LE(BMP280_REGISTER_DIG_P7)
      dig_P8 = device.readS16LE(BMP280_REGISTER_DIG_P8)
      dig_P9 = device.readS16LE(BMP280_REGISTER_DIG_P9)
  
def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
  
def init_web():
  global s
  #init webserver stuff
  try:
    del s
  except:
    s=0
  wifi.init()
  ai = socket.getaddrinfo(wifi_up(),80)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  try:
    s.bind(addr)
  except:
    print("Whatever, cannot bind 80, continuing to see what happends...")
  s.listen(5)

def main_target_temp():
  global ctemp,ttemp,burn,p33, ds, roms, settings,itemp

  print("Target temp thread started!")
  ugfx.input_init()
 
  ugfx.flush()
 
  while True:
    #read_bmp280()
    itemp=(esp.temperature_sens_read()-32)/1.8
    if roms:
      ds.convert_temp()
      ctemp=float(ds.read_temp(roms[0]))+float(settings['settings']['offset'])
    else:
      ctemp=itemp

    store_reading()

    if ctemp<(ttemp-float(settings['settings']['margin'])):
      burn=1
    else:
      burn=0
    p33.value(burn)
    #do screen stuff
    ugfx.input_attach(ugfx.BTN_START, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: ugfx.flush() if pushed else False)
    ugfx.input_attach(ugfx.JOY_UP, lambda pushed: new_temp(0.5) if pushed else False)
    ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: new_temp(-0.5) if pushed else False)
    ugfx.input_attach(ugfx.JOY_LEFT, lambda pushed: switch_screen(-1) if pushed else False)
    ugfx.input_attach(ugfx.JOY_RIGHT, lambda pushed: switch_screen(1) if pushed else False)
    ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_TIL() if pushed else False)

    ugfx.flush()
    show_set_screen()

    time.sleep(10)
    gc.collect()
    
def show_set_screen():
  global screen
  if screen==1:
    show_graph_screen()
  elif screen==2:
    show_settings_screen()
  elif screen==3:
    show_schedule_screen()
  elif screen==4:
    show_reboot_screen()
  else:
    show_main_screen()
  
def show_main_screen():
  global ctemp,ttemp,burn,message,dotw
  global buitentemp,windsnelheid,description,zonop,zonneer,itemp
  #tstatus=('idleing','burning')
  tstatus=('.zZ','!!!')
  moty=('','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
  now=time.localtime() #0year,1 month,2 day,3 hour,4 minute,5 sec,6 dayoftheweek,7 dayoftheyear
  if now[4]<10:
    mytime="%d:0%d"%(now[3],now[4])
  else:
  	mytime="%d:%d"%(now[3],now[4])
  ugfx.clear(ugfx.WHITE)
  ugfx.string(4, 0, "Huidige temperatuur is %.1f, Gewenste temperatuur is %.1f" % (ctemp,ttemp) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(4, 14, "De CPU is %.1f. Buiten temperatuur is %s, Windsnelheid %.1f " % (itemp,buitentemp,float(windsnelheid)) , "Roboto_BlackItalic12", ugfx.BLACK)
    
  ugfx.string(4, 28, "Het is %s %d %s %d en buiten is het %s" % (dotw[now[6]],now[2],moty[now[1]],now[0],description) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(4, 42, "Het is donker %s en de zon komt op om %s" % (zonneer,zonop) , "Roboto_BlackItalic12", ugfx.BLACK)

  ugfx.string(30, 62, "%.1f C     %s    [|||]=%s" %(ctemp,mytime,tstatus[burn]), "Roboto_Black22", ugfx.BLACK)
  ugfx.string(4, 90, " %s" % (message) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(4, 104, " %s" % (message2) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(4, 118, " %s" % (message3) , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()

def show_graph_screen():
  global readings
  t=263
  #height 128
  #width 296
  # de graph moet tussen y=24 en y=268 liggen 
  # de graph moet tussen x=0 en x=112 liggen 
  ugfx.clear(ugfx.WHITE)
  ugfx.line(14,0,14,128,ugfx.BLACK)
  ugfx.line(0,114,296,114,ugfx.BLACK)
  ugfx.string(0, 12, "30", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(0, 46, "20", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(0, 80, "10", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(16, 116, "-4u", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(77, 116, "-3u", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(137, 116, "-2u", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(198, 116, "-1u", "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(260, 116, "nu", "Roboto_BlackItalic12", ugfx.BLACK)
  #y=len(readings)-1
  r=1
  while r<48:
    y=storecount-r
    if y<0:
      y=48
    #readings.append(int(ctemp*10.0))
    #ugfx.line(t,114-int(readings[y-1]*0.32),t+5,114-int(readings[y]*0.32),ugfx.BLACK)
    ugfx.line(t,114-int(readings[y-1]/255*112),t+5,114-int(readings[y]/255*112),ugfx.BLACK)
    #ugfx.pixel(t,114-int(readings[y]*0.32),ugfx.BLACK)
    #print("x:%d y:%d"%(t,114-int(readings[y]*0.32)))
    t-=5
    r+=1
  ugfx.flush()
  
def show_settings_screen():
  global settings,uptime
  now=time.localtime(uptime)
  uptimestring=("%d:%d %d-%d-%d %d"%(now[3],now[4],now[2],now[1],now[0],time.time()-uptime))
  ugfx.clear(ugfx.WHITE)
  ugfx.string(4, 0, "Settings Screen" , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(4,14,"IP: %s"%(wifi.sta_if.ifconfig()[0]), "Roboto_BlackItalic12", ugfx.BLACK)
  l=28
  for p in settings['settings']:
    ugfx.string(4,l,"%s: %s"%(p,settings['settings'][p]), "Roboto_BlackItalic12", ugfx.BLACK)
    l+=14
  ugfx.string(4,l,"Mem free: %d Uptime: %s Seconds"%(gc.mem_free(),uptimestring), "Roboto_BlackItalic12", ugfx.BLACK)  

  ugfx.flush()

def show_schedule_screen():
  global schedule
  now=time.localtime()
  ugfx.clear(ugfx.WHITE)
  ugfx.string(4, 0, "Schedule Screen" , "Roboto_BlackItalic12", ugfx.BLACK)

  l=28
  ugfx.string(4,l,"%s"%(dotw[now[6]]), "Roboto_BlackItalic12", ugfx.BLACK)  
  l+=14
  ugfx.string(4,l,"Schakeltijd    Gewenste Temperatuur", "Roboto_BlackItalic12", ugfx.BLACK)  
  l+=14
  try:
    if len(schedule['schedule'][dotw[now[6]]])>0:
      for s in schedule['schedule'][dotw[now[6]]]:
        if int(s['hour'])<now[3] and int(s['min'])<now[4]:
          ugfx.string(4,l,"%s:%s             %.1f C"%(s['hour'],s['min'],float(s['temp'])/10), "Roboto_BlackItalic12", ugfx.BLACK)  
          l+=14
  except Exception as e:
    print("Error in current_schedule: %s"%(str(e)))
    ugfx.string(4,l,"Fout in schedule: %s"%(str(e)), "Roboto_BlackItalic12", ugfx.BLACK)  

  ugfx.flush()

def show_reboot_screen():
  ugfx.clear(ugfx.WHITE)
  ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.start_app('launcher') if pushed else False)
  ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: machine.reset() if pushed else False)
  ugfx.string(40, 30, "[START]: Launcher" , "DejaVuSans20", ugfx.BLACK)
  ugfx.string(40, 50, "[SELECT]: Reboot" , "DejaVuSans20", ugfx.BLACK)
  ugfx.flush()


def switch_screen(dir):
  global settings,screen
  maxscreen=4
  screen+=int(dir)
  if screen<0:
    screen=maxscreen
  if screen>maxscreen:
    screen=0
    
  show_set_screen()

  
def new_temp(delta):
  global ttemp
  #print("Temp is %.1f en delta is %.1f"%(ttemp,delta))
  ttemp+=float(delta)
  #ttemp=round(ttemp,1)
  ugfx.clear(ugfx.WHITE)
  ugfx.string(80, 35, "%.1f" %(ttemp), "DejaVuSans20", ugfx.BLACK)
  if ttemp>24.0:
    if ttemp<26.0:
      ugfx.string(80, 55, "Een beetje warm???", "DejaVuSans20", ugfx.BLACK)
    else:
      ugfx.string(80, 55, "Doe niet zo gek!!", "DejaVuSans20", ugfx.BLACK)
  ugfx.flush()
  time.sleep_ms(200)

def main_scheduler():
  global schedule,ttemp
  print("Scheduler thread started!")
  while True:
    #now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
    #print("Day of the week is %d" % (now[6]))
    sleep=current_schedule()
    print("Target temperature set to %.1f, sleeping for %d minutes" % (ttemp,sleep  )  )
    time.sleep(sleep*60)
  
def current_schedule():
  global ttemp,schedule,dotw
  #dotw=('','Zaterdag','Zondag','Maandag','Dinsdag','Woensdag','Donderdag','Vrijdag')
  now=time.localtime() #year, month,day,hour,minute,sec,dayoftheweek,dayoftheyear
  t=0
  try:
    if len(schedule['schedule'][dotw[now[6]]])>0:
      for s in schedule['schedule'][dotw[now[6]]]:
        if int(s['hour'])<now[3] and int(s['min'])<now[4]:
          ttemp=round(float(s['temp'])/10,1)
        t+=1
  except Exception as e:
    print("Error in current_schedule: %s"%(str(e)))
    ttemp=18.0
    return 300  # wait for 5 minutes
  if t==len(schedule['schedule'][dotw[now[6]]]):
    return((23-now[3])*60+60-now[4])
  else:
  	return((int(schedule['schedule'][dotw[now[6]]][t]['hour'])-int(s['hour']))*60+abs((int(schedule['schedule'][dotw[now[6]]][t]['hour'])-now[4])))
  return 60 
  
   
def main_handle_web():
  print("Handle web thread started!")
  global s,message,dotw
  global burn, ttemp,ctemp,buitentemp
  while True:
    try:
      print("Listening for connections!")
      res = s.accept()
      client_s = res[0]
      client_ip = str(res[1][0])
      print("Connection from ",client_ip)
      request = client_s.recv(512)
      request = str(request)
      ref=request.find('eferer')
      if ref>0: #sloop de referer eruit
        request=request[:ref]
      print("Request was : %s" % request)
    except:
      print("Can't handle the heat, not accepting web stuff!!!!")
      time.sleep(1)
      return
    if request.find('/favicon.ico')>0 or len(request)==0:  
      client_s.send(notfound_reply)
      client_s.close()
    else:
      if request.find('/?message=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        message=arg[1].replace('%20',' ')
        message=message.replace('%22','')
        print("change current message to %s" % message)
      elif request.find('/?ctemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ctemp=round(float(arg[1])/10,1)
        print("change current temp to %s" % ctemp)
      elif request.find('/?ttemp=')>0:
        rl=request.split(' ')
        arg=rl[1].split('=')
        ttemp=round(float(arg[1])/10,1)
      elif request.find('/?tempup')>0:
        ttemp+=0.5
      elif request.find('/?tempdown')>0:
        ttemp-=0.5
      elif request.find('/?schedule')>0:
        get_schedule()
      elif request.find('/chgsettings?')>0:
        #GET /chgsettings?offset=-0.5&loglevel=0&store_data=0&margin=0.5&openweatherkey=e8d05fb1070a4eeee6ce99f689fa1aef&default_screen=0 HTTP/1.1\r\n
        ss=request.find('?')
        ss+=1
        se=request[ss:].find(' ')+ss+1
        args=request[ss:se].split('&')
        for a in args:
          t=a.split('=')
          settings['settings'][t[0]]=t[1]
        store_settings()
      
      # send back html
      client_s.send(default_reply)
      try:
        file = open("/lib/thermostat/bootstrap.html", "r") 
        for line in file: 
          client_s.send(line)
        client_s.send("<div class=\"container\"><div class=\"starter-template\">")
        if request.find('/settings')>0:
          client_s.send("<h1>Instellingen:</h1><p class=\"lead\">\n")
          client_s.send("<form action=\"/chgsettings\" method=\"GET\">\n")
          for p in settings['settings']:
            client_s.send("<div class=\"form-group row\">\n<label class=\"col-sm-2 col-form-label\">%s</label>\n<div class=\"col-sm-10\">\n<input type=\"text\" class=\"form-control\" name=\"%s\" value=\"%s\"></div></div>\n"%(p,p,settings['settings'][p]))

          #client_s.send("%s <input type=\"text\" name=\"%s\" value=\"%s\"><br>\n"%(p,p,settings['settings'][p]))

          client_s.send("<input class=\"btn btn-lg btn-success\" role=\"button\" type=\"submit\" value=\"Sla op\"></form>")
        elif request.find('/schema')>0:
          client_s.send("<div id=\"schema\"></div>\n<script>\ntxt=\"<h1>Schema:</h1><br>\";\nscheduleObj=%s;\n\nfor (d in scheduleObj['schedule'])\n\t{\n\ttxt+=\"<h1>\"+d+\"</h1><br>\";\n\tfor (s in scheduleObj['schedule'][d])\n\t\t{\n\t\ttxt+=scheduleObj['schedule'][d][s].hour+\":\"+scheduleObj['schedule'][d][s].min+\" \"+scheduleObj['schedule'][d][s].temp/10+\"°C<br>\";\n\n\t}\n}\ndocument.getElementById(\"schema\").innerHTML = txt;\n</script>\n"%(schedule))
        else:
          client_s.send("<h1>Status:</h1><p class=\"lead\">")
          if(burn==0):
            client_s.send("Niet")
          else:
            client_s.send("Wel")
          client_s.send(" verwarmen!<br>\nGewenste temperatuur %.1f °C<br> Huidige temperatuur %.1f °C<br> Buiten temperatuur %.1f °C<br></p>\n" % (float(ttemp),float(ctemp),float(buitentemp)))
          client_s.send("<a class=\"btn btn-lg btn-success\" role=\"button\" href=\"/?tempup\">Warmer</a> ")
          client_s.send("<a class=\"btn btn-lg btn-primary\" role=\"button\" href=\"/?tempdown\">Kouder</a><br>")

        client_s.send("</div></div><script>\n$(document).ready(function() {\n$('a[href=\"' + this.location.pathname + '\"]').parent().addClass('active');\n});\n</script></body></html>\n")
      except Exception as e:
        print("Where is my socket and bootstrap file? %s"%(str(e)))
      
      
      file.close()
      client_s.close()
      gc.collect()      	

def get_weather():
  global buitentemp,windsnelheid,description,zonop,zonneer,settings
  #get the weather
  if len(settings['settings']['openweatherkey'])<10:
    description="Set Openweather Key"
    return
  openweatherUrl="http://api.openweathermap.org/data/2.5/weather?q=Breda,nl&lang=nl&units=metric&appid=%s"%(settings['settings']['openweatherkey'])
  try: 
    rw = requests.get(openweatherUrl)
    w=rw.json()
    rw.close()
    buitentemp=w['main']['temp']
    windsnelheid=float(w['wind']['speed'])
    description=w['weather'][0]['description']
    zonop="%d:%d" %(time.localtime(w['sys']['sunrise'])[3],time.localtime(w['sys']['sunrise'])[4])
    zonneer="%d:%d" %(time.localtime(w['sys']['sunset'])[3],time.localtime(w['sys']['sunset'])[4])
  except:
    ugfx.string(10, 10, "Could not get the weather", "Roboto_Regular12", 0)
    ugfx.flush()
    print('openweather fail')
    time.sleep(5)
    return
  
def get_TIL():
  global message,message2,message3,TIL
  #get top post reddit TIL
  #redditUrl="https://www.reddit.com/r/todayilearned/new.json?limit=1"
  redditUrl="https://www.reddit.com/r/worldnews/new.json?limit=1"

  try: 
    rw = requests.get(redditUrl)
    TIL=rw.json()
    rw.close()
 
  except:
    ugfx.string(10, 10, "Could not get the top post from reddit", "Roboto_Regular12", 0)
    ugfx.flush()
    print('reddit fail')
    time.sleep(5)
    return
  message=TIL['data']['children'][0]['data']['title']
  message2=""
  message3=""
  if len(message)>55:
    message2=message[55:]
    message=message[:55]
  if len(message2)>55:
    message3=message2[55:]
    message2=message2[:55]
  
def get_schedule():
  global schedule
  print("Getting schedule!")
  #get schedule
  scheduleUrl="http://192.168.2.11/tempsense/index.cgi?action=schedule"
  try: 
    rw = requests.get(scheduleUrl)
    schedule=rw.json()
    rw.close()
  except:
    ugfx.string(10, 10, "Could not get the schedule", "Roboto_Regular12", 0)
    ugfx.flush()
    print('schedule fail')
    schedule=json.loads('{"schedule": {"Maandag": [{"hour": "00", "min": "00", "temp":"160"}]}}')
    time.sleep(5)
    return
  print(schedule)
  
def store_temp():
  global ctemp
  webUrl="http://192.168.2.11/tempsense/index.cgi?action=new&reading=%.1f&type=1" % (ctemp)
  try:
    rw = requests.get(webUrl)
    rw.close()
  except:
    print("Could not store reading!")

def main_internet_info():
  print("Internet info thread started!\n")
  while True:
    time.sleep(1800)
    get_weather()
    get_TIL()
    store_temp()
    gc.collect()

def store_reading_old():
  #dit wordt elke 10 seconden aangeroepen
  #sla een waarde elke 5 minuten op dus 5*60=300/10=30
  #sla maximaal 12*4=48 waardes op
  global readings,ctemp,storecount
  if storecount>29:
    storecount=0
    if len(readings)>48:
      del readings[0]
    readings.append(int(ctemp*10.0))
  storecount+=1
  
  
def store_reading():
  #dit wordt elke 10 seconden aangeroepen
  #sla een waarde elke 5 minuten op dus 5*60=300/10=30
  #sla maximaal 12*4=48 waardes op
  global readings,ctemp,storecount,lasttime
  if (time.time()-lasttime)<300:
  	return
  lasttime=time.time()
  if storecount>48:
    storecount=0
  readings[storecount]=int(ctemp/35*255) # so max temp is 35 degrees we can store and we scale to max byte size
  #print("Storing %.1f as %d"%(ctemp,readings[storecount]))
  storecount+=1

def read_bmp280():
  #BMP280_REGISTER_VERSION = 0xD1
  #BMP280_REGISTER_STATUS = 0xF3
  BMP280_REGISTER_TEMPDATA_MSB = 0xFA
  BMP280_REGISTER_TEMPDATA_LSB = 0xFB
  BMP280_REGISTER_TEMPDATA_XLSB = 0xFC
  BMP280_REGISTER_PRESSDATA_MSB = 0xF7
  BMP280_REGISTER_PRESSDATA_LSB = 0xF8
  BMP280_REGISTER_PRESSDATA_XLSB = 0xF9
  raw_temp_msb=device.readU8(BMP280_REGISTER_TEMPDATA_MSB) # read raw temperature msb
  raw_temp_lsb=device.readU8(BMP280_REGISTER_TEMPDATA_LSB) # read raw temperature lsb
  raw_temp_xlsb=device.readU8(BMP280_REGISTER_TEMPDATA_XLSB) # read raw temperature xlsb
  raw_press_msb=device.readU8(BMP280_REGISTER_PRESSDATA_MSB) # read raw pressure msb
  raw_press_lsb=device.readU8(BMP280_REGISTER_PRESSDATA_LSB) # read raw pressure lsb
  raw_press_xlsb=device.readU8(BMP280_REGISTER_PRESSDATA_XLSB) # read raw pressure xlsb

  raw_temp=(raw_temp_msb <<12)+(raw_temp_lsb<<4)+(raw_temp_xlsb>>4) # combine 3 bytes  msb 12 bits left, lsb 4 bits left, xlsb 4 bits right
  raw_press=(raw_press_msb <<12)+(raw_press_lsb <<4)+(raw_press_xlsb >>4) # combine 3 bytes  msb 12 bits left, lsb 4 bits left, xlsb 4 bits right
  # print("raw_press_msb:",raw_press_msb," raw_press_lsb:",raw_press_xlsb," raw_press_xlsb:",raw_press_xlsb)
  # print("raw_temp_msb:",raw_temp_msb,"  raw_temp_lsb:",raw_temp_lsb," raw_temp_xlsb:",raw_temp_xlsb)
  # print("raw_press",raw_press)

  # the following values are from the calculation example in the datasheet
  # this values can be used to check the calculation formulas
  # dig_T1=27504
  # dig_T2=26435
  # dig_T3=-1000
  # dig_P1=36477
  # dig_P2=-10685
  # dig_P3=3024
  # dig_P4=2855
  # dig_P5=140
  # dig_P6=-7
  # dig_P7=15500
  # dig_P8=-14600
  # dig_P9=6000
  # t_fine=128422.2869948
  # raw_temp=519888
  # raw_press=415148

  var1=(raw_temp/16384.0-dig_T1/1024.0)*dig_T2 # formula for temperature from datasheet
  var2=(raw_temp/131072.0-dig_T1/8192.0)*(raw_temp/131072.0-dig_T1/8192.0)*dig_T3 # formula for temperature from datasheet
  temp=(var1+var2)/5120.0 # formula for temperature from datasheet
  t_fine=(var1+var2) # need for pressure calculation

  var1=t_fine/2.0-64000.0 # formula for pressure from datasheet
  var2=var1*var1*dig_P6/32768.0 # formula for pressure from datasheet
  var2=var2+var1*dig_P5*2 # formula for pressure from datasheet
  var2=var2/4.0+dig_P4*65536.0 # formula for pressure from datasheet
  var1=(dig_P3*var1*var1/524288.0+dig_P2*var1)/524288.0 # formula for pressure from datasheet
  var1=(1.0+var1/32768.0)*dig_P1 # formula for pressure from datasheet
  press=1048576.0-raw_press # formula for pressure from datasheet
  press=(press-var2/4096.0)*6250.0/var1 # formula for pressure from datasheet
  var1=dig_P9*press*press/2147483648.0 # formula for pressure from datasheet
  var2=press*dig_P8/32768.0 # formula for pressure from datasheet
  press=press+(var1+var2+dig_P7)/16.0 # formula for pressure from datasheet

  altitude= 44330.0 * (1.0 - pow(press / (QNH*100), (1.0/5.255))) # formula for altitude from airpressure
  print("temperature:{:.2f}".format(temp)+" C  pressure:{:.2f}".format(press/100)+" hPa   altitude:{:.2f}".format(altitude)+" m")

def progress():
  global pc
  ugfx.string(pc,100, '#', "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  pc+=10
  
try:
  gc.collect()
  print("Free mem: %d" %(gc.mem_free()))
  print("Initializing")
  init_hw()
  progress()#1
  #init_bmp280()
  #progress()#2
  read_settings()
  progress()#3
  init_web()
  progress()#4
  print("Done, starting up!\n")
  time.sleep(1)
  progress()#5
  get_schedule()
  progress()#6
  get_weather()
  progress()#7
  get_TIL()
  progress()#8
  _thread.start_new_thread(main_target_temp,())
  _thread.start_new_thread(main_scheduler,())
  _thread.start_new_thread(main_handle_web,())
  _thread.start_new_thread(main_internet_info,())

  print("All systems go!")
  time.sleep(5)
  gc.collect()
  print("Free mem: %d" %(gc.mem_free()))
  
except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  print("Picked up an error somewhere : %s"%(str(e)))
  ugfx.flush()