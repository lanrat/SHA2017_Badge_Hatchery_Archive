import time
import urequests
import ugfx
import wifi
import machine #to get the reset cause
import badge #to set splashscreen and wait for eink display
import deepsleep #deepsleep in the main routine
import appglue #to return home
import dialogs #to query the user for the url

#don't show refesh message when successfull, to save refreshs/energy
SHOW_WIFI_MESSAGES = False
OWNNAME = "infoscreen"
URL = badge.nvs_get_str(OWNNAME,"url","http://voidman.at/cal/cal.php?name=oeh_public") #http://voidman.at/cal/cal.php?name=oeh_public
SLEEPTIME = 24*60*60 #somehow doesn't work?
SLEEPTIMEMS = SLEEPTIME*1000 #somehow doesn't work?
FONT = badge.nvs_get_str(OWNNAME,"font","DejaVuSans20")
FONTS = ugfx.fonts_list()

def wait_wifi():
  if(SHOW_WIFI_MESSAGES):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.string(50, 25, "STILL", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.string(30, 50, "Connecting to wifi", "PermanentMarker22", ugfx.WHITE)
    le = ugfx.get_string_width("Connecting to wifi", "PermanentMarker22")
    ugfx.line(30, 72, 30 + 14 + le, 72, ugfx.WHITE)
    ugfx.string(140, 75, "Anyway", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.flush()

  #slower than default to save energy
  while not wifi.sta_if.isconnected():
    time.sleep(0.5)
    
def show(newtext):
  lineheight = int(FONT[-2:])
  lines = int(ugfx.height()/lineheight)
  firstN = newtext.split("\n")[:lines]
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  i=0 #line counter
  for line in firstN:
    #ypos 0 is invalid somehow?
    ypos = 1 + i * lineheight
    ugfx.string(1,ypos,line, FONT, ugfx.BLACK)
    i+=1
  ugfx.flush()
  
def mainroutine():
  wifi.init()
  wait_wifi()
  try:
    if(SHOW_WIFI_MESSAGES):
      show("Requesting...")
    r = urequests.get(URL)
  except:
    show("Connection problems")
    if not wifi.sta_if.isconnected():
      wifi.init()
      wait_wifi()
  else:
    if r.status_code == 200:
      show(r.text)
      r.close()
    else:
      show("Error at fetching file")
      r.close()
      
    badge.nvs_set_str('boot','splash', OWNNAME) #set badge to reboot into this
    badge.nvs_set_str(OWNNAME, 'sleepuntil', str(time.time() + SLEEPTIME))
    badge.eink_busy_wait() #wait for eink display to draw
    deepsleep.start_sleeping(SLEEPTIMEMS) #let's go to sleep

def set_font(font):
  global FONT
  FONT = font
  badge.nvs_set_str(OWNNAME,"font",font)
  mainmenu()
  
def set_url(url):
  global URL
  URL = url
  badge.nvs_set_str(OWNNAME,"url",URL)
  mainmenu()
  
def set_font_menu():
  global FONT
  global FONTS
  options = ugfx.List(0,0,int(ugfx.width()),ugfx.height())
  #options already handles up/down on it's own
  for font in FONTS:
    options.add_item(font)

  ugfx.input_init()
  ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.BTN_START,lambda pushed: set_font(options.selected_text()) if pushed else False)
  ugfx.input_attach(ugfx.BTN_A,lambda pushed: set_font(options.selected_text()) if pushed else False)
  ugfx.input_attach(ugfx.BTN_B,lambda pushed: mainmenu() if pushed else False)
  ugfx.flush()
     
  
#allow to set font on call of mainmenu
def mainmenu():
  global URL
  global FONT
  show("""[A] Set URL
[B] Return to home
[Start] start display routine
[Select] Select font
Font: """+FONT+"\n"+URL)
  ugfx.input_init()
  ugfx.input_attach(ugfx.BTN_A,lambda pushed: dialogs.prompt_text("Enter URL", URL, cb=set_url))
  ugfx.input_attach(ugfx.BTN_B,lambda pressed: appglue.start_app("launcher"))
  ugfx.input_attach(ugfx.BTN_START,lambda pressed: mainroutine())
  ugfx.input_attach(ugfx.BTN_SELECT,lambda pressed: set_font_menu())

  
ugfx.init()
badge.init()

displayloop = badge.nvs_get_str('boot','splash', "splash") == OWNNAME
#if the badge didn't boot from deepsleep (and is in display-loop) reset it to boot to splash
if( machine.reset_cause() == machine.DEEPSLEEP_RESET and displayloop ):
  if(time.time() < int(badge.nvs_get_str(OWNNAME, 'sleepuntil', "0"))): #if we wake up earlier but from timer (due to RTC-bug) sleep again
    deepsleep.start_sleeping(SLEEPTIMEMS) #let's go to sleep
  mainroutine()
else:
  badge.nvs_set_str('boot','splash','splash')
  mainmenu()