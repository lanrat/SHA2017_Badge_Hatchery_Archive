import easydraw, ugfx, appglue

easydraw.msg("","Magic 8-Ball", True)

def home(pressed):
  if pressed:
    appglue.home()
    
def program_main():
  ugfx.clear(ugfx.WHITE)
  ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)
  ugfx.string(0, 25, "Press A to start", "Roboto_BlackItalic24", ugfx.BLACK)
  
def eightball_simple():
  ugfx.clear(ugfx.WHITE)
  ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)
  ugfx.string(0, 100, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)
  ugfx.string(0, 50, "Press any direction to roll", "Roboto_BlackItalic24", ugfx.BLACK)

def eightball_advanced():
  ugfx.clear(ugfx.WHITE)
  ugfx.string(0, 0, "Magic 8-Ball", "PermanentMarker22", ugfx.BLACK)
  ugfx.string(0, 25, "Not implemented yet!", "Roboto_BlackItalic24", ugfx.BLACK)
    
def program_init():
  ugfx.init()
  ugfx.input_init()
  ugfx.input_attach(ugfx.BTN_START, home)
  ugfx.input_attach(ugfx.BTN_A, eightball_simple)
  ugfx.input_attach(ugfx.BTN_B, eightball_advanced)
  program_main()

program_init()