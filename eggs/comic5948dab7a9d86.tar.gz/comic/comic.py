import ugfx
import json

with open('lib/ComicNeue_Bold48.json', 'r') as f:
    dump = json.loads(f.read())

ugfx.init()
ugfx.fonts_load(dump)
ugfx.clear(ugfx.BLACK)
ugfx.string(5,25,"Hackers","ComicNeue_Bold48",ugfx.WHITE)
ugfx.string(140,55,"Gonna","ComicNeue_Bold48",ugfx.WHITE)
ugfx.string(15,75,"Hack","ComicNeue_Bold48",ugfx.WHITE)
ugfx.flush()
