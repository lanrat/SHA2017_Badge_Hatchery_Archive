import badge, easydraw, time, appglue

easydraw.msg("","Department of No", True)

enabled = badge.nvs_get_u8("departmentofno","enable", 0)
if enabled:
    enabled = 0
    easydraw.msg("Department of No disabled!")
else:
    enabled = 1
    easydraw.msg("Department of No enabled!")
    easydraw.msg("Go back to the splash and wait...")
enabled = badge.nvs_set_u8("departmentofno","enable", enabled)

time.sleep(5)
appglue.home()
