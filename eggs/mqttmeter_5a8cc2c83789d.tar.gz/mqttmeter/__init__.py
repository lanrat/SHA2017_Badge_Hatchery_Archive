import umqtt.simple

clnt = ""

def sub_cb(topic, msg):
	print((topic, msg))

def main():
  print("Init")
  clnt = umqtt.simple.MQTTClient("umqtt_client","revspace.nl")
  clnt.set_callback(sub_cb)
  print("Connect")
  clnt.connect()
  clnt.subscribe(b"revspace")
  while True:
    clnt.wait_msg()