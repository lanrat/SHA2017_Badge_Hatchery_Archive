import ugfx, badge, random, os

interval = 300000

texts = [
        "Cloud Hosting? The NSA is watching!",
        "Self-Driving cars are dangerous!",
        "Voting machines are insecure!"
]

seeded = False
message = ""

def setup():
    pass

def loop():
    global interval, seeded, message, texts
    enabled = badge.nvs_get_u8("departmentofno","enable", 0)
    if enabled:
        if not seeded:
            seed = sum(c << (i*8) for i, c in enumerate(os.urandom(4)))
            random.seed(seed)
            seeded = True
        # Do this here so that we don't choose a new message as soon as we redraw for sleep
        message = random.choice(texts);
        return interval

    return 9999999999

def draw(y, sleep=2):
    global message
    enabled = badge.nvs_get_u8("departmentofno","enable", 0)
    if enabled and seeded and sleep:
        nick = badge.nvs_get_str("owner", "name", 'CISO')

        ugfx.clear(ugfx.BLACK)
        ugfx.flush()
        ugfx.clear(ugfx.WHITE)
        ugfx.flush()

        ugfx.string_box(0,5,296,26, nick + " says:", "Roboto_Regular18", ugfx.BLACK, ugfx.justifyLeft)
        ugfx.string_box(0,40,296,70, message, "Roboto_Regular18", ugfx.BLACK, ugfx.justifyCenter)
        ugfx.string_box(100, 100, 150, 30, "-Department of No", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyRight)

        return [interval, 0]

    return [9999999999, 0]
