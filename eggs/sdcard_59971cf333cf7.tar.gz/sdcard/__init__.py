import badge, uos

try:
  uos.mkdir('/sdcard')
except:
  print("/sdcard already created")

try:
  badge.mount_sdcard()
except:
  print("failed to mount /sdcard")

__import__('/sdcard/sdcard')