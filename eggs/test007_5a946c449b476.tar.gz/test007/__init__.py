import ugfx
import badge
import random

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.input_attach(ugfx.BTN_A, lambda pressed: btn_a(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: btn_b(pressed))

load = 0
quit = 0

def btn_a(pressed):
	global load
	if pressed:
		load = 1
		ugfx.clear(ugfx.WHITE)
		ugfx.flush()
		rroulette()

def btn_b(pressed):
  global quit
  if pressed:
   	quit = 1
        
def rroulette():
  global load, quit
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  
  trial = 0
  
  bulletcham = random.randint(1, 6)
  ugfx.string(15, 20, str('Press A to load'), "Roboto_BlackItalic40", ugfx.BLACK)
  ugfx.flush()
  
  while bulletcham != trial and quit == 0 and load == 1:
    if bulletcham == trial:
      ugfx.string(30, 50, str('BAM! Dead...'), "Roboto_BlackItalic30", ugfx.BLACK)
      ugfx.flush()
    else:
      ugfx.string(50, 40, str('Survived'), "Roboto_BlackItalic24", ugfx.BLACK)
      ugfx.flush()
      load = 0
  
rroulette()