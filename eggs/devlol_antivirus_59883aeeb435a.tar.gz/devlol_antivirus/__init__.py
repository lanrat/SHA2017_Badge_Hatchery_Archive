from devlol_antivirus import devlol_antivirus
import appglue


devlol_antivirus.full_system_check()

appglue.home()
