import machine

#Globals
alarms = []

# Management

def alarms_add(timestamp,guid,title):
    global alarms
    alarm = {"timestamp":timestamp, "guid":guid, "title":title}
    alarms.append(alarm)
    
def alarm_exists(guid):
    global alarms
    for alarm in alarms:
        if (alarm['guid']==guid):
            return True
    return False
    
def alarms_remove(id):
    global alarms
    alarms.pop(id)
    
def alarms_read():
    global alarms
    try:
        f = open('alarms.json', 'r')
        data = f.read()
        f.close()
    except:
        data = ""
    try:
        alarms = ujson.loads(data)
    except:
        alarms = []
    
def alarms_write():
    global alarms
    data = ujson.dumps(alarms)
    f = open('alarms.json', 'w')
    f.write(data)
    f.close()
    
# Alarm clock
def alarm_notify():
  current_datetime = machine.RTC().datetime()
  #to-do...
  
