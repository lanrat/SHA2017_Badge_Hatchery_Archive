import badge, easywifi, ugfx, gc
ugfx.set_lut(ugfx.GREYSCALE)

easywifi.enable(False)

import urequests as requests
data = requests.get("https://revspace.nl/api.php?action=parse&format=json&prop=wikitext&disableeditsection&disabletoc&disablelimitreport&page=Gallery")

wiki = data.json()
data.close()
content = wiki['parse']['wikitext']['*'].split("\n")[:]
gc.collect()

indexteller=0
offsetlijst=[]

# lets find all the Heading 1 topics
for x in range(0, len(content)-1):
    if len(content[x].split("=")) == 3: # 5 for heading 2 and 7 for heading 3
        offsetlijst.append(x)
        gc.collect()

# Now we find if our nickname matches one of the headers
for x in range(0, len(offsetlijst)-1):
    if content[offsetlijst[x]].split("=")[1] == badge.nvs_get_str("owner","name"):
        identiteit = x

# Lets parse the information we selected
for x in range(offsetlijst[identiteit]+1, offsetlijst[identiteit+1]-1):
    print(content[x])
    if len(content[x].split("[[File:")) == 2:
        imagenaam = content[x].split("[[File:")[1].split("]]")[0]
    if len(content[x].split("=")) == 7:
        projectnaam = content[x].split("=")[3]
    if len(content[x].split("Maker: ")) == 2:
        maker = content[x].split("Maker: ")[1]
    if len(content[x].split("Omschrijving: ")) == 2:
        omschrijving = content[x].split("Omschrijving: ")[1]
    if len(content[x].split("Datum: ")) == 2:
        datum = content[x].split("Datum: ")[1]

# Image naam
# 

data = requests.get('https://revspace.nl/images/2/21/Sebastius_128_bw.png')
png_data = data.content
data.close()
gc.collect()

text = ugfx.Textbox(128,40, 168, 88)

ugfx.clear(ugfx.WHITE)
text.text(omschrijving)
badge.eink_png(0, 0, png_data)
ugfx.string_box(128,0,168,26, projectnaam, "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(128, 26, 168, 14, datum + " by " + maker, "pixelade13", ugfx.BLACK, ugfx.justifyCenter)
ugfx.box(128,40, 168, 88, ugfx.WHITE)
ugfx.flush()