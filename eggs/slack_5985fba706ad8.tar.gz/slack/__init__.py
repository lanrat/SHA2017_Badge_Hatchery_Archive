import ugfx
import ujson as json
import wifi
import gc
import urequests as requests
import time

ugfx.init()
wifi.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for Badge...","Roboto_Regular12", 0)
ugfx.flush()
time.sleep(3)

ugfx.clear(ugfx.WHITE)
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()


messages = []
index_counter=-1
def get_messages():
        gc.collect()
        try:
                data = requests.get("https://slack.com/api/channels.history?token=xoxp-222140683761-223564779030-223566349494-4f253c3185f11a91479c7d33ba7dd712&channel=C6JMKFHRS&unreads=1&count=10")
        except:
                print("Could not download JSON!")
                time.sleep(1)
                return
        try:
                global messages
                messages = json.loads(str(data.text))
        except:
                data.close()
                print("Could not decode JSON!")
                time.sleep(1)
                return
        data.close()
        message_array = []
        for message in messages['messages']:
                message_array.append(str(message['text']).encode("utf-8"))
        return message_array

messages = get_messages()


def display_next(messages,pressed):
    global index_counter
    if (pressed):
        index_counter = index_counter+1
        if index_counter>len(messages)-1:
        	index_counter=0
        ugfx.clear(ugfx.WHITE)
        #message_text = (messages[index_counter])
        for x in range(0,8):
        	if index_counter+x<len(messages):
        		ugfx.string(5,(x*17),(messages[index_counter+x]),"Roboto_Regular12",ugfx.BLACK)
        ugfx.flush()

def display_prev(messages,pressed):
    global index_counter
    if (pressed):
        index_counter=index_counter-1
        if index_counter<0:
        	index_counter=0
        ugfx.clear(ugfx.WHITE)
        message_text= (messages[index_counter])
        ugfx.string(5,50,message_text,"Robot_Regular12",ugfx.BLACK)
        ugfx.flush()

def passout():
    exit()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, lambda pressed: display_next(messages,pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: display_prev(messages,pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: passout())

def main():
#    display_next(messages,0)
	while True:
		display_next(messages,1)
		time.sleep(5)
main()