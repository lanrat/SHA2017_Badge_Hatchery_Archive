import os, appglue 

ransomware_list = ['ascii_porn', 'the_legend_of_zelda']

installed_software = os.listdir('/lib')

for s in installed_software:
    if s in ransomware_list:
        print(s) # TODO: remove

appglue.home()