import ugfx
import badge
import binascii
import time
import appglue
import uos as os
import ure as re
import uio as io

default_delay = 200
colours_list = list()

def init():
  global options
  options = ugfx.List(0, 0, int(ugfx.width() / 2), ugfx.height())
  list_led_files()

def list_led_files():
  global path
  filematch = '.+\.led$'
 
  # cleanup file list
  while options.count() > 0:
    options.remove_item(0)
  
  try:
    files = os.listdir(path)
  except OSError:
    files = []

  for file in files:
    if re.match(filematch, file):
      options.add_item(file)

  ugfx.flush()

def set_animation_name(name):
  #ugfx.string_box(148, 110, 148, 18, " " + name, "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
  return

def start_animation(pushed):
  global path
  if pushed:
    selected = options.selected_text()
    read_led_file(path + selected)

def stop_animation(pushed):
  badge.leds_disable()
  
def read_led_file(filename):
  debug_led()
  global path
  global colours_list
  
  fh = io.open(filename, 'rt')
  for line in fh:
    colours_list.append(re.split('[\s]+', line))

def hex_to_rgb_tuple(hex_str):
  r,g,b = binascii.unhexlify(hex_str)
  return (r,g,b)

def debug_led():
  badge.leds_enable()
  badge.leds_send_data(bytes([255,0,0, 0,181,160, 5,0,181, 160,5,0, 181,160,5, 0,181,160, 5,0,181, 160,5,0]), 24)

ugfx.input_init()
ugfx.set_lut(ugfx.LUT_FASTER)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string_box(148, 0, 148, 26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 23, 148, 23, "A. C. A. B.", "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 48, 148, 26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

# the line under the text
str_len = ugfx.get_string_width(" A. C. A. B. ", "PermanentMarker22")
line_begin = 148 + int((148 - str_len) / 2)
line_end = str_len + line_begin
ugfx.line(line_begin, 46, line_end, 46, ugfx.BLACK)

# the cursor past the text
cursor_pos = line_end + 5
ugfx.line(cursor_pos, 22, cursor_pos, 44, ugfx.BLACK)

# infobox on the right
ugfx.line(148, 78, 296, 78, ugfx.BLACK)
ugfx.string_box(148, 78, 148, 18, " A: Start", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(148, 78, 148, 18, " B: Stop", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyRight)
ugfx.string_box(148, 92, 148, 18, " START: Quit", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)
ugfx.line(148, 110, 296, 110, ugfx.BLACK)
#ugfx.string_box(148, 110, 148, 18, " " + "by ...", "Roboto_Regular12", ugfx.BLACK, ugfx.justifyLeft)

# ugfx.flush()
options = None
path = '/lib/acab'

init()

ugfx.input_attach(ugfx.BTN_A, start_animation)
ugfx.input_attach(ugfx.BTN_B, stop_animation)

ugfx.input_attach(ugfx.BTN_START, lambda pushed: appglue.home() if pushed else 0)
ugfx.input_attach(ugfx.BTN_SELECT, lambda pushed: appglue.home() if pushed else 0)

ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else 0)
ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else 0)

ugfx.flush(ugfx.LUT_FULL)