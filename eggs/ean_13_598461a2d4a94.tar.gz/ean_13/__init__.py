import ugfx
#import badge
from time import sleep

#badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
sleep(1)