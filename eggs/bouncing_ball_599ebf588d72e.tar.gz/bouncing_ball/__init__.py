import badge
import ugfx

badge.init()
ugfx.init()

for x in range(2):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  
while 1:
  ugfx.setPixel(20, 20, ugfx.BLACK)