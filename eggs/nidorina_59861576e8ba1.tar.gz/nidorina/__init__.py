import ugfx, badge

ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.display_image(0,0,'nidorina130.png')
ugfx.string(150, 50, "Nidorina", "PermanentMarker22", ugfx.WHITE)
ugfx.line(155, 75, 245, 75, ugfx.WHITE)


ugfx.flush()
