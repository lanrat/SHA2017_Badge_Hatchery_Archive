import ugfx
import wifi
from time import sleep

'''
There's still werk ta do. *werk-werk*
Just usin' the Hatchery 'cause it's soo easy to deploy.
Not working yet; hang in there :3
'''

def clear_screen():
    for color in [ugfx.WHITE, ugfx.BLACK, ugfx.WHITE]:
        ugfx.clear(color)
        ugfx.flush()

ugfx.init()
wifi.init()

# connect to wifi
clear_screen()
ugfx.demo("Connecting to WIFI")
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass
clear_screen()
current_ip = wifi.sta_if.ifconfig()[0]
ugfx.demo(current_ip)

# *shrug-smiley*