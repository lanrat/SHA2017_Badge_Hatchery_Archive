import badge, ugfx, time

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1
i = 1

def check_if_locked(_i):
  if _i > 5:
    global _continue
    _continue = 0

def setup():
    ugfx.init()
    badge.init()
    ugfx.clear(ugfx.BLACK)

def loop():
    badge.leds_enable()
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
  
    global i
    check_if_locked(i)
    global _continue
    while (_continue):
        time.sleep(1)  
        global i
        i += 1
        
    badge.leds_disable()
    return 15

def draw(x,y=2):
  ugfx.clear(ugfx.BLACK)
  ugfx.thickline(1, 1, 100, 100, ugfx.WHITE, 10, 5)
  ugfx.box(30, 30, 50, 50, ugfx.WHITE)
  return 296