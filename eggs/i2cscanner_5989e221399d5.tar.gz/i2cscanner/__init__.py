import ugfx
from appglue import home
from machine import I2C, Pin
from time import sleep

i2c = I2C( sda=Pin(26), scl=Pin(27), freq=100000 )
slaves = i2c.scan()

ugfx.clear( ugfx.WHITE )
ugfx.string( 0, 0, "Still Scanning Anyway", "PermanentMarker22", ugfx.BLACK )

ugfx.rounded_box( 0, 26, 296, 85, 4, ugfx.BLACK )
ugfx.line( 1, 44, 295, 44, ugfx.BLACK )
ugfx.string( 4, 30, "Addresses found", "Roboto_Regular12", ugfx.BLACK )

line_start = 47
for slave in slaves:
    ugfx.string( 4, line_start, hex( slave ), "Roboto_Regular12", ugfx.BLACK )
    line_start += 12

ugfx.string( 0, 115, "Returning to homescreen in ", "Roboto_Regular12", ugfx.BLACK )
char_start = ugfx.get_string_width( "Returning to homescreen in ", "Roboto_Regular12" )
for second in range( 10, 0, -1 ):
    ugfx.string( char_start, 115, str( second ), "Roboto_Regular12", ugfx.BLACK )
    ugfx.flush()
    sleep( 1 )
    char_start += ugfx.get_string_width( str( second ), "Roboto_Regular12" ) + 5

home()
