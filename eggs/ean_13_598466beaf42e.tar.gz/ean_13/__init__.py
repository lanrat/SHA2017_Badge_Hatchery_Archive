import ugfx
import badge
from time import sleep

def clear_paper():
  for i in range(5):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()

badge.init()
ugfx.init()
badge.eink_init()

clear_paper()

sleep(1)