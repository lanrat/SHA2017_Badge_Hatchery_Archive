import badge
import ugfx
import time
from random import randint
import deepsleep

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

def close(pressed):
  if pressed:
    deepsleep.reboot()


ugfx.input_attach(ugfx.BTN_B, close)

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "I bims eins LED","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

r = 0
b = 0
g = 0

while True:
	for r in range(255):
		badge.leds_send_data(leds_array)
		time.sleep(0.5)
		leds_array = leds_array[4:] + bytes([r, g, b, 100])
		for g in range(255):
			badge.leds_send_data(leds_array)
			time.sleep(0.5)
			leds_array = leds_array[4:] + bytes([r, g, b, 100])
			for b in range(255):
				badge.leds_send_data(leds_array)
				time.sleep(0.5)
				leds_array = leds_array[4:] + bytes([r, g, b, 100])