import badge
import ugfx

badge.eink_init()
ugfx.init()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(50,50,"Snake Game","PermanentMarker22",ugfx.BLACK)