import ugfx, wifi, appglue
import time, urandom
from umqtt.simple import MQTTClient

display_w = 296
display_h = 128
ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass


ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Connecting to MQTT...","Roboto_Regular12", 0)
ugfx.flush()



def sub_cb(topic, msg):
    global offset
    msg = msg.decode('utf-8')

    if topic.decode('utf-8') == 'strichliste/offset':
        offset = msg.split("|")

    ugfx.clear(ugfx.WHITE)
    ugfx.string(0, 0,  "Strichliste", "PermanentMarker22", ugfx.BLACK)

    f_names = "Roboto_Black22"
    names = [("Paul",f_names),("Antonia",f_names),("Jojo",f_names)]
    pos = center_text(names)
    for name, p in zip(names, pos):
        ugfx.string(p, 30, name[0], name[1], ugfx.BLACK)

    f_zahlen = "PermanentMarker22"
    zahlen = []
    for off in offset:
        zahlen.append((off, f_zahlen))
    pos = center_text(zahlen)
    for zahl, p in zip(zahlen, pos):
        ugfx.string(p, 62, zahl[0], zahl[1], ugfx.BLACK)

    ugfx.flush()

def main(server="mos.fritz.box"):
    clientname = 'SHA2017Badge ' + str(urandom.getrandbits(30))
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.publish("online", "strichliste")
    c.subscribe(b"strichliste/offset")
    c.check_msg()
    while True:
        c.check_msg()
        time.sleep(1)
    c.disconnect()

def go_home(pushed):
    if pushed:
        appglue.home()

def center_text(text):
    lens = []
    for t,f in text:
        lens.append(ugfx.get_string_width(t,f))
    pos = []
    for l,i in zip(lens, range(1,len(lens)+1)):
        pos.append(int( (74*i) - (l/2) ))
    print(pos)
    return pos

main()
