import ugfx, uos as os, appglue

ugfx.input_init()
ugfx.set_lut(ugfx.LUT_FASTER)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string_box(148, 0, 148, 26, "STILL", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 23, 148, 23, "All Colours Are Beautiful", "PermanentMarker22", ugfx.BLACK, ugfx.justifyCenter)
ugfx.string_box(148, 48, 148, 26, "Anyway", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)