import ugfx, appglue
ugfx.input_init()
ugfx.init()

def home(pressed):
  if pressed:
    appglue.home()

ugfx.input_attach(ugfx.BTN_B, home)
