import dialogs, ugfx
nick = dialogs.prompt_text("Hoe heet je?")
print(nick)
ugfx.clear(ugfx.BLACK)
ugfx.string(30,50,nick,"PermanentMarker36",ugfx.WHITE)
ugfx.flush()