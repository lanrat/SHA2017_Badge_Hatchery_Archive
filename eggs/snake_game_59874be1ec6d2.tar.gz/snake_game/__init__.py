import badge
import ugfx
from random import randint


class Game:

    def __init__(self, started):
        self.started = started
        self.pointx = 10
        self.pointy = 10
        self.direction = "RIGHT"
        self.steps = 0
        self.speed = 20000
        self.length = 25
        # self.targetx, self.targety = self.create_target(50,50)
        self.render_targets = []
        self.can_hit_target = True
        self.score = 0
        self.set_random_target()

    def should_render(self):
        return self.steps % self.speed == 0 
    def increment(self):
        self.steps +=1 
    

    
    def hits_target(self):
        
        abspointx = abs(self.pointx)
        abstargetx = abs(self.targetx)
        abspointy = abs(self.pointy)
        abstargety = abs(self.targety)
        absxdiff =  abs(abspointx - abstargetx)
        absydiff = abs(abspointy - abstargety)
        return absxdiff < 5 and absydiff < 5

    def create_target(self,targetx,targety):
        self.render_square(targetx,targety)
        return targetx,targety

    def set_random_target(self):
        x,y = randint(0,200),randint(0,100)

        self.targetx = x
        self.targety = y
        self.render_square(x,y)

    def render_square(self,pointx,pointy):
        ugfx.fill_polygon(pointx, pointy, [[10,5],[10,10],[5,10],[5,5]], ugfx.BLACK)


    def clear_square(self,pointx,pointy):
        ugfx.fill_polygon(pointx, pointy, [[10,5],[10,10],[5,10],[5,5]], ugfx.WHITE)


    def render_snake(self):
        # checkif the move buffer is above the length of the snake
        if(len(self.render_targets) > self.length):
            difference = len(self.render_targets) - self.length
            render_targets_to_remove = self.render_targets[:difference]
            for i,j in render_targets_to_remove:
                self.clear_square(i,j)
                self.render_targets.pop(0)
        self.render_targets.append([self.pointx,self.pointy])
        self.render_square(self.pointx,self.pointy) 

    def hits_self(self):
        
        for x,y in render_targets:
            abspointx = abs(self.pointx)
            abstargetx = abs(x)
            abspointy = abs(self.pointy)
            abstargety = abs(y)
            absxdiff =  abs(abspointx - abstargetx)
            absydiff = abs(abspointy - abstargety)
            hits =  absxdiff < 5 and absydiff < 5
            if(hits == True):
                return True
        return False

    def do_game(self):
        
        if(self.hits_target() and self.can_hit_target == True):
            self.length +=5
            self.speed -= 500
            self.clear_square(self.targetx,self.targety)
            self.set_random_target()
            self.can_hit_target = False
            self.score += 1
            print("Target Hit!!!!")
        if(self.hits_target() == True and self.can_hit_target == False):
            self.render_snake()
        else:
            self.can_hit_target = True
            self.render_snake()


def up(pressed,this_game):
    if(pressed == True):
        this_game.direction = "UP"

def down(pressed,this_game):
    if(pressed == True):
        this_game.direction = "DOWN"

def left(pressed, this_game):
    if(pressed == True):
        this_game.direction = "LEFT"

def right(pressed,this_game):
    if(pressed == True):
        this_game.direction = "RIGHT"


badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)

ugfx.input_init()
    
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: up(pressed,this_game))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: down(pressed,this_game))
ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: left(pressed,this_game))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: right(pressed,this_game))
# ugfx.input_attach(ugfx.BTN_A, lambda pressed: start(pressed,this_game))

this_game = Game(True) 

ugfx.box(5, 5, 287, 120, ugfx.BLACK)

print("Start Log")

def Step(this_game):
    this_game.increment()
    if(this_game.started == True and this_game.should_render()):
        if(this_game.direction == "LEFT"):
            this_game.pointx = this_game.pointx -2
        if(this_game.direction == "RIGHT"):
            this_game.pointx = this_game.pointx +2
        if(this_game.direction == "UP"):
            this_game.pointy = this_game.pointy -2
        if(this_game.direction == "DOWN"):
            this_game.pointy = this_game.pointy +2
        this_game.do_game()

while True:
    Step(this_game)