import badge
import binascii
import uio, ure, time
import appglue, ugfx

delay = 200
filename = 'knightrider.led'

def hex_to_rgb_tuple(hex_str):
  r,g,b = binascii.unhexlify(hex_str)
  return (r,g,b)

def load_file(fn):
  colours_array = list()
  fh = uio.open(fn, 'rt')
  #line_no = 0
  for line in fh:
    colours_array.append(ure.split("(\s)", line))
  return(colours_array)

def show_colours(colours_array):
  while True:
    for line in colours_array:
      for row in line:
        colours = ''.join([''.join(["{0:02x}".format(int(x)) for x in [r,g,b,0]]) for (r,g,b) in row])
        badge.leds_send_data(binascii.unhexlify(colours), 24)
        time.sleep(delay)

def exit():
  appglue.home()

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit())

show_colours(load_file(filename))