import ugfx
import time
import badge

score = 0

# X:296    Y: 128
def draw_cookie():
    ugfx.circle(100, 64, 30, ugfx.BLACK)
    ugfx.fill_rounded_box(105, 69, 5, 5, 10, ugfx.BLACK)
    ugfx.fill_rounded_box(100, 52, 5, 5, 10, ugfx.BLACK)
    ugfx.fill_rounded_box(89, 64, 5, 5, 10, ugfx.BLACK)

def draw_score():
	ugfx.string(180, 64, str(score), "PermanentMarker22", ugfx.BLACK)

def led_score():
  bstr = led_score_byte_str()
  badge.leds_send_data(bstr, 24)
    
def led_score_byte_str(value):
  return bytes([0, 0, 0, 100, 40, 0, 0, 100, 80, 0, 0, 100, 120, 0, 0, 100, 160, 0, 0, 100, 200, 0, 0, 100])
  

def cb_btna(pressed):
  global score
  if pressed:
    score += 1
    ugfx.clear()
    draw_cookie()
    draw_score()
    ugfx.flush()
    led_score()

ugfx.init()
ugfx.clear(ugfx.WHITE)

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_A, cb_btna)

badge.leds_init()

ugfx.clear()
draw_cookie()
draw_score()
ugfx.flush()
led_score()

while True:
  time.sleep(1)