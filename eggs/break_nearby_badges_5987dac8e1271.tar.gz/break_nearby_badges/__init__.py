import network, ugfx, appglue
# add mac spoofing and maybe some reading of traffic.
AP = network.WLAN(1)
AP.config(essid='SHA2017-insecure')
AP.active(True)

ugfx.string(15,15,"Pretending to be SHA2017-insecure <3.","Roboto_Black22",ugfx.BLACK)

ugfx.input_init()
ugfx.input_attach(ugfx.BTN_START, lambda x: appglue.home())

while True:
  pass