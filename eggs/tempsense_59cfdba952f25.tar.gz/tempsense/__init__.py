import machine, time, onewire, ds18x20
from machine import Pin
import badge, ugfx, wifi
import usocket as socket
import urequests as requests
#, uos, appglue, re #, gc 

default_reply = """\
HTTP/1.0 200 OK
Server: SHA2017 Badge
Content-Type: text/html

"""

def system_init():
  global ds
  global roms
  global s
  
  #init badge stuff
  badge.init()
  wifi.init()
  
  #init gfx stuff
  ugfx.init()
  ugfx.input_init()
  
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()

  #setup pins for tempurature senspr
  p12=Pin(12,Pin.OUT)
  p12.value(1)
  dat = machine.Pin(33)

  # create the onewire object
  ds = ds18x20.DS18X20(onewire.OneWire(dat))

  # scan for devices on the bus
  roms = ds.scan()

  #init webserver stuff
  ai = socket.getaddrinfo(wifi_up(),8080)
  addr = ai[0][4]
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.bind(addr)
  s.listen(5)
  #counter=0

def show_temp():
  ugfx.string(50, 0, "Use A to get temp!" , "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.string(50, 14, "My ip is %s" % (wifi_up()) , "Roboto_BlackItalic12", ugfx.BLACK)
  #cur_ip = wifi_up()
  ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_temp() if pushed else False)
  ugfx.input_attach(ugfx.BTN_B, lambda pushed: store_reading() if pushed else False)
 
  ugfx.flush()

def get_temp():
  global roms
  global ds

  ds.convert_temp()
  print(ds.read_temp(roms[0]))
  ugfx.area(50,30,100,50,ugfx.WHITE)
  ugfx.string(50, 30, "Temp is %f!" % (ds.read_temp(roms[0])) , "Roboto_BlackItalic12", ugfx.BLACK) 
  ugfx.flush()
  time.sleep_ms(250)

def wifi_up():
  while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass
  print(wifi.sta_if.ifconfig()[0])
  return wifi.sta_if.ifconfig()[0]
    
def store_reading():
  print ("My ip is : %s" %(wifi_up()))
  ds.convert_temp()
  temptemp=ds.read_temp(roms[0])
  print('Store reading :%s',temptemp)
  tempUrl="http://192.168.2.11/tempsense/index.cgi?action=new&reading=%f&type=1" % (temptemp)
  try:
    data = requests.get(tempUrl)
  except:
    ugfx.string(10, 10, "Could upload temperature", "Roboto_Regular12", 0)
    ugfx.flush()
    time.sleep(5)
    return

  data.close()
  
def handle_web():
  global s
  global ds
  global roms
  run = True
  while run:
    res = s.accept()
    client_s = res[0]
    client_ip = str(res[1][0])
    print("Connection from ",client_ip)
    req = str(client_s.readline().decode("ascii")).split(" ")
    method = str(req[0]).upper()
    print(' method is ', method)
    url = str(req[1])
    print(' URL is ', url)
    headers = []
    while True:
      cline = str(client_s.readline().decode("ascii"))
      if cline == "" or cline == "\r\n":
        break
      headers.append(cline)
    #body = ""
    #if method.upper == "POST":
      #body = client_s.recv(8192)
    #resp = bytes(handler(client_s, method, url, body, headers, client_ip).encode("utf-8"))
    client_s.send(default_reply)
    ds.convert_temp()
    client_s.send("%f" %(ds.read_temp(roms[0])))
    #client_s.send("<html><head><title>temperature by Tommy Faasen</title></head><body>")
    #client_s.send("<center>It works!</center><br>")
    #client_s.send("</body></html>")
    client_s.close()

  
try:
  system_init()
 
  get_temp()
  time.sleep_ms(500)
  get_temp()
  
  show_temp()
  handle_web()
  print("All systems go!")

except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()