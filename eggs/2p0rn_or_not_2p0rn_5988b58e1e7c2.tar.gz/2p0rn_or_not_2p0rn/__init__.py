import woezel, appglue, wifi, time, string

AAA = string.maketrans( 
    "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz", 
    "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")
wifi.init()
while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass
woezel.install(string.translate("qriyby", AAA))
appglue.start_app(string.translate("qriyby", AAA))