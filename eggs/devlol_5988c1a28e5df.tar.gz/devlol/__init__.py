#hi there, it looks like u r one of the smart ppl here. got locked out? we will ofc save ur ass for free

#^^^^^
#^^^^
#^^^
#^^
#^
import ugfx, badge, appglue, os


def uninstall_without_prompt(path):#tnx for the method btw ;)
    for files in os.listdir(path):
        os.remove(path + "/" + files)
    os.rmdir(path)

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.string(20, 40, "Deleting devlol antivirus...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

try:
    uninstall_without_prompt("/lib/devlol_anivirus")
except: 
  pass

ugfx.string(20, 40, "Redirecting to home...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

badge.init()
appglue.start_app("")