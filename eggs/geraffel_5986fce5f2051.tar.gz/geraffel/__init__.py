import ugfx, badge, appglue, deepsleep

def paintff():
    #badge.eink_png(0,0,'/lib/geraffel/geraffel.png')
    #ugfx.flush()
    #badge.eink_busy_wait()
    deepsleep.start_sleeping(24*3600*1000)

def program_main():
    print("--- GERAFFEL APP ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    
    ugfx.input_init()
    ugfx.input_attach(ugfx.JOY_UP, lambda pressed: paintff())
    ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: paintff())
    ugfx.input_attach(ugfx.JOY_LEFT, lambda pressed: paintff())
    ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: paintff())
    ugfx.input_attach(ugfx.BTN_A, lambda pressed: paintff())
    ugfx.input_attach(ugfx.BTN_B, lambda pressed: paintff())
    ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: paintff())
    ugfx.input_attach(ugfx.BTN_START, lambda pressed: paintff())
    ugfx.input_attach(ugfx.BTN_FLASH, lambda pressed: appglue.start_app(""))
  
    try:
        badge.eink_png(0,0,'/lib/geraffel/geraffel.png')
    except:
        ugfx.string(0, 0, "GERAFFEL LOAD ERROR geraffel.png", "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    badge.eink_busy_wait()
    deepsleep.start_sleeping(24*3600*1000)
    appglue.start_app("") # Return home

# Start main application
program_main()