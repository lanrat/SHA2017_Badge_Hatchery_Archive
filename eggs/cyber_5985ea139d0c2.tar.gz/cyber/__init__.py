import ugfx, sys
from . import cyber
    
def quit(pressed):
    if(pressed):
        sys.exit()
    ugfx.flush()

def program_main():
    print("--- Cyber Cyber v4 ---")
    ugfx.init()
    ugfx.set_lut(ugfx.LUT_FULL)
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    cyber.cyber()
    ugfx.input_init()
    ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))

# Start main application
program_main()