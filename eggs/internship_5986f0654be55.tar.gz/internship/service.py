import badge, ugfx, time#, network
#import urequests as requests

#badge.leds_enable()
#leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
#badge.leds_send_data(leds_array)

_continue = 1

def check_if_locked():
    #sta_if = network.WLAN(network.STA_IF); sta_if.active(True); sta_if.connect("SHA2017-insecure")
    #time.sleep(3)
    #t = requests.get("http://project1.online/sha2017-plsdonthackme/test.json").json()
    _id = "2"
    #t["id"]
    if _id == "1":
        global _continue
        _continue = 0

def setup():
    ugfx.init()
    badge.init()
    time.sleep(20)
    draw()
         
def freez():
    check_if_locked()
    global _continue
    if (_continue):
        time.sleep(10)
        leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
        badge.leds_send_data(leds_array)
    else:     
        leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0])
        badge.leds_send_data(leds_array)

def draw():
    ugfx.clear(ugfx.BLACK)
    ugfx.display_image(0, 178, '/lib/Internship/r.png')
    ugfx.string(12, 12, "YOUR BADGE HAS", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 25, "  BEEN LOCKED.", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 37, "To unlock your badge", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 49, "find us at XXXXX", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 62, "Your unique key for", "Roboto_Regular12", ugfx.WHITE)
    ugfx.string(12, 75, "decryption is XXXX", "Roboto_Regular12", ugfx.WHITE)
    ugfx.flush()  
    freez()