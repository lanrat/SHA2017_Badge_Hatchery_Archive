import ugfx, gc, wifi, badge, deepsleep, machine
from time import *
import urequests as requests

# Set up starting up screen
ugfx.init()
badge.init()
ugfx.input_init()
buttonpressed = False

ugfx.input_attach(ugfx.BTN_A, lambda pressed: buttonpressed = pressed)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(10, 10, "Go to the Torvalds field for further instructions.", "Roboto_Regular12", 0)
ugfx.string(10, 25, "Bring your laptop.", "Roboto_Regular12", 0)
ugfx.string(10, 55, "Verifying your location...", "Roboto_Regular12", 0)


ugfx.flush()

# Make sure WiFi is connected
wifi.ssid = "NW-challenge"
wifi.password = "Northwave Treintjes"
wifi.init()

sleep(2)

while not pressed:
    sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(10, 10, "Connect with: " + wifi.ssid, "Roboto_Regular12", 0)
ugfx.string(10, 25, "With password: " + wifi.password, "Roboto_Regular12", 0)
ugfx.flush()

sleep(2)

while not pressed:
    sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(10, 10, "Enter the Northwave tent for further instructions.", "Roboto_Regular12", 0)
ugfx.flush()

sleep(2)

while not pressed:
    sleep(0.1)

badge.eink_busy_wait()

machine.deepsleep(1)