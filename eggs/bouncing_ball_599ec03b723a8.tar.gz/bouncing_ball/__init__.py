import badge
import ugfx

badge.init()
ugfx.init()

for x in range(2):
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()
  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  
while 1:
  ugfx.circle(10,10,1,ugfx.ugfx.BLACK)