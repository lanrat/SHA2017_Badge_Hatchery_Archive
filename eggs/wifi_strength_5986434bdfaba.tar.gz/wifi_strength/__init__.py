import ugfx
import badge
import network as nwk
strength = 0
ugfx.init()
badge.init()
ugfx.clear(ugfx.BLACK)

network_if = nwk.WLAN(nwk.STA_IF)
network_if.active(True)
for wifi_net in network_if.scan():
	if(wifi_net[0].decode("ascii")== badge.nvs_get_str("badge","wifi.ssid","")):
		strength = wifi_net[3]
        ugfx.string(130, 50, str(strength), "PermanentMarker22", ugfx.WHITE)
ugfx.flush()