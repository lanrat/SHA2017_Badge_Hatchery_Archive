import ugfx, badge

ugfx.init()
badge.init()

def start():
    y = open("/boot.py", "r")
    ya = y.readlines()
    y.close()
    yb = ""
    for i, line in enumerate(ya):
        if not "__import__(splash)" in line:
            yb += line
        else:
            yb += "        test = 1"
        
    
    x = open("/boot.py", "w")
    x.writelines(yb)
    x.close()
    
start()