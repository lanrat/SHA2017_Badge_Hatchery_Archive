import ugfx, wifi, network
from time import sleep
ugfx.init()

# Make sure WiFi is connected
wifi.init()

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"Waiting for wifi...","Roboto_Regular12", 0)
ugfx.flush()

# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

ugfx.clear(ugfx.WHITE);
ugfx.string(10,10,"wifi is connected. Start scanning...","Roboto_Regular12", 0)
ugfx.flush()

def showPos(pushed):
    sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
    scanResults = sta_if.scan()
    print(scanResults)

ugfx.input_attach(ugfx.BTN_A, showPos)