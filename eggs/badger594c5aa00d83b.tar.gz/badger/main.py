import ugfx, sys

ugfx.init()

while True:
  for x in range(1, 5):
    ugfx.display_image(0,0,'badger%s.png' % x)
    ugfx.flush()