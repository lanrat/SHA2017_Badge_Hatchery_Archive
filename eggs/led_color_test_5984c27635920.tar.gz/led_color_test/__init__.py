import badge
import ugfx
import time

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 10, "LED Color Test","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
    leds_array = bytes([10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10])
    badge.leds_send_data(leds_array)
    time.sleep(5)
    leds_array = bytes([30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30])
    badge.leds_send_data(leds_array)
    time.sleep(5)