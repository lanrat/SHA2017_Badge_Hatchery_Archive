### Fahrplan Egg
### Author: f0x
### License: GPLv3

### Screen is divided in three columns, each representing a track
### each column represents a time period of 2 hours 


import ugfx, badge
import network, json, time
import urequests as requests

display_width  = 295 
display_height = 128


selected       = 0 # number of leftmost track currently displayed
day            = 1 # day to display data for TODO: get from user input
offset         = 0
#room_list      = ["No", "Pa", "Re"]
room_list      = []

column_width = int((display_width - 4)/3)


badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.WHITE)
ugfx.flush()

# Make sure WiFi is connected
sta_if = network.WLAN(network.STA_IF); sta_if.active(True)
badge.wifi_init()

# Fetch schedule, UPDATE URL IN FUTURE
string = "Getting schedule data for day "+str(day)
text_len = ugfx.get_string_width(string,"Roboto_Regular22")
position  = int((display_width-text_len)/2)
ugfx.string(position, 3, string, "Roboto_Regular22", ugfx.BLACK)

# Wait for WiFi connection
while not sta_if.isconnected():
    time.sleep(0.1)
    pass

url = "https://f.0x52.eu/dl/day" + str(day) + ".json"
r = requests.get(url)
schedule = r.json()
r.close()

for room in schedule["rooms"]:
    room_list.append(room)


def draw_gui():
    ugfx.box(0, 0, display_width+1, display_height, ugfx.BLACK)
    ugfx.line(1+column_width, 0, 1+column_width, display_height, ugfx.BLACK)
    ugfx.line(2+2*column_width, 0, 2+2*column_width, display_height, ugfx.BLACK)
    ugfx.line(0, 18, 295, 18, ugfx.BLACK)
    draw_headers()
    draw_blocks()

def draw_headers():
    draw_header(room_list[selected], 0)
    draw_header(room_list[selected+1], 1)
    draw_header(room_list[selected+2], 2)

def draw_header(string, pos):
    ## Write a stage header [string], where pos is column 0, 1 or 2
    stage_len = ugfx.get_string_width(string,"Roboto_Regular12")
    position  = int((column_width-stage_len)/2)
    ugfx.string(position + pos*column_width, 3, string, "Roboto_Regular12", ugfx.BLACK)

def draw_blocks():
    draw_block("Talk 1", 0, 0, 90)
    #draw_block("Another Talk", 0, 30, 60)
    #draw_block("Talk", 1, 0, 30)

    for event in schedule["rooms"][room_list[selected]]:
        #convert time from hh:mm to minutes
        event_start      = event["start"].split(":")
        event_start_mins = 60*int(event_start[0])+int(event_start[1])

        event_duration   = event["duration"].split(":")
        event_dur_mins   = 60*int(event_duration[0])+int(event_duration[1])

        event_stop_mins  = event_start_mins + event_dur_mins 

        print("Event: "+room_list[selected]+" start: "+str(event_start_mins) + " stop: "+str(event_stop_mins))
        


def draw_block(string, col, start, stop, selected = False):
    #convert start and stop times in minutes to lengths in pixels
    # whole column is 2 hours, and 128 - 18 = 110 pixels high, minus 2*2px padding = 106 pixels
    start = int(start * 106 / 120)-offset
    stop  = int(stop * 106 / 120)-offset

    #box position
    x     = 1 + col * column_width + col + 1
    y     = 2 + 18 + start

    x_len = column_width - 2
    y_len = stop-start

    #max amounts of chars is 16, so shorten if more
    string = (string[:14] + "..") if len(string) > 16 else string

    text_len = ugfx.get_string_width(string, "Roboto_Regular12") 
    text_x   = x + int(( x_len - text_len ) / 2)
    text_y   = y + int((y_len - 12) / 2)

    if selected:
        ugfx.area(x, y, x_len, y_len, ugfx.BLACK)
        ugfx.string(text_x, text_y, string, "Roboto_Regular12", ugfx.WHITE)
    else:
        ugfx.string(text_x, text_y, string, "Roboto_Regular12", ugfx.BLACK)
        ugfx.box(x, y, x_len, y_len, ugfx.BLACK)


def scroll_right(pressed):
    global selected
    if pressed:
        selected = selected + 1
        scroll(selected)
        print("JOY_RIGHT")

def scroll_left(pressed):
    global selected
    if pressed:
        selected = selected - 1
        scroll()
        print("JOY_LEFT")

def scroll_down(pressed):
    global offset
    if pressed:
        offset = offset + 20
        scroll(selected, offset)
        print("JOY_DOWN")


def scroll(selected, offset = 0):
    ugfx.clear(ugfx.WHITE)
    draw_gui()
    ugfx.flush()

scroll(selected, offset)

ugfx.flush()

ugfx.input_attach(ugfx.JOY_RIGHT, scroll_right)
ugfx.input_attach(ugfx.JOY_LEFT, scroll_left)
ugfx.input_attach(ugfx.JOY_DOWN, scroll_down)
