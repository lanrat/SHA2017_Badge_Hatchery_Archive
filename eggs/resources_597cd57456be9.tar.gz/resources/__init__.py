import utime, appglue

print("This resource package can not be started on it's own.") 
utime.sleep(5)
appglue.reboot()
