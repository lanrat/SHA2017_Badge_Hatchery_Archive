import badge
import ugfx
import time
import random

badge.init()
ugfx.init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

while True:
    if not badge.battery_charge_status():
        ugfx.clear()
        badge.eink_png(0,0,"/lib/bmo/default.png")
        ugfx.flush()
        time.sleep(random.uniform(0.5,5))
    ugfx.clear()
    badge.eink_png(0,0,"/lib/bmo/happy.png")
    ugfx.flush()
    time.sleep(random.uniform(0.1,1))