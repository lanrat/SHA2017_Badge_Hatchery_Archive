import ugfx
import random

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
    
def bubble():
    x = random.randint(20,276)
    y = random.randint(20,108)
    rad = random.randint(4,20)
    for r in range (3,rad):
        ugfx.fill_circle(x,y,r,ugfx.BLACK)
        ugfx.fill_circle(x,y,r-2,ugfx.WHITE)
        ugfx.flush()

ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, clean)
while True:
    bubble()