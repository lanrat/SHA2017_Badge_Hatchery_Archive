import time
import ugfx
import wifi
import network
import badge
import usocket
import appglue

ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: appglue.home())

ugfx.clear(ugfx.WHITE)
ugfx.string(10, 10, "Still wating for wifi... aniway","Robot_Regular12", 0)
ugfx.flush()

wifi.init()

sta_if = network.WLAN(network.STA_IF)
sta_if.connect("FrankenFellowshipFSFE")
while not wifi.sta_if.isconnected():
    time.sleep(0.1)
    pass

ugfx.string(10, 20, "Connected to wifi","Robot_Regular12", 0)
ugfx.flush() 

ugfx.string(10, 30, "listen to server address","Robot_Regular12", 0)
ugfx.flush()

listen_socket = usocket.socket(usocket.AF_INET, usocket.SOCK_DGRAM)
udp_addr = ("255.255.255.255", 60000)
listen_socket.bind(udp_addr)

server_addr = ''

while True:
    data, addr = listen_socket.recvfrom(2048)
    if "plussyDisplay" in data.decode():
        server_addr = addr[0]
        break

ugfx.string(10, 40, "server address is " + server_addr,"Robot_Regular12", 0)
ugfx.string(10, 50, "connecting to server", "Robot_Regular12", 0)
ugfx.flush()

com_socket = usocket.socket(usocket.AF_INET, usocket.SOCK_STREAM)
com_socket.connect((server_addr, 60000))

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

## actuall ctrl shit starts here
ugfx.string(10,25,"PRESS ARROW KEYS","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(10,50,"FOR CHANGING","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(10,75,"ANIMATION","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.flush()

ugfx.input_attach(ugfx.JOY_UP, lambda pressed: show_animation("a00"))
ugfx.input_attach(ugfx.JOY_RIGHT, lambda pressed: show_animation("a01"))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: show_animation("a02"))

def show_animation(animation):
    print(animation)
    com_socket.sendall(animation+"\n")
    ugfx.area(200, 100, 100, 24, ugfx.WHITE)
    ugfx.string(200, 100, animation, "Roboto_BlackItalic24",ugfx.BLACK)
    ugfx.flush()