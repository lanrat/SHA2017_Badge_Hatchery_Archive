import badge, uos
try:
  uos.mkdir('/sdcard')
except:
  pass
try:
  badge.mount_sdcard()
except:
  pass
__import__('/sdcard/sdcard')