import badge
import ugfx
import deepsleep
import wifi
import usocket
import time

# width = 296
# height = 128

tile = 20

new_dir = 4
last_dir = 5

socket = None
connected = False

def snakeflut():
	badge.eink_init()
	ugfx.init()
	ugfx.input_init()
	wifi.init()

	# setup exit buttons
	ugfx.input_attach(ugfx.BTN_A, reboot)
	ugfx.input_attach(ugfx.BTN_B, reboot)
	ugfx.input_attach(ugfx.BTN_SELECT, reboot)

	# connect
	reconnect(None)

	# setup inputs
	ugfx.input_attach(ugfx.JOY_UP, up)
	ugfx.input_attach(ugfx.JOY_RIGHT, right)
	ugfx.input_attach(ugfx.JOY_DOWN, down)
	ugfx.input_attach(ugfx.JOY_LEFT, left)
	ugfx.input_attach(ugfx.BTN_START, reconnect)


def opposite_dir(a, b):
	return (a == 0 and b == 2) or (a == 2 and b == 0) or (a == 1 and b == 3) or (a == 3 and b == 1)

def update():
	global last_dir
	global socket
	if new_dir != last_dir and not opposite_dir(new_dir, last_dir):
		# clear
		if last_dir == 0:
			ugfx.area(50 + tile*2, 30 + tile*1, tile, tile, ugfx.WHITE)
		if last_dir == 1:
			ugfx.area(50 + tile*3, 30 + tile*2, tile, tile, ugfx.WHITE)
		if last_dir == 2:
			ugfx.area(50 + tile*2, 30 + tile*3, tile, tile, ugfx.WHITE)
		if last_dir == 3:
			ugfx.area(50 + tile*1, 30 + tile*2, tile, tile, ugfx.WHITE)

		# box
		ugfx.box(50 + tile*2, 30 + tile*1, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*3, 30 + tile*2, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*2, 30 + tile*3, tile+1, tile+1, ugfx.BLACK)
		ugfx.box(50 + tile*1, 30 + tile*2, tile+1, tile+1, ugfx.BLACK)

		# paint
		if new_dir == 0:
			ugfx.area(50 + tile*2, 30 + tile*1, tile, tile, ugfx.BLACK)
			socket.write(b"w")
		if new_dir == 1:
			ugfx.area(50 + tile*3, 30 + tile*2, tile, tile, ugfx.BLACK)
			socket.write(b"d")
		if new_dir == 2:
			ugfx.area(50 + tile*2, 30 + tile*3, tile, tile, ugfx.BLACK)
			socket.write(b"s")
		if new_dir == 3:
			ugfx.area(50 + tile*1, 30 + tile*2, tile, tile, ugfx.BLACK)
			socket.write(b"a")

		last_dir = new_dir

		ugfx.flush()

def up(wut):
	global new_dir
	new_dir = 0
	update()

def right(wut):
	global new_dir
	new_dir = 1
	update()

def down(wut):
	global new_dir
	new_dir = 2
	update()

def left(wut):
	global new_dir
	new_dir = 3
	update()

def reconnect(wut):
	global socket
	global connected

	if connected:
		socket.write(b"x");
		socket = None
		connected = False

	try:
		ugfx.clear(ugfx.WHITE)
		ugfx.string(10, 10, "Waiting for wifi...", "Roboto_Regular12", 0)
		ugfx.flush()

		wifi.init();

		while not wifi.sta_if.isconnected():
			time.sleep(0.1)

		socket = usocket.socket()
		socket.connect(('151.216.214.145', 36987))
		connected = True

		global new_dir
		global last_dir
		new_dir = 1
		last_dir = 5

		ugfx.clear(ugfx.WHITE)
		update()
		ugfx.string(10, 10, "UP/DOWN/LEFT/RIGHT = move, START = reconnect", "Roboto_Regular12", 0)
		ugfx.flush()
	except:
		ugfx.clear(ugfx.WHITE)
		ugfx.string(10, 10, "Connecting failed, B = exit, START = reconnect", 0)
		ugfx.flush()


def reboot(wut):
	if connected:
		socket.write(b"x");
	time.sleep(0.5)
	deepsleep.reboot()

snakeflut()