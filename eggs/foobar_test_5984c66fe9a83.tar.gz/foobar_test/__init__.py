import badge
badge.init()
badge.eink_png(100,50,'/lib/beertime/beerguy.png')