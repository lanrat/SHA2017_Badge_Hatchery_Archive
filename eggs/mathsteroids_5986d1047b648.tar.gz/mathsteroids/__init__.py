import ugfx
import time
from math import sin,cos,floor,pi
ugfx.init()

SCREEN_Y = 126
SCREEN_X = 295
SPEED = 10
ROTATION = pi/8
FRAMERATE = 0.2

x,y,r = 30,30,0

ugfx.line(x,y,x-10,y-5,ugfx.BLACK)
ugfx.line(x,y,x-10,y+5,ugfx.BLACK)
ugfx.line(x-7,y,x-10,y-5,ugfx.BLACK)
ugfx.line(x-7,y,x-10,y+5,ugfx.BLACK)

while True:
	pass