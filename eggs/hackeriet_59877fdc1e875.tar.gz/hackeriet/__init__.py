import badge, ugfx, appglue, wifi, time, woezel
# TODO:
# autoupdate on start with woezel

name = badge.nvs_get_str('owner', 'name', 'n00b')
log_messages = []
fonts = [
  'Roboto_Regular18',
  'PermanentMarker36',
  'pixelade13'
]
logo_width = 77
logo_path = 'hackeriet-77.png'
is_updating = False

def log(text):
  global log_messages
  log_messages.insert(0, text)

  # Keep log short
  if len(log_messages) > 5:
  	log_messages.pop()

  # Write all log lines, then flush buffer
  for i, line in enumerate(log_messages):
  	ugfx.string(logo_width, 13 * i, line, fonts[2], ugfx.BLACK)
  ugfx.flush()

def clear_ghosting():
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()

def start_self_update():
  global is_updating
  is_updating = True
  log('Starting self update')
  attempts = 0
  attempts_max = 5
  wifi.init()
  while not wifi.sta_if.isconnected():
    if attempts > attempts_max:
      log('Giving up wifi... Skipping update!')
      is_updating = False
      return
    log('Waiting for wifi... (%d/%d)' % (attempts, attempts_max))
    time.sleep(1)
    pass
  # Attempt to install new version and restart the app if it succeeds
  try:
    woezel.install('hackeriet')
    appglue.start_app('hackeriet')
  except:
    log('woezel.install failed. May already be up to date.')
  is_updating = False

def exit_app():
  print('Button press received. Exiting app...')
  appglue.home()

def program_main():
  ugfx.init()
  ugfx.clear(ugfx.WHITE)
  
  try:
    badge.eink_png(0, 0, logo_path)
  except:
    log('Failed to load graphics')
  
  ugfx.string(0, logo_width, name, fonts[1], ugfx.BLACK)
  ugfx.string(logo_width, ugfx.height() - 13, '[FLASH to update] [B to exit]', fonts[2], ugfx.BLACK)
  ugfx.flush()
  
  ugfx.input_init()
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit_app())
  ugfx.input_attach(ugfx.BTN_FLASH, lambda pressed: start_self_update())
  
  iterations = 0
  while True:
    log('last loop on iteration %d' % (iterations))
    time.sleep(1)
    iterations += 1

program_main()