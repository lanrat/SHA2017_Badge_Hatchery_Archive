import machine, time, onewire, ds18x20
from machine import Pin
import badge, ugfx
#, uos, appglue, re #, gc 

def system_init():
  global ds
  global roms
  
  badge.init()
  ugfx.init()
  ugfx.input_init()

  ugfx.clear(ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)
  ugfx.flush()

  p12=Pin(12,Pin.OUT)
  p12.value(1)
  dat = machine.Pin(33)

  # create the onewire object
  ds = ds18x20.DS18X20(onewire.OneWire(dat))

  # scan for devices on the bus
  roms = ds.scan()


def show_temp():
  ugfx.string(50, 0, "Use A to get temp!" , "Roboto_BlackItalic12", ugfx.BLACK) 
  ugfx.input_attach(ugfx.BTN_A, lambda pushed: get_temp() if pushed else False)
  ugfx.flush()

def get_temp():
  global roms
  global ds

  ds.convert_temp()
  print(ds.read_temp(roms[0]))
  ugfx.area(50,30,90,50,ugfx.WHITE)
  ugfx.string(50, 30, "Temp is %f.2!" % (ds.read_temp(roms[0])) , "Roboto_BlackItalic12", ugfx.BLACK) 
  ugfx.flush()
  time.sleep_ms(250)

  
    
try:
  system_init()
  time.sleep_ms(150)
  get_temp()
  get_temp()
  
  show_temp()
  print("All systems go!")

except Exception as e: 
  #probably a bug:
  ugfx.string(50, 50,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()