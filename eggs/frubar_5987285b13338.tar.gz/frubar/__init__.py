import ugfx, badge

ugfx.init()
ugfx.LUT_FULL
ugfx.input_init()
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def do_refresh(pushed):
    if(pushed):
		ugfx.clear(ugfx.BLACK)
		ugfx.flush()
		ugfx.clear(ugfx.WHITE)
		ugfx.flush()
		badge.eink_png(0,20,'/lib/frubar/frubar.png')
		ugfx.flush()

ugfx.input_attach(ugfx.BTN_B, go_home)
ugfx.input_attach(ugfx.BTN_A, do_refresh)

do_refresh(1)