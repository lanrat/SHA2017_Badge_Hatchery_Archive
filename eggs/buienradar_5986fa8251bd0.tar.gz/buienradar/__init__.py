import buienradar

buienradar = buienradar.Buienradar()