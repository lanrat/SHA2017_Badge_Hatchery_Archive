import ugfx
import badge
import time

badge.init()
ugfx.init()

#296x128px screen
screen_width=296
screen_height=128

#start with white background
ugfx.clear(ugfx.WHITE)
ugfx.flush()
time.sleep(1)
ugfx.clear(ugfx.BLACK)
ugfx.flush()
time.sleep(1)
ugfx.clear(ugfx.WHITE)
ugfx.flush()

#get and draw logo
#needs full system path to logo
img = '/lib/Group_Sponsor_Logo_and_Name/logo.png'
ugfx.display_image(int(screen_width/4-25),int(screen_height/2-25), img)

#draw name
name="Daan Goumans"
name_font = "Roboto_BlackItalic24"
company_name="Northwave"
company_name_font="Roboto_Regular18"

ugfx.string(int(screen_width/2-25),int(screen_height/2-25),name,name_font,ugfx.BLACK)
name_len = ugfx.get_string_width(name,name_font)
ugfx.line(int(screen_width/2-25), int(screen_height/2), int(screen_width/2-25), int(screen_height/2)+len,ugfx.BLACK)
name_len2 = ugfx.get_string_width(company_name,company_name_font)
ugfx.string((int(screen_width/2-25)+(int(name_len/2))-int(name_len2/2)),int(screen_height/2+25),company_name,company_name_font,ugfx.BLACK)

ugfx.flush()