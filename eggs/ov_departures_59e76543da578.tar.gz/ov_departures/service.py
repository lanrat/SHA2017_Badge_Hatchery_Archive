def setup():
    import machine, badge, easydraw
    easydraw.msg("Setting ov_departures as boot app")
    badge.nvs_set_str('boot', 'splash', 'ov_departures')
    machine.deepsleep(1)
