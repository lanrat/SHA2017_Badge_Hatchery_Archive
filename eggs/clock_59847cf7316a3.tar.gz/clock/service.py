import easyrtc
import ugfx

def init():
    pass
  
def loop(counter):
    return False

def draw(x, y):
    t = easyrtc.string()
    ugfx.string(0, 50, t, "Roboto_Regular12", ugfx.BLACK)
    return 0