import easyrtc
import ugfx
import badge

def setup():
    pass
  
def loop():
    return 60000

def draw(y):
    t = easyrtc.string()
    ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    badge.leds_send_data(bytes([32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0,32,0,0,0]), 24)
    ugfx.flush()
    return [60000, 14]