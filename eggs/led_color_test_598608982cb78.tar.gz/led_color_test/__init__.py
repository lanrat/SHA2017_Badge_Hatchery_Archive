import badge
import ugfx
import time
import appglue

speed = 0.1

def quit(pressed):
    if(pressed):
        appglue.start_app("")
    ugfx.flush()

def speed_inc(pressed):
    global speed;
    if(pressed):
        speed -= 0.01
        if speed < 0:
            speed = 0

def speed_dec(pressed):
    global speed;
    if(pressed):
        speed += 0.01

def flash_leds(color):
    for x in range(0, 4):
        leds_array = bytes(color[:4]*6)
        badge.leds_send_data(leds_array)
        time.sleep(speed)
        leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        badge.leds_send_data(leds_array)
        time.sleep(speed)
    
def loop_leds(color):
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color[:4])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color[:8])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + color )
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0, 0, 0, 0, 0] + color + [0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes([0, 0, 0, 0] + color + [0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color[4:] + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)
    leds_array = bytes(color[8:] + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    badge.leds_send_data(leds_array)
    time.sleep(speed)

badge.init()
ugfx.init()
ugfx.input_init()
ugfx.input_attach(ugfx.JOY_UP, lambda pressed: speed_inc(pressed))
ugfx.input_attach(ugfx.JOY_DOWN, lambda pressed: speed_dec(pressed))
ugfx.input_attach(ugfx.BTN_A, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: quit(pressed))
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: quit(pressed))
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
nick = badge.nvs_get_str('owner', 'name', 'Hacker1337')
len = ugfx.get_string_width(nick,"PermanentMarker22")
center = int(len/2)
ugfx.string(110-center, 40, nick,"PermanentMarker36", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
    # green
    color = [255, 0, 0, 0, 25, 0, 0, 0, 5, 0, 0, 0]
    flash_leds(color)
    loop_leds(color)
    loop_leds(color)
    # red
    color = [0, 255, 0, 0, 0, 25, 0, 0, 0, 5, 0, 0]
    flash_leds(color)
    loop_leds(color)
    loop_leds(color)
    # blue
    color = [0, 0, 255, 0, 0, 0, 25, 0, 0, 0, 5, 0]
    flash_leds(color)
    loop_leds(color)
    loop_leds(color)