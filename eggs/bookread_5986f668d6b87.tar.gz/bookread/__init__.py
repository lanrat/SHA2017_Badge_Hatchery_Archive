import badge, ugfx, uos, appglue

badge.init()
ugfx.init()
ugfx.input_init()

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)

def select_file(active):
  if active:
    global files
    global options
    index = options.selected_index()
    if files[index]> 0:
      ugfx.string(150, 5, files[index], "Roboto_BlackItalic12", ugfx.BLACK)
      #ugfx.flush()
	

def filepick():
  global options
  global files
  ugfx.string(150, 5, "Pick a file", "Roboto_BlackItalic12", ugfx.BLACK)
  #ugfx.flush()
  options = ugfx.List(0,0,int(ugfx.width()/2),ugfx.height())

  options.add_item("<- Go Dir Up")
  #options.add_item("file 1")
  #options.add_item("file 2")
  files=uos.listdir('lib/bookread')

  for file in files:
      options.add_item("%s" % file)

  options.selected_index(0)

  ugfx.input_attach(ugfx.JOY_UP, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.JOY_DOWN, lambda pushed: ugfx.flush() if pushed else False)
  ugfx.input_attach(ugfx.BTN_A, select_file)
  ugfx.input_attach(ugfx.BTN_B, lambda pushed: appglue.start_app("launcher", False) if pushed else False)

  ugfx.flush()
  ugfx.set_lut(ugfx.LUT_NORMAL)

try:
  ugfx.clear(ugfx.WHITE)
  ugfx.set_lut(ugfx.LUT_FASTER)

  filepick()

    
except Exception as e: 
  #probably a bug:
  ugfx.string(150, 15,str(e), "Roboto_BlackItalic12", ugfx.BLACK)
  ugfx.flush()
  #dont re-raise it in the hope the user can continue
  #raise e