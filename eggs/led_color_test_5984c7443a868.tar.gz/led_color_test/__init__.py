import badge
import ugfx
import time

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(50, 50, "LED Color Test","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
    leds_array = bytes([255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100, 255, 0, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(5)
    leds_array = bytes([0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100, 0, 255, 0, 100])
    badge.leds_send_data(leds_array)
    time.sleep(5)