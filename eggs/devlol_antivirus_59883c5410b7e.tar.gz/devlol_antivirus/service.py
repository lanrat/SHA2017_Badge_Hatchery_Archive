from devlol_antivirus import devlol_antivirus

def setup():
    devlol_antivirus.full_system_check_while_boot()
