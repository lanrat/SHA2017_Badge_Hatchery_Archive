import easyrtc
import ugfx

def setup():
    pass
  
def loop():
    return 60000

def draw(y):
    t = easyrtc.string()
    ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    return [60000, 14]