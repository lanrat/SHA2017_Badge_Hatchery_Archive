import badge, easywifi, ugfx, gc
ugfx.set_lut(ugfx.GREYSCALE)

easywifi.enable(False)

import urequests as requests
data = requests.get("https://revspace.nl/api.php?action=parse&format=json&prop=wikitext&disableeditsection&disabletoc&disablelimitreport&page=Gallery")

wiki = data.json()
data.close()
content = wiki['parse']['wikitext']['*'].split("\n")[:100]

data = requests.get('https://revspace.nl/images/2/21/Sebastius_128_bw.png')
png_data = data.content
data.close()

text = ugfx.Textbox(128,26, 168, 102)

ugfx.clear(ugfx.WHITE)
text.text(content[5])
badge.eink_png(0, 0, png_data)
ugfx.string_box(128,0,168,26, content[4].split("===")[1], "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyCenter)

ugfx.flush()