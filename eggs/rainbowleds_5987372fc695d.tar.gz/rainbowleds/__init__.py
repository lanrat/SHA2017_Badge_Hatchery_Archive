# fork of sha_color

import badge
import ugfx
import appglue

brightness = 50
offset = 0

def main_menu(pushed):
    if(pushed):
        print("go home")
        appglue.home()

def brighter():
    brightness += 20
    if brightness > 255:
        brightness = 255
    create_colors()

def dimer():
    brightness -= 20
    if brightness < 20:
        brightness = 20
    create_colors()

def forward():
    offset += 1
    if offset > 5:
        offset = 0
    create_colors()

def backward():
    offset -= 1
    if offset < 0:
        offset = 5
    create_colors()

def create_colors(brightness, offset)
    blue = bytes([0, 0, brightness, 0])
    cyan = bytes([brightness, 0, brightness, 0])
    green = bytes([brightness, 0, 0, 0])
    yellow = bytes([brightness, brightness, 0, 0])
    red = bytes([0, brightness, 0, 0])
    magenta = bytes([0, brightness, brightness, 0])
    rainbow = [blue, cyan, green, yellow, red, magenta]
    values = bytes()
    for i in range(6):
        i += offset
        if i > 5:
            i -= 6
        values += rainbow[i]
    badge.leds_send_data(values)

badge.init() 
ugfx.init()
badge.leds_init()
ugfx.input_init()

ugfx.set_lut(ugfx.LUT_NORMAL)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(190,25,"STILL","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(170,50,"colorful","PermanentMarker22",ugfx.BLACK)
length = ugfx.get_string_width("colorful","PermanentMarker22")
ugfx.line(170, 72, 184 + length, 72, ugfx.BLACK)
ugfx.line(180 + length, 52, 180 + length, 70, ugfx.BLACK)
ugfx.string(180,75,"Anyway","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(20, 110, "SELECT: exit, START: off, A: low, B: high","Roboto_Regular12",ugfx.BLACK)
ugfx.string(255, 115, "rev. 18","Roboto_Regular12",ugfx.BLACK)
try:
    badge.eink_png(0,40,'/lib/sha2017_colors/shrug.png')
except:
    ugfx.string(100,50,"Error loading shrug.png"),ugfx.BLACK

ugfx.flush()

ugfx.input_attach(ugfx.BTN_START, main_menu)
ugfx.input_attach(ugfx.BTN_UP, brighter)
ugfx.input_attach(ugfx.BTN_DOWN, dimmer)
ugfx.input_attach(ugfx.BTN_LEFT, backward)
ugfx.input_attach(ugfx.BTN_RIGHT, forward)

badge.leds_enable()
create_colors(brightness, offset)
