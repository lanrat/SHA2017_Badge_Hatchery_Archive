def home():
    print('going to home screeen.....')
