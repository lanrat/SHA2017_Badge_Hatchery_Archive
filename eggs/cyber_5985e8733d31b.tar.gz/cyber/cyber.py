import ugfx, badge, utime

def cyber():
    cyber_cyber(0, 0)
    utime.sleep(4)
    for x in range(0, 296):
        cyber_cyber(x, 0)

def cyber_cyber(x, y):
    try:
        # Proudly stolen from https://cyber.equipment/cyber_plain.png
        badge.eink_png(x, y, '/lib/cyber/cyber_plain.png')
    except:
        ugfx.string(0, 0, "Error loading image", "Roboto_Regular12", ugfx.BLACK)