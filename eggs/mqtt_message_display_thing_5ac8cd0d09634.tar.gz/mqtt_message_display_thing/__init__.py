import easywifi, easydraw, urandom, gc, badge
from time import *

easydraw.msg("Connecting to WiFi", title = 'Still Connecting Anyway...', reset = True)
easywifi.enable(True)
if easywifi.state==False:
    easydraw.msg("Meh unable to connect to network")
    easydraw.msg("Waiting 5 seconds to try again!")
    badge.eink_busy_wait()
    import machine
    machine.deepsleep(5000)

easydraw.msg("Connecting to MQTT")

from umqtt.simple import MQTTClient

# Received messages from subscriptions will be delivered to this callback
def sub_cb(topic, msg):
    print((topic, msg))
    easydraw.msg(topic+" : "+msg)

def main(server="mqtt.bitlair.nl"):
    clientname = 'UM2 3dprintermessage'
    c = MQTTClient(clientname, server)
    c.set_callback(sub_cb)
    c.connect()
    c.subscribe(b"bitlair/test/#")
    easydraw.msg("MQTT Connected", title = 'Still MQTT Anyway...', reset = True)
    c.check_msg()
    while True:
        gc.collect()
        c.check_msg()
        sleep(1)
    c.disconnect()

main()