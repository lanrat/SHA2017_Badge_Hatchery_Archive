import badge
import ugfx
import time
from random import randint
import deepsleep

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

def close(pressed):
  if pressed:
    deepsleep.reboot()


ugfx.input_attach(ugfx.BTN_B, close)

ugfx.set_lut(ugfx.LUT_NORMAL)
ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

leds_array = bytes(24)

while True:
	time.sleep(0.1)
	for x in range(0, 255):
		for y in range(0, 255):
			for z in range(0, 255):
				leds_array = bytes([y, x, z, 100, y, x, z, 100, y, x, z, 100, y, x, z, 100, y, x, z, 100, y, x, z, 100])
				badge.leds_send_data(leds_array)