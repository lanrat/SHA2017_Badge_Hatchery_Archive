import ugfx
#import random

x = 54
y = 83

xMov = 0
yMov = 0

def go_home(pushed):
    if(pushed):
        import machine
        machine.deepsleep(1)

def clean(pushed):
    if(pushed):
        ugfx.clear(ugfx.WHITE)
  


ugfx.init()
ugfx.input_init()
ugfx.clear(ugfx.WHITE)
ugfx.clear(ugfx.BLACK)
ugfx.clear(ugfx.WHITE)
ugfx.input_attach(ugfx.BTN_START, go_home)
ugfx.input_attach(ugfx.BTN_A, clean)
ugfx.flush()

#x = random.randint(20,276)
#y = random.randint(20,108)

while True:
  if x > 287:
    xMov = 1
    
  if x < 1:
    xMov = 0
    
  if y > 119:
    yMov = 1
    
  if y < 1:
    yMov = 0
   
  if xMov == 0:
    x += 2
  else:
    x -= 1
    
  if yMov == 0:
    y += 1
  else:
    y -= 2
  
  ugfx.fill_circle(x, y, 8, ugfx.BLACK)
  ugfx.flush()
  ugfx.clear(ugfx.WHITE)