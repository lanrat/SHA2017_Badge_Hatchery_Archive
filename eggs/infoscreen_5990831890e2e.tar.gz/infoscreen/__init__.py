import gc
import time
import urequests
import ugfx
import wifi

URL = "http://voidman.at/cal/cal.php?nae=oeh_public"
SLEEPTIME = 30 #60*60*24 #a day
text = "None" #init text

def clear(color):
    ugfx.clear(ugfx.BLACK)
    ugfx.flush()
    ugfx.clear(ugfx.WHITE)
    ugfx.flush()
    ugfx.clear(color)

def wait_wifi():
    clear(ugfx.BLACK)
    ugfx.string(50, 25, "STILL", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.string(30, 50, "Connecting to wifi", "PermanentMarker22", ugfx.WHITE)
    le = ugfx.get_string_width("Connecting to wifi", "PermanentMarker22")
    ugfx.line(30, 72, 30 + 14 + le, 72, ugfx.WHITE)
    ugfx.string(140, 75, "Anyway", "Roboto_BlackItalic24", ugfx.WHITE)
    ugfx.flush()

    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        
    clear(ugfx.WHITE)
    ugfx.flush()
        
def show(newtext):
    global text
    first6lines = newtext.split("\n")[:6]
    newtext = "\n".join(first6lines) #join into a string
    if(newtext != text):
        return
    text = newtext
    clear(ugfx.WHITE)
    ugfx.string(0,0,text, "DejaVuSans20", ugfx.BLACK)
    ugfx.flush()
        
show("hi");
ugfx.init()
wifi.init()
wait_wifi()

while True:
    try:
        show("Requesting...")
        r = urequests.get(URL)
    except:
        if not wifi.sta_if.isconnected():
            wifi.init()
            wait_wifi()
    else:
        if r.status_code == 200:
            gc.collect()
            show(r.text);
            r.close()
        else:
            show("Error at fetching file");
            r.close();
        time.sleep(SLEEPTIME) #sleep after successfully displaying