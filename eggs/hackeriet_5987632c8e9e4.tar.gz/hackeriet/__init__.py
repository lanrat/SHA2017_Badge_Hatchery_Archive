import badge, ugfx, appglue, wifi, time
# TODO:
# autoupdate on start with woezel

name = badge.nvs_get_str('owner', 'name', 'n00b')
log_window_x = ugfx.width() / 7 * 3
log_window_y = 0
log = ['', '', '', '', '']
fonts = [
  'Roboto_Regular18',
  'PermanentMarker36',
  'pixelade13'
]

def log(text):
  log.insert(0, text)
  log.pop()
  font_height = 13
  for i, line in enumerate(log):
  	ugfx.string(log_window_x, log_window_y + font_height * i, line, fonts[2], ugfx.BLACK)
  ugfx.flush()

def clear_ghosting():
	ugfx.clear(ugfx.BLACK)
	ugfx.flush()
	badge.eink_busy_wait()
	ugfx.clear(ugfx.WHITE)
	ugfx.flush()
	badge.eink_busy_wait()

def attempt_update_self():
  attempts = 0
  attempts_max = 5
  while not wifi.sta_if.isconnected():
    log('Waiting for wifi... (%d/%d)' % (attempts, attempts_max))
    time.sleep(1)
    pass

def exit_app(pressed):
  appglue.start_app('')

def program_main():
  ugfx.init()
  wifi.init()
  clear_ghosting()
  
  try:
    badge.eink_png(0, 0, '/lib/hackeriet/hackeriet.png')
  except:
    log('Failed to load graphics')
  
  bx = int(ugfx.width() / 2)
  
  ugfx.string(bx, ugfx.height() - 16, '[Press B to exit]', fonts[0], ugfx.BLACK)
  
  # Name tag
  ugfx.string(177, 25, name, fonts[1], ugfx.BLACK)
  ugfx.flush()
  
  ugfx.input_attach(ugfx.BTN_B, lambda pressed: exit_app(pressed))
  
  iterations = 0
  while True:
    ugfx.string(bx, ugfx.height() - 32, str(iterations), fonts[0], ugfx.BLACK)
    iterations = iterations + 1

program_main()