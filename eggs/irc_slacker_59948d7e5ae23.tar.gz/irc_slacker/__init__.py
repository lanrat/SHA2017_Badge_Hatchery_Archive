import usocket as socket
import wifi
import time
import badge
import ugfx
import dialogs
import appglue

badge.init()
ugfx.init()
wifi.init()

messages = ['','','','','','','','','','']

while not wifi.sta_if.isconnected():
    time.sleep(0.1)

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"IRC pager","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.flush()

time.sleep(2)

HOST = "chat.freenode.net"
PORT = 6667

NICK = badge.nvs_get_str('owner', 'name', 'Hacker1337')+"_badge"
REALNAME = "SHA2017 badge client"

CHANNEL = badge.nvs_get_str("irc", "channel", "ACKspaceBots")

chan_change = 0
def select_button(pressed):
    global chan_change
    if not pressed:
        print( "change channel" )
        chan_change = 1

def changechan(pressed):
    global CHANNEL
    if not pressed:
        chan = dialogs.prompt_text("Enter channel", CHANNEL)
        if chan != CHANNEL:
            badge.nvs_set_str("irc", "channel", chan)
            CHANNEL = chan  
            return 1
    return 0

def exit_app():
    global s
    # Note: some IRC servers only will display your message after being connected for about 5 minutes
    s.send(bytes("QUIT :%s \r\n" % "Pressed Start", "UTF-8"))
    s.close()
    appglue.home()

def press_a(pressed):
    global s
    if pressed:
        s.send(bytes("PRIVMSG #%s :%s\r\n" % (CHANNEL, "button A: affirmative"), "UTF-8"))
        addMessage( "%s: button A: affirmative" % NICK )

def press_b(pressed):
    global s
    if pressed:
        s.send(bytes("PRIVMSG #%s :%s\r\n" % (CHANNEL, "button B: negative"), "UTF-8"))
        addMessage( "%s: button B: negative" % NICK )

def alert():
    badge.leds_send_data(''.join(['\0\0\0\50' for i in range(6)]))
    badge.vibrator_activate(0b11)
    badge.leds_send_data(''.join(['\0\0\0\0' for i in range(6)]))
    time.sleep(0.5)

def addMessage( message ):
    global messages
    global ugfx
    messages = messages[1:] + [message]
    ugfx.clear(ugfx.WHITE)
    for i, m in enumerate(messages):
        ugfx.string(0,i*12,m,"Roboto_Regular12",ugfx.BLACK)

    # Stolen from Show Nickname 
    enabled = badge.nvs_get_u8("shownick","enable", 0)
    if enabled:
        nick = badge.nvs_get_str("owner", "name", '')
        ugfx.string_box(0,45,296,38, nick, "PermanentMarker36", ugfx.BLACK, ugfx.justifyCenter)

    ugfx.flush()

if CHANNEL != "":
    changechan(0)

ugfx.input_init()

# TODO: make function for attaching events
ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: select_button(pressed))
ugfx.input_attach(ugfx.BTN_START, lambda pressed: exit_app())
ugfx.input_attach(ugfx.BTN_A, lambda pressed: press_a(pressed))
ugfx.input_attach(ugfx.BTN_B, lambda pressed: press_b(pressed))

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"IRC pager","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.string(0,24,"Connecting to %s:%s #%s" % (HOST,PORT,CHANNEL),"Roboto_Regular12",ugfx.BLACK)
ugfx.flush()

s = socket.socket()
s.connect((HOST, PORT))

s.send(bytes("NICK %s\r\n" % NICK, "UTF-8"))
s.send(bytes("USER %s 0 * :%s\r\n" % (NICK, REALNAME), "UTF-8"))
s.send(bytes("JOIN #%s\r\n" % CHANNEL, "UTF-8"));
s.setblocking(False)



while 1:
    if chan_change:
        print( "change channel in loop" )
        chan_change = 0
        chan = CHANNEL
        if changechan(0):
            s.send(bytes("JOIN #%s\r\n" % CHANNEL, "UTF-8"));
            s.send(bytes("PART #%s\r\n" % chan, "UTF-8"));
        # Reapply button binding (they get lost by calling dialog logic?)
        ugfx.input_attach(ugfx.BTN_SELECT, lambda pressed: select_button(pressed))
        ugfx.input_attach(ugfx.BTN_START, lambda pressed: exit_app())
        ugfx.input_attach(ugfx.BTN_A, lambda pressed: press_a(pressed))
        ugfx.input_attach(ugfx.BTN_B, lambda pressed: press_b(pressed))

    line = s.readline()
    if line is not None:
        parts = line.rstrip().split()
        
        if parts:
            if(parts[0] == b"PING"):
                s.send(bytes("PONG %s\r\n" % line[1], "UTF-8"))

            if(parts[1] == b"PRIVMSG"):
                msg = b' '.join(parts[3:])
                rnick = line.split(b'!')[0]

                addMessage( rnick + msg )

                if NICK in msg:
                    alert()
                    alert()

            if(parts[1] == b"JOIN"):
                rnick = line.split(b'!')[0]

                if NICK in rnick:
                    addMessage( b"Joined " + parts[2] )

            if(parts[1] == b"433"):
                NICK = NICK + "^"
                s.send(bytes("NICK %s\r\n" % NICK, "UTF-8"))
                s.send(bytes("USER %s 0 * :%s\r\n" % (NICK, REALNAME), "UTF-8"))
                s.send(bytes("JOIN #%s\r\n" % CHANNEL, "UTF-8"));

            print(line)