import badge
import ugfx

badge.init()
ugfx.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()

ugfx.clear(ugfx.WHITE)
ugfx.string(140, 75, "LED Rainbow","Roboto_BlackItalic24", ugfx.BLACK)
ugfx.flush()

badge.leds_send_data(bytes([
    255, 0, 0, 0,
    0, 255, 0, 0,
    0, 0, 255, 0,
    0, 0, 0, 255,
    255, 255, 255, 0,
    255, 255, 0, 0,
]))
