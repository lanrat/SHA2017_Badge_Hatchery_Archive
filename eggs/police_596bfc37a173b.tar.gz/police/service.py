# Police lights leds service
# Renze Nicolai 2017

import utime, badge, binascii

nyanCnt = 0
nyanLeds = []
nyanEnabled = 0
colorList = []

# This function gets called by the home application at boot
def setup():
    global nyanEnabled
    nyanEnabled = int(badge.nvs_get_str('police', 'state', '0'))
    if (nyanEnabled<1):
        print("[Police lights] Disabled! Please enable in the app!")
    else:
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            badge.leds_enable()
            badge.leds_set_state(bytes([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]))
            print("[Police lights] Leds enabled!")
        else:
            badge.leds_disable()
            print("[Police lights] battery low ("+str(vbatt)+" < 4000)...")
            return False # Do not prevent sleep

def loop(sleepCnt):
    global nyanEnabled
    if (nyanEnabled>0):
        vbatt = badge.battery_volt_sense()
        if (vbatt>4000):
            global nyanCnt
            global brVal
            global colorList
            nyanCnt = nyanCnt + 1
            if nyanCnt >= 1:
                nyanCnt = 0   
            if (nyanCnt==0):
                output = [0,0,nyanEnabled,0]
            else:
                output = [0,nyanEnabled,0,0]
            for i in range(1,5):
                output = output + [0,0,0,0]
            if (nyanCnt==0):    
                output = output + [0,nyanEnabled,0,0]
            else:
                output = output + [0,0,nyanEnabled,0]
            print("[Police lights] Loop ("+str(nyanCnt)+") = ", output)
            badge.leds_set_state(bytes(output))
            return True # Prevent sleep
        else:
            badge.leds_disable()
            print("[Police lights] battery low...")
            return False # Do not prevent sleep
    return False

def draw(x,y):
    # Not drawing anything
    return 0
