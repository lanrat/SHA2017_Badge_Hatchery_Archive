import ugfx, wifi, badge, deepsleep, sys
from time import sleep
import urequests as requests

ugfx.init()

# Make sure WiFi is connected
wifi.init()

def set_message(text):
  ugfx.clear(ugfx.WHITE);
  ugfx.string(10,10,text,"Roboto_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()

set_message("Waiting for wifi...")
  
# Wait for WiFi connection
while not wifi.sta_if.isconnected():
    sleep(0.1)
    pass

set_message("Got wifi loading data")

data=None
try:
  url = "https://poc.sha2017.org/phonebook.csv?limit=1"
  set_message(url)
  r = requests.get(url)
  data = r.text
  r.close()
except Exception as e:
  set_message("Unexpected error: "+str(e))
  sys.exit()

set_message("Got data. Parsing...")

for entry in data.split('\n'):
  extension = entry.split(',')[0]
  name = (entry.split(',')[1]).replace('"', '')
  ugfx.clear()
  ugfx.string(10,10,extension+' -> '+name,"Robot_Regular12", 0)
  ugfx.flush()
  badge.eink_busy_wait()
  sleep(0.5)

ugfx.clear()
ugfx.string(10,10,"End","Robot_Regular12", 0)
ugfx.flush()
badge.eink_busy_wait()
deepsleep.start_sleeping(60000)