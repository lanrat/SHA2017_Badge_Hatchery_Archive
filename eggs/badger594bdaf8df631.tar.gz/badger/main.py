import ugfx, sys

ugfx.init()

for x in range(1, 5):
    ugfx.display_image(0,0,'%s/badger/badger%s.png' % (sys.path[1], x))
    ugfx.flush()