import easyrtc
import ugfx
import badge
import ugfx
import time

badge.init()
ugfx.init()

ugfx.clear(ugfx.WHITE)
ugfx.string(0,0,"A working clock","Roboto_BlackItalic24",ugfx.BLACK)
ugfx.flush()
time.sleep(5)

while True:
    t = easyrtc.string()
    ugfx.string(0, y-12, "Still about %s anyway" % t, "Roboto_Regular12", ugfx.BLACK)
    ugfx.flush()
    time.sleep(60)
