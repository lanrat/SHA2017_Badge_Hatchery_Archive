# Police lights leds service
# Renze Nicolai 2017

import utime, badge, binascii

nyanCnt = 0
nyanLeds = []
nyanEnabled = 0
colorList = []

# This function gets called by the home application at boot
def setup():
    global nyanEnabled
    nyanEnabled = badge.nvs_get_u8('police', 'brightness', 0)
    if (nyanEnabled<1):
        print("[Police lights] Disabled! Please enable in the app!")
    else:
        badge.leds_enable()

def loop():
    global nyanEnabled
    if (nyanEnabled>0):
        global nyanCnt
        global brVal
        global colorList
        
        nyanCnt = nyanCnt + 1
        if nyanCnt > 1:
            nyanCnt = 0   
            
        if (nyanCnt==0):
            output = [0,0,nyanEnabled,0]
        else:
            output = [0,nyanEnabled,0,0]
        for i in range(1,5):
            output = output + [0,0,0,0]
        if (nyanCnt==0):    
            output = output + [0,nyanEnabled,0,0]
        else:
            output = output + [0,0,nyanEnabled,0]
        print("[Police lights] Loop ("+str(nyanCnt)+") = ", output)
        badge.leds_send_data(bytes(output),24)
        return badge.nvs_get_u8('police', 'delay', 100)
    return 0

def draw(x,y):
    # Not drawing anything
    return 0
