import badge
import ugfx
import time
from random import randint
import appglue

badge.init()
ugfx.input_init()
badge.leds_init()
badge.leds_enable()
ugfx.LUT_FULL
ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.input_init()
ugfx.init()

def home(pressed):
    if (pressed):
        appglue.start_app("")
    
def buzz(pressed):
  if pressed:
	badge.vibrator_activate(0xFF)

def rood(pressed):
  offset = 0
  if pressed:
    red = bytes([0, brightness, 0, 0])
    rainbow = [red, red, red, red, red, red]
    values = bytes()
    for i in range(6):
        i += offset
        if i > 5:
            i -= 6
        values += rainbow[i]
    badge.leds_send_data(values)
    time.sleep(1)

def brighter(pushed):
    if(pushed):
        global brightness
        brightness += 20
        if brightness > 255:
            brightness = 255
        rood

def dimmer(pushed):
    if(pushed):
        global brightness
        brightness -= 20
        if brightness < 20:
            brightness = 20
        rood
        
ugfx.input_attach(ugfx.JOY_RIGHT, buzz)
ugfx.input_attach(ugfx.JOY_LEFT, buzz)
ugfx.input_attach(ugfx.JOY_UP, brighter)
ugfx.input_attach(ugfx.JOY_DOWN, dimmer)
ugfx.input_attach(ugfx.JOY_RIGHT, buzz)
ugfx.input_attach(ugfx.BTN_A, rood)
ugfx.input_attach(ugfx.BTN_B, home)
ugfx.input_attach(ugfx.BTN_START, buzz)
ugfx.input_attach(ugfx.BTN_SELECT, buzz)

ugfx.string_box(0,10,296,26, "Mozolightplay", "Roboto_BlackItalic24", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,30,296,26, "Druk op [B] om deze app te verlaten", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,40,296,26, "Press [B] to exit this app", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,50,296,26, "bekijk onze website", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,60,296,26, "Check out our website", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.string_box(0,70,296,26, "http://www.imozocom.jouwweb.nl/", "Roboto_BlackItalic20", ugfx.BLACK, ugfx.justifyLeft)
ugfx.flush()
badge.eink_png(245,73,'/lib/mozolightplay/mozo.png')

leds_array = bytes(24)

while True:
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[4:] + bytes([randint(128, 255), randint(0, 255), randint(0, 128), 0])
	badge.leds_send_data(leds_array)
	time.sleep(0.1)
	leds_array = leds_array[4:] + bytes([randint(0, 128), randint(0, 255), randint(128, 255), 0])