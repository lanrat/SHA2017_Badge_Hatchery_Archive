html = """<!DOCTYPE html>
<html>
    <head> <title>ESP8266 Pins</title> </head>
    <body> <h1>Post hier je tekst naartoe!</h1>
    <form method='post'>
    <input type='text' name='textpost'/>
    <input type='submit' value='submit'/>
    </form>
    </body>
</html>
"""

search = "textpost"
import badge
import ugfx



import network
ap_if = network.WLAN(network.AP_IF)
ap_if.active(True)
print (ap_if.ifconfig())
import socket
addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]



s = socket.socket()
s.bind(addr)
s.listen(1)

print('listening on', addr)



while True:
    cl, addr = s.accept()
    stringvar = cl.recv(10240)
    index = len(search)
    for line in stringvar.splitlines():
        print (line[0:index])
        if search in line[0:index]:
            printvalue = line[index+1:]
            print (printvalue)
            badge.init()
            ugfx.init()
            ugfx.init()
            ugfx.clear(ugfx.BLACK)
            ugfx.string(130, 50, printvalue, "PermanentMarker22", ugfx.WHITE)
            ugfx.flush()
    print('client connected from', addr)
    cl.send(html)
    cl.close()