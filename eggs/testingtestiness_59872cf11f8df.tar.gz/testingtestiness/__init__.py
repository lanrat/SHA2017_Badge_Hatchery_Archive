import ugfx, gc, badge, deepsleep, machine
from time import *

# Set up starting up screen
ugfx.init()
badge.init()
ugfx.input_init()
apressed = False

ugfx.input_attach(ugfx.BTN_A, lambda pressed: pressing(pressed))

def pressing(pressed):
    global apressed
    apressed = pressed

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()

ugfx.string(10, 10, "Go to the Torvalds field for further instructions.", "Roboto_Regular12", 0)
ugfx.string(10, 25, "Bring your laptop.", "Roboto_Regular12", 0)

ugfx.flush()

sleep(2)

while not apressed:
    sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(10, 10, "Connect with: NW-challenge", "Roboto_Regular12", 0)
ugfx.string(10, 25, "With password: Northwave Treintjes", "Roboto_Regular12", 0)
ugfx.flush()

sleep(2)

while not apressed:
    sleep(0.1)

ugfx.clear(ugfx.BLACK)
ugfx.flush()
ugfx.clear(ugfx.WHITE)
ugfx.flush()
ugfx.string(10, 10, "Enter the Northwave tent for further instructions.", "Roboto_Regular12", 0)
ugfx.flush()

sleep(2)

while not apressed:
    sleep(0.1)

badge.eink_busy_wait()

machine.deepsleep(1)