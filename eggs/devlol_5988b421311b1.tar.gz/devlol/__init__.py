#hi there, it looks like u r one of the smart ppl here. got locked out? we will ofc save ur ass for free

#^^^^^
#^^^^
#^^^
#^^
#^
import ugfx, badge, appglue

ugfx.init()
ugfx.clear(ugfx.BLACK)
ugfx.string(20, 40, "Redirecting to home...", 'Roboto_BlackItalic24', ugfx.WHITE)
ugfx.flush()

badge.init()
appglue.start_app("")